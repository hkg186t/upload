package com.ofss.digx.framework.domain.transaction;

import com.ofss.digx.datatype.CurrencyAmount;

import javax.persistence.Column;
import javax.persistence.Embedded;
import javax.persistence.Entity;
import javax.persistence.DiscriminatorValue;
import javax.persistence.Cacheable;
import javax.persistence.Table;
import java.time.LocalDate;

@Entity
@DiscriminatorValue("AM")
@Cacheable(false)
public class AmountTransaction extends Transaction {

    @Embedded
    private CurrencyAmount amount;

    @Column(name = "VALUE_DATE")
    private LocalDate valueDate;

    public AmountTransaction() {
        super();
    }

    public CurrencyAmount getAmount() {
        return amount;
    }

    public void setAmount(CurrencyAmount amount) {
        this.amount = amount;
    }

    public LocalDate getValueDate() {
        return valueDate;
    }

    public void setValueDate(LocalDate valueDate) {
        this.valueDate = valueDate;
    }
}


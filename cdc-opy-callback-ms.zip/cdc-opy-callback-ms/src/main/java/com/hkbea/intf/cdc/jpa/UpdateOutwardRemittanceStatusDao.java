package com.hkbea.intf.cdc.jpa;



import com.hkbea.microservice.cdc.approvalcenter.model.OutwardRemittanceStatusInfo;

import java.util.Map;

public interface UpdateOutwardRemittanceStatusDao {
    int updateOutwardRemittanceStatus(OutwardRemittanceStatusInfo outwardRemittanceStatusInfo);
    int insertOutwardRemittanceResult(OutwardRemittanceStatusInfo outwardRemittanceStatusInfo);
    Map<String,String> selectLMTxnReqByLmApTxn(OutwardRemittanceStatusInfo outwardRemittanceStatusInfo);
    int updateCdcLmTxnReqField(Map<String,Object> paramMap);
    int updateCdcLmTxnHistField(Map<String,String> paramMap);
    int updateCdcLmTxnHistSummaryField(Map<String,Object> paramMap);
}

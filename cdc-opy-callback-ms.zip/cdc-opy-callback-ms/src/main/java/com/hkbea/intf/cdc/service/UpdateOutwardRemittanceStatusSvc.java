package com.hkbea.intf.cdc.service;

import com.hkbea.microservice.cdc.approvalcenter.api.ApiException;
import com.hkbea.microservice.cdc.approvalcenter.model.OutwardRemittanceStatusInfo;


public interface UpdateOutwardRemittanceStatusSvc {
    public void checkTransactionInfoValid(OutwardRemittanceStatusInfo outwardRemittanceStatusInfo) throws ApiException;
    public int updateOutwardRemittanceStatus(OutwardRemittanceStatusInfo outwardRemittanceStatusInfo) throws ApiException;
    public void recordOutwardRemittanceInfo(OutwardRemittanceStatusInfo outwardRemittanceStatusInfo) throws ApiException;
    public void updateLMRelatedTable(OutwardRemittanceStatusInfo outwardRemittanceStatusInfo) throws ApiException;
}

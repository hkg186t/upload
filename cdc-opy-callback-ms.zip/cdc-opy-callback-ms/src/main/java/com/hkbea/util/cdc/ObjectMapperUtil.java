package com.hkbea.util.cdc;

import com.fasterxml.jackson.annotation.JsonAutoDetect;
import com.fasterxml.jackson.annotation.PropertyAccessor;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.datatype.jdk8.Jdk8Module;
import com.fasterxml.jackson.datatype.joda.JodaModule;
import org.apache.commons.lang3.StringUtils;

import java.io.IOException;
import java.io.InputStream;

public class ObjectMapperUtil {
    private static ObjectMapper _objectMapper;

    static {
        _objectMapper = createObjectMapper ();
    }

    static private ObjectMapper createObjectMapper () {
        ObjectMapper objectMapper = new ObjectMapper ();
        objectMapper.registerModule(new Jdk8Module() );
        objectMapper.registerModule(new JodaModule() );
        objectMapper.setVisibility(PropertyAccessor.FIELD, JsonAutoDetect.Visibility.ANY);
        objectMapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);

        return objectMapper;
    }

    static public ObjectMapper getObjectMapper () {
        return _objectMapper;
    }

    static public <T> T readValue(String content, Class<T> valueType)
    {
        try {
            return _objectMapper.readValue(content, valueType);
        } catch (IOException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
            return null;
        }
    }

    static public <T> T readValue(InputStream src, Class<T> valueType)
    {
        try {
            return _objectMapper.readValue(src, valueType);
        } catch (IOException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
            return null;
        }
    }

    /**
     * @param value
     * @return
     * @see com.fasterxml.jackson.databind.ObjectMapper#writeValueAsString(java.lang.Object)
     */
    static public String writeValueAsString(Object value)  {
        try {
            return _objectMapper.writeValueAsString(value);
        } catch (JsonProcessingException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
            return StringUtils.EMPTY;
        }
    }

    static public <T> T deepCopy ( Object src, Class<T> dstClz ) {
        try {

            return _objectMapper.readValue(_objectMapper.writeValueAsString(src), dstClz);
        } catch (Exception e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
            return null;
        }
//		return _objectMapper.convertValue(src, dstClz );

    }
}

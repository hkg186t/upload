package com.hkbea.microservice.cdc.approvalcenter.bean;

import javax.persistence.Column;
import javax.persistence.Embeddable;
import java.io.Serializable;

@Embeddable
public class TransactionApprovalDetails implements Serializable {

    @Column(name = "APPR_REMARKS")
    private String remarks;

    @Column(name = "APPR_STEP_NO")
    private Integer stepNo;

    @Column(name = "APPR_STATUS")
    private String status;

    @Column(name = "SIGNED_BY")
    private String signedBy;

    @Column(name = "APPR_ACTION")
    private String action;

    @Column(name = "APPROVAL_TYPE")
    private String approvalType;

    public TransactionApprovalDetails() {
    }

    public String getRemarks() {
        return remarks;
    }

    public void setRemarks(String remarks) {
        this.remarks = remarks;
    }

    public Integer getStepNo() {
        return stepNo;
    }

    public void setStepNo(Integer stepNo) {
        this.stepNo = stepNo;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getSignedBy() {
        return signedBy;
    }

    public void setSignedBy(String signedBy) {
        this.signedBy = signedBy;
    }

    public String getAction() {
        return action;
    }

    public void setAction(String action) {
        this.action = action;
    }

    public String getApprovalType() {
        return approvalType;
    }

    public void setApprovalType(String approvalType) {
        this.approvalType = approvalType;
    }
}


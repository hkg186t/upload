package com.hkbea.microservice.cdc.approvalcenter.bean;

import com.ofss.digx.framework.domain.transaction.Transaction;

import javax.persistence.*;
import java.io.Serializable;
import java.time.LocalDateTime;

@Entity
@Table(name = "DIGX_AP_TXN_WORKFLOW_SNAPSHOT")
public class TransactionWorkflowSnapshot implements Serializable {

    @EmbeddedId
    private TransactionWorkflowSnapshotKey key;

    @Column(name = "LAST_UPDATED_BY")
    private String lastUpdatedBy;

    @Column(name = "CREATED_BY", updatable = false)
    private String createdBy;

    @Column(name = "WORKFLOW_ID")
    private String workflowId;

    @Column(name = "STEP_NO")
    private Integer stepNo;

    @Column(name = "CREATION_DATE")
    private LocalDateTime creationDate;

    @Column(name = "LAST_UPDATED_DATE")
    private LocalDateTime lastUpdatedDate;

    @Column(name = "object_status")
    private String entityStatus;

    @Version
    @Column(name = "OBJECT_VERSION_NUMBER")
    private Integer version;

    @ManyToOne
    @JoinColumn(name = "TXN_ID", referencedColumnName = "TXN_ID")
    private Transaction transaction;

    @Embedded
    private WorkflowStep workflowStep;

    public TransactionWorkflowSnapshot() {
    }

    // Getters and setters

    public TransactionWorkflowSnapshotKey getKey() {
        return key;
    }

    public void setKey(TransactionWorkflowSnapshotKey key) {
        this.key = key;
    }

    public String getLastUpdatedBy() {
        return lastUpdatedBy;
    }

    public void setLastUpdatedBy(String lastUpdatedBy) {
        this.lastUpdatedBy = lastUpdatedBy;
    }

    public String getCreatedBy() {
        return createdBy;
    }

    public void setCreatedBy(String createdBy) {
        this.createdBy = createdBy;
    }

    public String getWorkflowId() {
        return workflowId;
    }

    public void setWorkflowId(String workflowId) {
        this.workflowId = workflowId;
    }

    public Integer getStepNo() {
        return stepNo;
    }

    public void setStepNo(Integer stepNo) {
        this.stepNo = stepNo;
    }

    public LocalDateTime getCreationDate() {
        return creationDate;
    }

    public void setCreationDate(LocalDateTime creationDate) {
        this.creationDate = creationDate;
    }

    public LocalDateTime getLastUpdatedDate() {
        return lastUpdatedDate;
    }

    public void setLastUpdatedDate(LocalDateTime lastUpdatedDate) {
        this.lastUpdatedDate = lastUpdatedDate;
    }

    public String getEntityStatus() {
        return entityStatus;
    }

    public void setEntityStatus(String entityStatus) {
        this.entityStatus = entityStatus;
    }

    public Integer getVersion() {
        return version;
    }

    public void setVersion(Integer version) {
        this.version = version;
    }

    public Transaction getTransaction() {
        return transaction;
    }

    public void setTransaction(Transaction transaction) {
        this.transaction = transaction;
    }

    public WorkflowStep getWorkflowStep() {
        return workflowStep;
    }

    public void setWorkflowStep(WorkflowStep workflowStep) {
        this.workflowStep = workflowStep;
    }
}


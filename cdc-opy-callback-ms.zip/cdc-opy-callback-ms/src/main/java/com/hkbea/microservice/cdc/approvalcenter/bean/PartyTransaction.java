package com.hkbea.microservice.cdc.approvalcenter.bean;

import javax.persistence.*;

@Entity
@DiscriminatorValue("P")
@Cacheable(false)
public class PartyTransaction extends Transaction {

    @Column(name = "PARTY_ID")
    private String partyId;

    @Embedded
    @AttributeOverrides({
            @AttributeOverride(name = "firstName", column = @Column(name = "PARTY_FIRST_NAME")),
            @AttributeOverride(name = "middleName", column = @Column(name = "PARTY_MIDDLE_NAME")),
            @AttributeOverride(name = "lastName", column = @Column(name = "PARTY_LAST_NAME")),
            @AttributeOverride(name = "salutation", column = @Column(name = "PARTY_SALUTATION")),
            @AttributeOverride(name = "fullName", column = @Column(name = "PARTY_FULL_NAME"))
    })
    private PartyName partyName;

    public PartyTransaction() {
        super();
    }

    public String getPartyId() {
        return partyId;
    }

    public void setPartyId(String partyId) {
        this.partyId = partyId;
    }

    public PartyName getPartyName() {
        return partyName;
    }

    public void setPartyName(PartyName partyName) {
        this.partyName = partyName;
    }
}


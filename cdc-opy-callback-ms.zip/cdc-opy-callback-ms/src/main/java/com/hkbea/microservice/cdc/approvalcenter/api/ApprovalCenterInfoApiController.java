package com.hkbea.microservice.cdc.approvalcenter.api;


import com.hkbea.intf.cdc.service.UpdateOutwardRemittanceStatusSvc;
import com.hkbea.microservice.cdc.approvalcenter.model.BaseResponseResult;
import com.hkbea.microservice.cdc.approvalcenter.model.OutwardRemittanceStatusInfo;
import com.hkbea.util.cdc.ObjectMapperUtil;
import com.hkbea.util.xaa.log.Logger;
import com.hkbea.util.xaa.log.LoggerManager;
import io.swagger.annotations.ApiParam;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;

@Controller
public class ApprovalCenterInfoApiController implements ApprovalCenterInfoApi {
    private static final Logger logger = LoggerManager.getLogger(ApprovalCenterInfoApiController.class);

    @Autowired
    private UpdateOutwardRemittanceStatusSvc updateOutwardRemittanceStatusSvc;

    @Override
    public ResponseEntity<BaseResponseResult> approve(
            @ApiParam(value = "Transaction ID", required = true) @PathVariable("txn_id") String txnId,
            @Valid @RequestBody ApprovalRequest request) {
        logger.info("ApprovalCenter /{}/approve request= {}", txnId, ObjectMapperUtil.writeValueAsString(request));

        try {
            BaseResponseResult bresp = new BaseResponseResult();
            //update status
            logger.info("Controller updateOutwardRemittanceStatus start");
            int updateCount = updateOutwardRemittanceStatusSvc.updateOutwardRemittanceStatus(outwardRemittanceStatusInfoRequest);
            logger.info("Controller updateOutwardRemittanceStatus end");
            //Record Outward Remittance information into the table DIGX_CZ_OPY_CALLBACK.
            logger.info("Controller Record Outward Remittance information into the table DIGX_CZ_OPY_CALLBACK. start");
            updateOutwardRemittanceStatusSvc.recordOutwardRemittanceInfo(outwardRemittanceStatusInfoRequest);
            logger.info("Controller Record Outward Remittance information into the table DIGX_CZ_OPY_CALLBACK. end");
            if (updateCount > 0) {
                logger.info("Controller updateOutwardRemittanceStatus exit data And update DIGX_CZ_PY_NWPAYMENT_PAYOUT Success");
                return new ResponseEntity<BaseResponseResult>(bresp, HttpStatus.OK);
            } else {
                //find in LM Table info and update related table.
                logger.info("Controller updateLMRelatedTable  start");
                updateOutwardRemittanceStatusSvc.updateLMRelatedTable(outwardRemittanceStatusInfoRequest);
                logger.info("Controller updateLMRelatedTable  end");
            }
            logger.info("update outwardRemittance status response: {}", ObjectMapperUtil.writeValueAsString(bresp));
            return new ResponseEntity<BaseResponseResult>(bresp, HttpStatus.OK);
        } catch (ApiException e) {
            logger.info("Controller ApiException code {} and ApiException Msg {}", e.getCode(),e.getMsg());
            BaseResponseResult bresp = new BaseResponseResult();
            bresp.setCode(e.getCode());
            bresp.setDetail(e.getMsg());

            if (logger.isDebugEnabled()) {
                logger.debug("update outwardRemittance status response exception: {}", ObjectMapperUtil.writeValueAsString(bresp));
            }
            return new ResponseEntity<BaseResponseResult>(bresp, HttpStatus.OK);
        }
    }
}


package com.hkbea.microservice.cdc.approvalcenter.bean;

import javax.persistence.Column;
import javax.persistence.Embeddable;
import java.io.Serializable;

@Embeddable
public class ProcessingDetails implements Serializable {

    @Column(name = "PROCESSING_CURRENT_STEP")
    private String currentStep;

    @Column(name = "PROCESSING_STATUS")
    private String status;

    @Column(name = "PROCESSING_ERROR_CODE")
    private String errorCode;

    @Column(name = "PROCESSING_ERROR_MESSAGE")
    private String errorMessage;

    @Column(name = "PROCESSING_REFNO")
    private String referenceNumber;

    public ProcessingDetails() {
    }

    public String getCurrentStep() {
        return currentStep;
    }

    public void setCurrentStep(String currentStep) {
        this.currentStep = currentStep;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getErrorCode() {
        return errorCode;
    }

    public void setErrorCode(String errorCode) {
        this.errorCode = errorCode;
    }

    public String getErrorMessage() {
        return errorMessage;
    }

    public void setErrorMessage(String errorMessage) {
        this.errorMessage = errorMessage;
    }

    public String getReferenceNumber() {
        return referenceNumber;
    }

    public void setReferenceNumber(String referenceNumber) {
        this.referenceNumber = referenceNumber;
    }
}


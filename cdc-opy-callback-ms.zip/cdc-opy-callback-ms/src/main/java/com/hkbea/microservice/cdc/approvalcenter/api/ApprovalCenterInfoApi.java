package com.hkbea.microservice.cdc.approvalcenter.api;

import com.hkbea.microservice.cdc.approvalcenter.model.BaseResponseResult;
import com.hkbea.microservice.cdc.approvalcenter.model.ApprovalRequest;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import jakarta.validation.Valid;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

@Api(value = "ApprovalCenter",tags = "Approval Center")
public interface ApprovalCenterInfoApi {
    @ApiOperation(value = "Approve Single Transaction", notes = "", response = BaseResponseResult.class, tags={ "approve", })
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "successful operation"),
            @ApiResponse(responseCode = "400", description = "Bad request"),
            @ApiResponse(responseCode = "405", description = "Method not allowed"),
            @ApiResponse(responseCode = "500", description = "Unexpected Error") })
    @RequestMapping(value = "/approvalCenter/transaction/{txn_id}/approve",
            produces = { "application/json" },
            consumes = { "application/json" },
            method = RequestMethod.POST)
    ResponseEntity<BaseResponseResult> approve(
            @ApiParam(value = "Transaction ID", required = true) @PathVariable("txn_id") String txnId,
            @Valid @RequestBody ApprovalRequest request);
}

package com.hkbea.microservice.ich.cdc;

import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.ExitCodeGenerator;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.data.mongo.MongoDataAutoConfiguration;
import org.springframework.boot.autoconfigure.mongo.MongoAutoConfiguration;
import org.springframework.boot.autoconfigure.transaction.TransactionAutoConfiguration;
import org.springframework.boot.builder.SpringApplicationBuilder;
import org.springframework.boot.web.servlet.support.SpringBootServletInitializer;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.ImportResource;

@SpringBootApplication(exclude = { MongoAutoConfiguration.class, MongoDataAutoConfiguration.class, TransactionAutoConfiguration.class })
@ComponentScan(basePackages = {
        "com.hkbea.microservice.ich",
        "com.hkbea.util",
        "com.hkbea.microservice.xaa",
        "com.hkbea.microservice.*.xaa",
        "com.hkbea.dao.xsa.admin",
        "com.hkbea.config.cdc",
        "com.hkbea.dao.cdc",
        "com.hkbea.service.cdc",
        "com.hkbea.microservice.cdc.approvalcenter",
        "com.hkbea.microservice.cdc.approvalcenter.api",
        "com.hkbea.microservice.cdc.approvalcenter.configuration",
})
@ImportResource("classpath*:com/hkbea/applicationContext.xml")
public class Swagger2SpringBoot extends SpringBootServletInitializer implements CommandLineRunner {

    @Override
    public void run(String... arg0) throws Exception {
        if (arg0.length > 0 && arg0[0].equals("exitcode")) {
            throw new ExitException();
        }
    }

    public static void main(String[] args) throws Exception {
        SpringApplication.run(Swagger2SpringBoot.class, args);
    }

    public Swagger2SpringBoot(){
        super();
        setRegisterErrorPageFilter(false);//close error page
    }
    
    @Override
   	protected SpringApplicationBuilder configure(SpringApplicationBuilder application) {
   		return application.sources(Swagger2SpringBoot.class);
   	}

    class ExitException extends RuntimeException implements ExitCodeGenerator {
        private static final long serialVersionUID = 1L;

        @Override
        public int getExitCode() {
            return 10;
        }

    }
}

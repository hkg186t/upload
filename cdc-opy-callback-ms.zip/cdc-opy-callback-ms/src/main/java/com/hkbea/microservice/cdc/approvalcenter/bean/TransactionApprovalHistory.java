package com.hkbea.microservice.cdc.approvalcenter.bean;

import javax.persistence.Column;
import javax.persistence.Embeddable;
import javax.persistence.Embedded;
import java.io.Serializable;
import java.time.LocalDateTime;

@Embeddable
public class TransactionApprovalHistory implements Serializable {

    // existing approvalDetails flat fields (keep them)
    @Column(name = "REMARKS")
    private String remarks;

    @Column(name = "STEP_NO")
    private Integer stepNo;

    @Column(name = "STATUS")
    private String status;

    @Column(name = "ACTION")
    private String action;

    @Column(name = "SIGNED_BY")
    private String signedBy;

    // existing processingDetails flat fields (keep them)
    @Column(name = "PROCESSING_CURRENT_STEP")
    private String processingCurrentStep;

    @Column(name = "PROCESSING_STATUS")
    private String processingStatus;

    @Column(name = "PROCESSING_ERROR_CODE")
    private String processingErrorCode;

    @Column(name = "PROCESSING_ERROR_MESSAGE")
    private String processingErrorMessage;

    @Column(name = "PROCESSING_REFNO")
    private String processingReferenceNumber;

    // existing updatedByDetails flat fields (keep them)
    @Column(name = "UPDATER_TITLE")
    private String updaterTitle;

    @Column(name = "UPDATER_FIRST_NAME")
    private String updaterFirstName;

    @Column(name = "UPDATER_MIDDLE_NAME")
    private String updaterMiddleName;

    @Column(name = "UPDATER_LAST_NAME")
    private String updaterLastName;

    @Column(name = "UPDATER_EMAIL_ID")
    private String updaterEmailId;

    @Column(name = "UPDATER_MOBILE_NO")
    private String updaterMobileNo;

    @Column(name = "UPDATER_PHONE_NO")
    private String updaterPhoneNo;

    // --- New fields from provided XML (added, existing fields kept) ---

    @Embedded
    private TransactionApprovalDetails approvalDetails;

    @Embedded
    private ProcessingDetails processingDetails;

    @Embedded
    private TransactionUserDetails updatedByDetails;

    @Column(name = "LAST_UPDATED_BY")
    private String lastUpdatedBy;

    @Column(name = "CREATED_BY", updatable = false)
    private String createdBy;

    @Column(name = "CREATION_DATE")
    private LocalDateTime creationDate;

    @Column(name = "LAST_UPDATED_DATE")
    private LocalDateTime lastUpdatedDate;

    public TransactionApprovalHistory() {
    }

    // Getters and setters for existing fields

    public String getRemarks() {
        return remarks;
    }

    public void setRemarks(String remarks) {
        this.remarks = remarks;
    }

    public Integer getStepNo() {
        return stepNo;
    }

    public void setStepNo(Integer stepNo) {
        this.stepNo = stepNo;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getAction() {
        return action;
    }

    public void setAction(String action) {
        this.action = action;
    }

    public String getSignedBy() {
        return signedBy;
    }

    public void setSignedBy(String signedBy) {
        this.signedBy = signedBy;
    }

    public String getProcessingCurrentStep() {
        return processingCurrentStep;
    }

    public void setProcessingCurrentStep(String processingCurrentStep) {
        this.processingCurrentStep = processingCurrentStep;
    }

    public String getProcessingStatus() {
        return processingStatus;
    }

    public void setProcessingStatus(String processingStatus) {
        this.processingStatus = processingStatus;
    }

    public String getProcessingErrorCode() {
        return processingErrorCode;
    }

    public void setProcessingErrorCode(String processingErrorCode) {
        this.processingErrorCode = processingErrorCode;
    }

    public String getProcessingErrorMessage() {
        return processingErrorMessage;
    }

    public void setProcessingErrorMessage(String processingErrorMessage) {
        this.processingErrorMessage = processingErrorMessage;
    }

    public String getProcessingReferenceNumber() {
        return processingReferenceNumber;
    }

    public void setProcessingReferenceNumber(String processingReferenceNumber) {
        this.processingReferenceNumber = processingReferenceNumber;
    }

    public String getUpdaterTitle() {
        return updaterTitle;
    }

    public void setUpdaterTitle(String updaterTitle) {
        this.updaterTitle = updaterTitle;
    }

    public String getUpdaterFirstName() {
        return updaterFirstName;
    }

    public void setUpdaterFirstName(String updaterFirstName) {
        this.updaterFirstName = updaterFirstName;
    }

    public String getUpdaterMiddleName() {
        return updaterMiddleName;
    }

    public void setUpdaterMiddleName(String updaterMiddleName) {
        this.updaterMiddleName = updaterMiddleName;
    }

    public String getUpdaterLastName() {
        return updaterLastName;
    }

    public void setUpdaterLastName(String updaterLastName) {
        this.updaterLastName = updaterLastName;
    }

    public String getUpdaterEmailId() {
        return updaterEmailId;
    }

    public void setUpdaterEmailId(String updaterEmailId) {
        this.updaterEmailId = updaterEmailId;
    }

    public String getUpdaterMobileNo() {
        return updaterMobileNo;
    }

    public void setUpdaterMobileNo(String updaterMobileNo) {
        this.updaterMobileNo = updaterMobileNo;
    }

    public String getUpdaterPhoneNo() {
        return updaterPhoneNo;
    }

    public void setUpdaterPhoneNo(String updaterPhoneNo) {
        this.updaterPhoneNo = updaterPhoneNo;
    }

    // Getters and setters for new embedded fields

    public TransactionApprovalDetails getApprovalDetails() {
        return approvalDetails;
    }

    public void setApprovalDetails(TransactionApprovalDetails approvalDetails) {
        this.approvalDetails = approvalDetails;
    }

    public ProcessingDetails getProcessingDetails() {
        return processingDetails;
    }

    public void setProcessingDetails(ProcessingDetails processingDetails) {
        this.processingDetails = processingDetails;
    }

    public TransactionUserDetails getUpdatedByDetails() {
        return updatedByDetails;
    }

    public void setUpdatedByDetails(TransactionUserDetails updatedByDetails) {
        this.updatedByDetails = updatedByDetails;
    }

    public String getLastUpdatedBy() {
        return lastUpdatedBy;
    }

    public void setLastUpdatedBy(String lastUpdatedBy) {
        this.lastUpdatedBy = lastUpdatedBy;
    }

    public String getCreatedBy() {
        return createdBy;
    }

    public void setCreatedBy(String createdBy) {
        this.createdBy = createdBy;
    }

    public LocalDateTime getCreationDate() {
        return creationDate;
    }

    public void setCreationDate(LocalDateTime creationDate) {
        this.creationDate = creationDate;
    }

    public LocalDateTime getLastUpdatedDate() {
        return lastUpdatedDate;
    }

    public void setLastUpdatedDate(LocalDateTime lastUpdatedDate) {
        this.lastUpdatedDate = lastUpdatedDate;
    }
}

package com.hkbea.microservice.cdc.approvalcenter.bean;

import com.ofss.digx.domain.approval.entity.transaction.checkerdetails.ApprovalCheckerDetailsKey;
import com.ofss.digx.framework.domain.transaction.Transaction;

import javax.persistence.*;
import java.io.Serializable;
import java.time.LocalDateTime;

@Entity
@Table(name = "DIGX_AP_CHECKER_DETAILS")
public class ApprovalCheckerDetails implements Serializable {

    @EmbeddedId
    private ApprovalCheckerDetailsKey key;

    @Column(name = "SNAPSHOT_ID")
    private String transactionWorkflowSnapshot;

    @ManyToOne
    @JoinColumn(name = "TXN_ID", referencedColumnName = "TXN_ID")
    private Transaction transaction;

    @Column(name = "STEP_NO")
    private Integer stepNo;

    @Column(name = "USER_NAME")
    private String userName;

    @Column(name = "LAST_UPDATED_BY")
    private String lastUpdatedBy;

    @Column(name = "CREATED_BY")
    private String createdBy;

    @Column(name = "CREATION_DATE")
    private LocalDateTime creationDate;

    @Column(name = "LAST_UPDATED_DATE")
    private LocalDateTime lastUpdatedDate;

    @Column(name = "MAX_APPROVAL_DATE")
    private LocalDateTime maxApprovalDate;

    public ApprovalCheckerDetails() {
    }

    // Getters and setters

    public ApprovalCheckerDetailsKey getKey() {
        return key;
    }

    public void setKey(ApprovalCheckerDetailsKey key) {
        this.key = key;
    }

    public String getTransactionWorkflowSnapshot() {
        return transactionWorkflowSnapshot;
    }

    public void setTransactionWorkflowSnapshot(String transactionWorkflowSnapshot) {
        this.transactionWorkflowSnapshot = transactionWorkflowSnapshot;
    }

    public Transaction getTransaction() {
        return transaction;
    }

    public void setTransaction(Transaction transaction) {
        this.transaction = transaction;
    }

    public Integer getStepNo() {
        return stepNo;
    }

    public void setStepNo(Integer stepNo) {
        this.stepNo = stepNo;
    }

    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public String getLastUpdatedBy() {
        return lastUpdatedBy;
    }

    public void setLastUpdatedBy(String lastUpdatedBy) {
        this.lastUpdatedBy = lastUpdatedBy;
    }

    public String getCreatedBy() {
        return createdBy;
    }

    public void setCreatedBy(String createdBy) {
        this.createdBy = createdBy;
    }

    public LocalDateTime getCreationDate() {
        return creationDate;
    }

    public void setCreationDate(LocalDateTime creationDate) {
        this.creationDate = creationDate;
    }

    public LocalDateTime getLastUpdatedDate() {
        return lastUpdatedDate;
    }

    public void setLastUpdatedDate(LocalDateTime lastUpdatedDate) {
        this.lastUpdatedDate = lastUpdatedDate;
    }

    public LocalDateTime getMaxApprovalDate() {
        return maxApprovalDate;
    }

    public void setMaxApprovalDate(LocalDateTime maxApprovalDate) {
        this.maxApprovalDate = maxApprovalDate;
    }
}


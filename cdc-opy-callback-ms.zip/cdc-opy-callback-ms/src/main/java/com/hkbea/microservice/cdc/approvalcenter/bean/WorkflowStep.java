package com.hkbea.microservice.cdc.approvalcenter.bean;

import javax.persistence.*;
import java.io.Serializable;

@Embeddable
public class WorkflowStep implements Serializable {

    @Column(name = "SEQUENCE_NO")
    private Integer sequenceNo;

    @ManyToOne
    @JoinColumn(name = "USERGROUP_ID", referencedColumnName = "ID")
    private UserGroup userGroup;

    public WorkflowStep() {
    }

    public Integer getSequenceNo() {
        return sequenceNo;
    }

    public void setSequenceNo(Integer sequenceNo) {
        this.sequenceNo = sequenceNo;
    }

    public UserGroup getUserGroup() {
        return userGroup;
    }

    public void setUserGroup(UserGroup userGroup) {
        this.userGroup = userGroup;
    }
}


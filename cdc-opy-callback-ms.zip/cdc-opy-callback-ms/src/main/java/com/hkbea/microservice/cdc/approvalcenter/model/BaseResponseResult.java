package com.hkbea.microservice.cdc.approvalcenter.model;

import com.fasterxml.jackson.annotation.JsonProperty;
import io.swagger.annotations.ApiModelProperty;

import java.io.Serializable;
import java.util.Objects;

/**
 * BaseResponseResult
 */
public class BaseResponseResult implements Serializable {

    private static final long serialVersionUID = 1L;

    @JsonProperty("code")
    private String code = null;

    @JsonProperty("message")
    private String detail = null;

    public BaseResponseResult() {
        this.code= "";
        this.detail = "";
    }

    /**
     * The error code
     * @return code
     **/
    @ApiModelProperty(value = "The error code")
    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }


    /**
     * The description for the error
     * @return message
     **/
    @ApiModelProperty(value = "The description for the error")


    public String getDetail() {
        return detail;
    }

    public void setDetail(String detail) {
        this.detail = detail;
    }



    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }
        BaseResponseResult baseResponseResult = (BaseResponseResult) o;
        return Objects.equals(this.code, baseResponseResult.code) &&
                Objects.equals(this.detail, baseResponseResult.detail);
    }

    @Override
    public int hashCode() {
        return Objects.hash(code, detail);
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append("class BaseResponseResult {\n");
        sb.append("    code: ").append(toIndentedString(code)).append("\n");
        sb.append("    message: ").append(toIndentedString(detail)).append("\n");
        sb.append("}");
        return sb.toString();
    }

    /**
     * Convert the given object to string with each line indented by 4 spaces
     * (except the first line).
     */
    private String toIndentedString(Object o) {
        if (o == null) {
            return "null";
        }
        return o.toString().replace("\n", "\n    ");
    }

}

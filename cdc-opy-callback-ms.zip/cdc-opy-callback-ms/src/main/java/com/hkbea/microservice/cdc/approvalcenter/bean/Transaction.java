package com.hkbea.microservice.cdc.approvalcenter.bean;

import javax.persistence.*;
import java.io.Serializable;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

import com.hkbea.microservice.cdc.approvalcenter.bean.TransactionKey;
import com.hkbea.microservice.cdc.approvalcenter.bean.ProcessingDetails;
import com.hkbea.microservice.cdc.approvalcenter.bean.TransactionApprovalDetails;
import com.hkbea.microservice.cdc.approvalcenter.bean.TransactionUserDetails;
import com.hkbea.microservice.cdc.approvalcenter.bean.TransactionApprovalHistory;
import com.hkbea.microservice.cdc.approvalcenter.bean.ProcessingError;

@Entity
@Table(name = "DIGX_AP_TRANSACTION")
@Cacheable(false)
@Inheritance(strategy = InheritanceType.SINGLE_TABLE)
@DiscriminatorColumn(name = "disc")
@DiscriminatorValue("T")
public class Transaction implements Serializable {

    @EmbeddedId
    private TransactionKey key;

    @Column(name = "MODULE_REFERENCE_ID")
    private String moduleReferenceId;

    @Column(name = "TXN_NAME")
    private String transactionName;

    @Column(name = "LMT_TASK_CD")
    private String limitTaskCode;

    @Column(name = "SERVICE_ID")
    private String serviceId;

    // Stored as JSON in original mapping; map to a lob String here
    @Lob
    @Column(name = "TXN_DETAILS")
    private String transactionSnapshot;

    @Column(name = "MODULE_TYPE")
    private String moduleType;

    @Column(name = "TRANSIENT")
    private Boolean transientTxn;

    @Column(name = "LAST_UPDATED_BY")
    private String lastUpdatedBy;

    @Column(name = "CREATED_BY", updatable = false)
    private String createdBy;

    @Column(name = "CREATION_DATE")
    private LocalDateTime creationDate;

    @Column(name = "LAST_UPDATED_DATE")
    private LocalDateTime lastUpdatedDate;

    @Column(name = "object_status")
    private String entityStatus;

    @Column(name = "DISCRIMINATOR")
    private String discriminator;

    @Version
    @Column(name = "OBJECT_VERSION_NUMBER")
    private Integer version;

    @ElementCollection
    @CollectionTable(name = "DIGX_AP_TXN_APPROVAL_HISTORY", joinColumns = @JoinColumn(name = "TXN_ID"))
    @OrderColumn(name = "index_num")
    private List<TransactionApprovalHistory> transactionApprovalHistory = new ArrayList<>();

    @Embedded
    @AttributeOverrides({
            @AttributeOverride(name = "currentStep", column = @Column(name = "PROCESSING_CURRENT_STEP")),
            @AttributeOverride(name = "status", column = @Column(name = "PROCESSING_STATUS")),
            @AttributeOverride(name = "referenceNumber", column = @Column(name = "PROCESSING_REFNO"))
    })
    private ProcessingDetails processingDetails;

    @Embedded
    @AttributeOverrides({
            @AttributeOverride(name = "remarks", column = @Column(name = "APPR_REMARKS")),
            @AttributeOverride(name = "stepNo", column = @Column(name = "APPR_STEP_NO")),
            @AttributeOverride(name = "status", column = @Column(name = "APPR_STATUS")),
            @AttributeOverride(name = "signedBy", column = @Column(name = "SIGNED_BY")),
            @AttributeOverride(name = "action", column = @Column(name = "APPR_ACTION")),
            @AttributeOverride(name = "approvalType", column = @Column(name = "APPROVAL_TYPE"))
    })
    private TransactionApprovalDetails approvalDetails;

    @Embedded
    @AttributeOverrides({
            @AttributeOverride(name = "title", column = @Column(name = "CREATOR_TITLE")),
            @AttributeOverride(name = "firstName", column = @Column(name = "CREATOR_FIRST_NAME")),
            @AttributeOverride(name = "middleName", column = @Column(name = "CREATOR_MIDDLE_NAME")),
            @AttributeOverride(name = "lastName", column = @Column(name = "CREATOR_LAST_NAME")),
            @AttributeOverride(name = "emailId", column = @Column(name = "CREATOR_EMAIL_ID")),
            @AttributeOverride(name = "mobileNumber", column = @Column(name = "CREATOR_MOBILE_NO")),
            @AttributeOverride(name = "phoneNumber", column = @Column(name = "CREATOR_PHONE_NO"))
    })
    private TransactionUserDetails createdByDetails;

    @Embedded
    @AttributeOverrides({
            @AttributeOverride(name = "title", column = @Column(name = "UPDATER_TITLE")),
            @AttributeOverride(name = "firstName", column = @Column(name = "UPDATER_FIRST_NAME")),
            @AttributeOverride(name = "middleName", column = @Column(name = "UPDATER_MIDDLE_NAME")),
            @AttributeOverride(name = "lastName", column = @Column(name = "UPDATER_LAST_NAME")),
            @AttributeOverride(name = "emailId", column = @Column(name = "UPDATER_EMAIL_ID")),
            @AttributeOverride(name = "mobileNumber", column = @Column(name = "UPDATER_MOBILE_NO")),
            @AttributeOverride(name = "phoneNumber", column = @Column(name = "UPDATER_PHONE_NO"))
    })
    private TransactionUserDetails updatedByDetails;

    @ElementCollection
    @CollectionTable(name = "DIGX_AP_TXN_PROCESS_ERROR", joinColumns = @JoinColumn(name = "TXN_ID"))
    @OrderBy("errorCode ASC")
    private List<ProcessingError> errors = new ArrayList<>();

    @ElementCollection
    @CollectionTable(name = "DIGX_AP_TXN_ENTITY_IDENTIFIER", joinColumns = @JoinColumn(name = "TXN_ID", referencedColumnName = "TXN_ID"))
    @Column(name = "ENTITY_IDENTIFIER")
    private List<String> entityIdentifiers = new ArrayList<>();

    @Column(name = "DETERMINANT_VALUE")
    private String determinantValue;

    public Transaction() {
    }

    @PrePersist
    public void updateModuleReferenceId() {
        if (this.moduleReferenceId == null && this.key != null) {
            this.moduleReferenceId = this.key.getId();
        }
    }

    // Getters and setters

    public TransactionKey getKey() {
        return key;
    }

    public void setKey(TransactionKey key) {
        this.key = key;
    }

    public String getModuleReferenceId() {
        return moduleReferenceId;
    }

    public void setModuleReferenceId(String moduleReferenceId) {
        this.moduleReferenceId = moduleReferenceId;
    }

    public String getTransactionName() {
        return transactionName;
    }

    public void setTransactionName(String transactionName) {
        this.transactionName = transactionName;
    }

    public String getLimitTaskCode() {
        return limitTaskCode;
    }

    public void setLimitTaskCode(String limitTaskCode) {
        this.limitTaskCode = limitTaskCode;
    }

    public String getServiceId() {
        return serviceId;
    }

    public void setServiceId(String serviceId) {
        this.serviceId = serviceId;
    }

    public String getTransactionSnapshot() {
        return transactionSnapshot;
    }

    public void setTransactionSnapshot(String transactionSnapshot) {
        this.transactionSnapshot = transactionSnapshot;
    }

    public String getModuleType() {
        return moduleType;
    }

    public void setModuleType(String moduleType) {
        this.moduleType = moduleType;
    }

    public Boolean getTransientTxn() {
        return transientTxn;
    }

    public void setTransientTxn(Boolean transientTxn) {
        this.transientTxn = transientTxn;
    }

    public String getLastUpdatedBy() {
        return lastUpdatedBy;
    }

    public void setLastUpdatedBy(String lastUpdatedBy) {
        this.lastUpdatedBy = lastUpdatedBy;
    }

    public String getCreatedBy() {
        return createdBy;
    }

    public void setCreatedBy(String createdBy) {
        this.createdBy = createdBy;
    }

    public LocalDateTime getCreationDate() {
        return creationDate;
    }

    public void setCreationDate(LocalDateTime creationDate) {
        this.creationDate = creationDate;
    }

    public LocalDateTime getLastUpdatedDate() {
        return lastUpdatedDate;
    }

    public void setLastUpdatedDate(LocalDateTime lastUpdatedDate) {
        this.lastUpdatedDate = lastUpdatedDate;
    }

    public String getEntityStatus() {
        return entityStatus;
    }

    public void setEntityStatus(String entityStatus) {
        this.entityStatus = entityStatus;
    }

    public String getDiscriminator() {
        return discriminator;
    }

    public void setDiscriminator(String discriminator) {
        this.discriminator = discriminator;
    }

    public Integer getVersion() {
        return version;
    }

    public void setVersion(Integer version) {
        this.version = version;
    }

    public List<TransactionApprovalHistory> getTransactionApprovalHistory() {
        return transactionApprovalHistory;
    }

    public void setTransactionApprovalHistory(List<TransactionApprovalHistory> transactionApprovalHistory) {
        this.transactionApprovalHistory = transactionApprovalHistory;
    }

    public ProcessingDetails getProcessingDetails() {
        return processingDetails;
    }

    public void setProcessingDetails(ProcessingDetails processingDetails) {
        this.processingDetails = processingDetails;
    }

    public TransactionApprovalDetails getApprovalDetails() {
        return approvalDetails;
    }

    public void setApprovalDetails(TransactionApprovalDetails approvalDetails) {
        this.approvalDetails = approvalDetails;
    }

    public TransactionUserDetails getCreatedByDetails() {
        return createdByDetails;
    }

    public void setCreatedByDetails(TransactionUserDetails createdByDetails) {
        this.createdByDetails = createdByDetails;
    }

    public TransactionUserDetails getUpdatedByDetails() {
        return updatedByDetails;
    }

    public void setUpdatedByDetails(TransactionUserDetails updatedByDetails) {
        this.updatedByDetails = updatedByDetails;
    }

    public List<ProcessingError> getErrors() {
        return errors;
    }

    public void setErrors(List<ProcessingError> errors) {
        this.errors = errors;
    }

    public List<String> getEntityIdentifiers() {
        return entityIdentifiers;
    }

    public void setEntityIdentifiers(List<String> entityIdentifiers) {
        this.entityIdentifiers = entityIdentifiers;
    }

    public String getDeterminantValue() {
        return determinantValue;
    }

    public void setDeterminantValue(String determinantValue) {
        this.determinantValue = determinantValue;
    }
}


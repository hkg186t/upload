package com.hkbea.microservice.cdc.approvalcenter.model;

import com.fasterxml.jackson.annotation.JsonProperty;
import io.swagger.annotations.ApiModelProperty;
import jakarta.validation.Valid;

import java.io.Serializable;

public class ApprovalRequest implements Serializable {

    private static final long serialVersionUID = 1L;

    @JsonProperty("macData")
    @ApiModelProperty(value = "MAC data for request validation")
    @Valid
    private MacData macData;

    @JsonProperty("challengeResponse")
    @ApiModelProperty(value = "Challenge response for authentication")
    @Valid
    private ChallengeResponse challengeResponse;

    public MacData getMacData() {
        return macData;
    }

    public void setMacData(MacData macData) {
        this.macData = macData;
    }

    public ChallengeResponse getChallengeResponse() {
        return challengeResponse;
    }

    public void setChallengeResponse(ChallengeResponse challengeResponse) {
        this.challengeResponse = challengeResponse;
    }

    public static class MacData implements Serializable {
        private static final long serialVersionUID = 1L;

        @JsonProperty("macEncryptedData")
        @ApiModelProperty(value = "MAC encrypted data")
        private String macEncryptedData;

        @JsonProperty("macKey")
        @ApiModelProperty(value = "MAC key")
        private String macKey;

        @JsonProperty("macModulus")
        @ApiModelProperty(value = "MAC modulus")
        private String macModulus;

        @JsonProperty("macRsaIndicator")
        @ApiModelProperty(value = "MAC RSA indicator")
        private String macRsaIndicator;

        @JsonProperty("macData")
        @ApiModelProperty(value = "MAC data")
        private String macData;

        public String getMacEncryptedData() {
            return macEncryptedData;
        }

        public void setMacEncryptedData(String macEncryptedData) {
            this.macEncryptedData = macEncryptedData;
        }

        public String getMacKey() {
            return macKey;
        }

        public void setMacKey(String macKey) {
            this.macKey = macKey;
        }

        public String getMacModulus() {
            return macModulus;
        }

        public void setMacModulus(String macModulus) {
            this.macModulus = macModulus;
        }

        public String getMacRsaIndicator() {
            return macRsaIndicator;
        }

        public void setMacRsaIndicator(String macRsaIndicator) {
            this.macRsaIndicator = macRsaIndicator;
        }

        public String getMacData() {
            return macData;
        }

        public void setMacData(String macData) {
            this.macData = macData;
        }
    }

    public static class ChallengeResponse implements Serializable {
        private static final long serialVersionUID = 1L;

        @JsonProperty("msessageContent")
        @ApiModelProperty(value = "signer pin after RSA encrypted")
        private String msessageContent;

        @JsonProperty("rsaKeyIndicator")
        @ApiModelProperty(value = "RSA key indicator", example = "CDC002")
        private String rsaKeyIndicator;

        @JsonProperty("token")
        @ApiModelProperty(value = "Token", example = "73519533")
        private String token;

        @JsonProperty("otp")
        @ApiModelProperty(value = "OTP", example = "570208")
        private String otp;

        @JsonProperty("referenceNo")
        @ApiModelProperty(value = "Reference number", example = "7313854")
        private String referenceNo;

        @JsonProperty("authType")
        @ApiModelProperty(value = "Authentication type", example = "SIGNEROTPITOKEN")
        private String authType;

        public String getMsessageContent() {
            return msessageContent;
        }

        public void setMsessageContent(String msessageContent) {
            this.msessageContent = msessageContent;
        }

        public String getRsaKeyIndicator() {
            return rsaKeyIndicator;
        }

        public void setRsaKeyIndicator(String rsaKeyIndicator) {
            this.rsaKeyIndicator = rsaKeyIndicator;
        }

        public String getToken() {
            return token;
        }

        public void setToken(String token) {
            this.token = token;
        }

        public String getOtp() {
            return otp;
        }

        public void setOtp(String otp) {
            this.otp = otp;
        }

        public String getReferenceNo() {
            return referenceNo;
        }

        public void setReferenceNo(String referenceNo) {
            this.referenceNo = referenceNo;
        }

        public String getAuthType() {
            return authType;
        }

        public void setAuthType(String authType) {
            this.authType = authType;
        }
    }
}

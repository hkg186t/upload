package com.hkbea.service.cdc;

import com.hkbea.dao.cdc.UpdateOutwardRemittanceStatusDaoImpl;
import com.hkbea.intf.cdc.jpa.UpdateOutwardRemittanceStatusDao;
import com.hkbea.intf.cdc.service.UpdateOutwardRemittanceStatusSvc;
import com.hkbea.microservice.cdc.approvalcenter.api.ApiException;

import com.hkbea.microservice.cdc.approvalcenter.model.OutwardRemittanceStatusInfo;
import com.hkbea.util.xaa.log.Logger;
import com.hkbea.util.xaa.log.LoggerManager;
import jakarta.transaction.Transactional;
import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;

@Service
public class UpdateOutwardRemittanceStatusSvcImpl implements UpdateOutwardRemittanceStatusSvc {


    public static final String REQUEST_STATUS_COMPLETE = "Complete";
    public static final String REQUEST_STATUS_REJECT = "Reject";
    public final static String DATABASE_STATUS_ACC = "ACC";
    public final static String DATABASE_STATUS_REJ = "REJ";

    @Autowired
    private UpdateOutwardRemittanceStatusDao updateOutwardRemittanceStatusDao;
    private static final Logger logger = LoggerManager.getLogger(UpdateOutwardRemittanceStatusSvcImpl.class);

    @Override
    public void checkTransactionInfoValid(OutwardRemittanceStatusInfo outwardRemittanceStatusInfo) throws ApiException {
        logger.info("Service method checkTransactionInfoValid start");
        if (outwardRemittanceStatusInfo == null) {
            logger.info("outwardRemittanceStatusInfo is null");
            throw new ApiException("DIGX_CZ_OWREM_001", "Invalid CDC AP transaction number.");
        }
        String cdcApTxnNo = outwardRemittanceStatusInfo.getCdcApTxnNo();
        String status = outwardRemittanceStatusInfo.getStatus();
        if (StringUtils.isBlank(cdcApTxnNo)) {
            logger.info("outwardRemittanceStatusInfo cdcApTxnNo is null");
            throw new ApiException("DIGX_CZ_OWREM_001", "Invalid CDC AP transaction number");
        }
        if (StringUtils.isNotBlank(status) && !Arrays.asList("Complete", "Reject").contains(status)) {
            logger.info("outwardRemittanceStatusInfo status is Invalid status vlaue");
            throw new ApiException("DIGX_CZ_OWREM_002", "Invalid status vlaue");
        }

        logger.info("Service method checkTransactionInfoValid end");
    }

    @Override
    public int updateOutwardRemittanceStatus(OutwardRemittanceStatusInfo outwardRemittanceStatusInfo) throws ApiException {
        checkTransactionInfoValid(outwardRemittanceStatusInfo);
        return updateOutwardRemittanceStatusDao.updateOutwardRemittanceStatus(outwardRemittanceStatusInfo);

    }

    @Override
    public void recordOutwardRemittanceInfo(OutwardRemittanceStatusInfo outwardRemittanceStatusInfo) throws ApiException {
        try {
            int count = updateOutwardRemittanceStatusDao.insertOutwardRemittanceResult(outwardRemittanceStatusInfo);
            if (count > 0) {
                logger.info("Insert DIGX_CZ_OPY_CALLBACK table success, record count {}.", count);
            } else {
                logger.info("Insert DIGX_CZ_OPY_CALLBACK table failed");
                throw new ApiException("DIGX_CZ_OWREM_005", "An internal server error has occurred");
            }
        } catch (Exception e) {
            logger.info("Insert DIGX_CZ_OPY_CALLBACK table failed");
            logger.info("An exception occurred", e);
            throw new ApiException("DIGX_CZ_OWREM_005", "An internal server error has occurred");
        }
    }


    @Override
    public void updateLMRelatedTable(OutwardRemittanceStatusInfo outwardRemittanceStatusInfo) throws ApiException {
        try{
            //1.select txn_status from cdc_LM_txn_req
            Map<String, String> txnStatusMap = updateOutwardRemittanceStatusDao.selectLMTxnReqByLmApTxn(outwardRemittanceStatusInfo);
            if(txnStatusMap==null){
                logger.info("select txn_status from cdc_LM_txn_req result is null");
                throw new ApiException("DIGX_CZ_OWREM_005","An internal server error has occurred");
            }
            String txnStatus = txnStatusMap.get("txnStatus");
            String cibAcctNo = txnStatusMap.get("cibAcctNo");
            String txnNo = txnStatusMap.get("txnNo");
            String runDt = txnStatusMap.get("runDt");
            //1.update cdc_LM_txn_req table
            updateCdcTxnReqTable(outwardRemittanceStatusInfo, txnStatus);
            if (DATABASE_STATUS_REJ.equals(txnStatus) && REQUEST_STATUS_COMPLETE.equals(outwardRemittanceStatusInfo.getStatus())) {
                logger.info("DATABASE_STATUS_REJ is rej and REQUEST_STATUS_COMPLETE is complete");
                //2.update cdc_lm_txn_hist table
                updateCdcLmTxnHistTable(outwardRemittanceStatusInfo, txnStatus, cibAcctNo, txnNo, runDt);
                //3.update cdc_lm_txn_hist_summary table
                updateCdcLmTxnHistSummary(outwardRemittanceStatusInfo, txnStatus, cibAcctNo, runDt);
            } else if (DATABASE_STATUS_ACC.equals(txnStatus) && REQUEST_STATUS_REJECT.equals(outwardRemittanceStatusInfo.getStatus())) {
                logger.info("DATABASE_STATUS_ACC is acc and REQUEST_STATUS_REJECT is reject");
                //2.update cdc_lm_txn_hist table
                updateCdcLmTxnHistTable(outwardRemittanceStatusInfo, txnStatus, cibAcctNo, txnNo, runDt);
                //3.update cdc_lm_txn_hist_summary table
                updateCdcLmTxnHistSummary(outwardRemittanceStatusInfo, txnStatus, cibAcctNo, runDt);
            }
        }catch (Exception e){
            logger.info("select  cdc_LM_txn_req table failed");
            logger.info("An exception occurred", e);
            throw new ApiException("DIGX_CZ_OWREM_005", "An internal server error has occurred");
        }

    }


    private void updateCdcTxnReqTable(OutwardRemittanceStatusInfo outwardRemittanceStatusInfo, String txnStatus) throws ApiException {

        Map<String, Object> paramMap = new HashMap<>();
        paramMap.put("cdcApTxnNo", outwardRemittanceStatusInfo.getCdcApTxnNo());
        paramMap.put("txn_status", null);
        paramMap.put("rejectCode", null);
        paramMap.put("rejectReason", null);
        paramMap.put("txnResultStatus", null);
        paramMap.put("uetr", null);
        if (DATABASE_STATUS_REJ.equals(txnStatus) && REQUEST_STATUS_COMPLETE.equals(outwardRemittanceStatusInfo.getStatus())) {
            logger.info("DATABASE_STATUS_REJ is rej and REQUEST_STATUS_COMPLETE is complete");
            paramMap.put("txn_status", "ACC");
            paramMap.put("rejectCode", "");
            paramMap.put("rejectReason", "");
            paramMap.put("txnStatusMsg", "OPYACC");
            paramMap.put("txnResultStatus", "S");
            paramMap.put("uetr", outwardRemittanceStatusInfo.getUetr());
            paramMap.put("approvalCenterStatus", outwardRemittanceStatusInfo.getStatus());
        } else if (DATABASE_STATUS_ACC.equals(txnStatus) && REQUEST_STATUS_REJECT.equals(outwardRemittanceStatusInfo.getStatus())) {
            logger.info("DATABASE_STATUS_ACC is acc and REQUEST_STATUS_REJECT is reject");
            paramMap.put("cdcApTxnNo", outwardRemittanceStatusInfo.getCdcApTxnNo());
            paramMap.put("txn_status", "REJ");
            paramMap.put("rejectCode", outwardRemittanceStatusInfo.getRejectCode());
            paramMap.put("rejectReason", outwardRemittanceStatusInfo.getRejectReason());
            paramMap.put("txnStatusMsg", "OPYREJ");
            paramMap.put("txnResultStatus", "F");
            paramMap.put("approvalCenterStatus", outwardRemittanceStatusInfo.getStatus());
        } else if (DATABASE_STATUS_ACC.equals(txnStatus) && REQUEST_STATUS_COMPLETE.equals(outwardRemittanceStatusInfo.getStatus())) {
            logger.info("DATABASE_STATUS_ACC is acc and REQUEST_STATUS_COMPLETE is complete");
            paramMap.put("txnStatusMsg", "OPYACC");
            paramMap.put("uetr", outwardRemittanceStatusInfo.getUetr());
            paramMap.put("approvalCenterStatus", outwardRemittanceStatusInfo.getStatus());
        } else if (DATABASE_STATUS_REJ.equals(txnStatus) && REQUEST_STATUS_REJECT.equals(outwardRemittanceStatusInfo.getStatus())) {
            logger.info("DATABASE_STATUS_REJ is rej and REQUEST_STATUS_REJECT is reject");
            paramMap.put("rejectCode", outwardRemittanceStatusInfo.getRejectCode());
            paramMap.put("rejectReason", outwardRemittanceStatusInfo.getRejectReason());
            paramMap.put("txnStatusMsg", "OPYREJ");
            paramMap.put("txnResultStatus", "F");
            paramMap.put("approvalCenterStatus", outwardRemittanceStatusInfo.getStatus());
        }
        for (Map.Entry<String, Object> entry : paramMap.entrySet()) {
            logger.info("paramMap key: {}, paramMap value: {} ", entry.getKey(), (String)entry.getValue());
        }
        try {
            int count = updateOutwardRemittanceStatusDao.updateCdcLmTxnReqField(paramMap);
            if (count > 0) {
                logger.info("update cdc_LM_txn_req table success, record count {}.", count);
            }else{
                logger.info("update cdc_LM_txn_req table failed, record count {}.", count);
                throw new ApiException("DIGX_CZ_OWREM_005", "An internal server error has occurred");
            }
        } catch (Exception e) {
            logger.info("update cdc_LM_txn_req table failed");
            logger.info("An exception occurred", e);
            throw new ApiException("DIGX_CZ_OWREM_005", "An internal server error has occurred");
        }


    }


    private void updateCdcLmTxnHistTable(OutwardRemittanceStatusInfo outwardRemittanceStatusInfo, String txnStatus, String cibAcctNo, String txnNo, String runDt) throws ApiException {

        Map<String, String> paramMap = new HashMap<>();
        if (DATABASE_STATUS_REJ.equals(txnStatus) && REQUEST_STATUS_COMPLETE.equals(outwardRemittanceStatusInfo.getStatus())) {
            paramMap.put("txnStatus", "ACC");
            paramMap.put("rejectCode", "");
            paramMap.put("rejectReason", "");

        } else if (DATABASE_STATUS_ACC.equals(txnStatus) && REQUEST_STATUS_REJECT.equals(outwardRemittanceStatusInfo.getStatus())) {
            paramMap.put("txnStatus", "REJ");
            paramMap.put("rejectCode", outwardRemittanceStatusInfo.getRejectCode());
            paramMap.put("rejectReason", outwardRemittanceStatusInfo.getRejectReason());
        }
        paramMap.put("acctNo", cibAcctNo);
        paramMap.put("txnNo", txnNo);
        paramMap.put("runDt", runDt);
        try {
            int count = updateOutwardRemittanceStatusDao.updateCdcLmTxnHistField(paramMap);
            if (count > 0) {
                logger.info("update cdc_lm_txn_hist table success, record count {}.", count);
            }else{
                logger.info("update cdc_lm_txn_hist table failed, record count {}.", count);
                throw new ApiException("DIGX_CZ_OWREM_005", "An internal server error has occurred");
            }
        } catch (Exception e) {
            logger.info("update cdc_lm_txn_hist table failed");
            logger.info("An exception occurred", e);
            throw new ApiException("DIGX_CZ_OWREM_005", "An internal server error has occurred");
        }
    }

    private void updateCdcLmTxnHistSummary(OutwardRemittanceStatusInfo outwardRemittanceStatusInfo, String txnStatus, String cibAcctNo, String runDt) throws ApiException {
        Map<String, Object> paramMap = new HashMap<>();
        if (DATABASE_STATUS_REJ.equals(txnStatus) && REQUEST_STATUS_COMPLETE.equals(outwardRemittanceStatusInfo.getStatus())) {
            paramMap.put("instruRejExecCount", -1);
            paramMap.put("instruExecCount", 1);

        } else if (DATABASE_STATUS_ACC.equals(txnStatus) && REQUEST_STATUS_REJECT.equals(outwardRemittanceStatusInfo.getStatus())) {
            paramMap.put("instruRejExecCount", 1);
            paramMap.put("instruExecCount", -1);
        }
        paramMap.put("acctNo", cibAcctNo);
        paramMap.put("runDt", runDt);
        try {
            int count = updateOutwardRemittanceStatusDao.updateCdcLmTxnHistSummaryField(paramMap);
            if (count > 0) {
                logger.info("update cdc_lm_txn_hist_summary table success, record count {}.", count);
            }else{
                logger.info("update cdc_lm_txn_hist_summary table failed, record count {}.", count);
                throw new ApiException("DIGX_CZ_OWREM_005", "An internal server error has occurred");
            }
        } catch (Exception e) {
            logger.info("update cdc_lm_txn_hist_summary table failed");
            logger.info("An exception occurred", e);
            throw new ApiException("DIGX_CZ_OWREM_005", "An internal server error has occurred");
        }
    }
}

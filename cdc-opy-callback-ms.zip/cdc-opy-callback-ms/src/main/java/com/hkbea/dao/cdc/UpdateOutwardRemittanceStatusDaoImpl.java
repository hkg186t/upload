package com.hkbea.dao.cdc;

import com.hkbea.dao.XaaJdbcDaoSupport;
import com.hkbea.dao.xaa.annotation.SRepository;
import com.hkbea.intf.cdc.jpa.UpdateOutwardRemittanceStatusDao;

import com.hkbea.microservice.cdc.approvalcenter.model.OutwardRemittanceStatusInfo;
import com.hkbea.util.xaa.log.Logger;
import com.hkbea.util.xaa.log.LoggerManager;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.EnableTransactionManagement;
import org.springframework.transaction.annotation.Transactional;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Component
@SRepository
@EnableTransactionManagement
@Transactional
public class UpdateOutwardRemittanceStatusDaoImpl extends XaaJdbcDaoSupport implements UpdateOutwardRemittanceStatusDao {
    private static final Logger logger = LoggerManager.getLogger(UpdateOutwardRemittanceStatusDaoImpl.class);

    @Override
    public int updateOutwardRemittanceStatus(OutwardRemittanceStatusInfo outwardRemittanceStatusInfo) {
        logger.info("DAO updateOutwardRemittanceStatus started.");

        String sql = "update DIGX_CZ_PY_NWPAYMENT_PAYOUT set STATUS = :outwardRemittanceStatus, UETR_REF_NUM = :uetr where opy_Ref = :opyRefNo or APTXNNO = :cdcApTxnNo";

        Map<String, String> paramMap = new HashMap<>();
        if ("Complete".equals(outwardRemittanceStatusInfo.getStatus())) {
            paramMap.put("outwardRemittanceStatus", "COM");
        } else {
            paramMap.put("outwardRemittanceStatus", "REJ");
        }
        paramMap.put("uetr", outwardRemittanceStatusInfo.getUetr());
        paramMap.put("opyRefNo", outwardRemittanceStatusInfo.getOpyRefNo());
        paramMap.put("cdcApTxnNo", outwardRemittanceStatusInfo.getCdcApTxnNo());

        logger.info("update outwardRemittance status log sql = {}", sql);
        logger.info("update outwardRemittance status log paramMap = {}", paramMap);
        int result = super.update(sql, paramMap);
        logger.info("result int = {}", result);
        logger.info("DAO updateOutwardRemittanceStatus end.");
        return result;
    }

    @Override
    public int insertOutwardRemittanceResult(OutwardRemittanceStatusInfo outwardRemittanceStatusInfo) {
        logger.info("DAO insertOutwardRemittanceResult started.");
        String sql = "INSERT INTO DIGX_CZ_OPY_CALLBACK (CDCAPTXNNO,STATUS,REJECTCODE,REJECTREASON,OPYREFNO,UETR,REC_TM) " +
                "VALUES(:cdcApTxnNo, :outwardRemittanceStatus, :rejectCode, :rejectReason, :opyRefNo, :uetr, sysdate)";
        Map<String, String> paramMap = new HashMap<>();

        paramMap.put("cdcApTxnNo", outwardRemittanceStatusInfo.getCdcApTxnNo());
        paramMap.put("outwardRemittanceStatus", outwardRemittanceStatusInfo.getStatus());
        paramMap.put("rejectCode", outwardRemittanceStatusInfo.getRejectCode());
        paramMap.put("rejectReason", outwardRemittanceStatusInfo.getRejectReason());
        paramMap.put("opyRefNo", outwardRemittanceStatusInfo.getOpyRefNo());
        paramMap.put("uetr", outwardRemittanceStatusInfo.getUetr());
        logger.info("insert into DIGX_CZ_OPY_CALLBACK table log sql = {}", sql);
        logger.info("insert into DIGX_CZ_OPY_CALLBACK table log paramMap = {}", paramMap);
        int result = super.update(sql, paramMap);
        logger.info("result int = {}", result);
        logger.info("DAO insertOutwardRemittanceResult end.");
        return result;
    }

    @Override
    public Map<String, String> selectLMTxnReqByLmApTxn(OutwardRemittanceStatusInfo outwardRemittanceStatusInfo) {
        logger.info("DAO selectLMTxnReqByLmApTxn started.");
        String sql = "SELECT txn_status AS txnStatus, CIB_ACCT_NO as cibAcctNo,TXN_NO AS txnNo, TO_CHAR(RUN_DT, 'YYYY-MM-DD') as runDt " +
                " FROM cdc_LM_txn_req WHERE CDC_LM_AP_TXN = :cdcApTxnNo";
        Map<String, String> paramMap = new HashMap<>();
        Map<String, String> ResultMap = new HashMap<>();
        paramMap.put("cdcApTxnNo", outwardRemittanceStatusInfo.getCdcApTxnNo());
        logger.info("paramMap cdcApTxnNo :{}",outwardRemittanceStatusInfo.getCdcApTxnNo());
        logger.info("select cdc_LM_txn_req table log sql = {}", sql);
        logger.info("select cdc_LM_txn_req table log paramMap = {}", paramMap);
        List<Map<String, Object>> lmTxnReqTxnStatusMap = super.list(sql, paramMap);
        if (!lmTxnReqTxnStatusMap.isEmpty()) {
            ResultMap.put("txnStatus",(String)lmTxnReqTxnStatusMap.get(0).get("txnStatus"));
            ResultMap.put("cibAcctNo",(String)lmTxnReqTxnStatusMap.get(0).get("cibAcctNo"));
            ResultMap.put("txnNo",(String)lmTxnReqTxnStatusMap.get(0).get("txnNo"));
            ResultMap.put("runDt",(String)lmTxnReqTxnStatusMap.get(0).get("runDt"));
            return ResultMap;
        }
        logger.info("DAO selectLMTxnReqByLmApTxn end.");
        return null;
    }

    @Override
    public int updateCdcLmTxnReqField(Map<String, Object> paramMap) {
        logger.info("DAO updateCdcLmTxnReqField started.");
        Map<String, String> dbParaMap = new HashMap<>();
        String sqlSetValue = "UPDATE cdc_lm_txn_req SET TXN_STATUS_MSG = :txnStatusMsg, APPROVAL_CENTER_STATUS = :approvalCenterStatus";
        String sqlCondition = " where CDC_LM_AP_TXN = :cdcLmAptxn ";
        if (paramMap.get("txn_status") != null) {
            sqlSetValue += ", TXN_STATUS = :txn_status";
            dbParaMap.put("txn_status", (String)paramMap.get("txn_status"));
        }
        if (paramMap.get("rejectCode") != null){
            sqlSetValue += ", BANK_MSG_ID = :rejectCode";
            dbParaMap.put("rejectCode", (String)paramMap.get("rejectCode"));
        }
        if (paramMap.get("rejectReason") != null){
            sqlSetValue += ", BANK_MSG_DESC = :rejectReason";
            dbParaMap.put("rejectReason", (String)paramMap.get("rejectReason"));
        }
        if (paramMap.get("txnResultStatus") != null){
            sqlSetValue += ", TXN_RESULT_STATUS = :txnResultStatus";
            dbParaMap.put("txnResultStatus", (String)paramMap.get("txnResultStatus"));
        }
        if (paramMap.get("uetr") != null){
            sqlSetValue += ", OPY_UETR = :uetr";
            dbParaMap.put("uetr", (String)paramMap.get("uetr"));
        }
        dbParaMap.put("txnStatusMsg", (String)paramMap.get("txnStatusMsg"));
        dbParaMap.put("approvalCenterStatus", (String)paramMap.get("approvalCenterStatus"));
        dbParaMap.put("cdcLmAptxn", (String)paramMap.get("cdcApTxnNo"));
        String sql = sqlSetValue + sqlCondition;
        logger.info("update cdc_LM_txn_req table log sql = {}", sql);
        logger.info("update cdc_LM_txn_req table log dbParaMap = {}", dbParaMap);
        int result = super.update(sql, dbParaMap);
        logger.info("result int = {}", result);
        logger.info("DAO updateCdcLmTxnReqField end.");
        return result;
    }

    @Override
    public int updateCdcLmTxnHistField(Map<String, String> paramMap) {

        logger.info("DAO updateCdcLmTxnHistField started.");
        String sql = "UPDATE cdc_lm_txn_hist SET status = :txnStatus, BANK_MSG_ID = :rejectCode, BANK_MSG_DESC = :rejectReason " +
                "WHERE ACCT_NO = :acctNo AND TXN_NO = :txnNo AND TO_CHAR(UPDATE_DATE, 'YYYY-MM-DD') = :runDt";

        logger.info("update cdc_lm_txn_hist table log sql = {}", sql);
        logger.info("update cdc_lm_txn_hist table log paramMap = {}", paramMap);
        int result = super.update(sql, paramMap);
        logger.info("result int = {}", result);
        logger.info("DAO updateCdcLmTxnHistField end.");
        return result;
    }

    @Override
    public int updateCdcLmTxnHistSummaryField(Map<String, Object> paramMap) {
        logger.info("DAO updateCdcLmTxnHistSummaryField started.");
        String sql = "UPDATE cdc_lm_txn_hist_summary SET instru_rej_exec_count = instru_rej_exec_count + :instruRejExecCount, " +
                " instru_exec_count = instru_exec_count + :instruExecCount " +
                " WHERE ACCT_NO = :acctNo AND TO_CHAR(TXN_DATE, 'YYYY-MM-DD') = :runDt";

        logger.info("update cdc_lm_txn_hist_summary table log sql = {}", sql);
        logger.info("update cdc_lm_txn_hist_summary table log paramMap = {}", paramMap);
        int result = super.update(sql, paramMap);
        logger.info("result int = {}", result);
        logger.info("DAO updateCdcLmTxnHistSummaryField end.");
        return result;
    }
}

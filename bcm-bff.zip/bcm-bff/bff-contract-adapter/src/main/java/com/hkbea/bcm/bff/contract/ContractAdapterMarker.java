package com.hkbea.bcm.bff.contract;

public final class ContractAdapterMarker {
    private ContractAdapterMarker() {
    }
}

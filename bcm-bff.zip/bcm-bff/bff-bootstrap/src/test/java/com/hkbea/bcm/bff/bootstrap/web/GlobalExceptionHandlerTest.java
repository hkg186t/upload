package com.hkbea.bcm.bff.bootstrap.web;

import com.hkbea.bcm.bff.shared.api.ErrorResponse;
import com.hkbea.bcm.bff.shared.http.HeaderConstants;
import org.junit.jupiter.api.Test;
import org.springframework.http.HttpStatus;
import org.springframework.mock.http.server.reactive.MockServerHttpRequest;
import org.springframework.mock.web.server.MockServerWebExchange;
import org.springframework.web.server.ResponseStatusException;

import static org.assertj.core.api.Assertions.assertThat;

class GlobalExceptionHandlerTest {
    private final GlobalExceptionHandler handler = new GlobalExceptionHandler();

    @Test
    void preservesResponseStatusExceptionStatusInErrorEnvelope() {
        String traceId = "missing-resource-trace";
        MockServerWebExchange exchange = MockServerWebExchange.from(MockServerHttpRequest
                .get("/missing")
                .header(HeaderConstants.X_REQUEST_ID, traceId)
                .build());

        var response = handler.handleResponseStatusException(
                new ResponseStatusException(HttpStatus.NOT_FOUND),
                exchange);

        assertThat(response.getStatusCode()).isEqualTo(HttpStatus.NOT_FOUND);
        assertThat(response.getBody()).isEqualTo(new ErrorResponse(
                "404",
                "404",
                "Resource not found",
                traceId));
    }

    @Test
    void preservesUnmappedResponseStatusExceptionCodeInErrorEnvelope() {
        String traceId = "method-not-allowed-trace";
        MockServerWebExchange exchange = MockServerWebExchange.from(MockServerHttpRequest
                .post("/health")
                .header(HeaderConstants.X_REQUEST_ID, traceId)
                .build());

        var response = handler.handleResponseStatusException(
                new ResponseStatusException(HttpStatus.METHOD_NOT_ALLOWED),
                exchange);

        assertThat(response.getStatusCode()).isEqualTo(HttpStatus.METHOD_NOT_ALLOWED);
        assertThat(response.getBody()).isEqualTo(new ErrorResponse(
                "405",
                "405",
                "Method Not Allowed",
                traceId));
    }
}

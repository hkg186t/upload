package com.hkbea.bcm.bff.bootstrap.web.proxy;

import com.fasterxml.jackson.databind.JsonNode;
import com.hkbea.bcm.bff.bootstrap.test.BffRandomPortSpringBootTest;
import com.hkbea.bcm.bff.bootstrap.web.ContractTestHeaders;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.DynamicPropertyRegistry;
import org.springframework.test.context.DynamicPropertySource;
import org.springframework.test.web.reactive.server.WebTestClient;

import java.util.List;
import java.util.Map;
import java.util.UUID;

import static com.hkbea.bcm.bff.bootstrap.web.RuntimeEnvelopeAssertions.assertErrorEnvelope;
import static com.hkbea.bcm.bff.bootstrap.web.RuntimeEnvelopeAssertions.assertSuccessEnvelope;
import static org.assertj.core.api.Assertions.assertThat;
import static org.springframework.http.MediaType.APPLICATION_JSON;

@BffRandomPortSpringBootTest(properties = {
        "bff.auth.jwt-secret=test-secret-for-bff-aggregation"
})
class BffAggregationIntegrationTest {
    private static final MockBcmUpstream UPSTREAM = MockBcmUpstream.start();

    @Autowired
    private WebTestClient webTestClient;

    @DynamicPropertySource
    static void properties(DynamicPropertyRegistry registry) {
        registry.add("bff.proxy.bcm.base-url", UPSTREAM::baseUrl);
        registry.add("bff.proxy.bcm.routes.optional-failure.method", () -> "POST");
        registry.add("bff.proxy.bcm.routes.optional-failure.upstream-path", UPSTREAM::optionalFailurePath);
        registry.add("bff.aggregation.routes.optional-summary.public-method", () -> "POST");
        registry.add("bff.aggregation.routes.optional-summary.public-path", () -> "/bff/demo/optional-summary");
        registry.add("bff.aggregation.routes.optional-summary.partial-response-enabled", () -> "true");
        registry.add("bff.aggregation.routes.optional-summary.steps[0].name", () -> "userProfile");
        registry.add("bff.aggregation.routes.optional-summary.steps[0].proxy-route-id", () -> "user-profile");
        registry.add("bff.aggregation.routes.optional-summary.steps[0].required", () -> "true");
        registry.add("bff.aggregation.routes.optional-summary.steps[1].name", () -> "optionalFailure");
        registry.add("bff.aggregation.routes.optional-summary.steps[1].proxy-route-id", () -> "optional-failure");
        registry.add("bff.aggregation.routes.optional-summary.steps[1].required", () -> "false");
        registry.add("bff.authorization.rules.optional-summary.method", () -> "POST");
        registry.add("bff.authorization.rules.optional-summary.path", () -> "/bff/demo/optional-summary");
        registry.add("bff.authorization.rules.optional-summary.required-roles[0]", () -> "BCM_USER");
        registry.add("bff.authorization.rules.optional-summary.required-scopes[0]", () -> "bcm:aggregate");
        registry.add("bff.authorization.rules.optional-summary.allowed-device-os[0]", () -> "Android");
        registry.add("bff.authorization.rules.optional-summary.allowed-device-os[1]", () -> "iOS");
    }

    @AfterAll
    static void stopUpstream() {
        UPSTREAM.stop();
    }

    @Test
    void aggregatesContractDrivenRoute() {
        String token = login();

        JsonNode body = aggregate(token, "/bff/demo/home-summary", Map.of("mode", "normal"), 200);

        JsonNode data = assertSuccessEnvelope(body);
        assertThat(data.path("partial").asBoolean()).isFalse();
        assertThat(data.path("items").path("userProfile").path("ok").asBoolean()).isTrue();
        assertThat(data.path("items").path("userProfile").path("mode").asText()).isEqualTo("normal");
        assertThat(data.path("errors").size()).isZero();
    }

    @Test
    void propagatesRequiredStepFailure() {
        String token = login();

        JsonNode body = aggregate(token, "/bff/demo/home-summary", Map.of("mode", "upstream500"), 502);

        assertErrorEnvelope(body, "502", "Upstream service error");
    }

    @Test
    void returnsPartialResponseWhenOptionalStepFails() {
        String token = login();

        JsonNode body = aggregate(token, "/bff/demo/optional-summary", Map.of("mode", "normal"), 200);

        JsonNode data = assertSuccessEnvelope(body);
        assertThat(data.path("partial").asBoolean()).isTrue();
        assertThat(data.path("items").path("userProfile").path("ok").asBoolean()).isTrue();
        assertThat(data.path("errors").path("optionalFailure").path("code").asText()).isEqualTo("502");
    }

    private String login() {
        JsonNode body = ContractTestHeaders.withRequiredHeaders(webTestClient.post()
                .uri("/auth/login"))
                .contentType(APPLICATION_JSON)
                .bodyValue(Map.of(
                        "username", "AGG-" + UUID.randomUUID(),
                        "password", "demo",
                        "parentAccountId", "015521104095930",
                        "deviceId", "test-device-" + UUID.randomUUID(),
                        "deviceOs", "Android",
                        "locale", "en",
                        "roles", List.of("BCM_USER"),
                        "scopes", List.of("bcm:proxy", "bcm:aggregate")))
                .exchange()
                .expectStatus().isOk()
                .expectBody(JsonNode.class)
                .returnResult()
                .getResponseBody();

        assertThat(body).isNotNull();
        return body.path("data").path("accessToken").asText();
    }

    private JsonNode aggregate(String token, String path, Map<String, String> requestBody, int expectedStatus) {
        JsonNode body = ContractTestHeaders.withRequiredHeaders(webTestClient.post()
                .uri(path), "agg-" + UUID.randomUUID())
                .contentType(APPLICATION_JSON)
                .header("Authorization", "Bearer " + token)
                .bodyValue(requestBody)
                .exchange()
                .expectStatus().isEqualTo(expectedStatus)
                .expectBody(JsonNode.class)
                .returnResult()
                .getResponseBody();

        assertThat(body).isNotNull();
        return body;
    }
}

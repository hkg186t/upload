package com.hkbea.bcm.bff.bootstrap.config;

import com.hkbea.bcm.bff.access.config.AuthProperties;
import com.hkbea.bcm.bff.access.config.EntitlementProperties;
import com.hkbea.bcm.bff.access.config.SessionStoreProperties;
import com.hkbea.bcm.bff.proxy.config.BcoProxyProperties;
import com.hkbea.bcm.bff.proxy.config.BcmProxyProperties;
import org.springframework.boot.autoconfigure.data.redis.RedisProperties;
import org.junit.jupiter.api.Test;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.boot.test.context.runner.ApplicationContextRunner;
import org.springframework.context.annotation.Import;

import static org.assertj.core.api.Assertions.assertThat;

class ProductionRuntimeConfigurationValidatorTest {
    private final ApplicationContextRunner contextRunner = new ApplicationContextRunner()
            .withUserConfiguration(TestConfiguration.class)
            .withPropertyValues(validProductionConfig());

    @Test
    void acceptsValidProductionConfig() {
        contextRunner.run(context -> assertThat(context)
                .hasNotFailed()
                .hasSingleBean(ProductionRuntimeConfigurationValidator.class));
    }

    @Test
    void failsWhenJwtSecretUsesLocalDefault() {
        contextRunner
                .withPropertyValues("bff.auth.jwt-secret=local-dev-change-me-at-least-32-bytes")
                .run(context -> {
                    assertThat(context).hasFailed();
                    assertThat(context.getStartupFailure())
                            .hasMessageContaining("BFF_JWT_SECRET must not use the local development default");
                });
    }

    @Test
    void failsWhenJwtKeyIdUsesLocalDefault() {
        contextRunner
                .withPropertyValues("bff.auth.jwt-key-id=local")
                .run(context -> {
                    assertThat(context).hasFailed();
                    assertThat(context.getStartupFailure())
                            .hasMessageContaining("BFF_JWT_KEY_ID must not use the local development default");
                });
    }

    @Test
    void failsWhenPreviousJwtKeysAreMalformed() {
        contextRunner
                .withPropertyValues("bff.auth.jwt-previous-keys=previous-key-without-secret")
                .run(context -> {
                    assertThat(context).hasFailed();
                    assertThat(context.getStartupFailure())
                            .hasMessageContaining("BFF_JWT_PREVIOUS_KEYS must use comma-separated kid=secret entries");
                });
    }

    @Test
    void failsWhenPreviousJwtSecretIsTooShort() {
        contextRunner
                .withPropertyValues("bff.auth.jwt-previous-keys=old=short")
                .run(context -> {
                    assertThat(context).hasFailed();
                    assertThat(context.getStartupFailure())
                            .hasMessageContaining("BFF_JWT_PREVIOUS_KEYS secrets must be at least 32 characters");
                });
    }

    @Test
    void failsWhenJwtAudienceIsBlank() {
        contextRunner
                .withPropertyValues("bff.auth.audience=")
                .run(context -> {
                    assertThat(context).hasFailed();
                    assertThat(context.getStartupFailure())
                            .hasMessageContaining("BFF_AUTH_AUDIENCE is required");
                });
    }

    @Test
    void failsWhenSessionStoreIsNotRedis() {
        contextRunner
                .withPropertyValues("bff.session.store=memory")
                .run(context -> {
                    assertThat(context).hasFailed();
                    assertThat(context.getStartupFailure())
                            .hasMessageContaining("BFF_SESSION_STORE must be redis");
                });
    }

    @Test
    void failsWhenRedisUsernameIsBlank() {
        contextRunner
                .withPropertyValues("spring.data.redis.username=")
                .run(context -> {
                    assertThat(context).hasFailed();
                    assertThat(context.getStartupFailure())
                            .hasMessageContaining("SPRING_DATA_REDIS_USERNAME is required");
                });
    }

    @Test
    void failsWhenRedisPasswordIsBlank() {
        contextRunner
                .withPropertyValues("spring.data.redis.password=")
                .run(context -> {
                    assertThat(context).hasFailed();
                    assertThat(context.getStartupFailure())
                            .hasMessageContaining("SPRING_DATA_REDIS_PASSWORD is required");
                });
    }

    @Test
    void failsWhenLocalLoginIsEnabled() {
        contextRunner
                .withPropertyValues("bff.auth.local-login-enabled=true")
                .run(context -> {
                    assertThat(context).hasFailed();
                    assertThat(context.getStartupFailure())
                            .hasMessageContaining("BFF_AUTH_LOCAL_LOGIN_ENABLED must be false");
                });
    }

    @Test
    void failsWhenLoginProviderIsLocal() {
        contextRunner
                .withPropertyValues("bff.auth.login-provider=local")
                .run(context -> {
                    assertThat(context).hasFailed();
                    assertThat(context.getStartupFailure())
                            .hasMessageContaining("BFF_AUTH_LOGIN_PROVIDER must not be local");
                });
    }

    @Test
    void failsWhenBcmUpstreamPointsToLocalhost() {
        contextRunner
                .withPropertyValues("bff.proxy.bcm.base-url=http://127.0.0.1:19090")
                .run(context -> {
                    assertThat(context).hasFailed();
                    assertThat(context.getStartupFailure())
                            .hasMessageContaining("BFF_PROXY_BCM_BASE_URL must not point to a local host");
                });
    }

    @Test
    void failsWhenBcmIbmClientIdIsBlank() {
        contextRunner
                .withPropertyValues("bff.proxy.bcm.ibm-client-id=")
                .run(context -> {
                    assertThat(context).hasFailed();
                    assertThat(context.getStartupFailure())
                            .hasMessageContaining("BFF_PROXY_BCM_IBM_CLIENT_ID is required");
                });
    }

    @Test
    void failsWhenBcmIbmClientSecretIsBlank() {
        contextRunner
                .withPropertyValues("bff.proxy.bcm.ibm-client-secret=")
                .run(context -> {
                    assertThat(context).hasFailed();
                    assertThat(context.getStartupFailure())
                            .hasMessageContaining("BFF_PROXY_BCM_IBM_CLIENT_SECRET is required");
                });
    }

    @Test
    void failsWhenBcmMtlsIsEnabledWithoutCertFiles() {
        contextRunner
                .withPropertyValues("bff.proxy.bcm.mtls.enabled=true")
                .run(context -> {
                    assertThat(context).hasFailed();
                    assertThat(context.getStartupFailure())
                            .hasMessageContaining("BFF_PROXY_BCM_MTLS_CERT_FILE is required");
                });
    }

    @Test
    void failsWhenBcmTlsInsecureSkipVerifyIsEnabled() {
        contextRunner
                .withPropertyValues("bff.proxy.bcm.tls.insecure-skip-verify=true")
                .run(context -> {
                    assertThat(context).hasFailed();
                    assertThat(context.getStartupFailure())
                            .hasMessageContaining("BFF_PROXY_BCM_TLS_INSECURE_SKIP_VERIFY must be false");
                });
    }

    @Test
    void failsWhenBcmMtlsInsecureSkipVerifyIsEnabled() {
        contextRunner
                .withPropertyValues("bff.proxy.bcm.mtls.insecure-skip-verify=true")
                .run(context -> {
                    assertThat(context).hasFailed();
                    assertThat(context.getStartupFailure())
                            .hasMessageContaining("BFF_PROXY_BCM_MTLS_INSECURE_SKIP_VERIFY must be false");
                });
    }

    @Test
    void failsWhenBcoUpstreamPointsToLocalhost() {
        contextRunner
                .withPropertyValues("bff.proxy.bco.base-url=http://127.0.0.1:19091")
                .run(context -> {
                    assertThat(context).hasFailed();
                    assertThat(context.getStartupFailure())
                            .hasMessageContaining("BFF_PROXY_BCO_BASE_URL must not point to a local host");
                });
    }

    @Test
    void failsWhenBcoTlsInsecureSkipVerifyIsEnabled() {
        contextRunner
                .withPropertyValues("bff.proxy.bco.tls.insecure-skip-verify=true")
                .run(context -> {
                    assertThat(context).hasFailed();
                    assertThat(context.getStartupFailure())
                            .hasMessageContaining("BFF_PROXY_BCO_TLS_INSECURE_SKIP_VERIFY must be false");
                });
    }

    @Test
    void failsWhenIamMockIsEnabled() {
        contextRunner
                .withPropertyValues("bff.entitlement.iam.mock-enabled=true")
                .run(context -> {
                    assertThat(context).hasFailed();
                    assertThat(context.getStartupFailure())
                            .hasMessageContaining("BFF_ENTITLEMENT_IAM_MOCK_ENABLED must be false");
                });
    }

    @Test
    void failsWhenConfiguredManagementMetricsTokenIsTooShort() {
        contextRunner
                .withPropertyValues("bff.management-access.metrics-token=short")
                .run(context -> {
                    assertThat(context).hasFailed();
                    assertThat(context.getStartupFailure())
                            .hasMessageContaining("BFF_MANAGEMENT_ACCESS_METRICS_TOKEN must be at least 32 characters");
                });
    }

    @Test
    void failsWhenRateLimitStoreIsMemoryAndRateLimitIsEnabled() {
        contextRunner
                .withPropertyValues("bff.rate-limit.store=memory")
                .run(context -> {
                    assertThat(context).hasFailed();
                    assertThat(context.getStartupFailure())
                            .hasMessageContaining("BFF_RATE_LIMIT_STORE must be redis");
                });
    }

    @Test
    void failsWhenForwardedForIsNotTrustedAndRateLimitIsEnabled() {
        contextRunner
                .withPropertyValues("bff.rate-limit.trust-x-forwarded-for=false")
                .run(context -> {
                    assertThat(context).hasFailed();
                    assertThat(context.getStartupFailure())
                            .hasMessageContaining("BFF_RATE_LIMIT_TRUST_X_FORWARDED_FOR must be true");
                });
    }

    @Test
    void acceptsMemoryRateLimitStoreWhenRateLimitIsDisabled() {
        contextRunner
                .withPropertyValues(
                        "bff.rate-limit.enabled=false",
                        "bff.rate-limit.store=memory")
                .run(context -> assertThat(context).hasNotFailed());
    }

    @Test
    void failsWhenHstsIsDisabled() {
        contextRunner
                .withPropertyValues("bff.security-headers.hsts.enabled=false")
                .run(context -> {
                    assertThat(context).hasFailed();
                    assertThat(context.getStartupFailure())
                            .hasMessageContaining("BFF_SECURITY_HEADERS_HSTS_ENABLED must be true");
                });
    }

    @Test
    void failsWhenHstsMaxAgeIsZero() {
        contextRunner
                .withPropertyValues("bff.security-headers.hsts.max-age-seconds=0")
                .run(context -> {
                    assertThat(context).hasFailed();
                    assertThat(context.getStartupFailure())
                            .hasMessageContaining("BFF_SECURITY_HEADERS_HSTS_MAX_AGE_SECONDS must be greater than zero");
                });
    }

    @Test
    void acceptsCorsDisabledInProduction() {
        contextRunner
                .withPropertyValues(
                        "bff.cors.enabled=false",
                        "bff.cors.allowed-origins=")
                .run(context -> assertThat(context).hasNotFailed());
    }

    @Test
    void acceptsHttpsCorsOriginsWhenCorsIsEnabled() {
        contextRunner
                .withPropertyValues(
                        "bff.cors.enabled=true",
                        "bff.cors.allowed-origins=https://bcm.example.com,https://portal.example.com")
                .run(context -> assertThat(context).hasNotFailed());
    }

    @Test
    void failsWhenCorsIsEnabledWithoutOrigins() {
        contextRunner
                .withPropertyValues(
                        "bff.cors.enabled=true",
                        "bff.cors.allowed-origins=")
                .run(context -> {
                    assertThat(context).hasFailed();
                    assertThat(context.getStartupFailure())
                            .hasMessageContaining("BFF_CORS_ALLOWED_ORIGINS must not be blank");
                });
    }

    @Test
    void failsWhenCorsOriginUsesWildcard() {
        contextRunner
                .withPropertyValues(
                        "bff.cors.enabled=true",
                        "bff.cors.allowed-origins=*")
                .run(context -> {
                    assertThat(context).hasFailed();
                    assertThat(context.getStartupFailure())
                            .hasMessageContaining("BFF_CORS_ALLOWED_ORIGINS must not contain wildcard origins");
                });
    }

    @Test
    void failsWhenCorsOriginIsNotHttps() {
        contextRunner
                .withPropertyValues(
                        "bff.cors.enabled=true",
                        "bff.cors.allowed-origins=http://bcm.example.com")
                .run(context -> {
                    assertThat(context).hasFailed();
                    assertThat(context.getStartupFailure())
                            .hasMessageContaining("BFF_CORS_ALLOWED_ORIGINS must contain only https:// origins");
                });
    }

    @Test
    void failsWhenCorsOriginPointsToLocalhost() {
        contextRunner
                .withPropertyValues(
                        "bff.cors.enabled=true",
                        "bff.cors.allowed-origins=https://localhost")
                .run(context -> {
                    assertThat(context).hasFailed();
                    assertThat(context.getStartupFailure())
                            .hasMessageContaining("BFF_CORS_ALLOWED_ORIGINS must not point to a local host");
                });
    }

    @Test
    void failsWhenCorsMaxAgeIsZero() {
        contextRunner
                .withPropertyValues(
                        "bff.cors.enabled=true",
                        "bff.cors.allowed-origins=https://bcm.example.com",
                        "bff.cors.max-age-seconds=0")
                .run(context -> {
                    assertThat(context).hasFailed();
                    assertThat(context.getStartupFailure())
                            .hasMessageContaining("BFF_CORS_MAX_AGE_SECONDS must be greater than zero");
                });
    }

    private static String[] validProductionConfig() {
        return new String[]{
                "spring.profiles.active=prod",
                "bff.cors.enabled=false",
                "bff.security-headers.hsts.enabled=true",
                "bff.auth.issuer=bcm-bff",
                "bff.auth.audience=bcm-bff",
                "bff.auth.jwt-secret=prod-secret-prod-secret-prod-secret-32",
                "bff.auth.jwt-key-id=prod-2026-05",
                "bff.auth.local-login-enabled=false",
                "bff.auth.login-provider=disabled",
                "bff.session.store=redis",
                "spring.data.redis.host=r-3ns55b26c559d944.redis.cnhk.rds.aliyuncs.com",
                "spring.data.redis.username=r-3ns55b26c559d944",
                "spring.data.redis.password=prod-redis-password",
                "bff.rate-limit.store=redis",
                "bff.rate-limit.trust-x-forwarded-for=true",
                "bff.proxy.bcm.base-url=https://eam-intgw-test.intranet.hkbea.com/hkbea/uat-int",
                "bff.proxy.bco.base-url=https://cdcuat-cmapp1.intranet.hkbea.com:9443",
                "bff.proxy.bcm.ibm-client-id=prod-client-id",
                "bff.proxy.bcm.ibm-client-secret=prod-client-secret",
                "bff.entitlement.provider=session",
                "bff.entitlement.iam.mock-enabled=false"
        };
    }

    @Import(ProductionRuntimeConfigurationValidator.class)
    @EnableConfigurationProperties({
            AuthProperties.class,
            SessionStoreProperties.class,
            BcmProxyProperties.class,
            BcoProxyProperties.class,
            EntitlementProperties.class,
            ManagementAccessProperties.class,
            RateLimitProperties.class,
            SecurityHeadersProperties.class,
            CorsProperties.class,
            RedisProperties.class
    })
    static class TestConfiguration {
    }
}

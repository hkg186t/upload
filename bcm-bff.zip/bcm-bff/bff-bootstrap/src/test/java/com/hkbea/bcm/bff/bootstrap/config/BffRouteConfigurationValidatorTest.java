package com.hkbea.bcm.bff.bootstrap.config;

import com.hkbea.bcm.bff.access.config.AuthorizationPolicyProperties;
import com.hkbea.bcm.bff.aggregation.config.AggregationProperties;
import com.hkbea.bcm.bff.proxy.config.BcmProxyProperties;
import org.junit.jupiter.api.Test;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.boot.test.context.runner.ApplicationContextRunner;
import org.springframework.context.annotation.Import;

import static org.assertj.core.api.Assertions.assertThat;

class BffRouteConfigurationValidatorTest {
    private final ApplicationContextRunner contextRunner = new ApplicationContextRunner()
            .withUserConfiguration(TestConfiguration.class)
            .withPropertyValues(validProxyRoute())
            .withPropertyValues(validAggregationRoute())
            .withPropertyValues(validAuthorizationRules());

    @Test
    void acceptsValidProxyAndAggregationRoutes() {
        contextRunner.run(context -> assertThat(context)
                .hasNotFailed()
                .hasSingleBean(BffRouteConfigurationValidator.class));
    }

    @Test
    void failsWhenAggregationStepReferencesUnknownProxyRoute() {
        contextRunner
                .withPropertyValues("bff.aggregation.routes.home-summary.steps[0].proxy-route-id=missing-route")
                .run(context -> {
                    assertThat(context).hasFailed();
                    assertThat(context.getStartupFailure())
                            .hasMessageContaining("Invalid BCM proxy route configuration: missing-route");
                });
    }

    @Test
    void failsWhenProxyPublicPathIsOutsideBcmNamespace() {
        contextRunner
                .withPropertyValues("bff.proxy.bcm.routes.user-profile.public-path=/bff/demo/user-profile")
                .run(context -> {
                    assertThat(context).hasFailed();
                    assertThat(context.getStartupFailure())
                            .hasMessageContaining("Invalid proxy public path for user-profile");
                });
    }

    @Test
    void failsWhenPublicRoutesAreDuplicated() {
        contextRunner
                .withPropertyValues("bff.proxy.bcm.routes.duplicate-profile.public-method=POST")
                .withPropertyValues("bff.proxy.bcm.routes.duplicate-profile.public-path=/bcm/demo/user-profile")
                .withPropertyValues("bff.proxy.bcm.routes.duplicate-profile.method=POST")
                .withPropertyValues("bff.proxy.bcm.routes.duplicate-profile.upstream-path=/mock/duplicate")
                .run(context -> {
                    assertThat(context).hasFailed();
                    assertThat(context.getStartupFailure())
                            .hasMessageContaining("Duplicate BFF public route: POST /bcm/demo/user-profile");
                });
    }

    @Test
    void failsWhenProxyRouteHasNoAuthorizationRule() {
        contextRunner
                .withPropertyValues("bff.proxy.bcm.routes.user-profile.public-path=/bcm/demo/unprotected-profile")
                .run(context -> {
                    assertThat(context).hasFailed();
                    assertThat(context.getStartupFailure())
                            .hasMessageContaining("Missing authorization rule for proxy route user-profile");
                });
    }

    @Test
    void failsWhenAggregationRouteHasNoAuthorizationRule() {
        contextRunner
                .withPropertyValues("bff.aggregation.routes.home-summary.public-path=/bff/demo/unprotected-summary")
                .run(context -> {
                    assertThat(context).hasFailed();
                    assertThat(context.getStartupFailure())
                            .hasMessageContaining("Missing authorization rule for aggregation route home-summary");
                });
    }

    @Test
    void failsWhenMatchingAuthorizationRuleHasNoConstraints() {
        new ApplicationContextRunner()
                .withUserConfiguration(TestConfiguration.class)
                .withPropertyValues(validProxyRoute())
                .withPropertyValues(validAggregationRoute())
                .withPropertyValues(validAggregationAuthorizationRule())
                .withPropertyValues(
                        "bff.authorization.rules.user-profile.method=POST",
                        "bff.authorization.rules.user-profile.path=/bcm/demo/user-profile"
                )
                .run(context -> {
                    assertThat(context).hasFailed();
                    assertThat(context.getStartupFailure())
                            .hasMessageContaining("Authorization rule for proxy route user-profile must define");
                });
    }

    private static String[] validProxyRoute() {
        return new String[]{
                "bff.proxy.bcm.routes.user-profile.public-method=POST",
                "bff.proxy.bcm.routes.user-profile.public-path=/bcm/demo/user-profile",
                "bff.proxy.bcm.routes.user-profile.method=POST",
                "bff.proxy.bcm.routes.user-profile.upstream-path=/corporate/v1/approval/center/user/userProfile"
        };
    }

    private static String[] validAggregationRoute() {
        return new String[]{
                "bff.aggregation.routes.home-summary.public-method=POST",
                "bff.aggregation.routes.home-summary.public-path=/bff/demo/home-summary",
                "bff.aggregation.routes.home-summary.steps[0].name=userProfile",
                "bff.aggregation.routes.home-summary.steps[0].proxy-route-id=user-profile",
                "bff.aggregation.routes.home-summary.steps[0].required=true"
        };
    }

    private static String[] validAuthorizationRules() {
        return new String[]{
                "bff.authorization.rules.user-profile.method=POST",
                "bff.authorization.rules.user-profile.path=/bcm/demo/user-profile",
                "bff.authorization.rules.user-profile.required-roles[0]=BCM_USER",
                "bff.authorization.rules.user-profile.required-scopes[0]=bcm:proxy",
                "bff.authorization.rules.user-profile.allowed-device-os[0]=Android",
                "bff.authorization.rules.user-profile.allowed-device-os[1]=iOS",
                "bff.authorization.rules.aggregation-home-summary.method=POST",
                "bff.authorization.rules.aggregation-home-summary.path=/bff/demo/home-summary",
                "bff.authorization.rules.aggregation-home-summary.required-roles[0]=BCM_USER",
                "bff.authorization.rules.aggregation-home-summary.required-scopes[0]=bcm:aggregate",
                "bff.authorization.rules.aggregation-home-summary.allowed-device-os[0]=Android",
                "bff.authorization.rules.aggregation-home-summary.allowed-device-os[1]=iOS"
        };
    }

    private static String[] validAggregationAuthorizationRule() {
        return new String[]{
                "bff.authorization.rules.aggregation-home-summary.method=POST",
                "bff.authorization.rules.aggregation-home-summary.path=/bff/demo/home-summary",
                "bff.authorization.rules.aggregation-home-summary.required-roles[0]=BCM_USER",
                "bff.authorization.rules.aggregation-home-summary.required-scopes[0]=bcm:aggregate",
                "bff.authorization.rules.aggregation-home-summary.allowed-device-os[0]=Android",
                "bff.authorization.rules.aggregation-home-summary.allowed-device-os[1]=iOS"
        };
    }

    @Import(BffRouteConfigurationValidator.class)
    @EnableConfigurationProperties({
            BcmProxyProperties.class,
            AggregationProperties.class,
            AuthorizationPolicyProperties.class
    })
    static class TestConfiguration {
    }
}

package com.hkbea.bcm.bff.bootstrap.web.proxy;

import com.fasterxml.jackson.databind.JsonNode;
import com.hkbea.bcm.bff.bootstrap.test.BffRandomPortSpringBootTest;
import com.hkbea.bcm.bff.bootstrap.web.ContractTestHeaders;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.DynamicPropertyRegistry;
import org.springframework.test.context.DynamicPropertySource;
import org.springframework.test.web.reactive.server.WebTestClient;

import java.util.List;
import java.util.Map;
import java.util.UUID;

import static com.hkbea.bcm.bff.bootstrap.web.RuntimeEnvelopeAssertions.assertSuccessEnvelope;
import static org.assertj.core.api.Assertions.assertThat;
import static org.springframework.http.MediaType.APPLICATION_JSON;

@BffRandomPortSpringBootTest(properties = {
        "bff.auth.jwt-secret=test-secret-for-success-envelope"
})
class SuccessEnvelopeIntegrationTest {
    private static final MockBcmUpstream UPSTREAM = MockBcmUpstream.start();

    @Autowired
    private WebTestClient webTestClient;

    @DynamicPropertySource
    static void proxyProperties(DynamicPropertyRegistry registry) {
        registry.add("bff.proxy.bcm.base-url", UPSTREAM::baseUrl);
    }

    @AfterAll
    static void stopUpstream() {
        UPSTREAM.stop();
    }

    @Test
    void loginReturnsRuntimeSuccessEnvelopeMatchingContract() {
        String traceId = "success-login-" + UUID.randomUUID();

        JsonNode body = login(traceId);

        assertSuccessEnvelope(body, traceId);
        assertThat(body.path("data").path("tokenType").asText()).isEqualTo("Bearer");
        assertThat(body.path("data").path("accessToken").asText()).isNotBlank();
        assertThat(body.path("data").path("refreshToken").asText()).isNotBlank();
        assertThat(body.path("data").path("user").path("username").asText()).startsWith("SUCCESS-");
    }

    @Test
    void refreshReturnsRuntimeSuccessEnvelopeMatchingContract() {
        String deviceId = "test-device-" + UUID.randomUUID();
        JsonNode loginBody = login("success-refresh-login-" + UUID.randomUUID(), deviceId);
        String originalRefreshToken = loginBody.path("data").path("refreshToken").asText();
        String traceId = "success-refresh-" + UUID.randomUUID();

        JsonNode body = ContractTestHeaders.withRequiredHeaders(webTestClient.post()
                .uri("/auth/refresh"), traceId)
                .contentType(APPLICATION_JSON)
                .bodyValue(Map.of(
                        "refreshToken", originalRefreshToken,
                        "deviceId", deviceId))
                .exchange()
                .expectStatus().isOk()
                .expectHeader().valueEquals("X-Correlation-Id", traceId)
                .expectBody(JsonNode.class)
                .returnResult()
                .getResponseBody();

        assertSuccessEnvelope(body, traceId);
        assertThat(body.path("data").path("tokenType").asText()).isEqualTo("Bearer");
        assertThat(body.path("data").path("accessToken").asText()).isNotBlank();
        assertThat(body.path("data").path("refreshToken").asText()).isNotBlank();
        assertThat(body.path("data").path("refreshToken").asText()).isNotEqualTo(originalRefreshToken);
    }

    @Test
    void logoutReturnsRuntimeSuccessEnvelopeMatchingContract() {
        String token = login("success-logout-login-" + UUID.randomUUID())
                .path("data")
                .path("accessToken")
                .asText();
        String traceId = "success-logout-" + UUID.randomUUID();

        JsonNode body = ContractTestHeaders.withRequiredHeaders(webTestClient.post()
                .uri("/auth/logout"), traceId)
                .header("Authorization", "Bearer " + token)
                .exchange()
                .expectStatus().isOk()
                .expectHeader().valueEquals("X-Correlation-Id", traceId)
                .expectBody(JsonNode.class)
                .returnResult()
                .getResponseBody();

        assertSuccessEnvelope(body, traceId);
        assertThat(body.path("data").path("success").asBoolean()).isTrue();
    }

    @Test
    void proxyReturnsRuntimeSuccessEnvelopeMatchingContract() {
        String token = login("success-proxy-login-" + UUID.randomUUID())
                .path("data")
                .path("accessToken")
                .asText();
        String traceId = "success-proxy-" + UUID.randomUUID();

        JsonNode body = ContractTestHeaders.withRequiredHeaders(webTestClient.post()
                .uri("/bcm/demo/user-profile"), traceId)
                .contentType(APPLICATION_JSON)
                .header("Authorization", "Bearer " + token)
                .bodyValue(Map.of("mode", "normal"))
                .exchange()
                .expectStatus().isOk()
                .expectHeader().valueEquals("X-Correlation-Id", traceId)
                .expectBody(JsonNode.class)
                .returnResult()
                .getResponseBody();

        assertSuccessEnvelope(body, traceId);
        assertThat(body.path("data").path("ok").asBoolean()).isTrue();
        assertThat(body.path("data").path("mode").asText()).isEqualTo("normal");
    }

    @Test
    void aggregationReturnsRuntimeSuccessEnvelopeMatchingContract() {
        String token = login("success-aggregation-login-" + UUID.randomUUID())
                .path("data")
                .path("accessToken")
                .asText();
        String traceId = "success-aggregation-" + UUID.randomUUID();

        JsonNode body = ContractTestHeaders.withRequiredHeaders(webTestClient.post()
                .uri("/bff/demo/home-summary"), traceId)
                .contentType(APPLICATION_JSON)
                .header("Authorization", "Bearer " + token)
                .bodyValue(Map.of("mode", "normal"))
                .exchange()
                .expectStatus().isOk()
                .expectHeader().valueEquals("X-Correlation-Id", traceId)
                .expectBody(JsonNode.class)
                .returnResult()
                .getResponseBody();

        assertSuccessEnvelope(body, traceId);
        assertThat(body.path("data").path("partial").asBoolean()).isFalse();
        assertThat(body.path("data").path("items").path("userProfile").path("ok").asBoolean()).isTrue();
        assertThat(body.path("data").path("errors").size()).isZero();
    }

    private JsonNode login(String traceId) {
        return login(traceId, "test-device-" + UUID.randomUUID());
    }

    private JsonNode login(String traceId, String deviceId) {
        JsonNode body = ContractTestHeaders.withRequiredHeaders(webTestClient.post()
                .uri("/auth/login"), traceId)
                .contentType(APPLICATION_JSON)
                .bodyValue(Map.of(
                        "username", "SUCCESS-" + UUID.randomUUID(),
                        "password", "demo",
                        "parentAccountId", "015521104095930",
                        "deviceId", deviceId,
                        "deviceOs", "Android",
                        "locale", "en",
                        "roles", List.of("BCM_USER"),
                        "scopes", List.of("bcm:proxy", "bcm:aggregate")))
                .exchange()
                .expectStatus().isOk()
                .expectHeader().valueEquals("X-Correlation-Id", traceId)
                .expectBody(JsonNode.class)
                .returnResult()
                .getResponseBody();

        assertThat(body).isNotNull();
        return body;
    }

}

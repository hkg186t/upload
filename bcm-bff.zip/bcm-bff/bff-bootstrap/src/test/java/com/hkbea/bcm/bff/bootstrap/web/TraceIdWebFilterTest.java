package com.hkbea.bcm.bff.bootstrap.web;

import com.hkbea.bcm.bff.shared.context.RequestContextKeys;
import com.hkbea.bcm.bff.shared.http.HeaderConstants;
import org.junit.jupiter.api.Test;
import org.springframework.mock.http.server.reactive.MockServerHttpRequest;
import org.springframework.mock.web.server.MockServerWebExchange;
import org.springframework.web.server.ServerWebExchange;
import org.springframework.web.server.WebFilterChain;
import reactor.core.publisher.Mono;

import java.util.concurrent.atomic.AtomicReference;

import static org.assertj.core.api.Assertions.assertThat;

class TraceIdWebFilterTest {

    @Test
    void preservesSafeRequestTraceIdAcrossRequestResponseAndContext() {
        TraceIdWebFilter filter = new TraceIdWebFilter(() -> "fallback-trace");
        MockServerWebExchange exchange = MockServerWebExchange.from(MockServerHttpRequest
                .get("/health")
                .header(HeaderConstants.X_REQUEST_ID, "trace-123_ABC.def:ghi"));
        AtomicReference<ServerWebExchange> capturedExchange = new AtomicReference<>();
        AtomicReference<String> capturedContextTraceId = new AtomicReference<>();

        filter.filter(exchange, capture(capturedExchange, capturedContextTraceId)).block();

        assertThat(capturedExchange.get().getRequest().getHeaders().get(HeaderConstants.X_REQUEST_ID))
                .containsExactly("trace-123_ABC.def:ghi");
        assertThat(capturedExchange.get().getRequest().getHeaders().get(HeaderConstants.X_CORRELATION_ID))
                .containsExactly("trace-123_ABC.def:ghi");
        assertThat(capturedExchange.get().getResponse().getHeaders().getFirst(HeaderConstants.X_REQUEST_ID))
                .isEqualTo("trace-123_ABC.def:ghi");
        assertThat(capturedContextTraceId.get()).isEqualTo("trace-123_ABC.def:ghi");
    }

    @Test
    void replacesUnsafeTraceHeadersWithFallbackTraceId() {
        TraceIdWebFilter filter = new TraceIdWebFilter(() -> "fallback-trace");
        MockServerWebExchange exchange = MockServerWebExchange.from(MockServerHttpRequest
                .get("/health")
                .header(HeaderConstants.X_REQUEST_ID, "trace-1\nBCM_HTTP_ACCESS forged=true")
                .header(HeaderConstants.X_CORRELATION_ID, "null"));
        AtomicReference<ServerWebExchange> capturedExchange = new AtomicReference<>();
        AtomicReference<String> capturedContextTraceId = new AtomicReference<>();

        filter.filter(exchange, capture(capturedExchange, capturedContextTraceId)).block();

        assertThat(capturedExchange.get().getRequest().getHeaders().get(HeaderConstants.X_REQUEST_ID))
                .containsExactly("fallback-trace");
        assertThat(capturedExchange.get().getRequest().getHeaders().get(HeaderConstants.X_CORRELATION_ID))
                .containsExactly("fallback-trace");
        assertThat(capturedExchange.get().getResponse().getHeaders().getFirst(HeaderConstants.X_REQUEST_ID))
                .isEqualTo("fallback-trace");
        assertThat(capturedContextTraceId.get()).isEqualTo("fallback-trace");
    }

    @Test
    void fallsBackWhenTraceIdIsTooLong() {
        TraceIdWebFilter filter = new TraceIdWebFilter(() -> "fallback-trace");
        String tooLong = "a".repeat(TraceIdWebFilter.MAX_TRACE_ID_LENGTH + 1);
        MockServerWebExchange exchange = MockServerWebExchange.from(MockServerHttpRequest
                .get("/health")
                .header(HeaderConstants.X_REQUEST_ID, tooLong));
        AtomicReference<ServerWebExchange> capturedExchange = new AtomicReference<>();
        AtomicReference<String> capturedContextTraceId = new AtomicReference<>();

        filter.filter(exchange, capture(capturedExchange, capturedContextTraceId)).block();

        assertThat(capturedExchange.get().getRequest().getHeaders().get(HeaderConstants.X_REQUEST_ID))
                .containsExactly("fallback-trace");
        assertThat(capturedContextTraceId.get()).isEqualTo("fallback-trace");
    }

    private static WebFilterChain capture(
            AtomicReference<ServerWebExchange> capturedExchange,
            AtomicReference<String> capturedContextTraceId
    ) {
        return currentExchange -> Mono.deferContextual(context -> {
            capturedExchange.set(currentExchange);
            capturedContextTraceId.set(context.get(RequestContextKeys.TRACE_ID));
            return Mono.empty();
        });
    }
}

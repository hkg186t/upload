package com.hkbea.bcm.bff.bootstrap.web;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.JsonNode;
import com.hkbea.bcm.bff.bootstrap.config.RequestSizeLimitProperties;
import org.junit.jupiter.api.Test;
import org.springframework.core.io.buffer.DataBuffer;
import org.springframework.core.io.buffer.DataBufferUtils;
import org.springframework.core.io.buffer.DefaultDataBufferFactory;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.mock.http.server.reactive.MockServerHttpRequest;
import org.springframework.mock.web.server.MockServerWebExchange;
import org.springframework.web.server.WebFilterChain;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

import java.nio.charset.StandardCharsets;
import java.util.List;
import java.util.concurrent.atomic.AtomicInteger;

import static com.hkbea.bcm.bff.bootstrap.web.RuntimeEnvelopeAssertions.assertErrorEnvelope;
import static org.assertj.core.api.Assertions.assertThat;

class RequestSizeLimitWebFilterTest {
    private static final ObjectMapper OBJECT_MAPPER = new ObjectMapper();

    @Test
    void rejectsRequestWhenContentLengthExceedsLimit() {
        RequestSizeLimitWebFilter filter = new RequestSizeLimitWebFilter(properties("/bcm/", 8), errorWriter());
        AtomicInteger chainCalls = new AtomicInteger();
        WebFilterChain chain = exchange -> {
            chainCalls.incrementAndGet();
            return Mono.empty();
        };
        MockServerWebExchange exchange = MockServerWebExchange.from(MockServerHttpRequest
                .post("/bcm/demo/user-profile")
                .header(HttpHeaders.CONTENT_LENGTH, "16"));

        filter.filter(exchange, chain).block();

        assertThat(chainCalls).hasValue(0);
        assertThat(exchange.getResponse().getStatusCode()).isEqualTo(HttpStatus.PAYLOAD_TOO_LARGE);
        JsonNode body = readBody(exchange);
        assertErrorEnvelope(body, "413", "Request Entity Too Large");
    }

    @Test
    void rejectsChunkedRequestWhenObservedBodyExceedsLimit() {
        RequestSizeLimitWebFilter filter = new RequestSizeLimitWebFilter(properties("/bff/", 8), errorWriter());
        AtomicInteger chainCalls = new AtomicInteger();
        WebFilterChain chain = exchange -> {
            chainCalls.incrementAndGet();
            return DataBufferUtils.join(exchange.getRequest().getBody())
                    .flatMap(dataBuffer -> {
                        DataBufferUtils.release(dataBuffer);
                        return Mono.empty();
                    });
        };
        MockServerWebExchange exchange = MockServerWebExchange.from(MockServerHttpRequest
                .post("/bff/demo/home-summary")
                .body(Flux.just(buffer("12345"), buffer("67890"))));

        filter.filter(exchange, chain).block();

        assertThat(chainCalls).hasValue(1);
        assertThat(exchange.getResponse().getStatusCode()).isEqualTo(HttpStatus.PAYLOAD_TOO_LARGE);
    }

    @Test
    void allowsRequestWithinLimit() {
        RequestSizeLimitWebFilter filter = new RequestSizeLimitWebFilter(properties("/auth/", 16), errorWriter());
        AtomicInteger chainCalls = new AtomicInteger();
        WebFilterChain chain = exchange -> {
            chainCalls.incrementAndGet();
            exchange.getResponse().setStatusCode(HttpStatus.OK);
            return DataBufferUtils.join(exchange.getRequest().getBody())
                    .flatMap(dataBuffer -> {
                        DataBufferUtils.release(dataBuffer);
                        return Mono.empty();
                    });
        };
        MockServerWebExchange exchange = MockServerWebExchange.from(MockServerHttpRequest
                .post("/auth/login")
                .body(Flux.just(buffer("{}"))));

        filter.filter(exchange, chain).block();

        assertThat(chainCalls).hasValue(1);
        assertThat(exchange.getResponse().getStatusCode()).isEqualTo(HttpStatus.OK);
    }

    @Test
    void ignoresPathsWithoutMatchingRule() {
        RequestSizeLimitWebFilter filter = new RequestSizeLimitWebFilter(properties("/bcm/", 1), errorWriter());
        AtomicInteger chainCalls = new AtomicInteger();
        WebFilterChain chain = exchange -> {
            chainCalls.incrementAndGet();
            return Mono.empty();
        };
        MockServerWebExchange exchange = MockServerWebExchange.from(MockServerHttpRequest
                .post("/health")
                .header(HttpHeaders.CONTENT_LENGTH, "1024"));

        filter.filter(exchange, chain).block();

        assertThat(chainCalls).hasValue(1);
        assertThat(exchange.getResponse().getStatusCode()).isNull();
    }

    private static RequestSizeLimitProperties properties(String pathPrefix, long maxBytes) {
        RequestSizeLimitProperties properties = new RequestSizeLimitProperties();
        properties.setRules(List.of(new RequestSizeLimitProperties.Rule("test", pathPrefix, maxBytes)));
        return properties;
    }

    private static BffErrorResponseWriter errorWriter() {
        return new BffErrorResponseWriter(OBJECT_MAPPER);
    }

    private static JsonNode readBody(MockServerWebExchange exchange) {
        try {
            return OBJECT_MAPPER.readTree(exchange.getResponse().getBodyAsString().block());
        } catch (Exception error) {
            throw new AssertionError("Failed to read response body", error);
        }
    }

    private static DataBuffer buffer(String value) {
        return DefaultDataBufferFactory.sharedInstance.wrap(value.getBytes(StandardCharsets.UTF_8));
    }
}

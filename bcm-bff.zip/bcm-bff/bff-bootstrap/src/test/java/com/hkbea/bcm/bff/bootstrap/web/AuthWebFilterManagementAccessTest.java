package com.hkbea.bcm.bff.bootstrap.web;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.JsonNode;
import com.hkbea.bcm.bff.access.config.AuthorizationPolicyProperties;
import com.hkbea.bcm.bff.access.entitlement.EntitlementContext;
import com.hkbea.bcm.bff.access.model.AuthResult;
import com.hkbea.bcm.bff.access.model.LoginCommand;
import com.hkbea.bcm.bff.access.model.RefreshCommand;
import com.hkbea.bcm.bff.access.model.SessionRecord;
import com.hkbea.bcm.bff.access.model.TokenPair;
import com.hkbea.bcm.bff.access.service.AuthService;
import com.hkbea.bcm.bff.access.service.AuthorizationPolicyService;
import com.hkbea.bcm.bff.bootstrap.config.ManagementAccessProperties;
import com.hkbea.bcm.bff.proxy.config.BcoProxyProperties;
import com.hkbea.bcm.bff.proxy.config.BcmProxyProperties;
import com.hkbea.bcm.bff.shared.api.BffException;
import com.hkbea.bcm.bff.shared.api.ErrorCode;
import org.junit.jupiter.api.Test;
import org.springframework.http.HttpStatus;
import org.springframework.mock.http.server.reactive.MockServerHttpRequest;
import org.springframework.mock.web.server.MockServerWebExchange;
import org.springframework.web.server.WebFilterChain;
import reactor.core.publisher.Mono;

import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicInteger;

import static com.hkbea.bcm.bff.bootstrap.web.RuntimeEnvelopeAssertions.assertErrorEnvelope;
import static org.assertj.core.api.Assertions.assertThat;

class AuthWebFilterManagementAccessTest {
    private static final String METRICS_TOKEN = "monitoring-token-monitoring-token-32";
    private static final ObjectMapper OBJECT_MAPPER = new ObjectMapper();

    @Test
    void allowsPrometheusWithConfiguredManagementTokenWithoutUserBearer() {
        CountingAuthService authService = new CountingAuthService();
        AuthWebFilter filter = newFilter(authService, managementProperties(METRICS_TOKEN));
        AtomicBoolean chainCalled = new AtomicBoolean(false);
        MockServerWebExchange exchange = MockServerWebExchange.from(MockServerHttpRequest
                .get("/actuator/prometheus")
                .header(ManagementAccessProperties.DEFAULT_METRICS_TOKEN_HEADER, METRICS_TOKEN));
        WebFilterChain chain = currentExchange -> {
            chainCalled.set(true);
            currentExchange.getResponse().setStatusCode(HttpStatus.OK);
            return Mono.empty();
        };

        filter.filter(exchange, chain).block();

        assertThat(chainCalled).isTrue();
        assertThat(authService.validateCalls()).isZero();
        assertThat(exchange.getResponse().getStatusCode()).isEqualTo(HttpStatus.OK);
    }

    @Test
    void keepsPrometheusProtectedWhenManagementTokenIsWrong() {
        CountingAuthService authService = new CountingAuthService();
        AuthWebFilter filter = newFilter(authService, managementProperties(METRICS_TOKEN));
        AtomicBoolean chainCalled = new AtomicBoolean(false);
        MockServerWebExchange exchange = MockServerWebExchange.from(MockServerHttpRequest
                .get("/actuator/prometheus")
                .header(ManagementAccessProperties.DEFAULT_METRICS_TOKEN_HEADER, "wrong-token"));

        filter.filter(exchange, currentExchange -> {
            chainCalled.set(true);
            return Mono.empty();
        }).block();

        assertThat(chainCalled).isFalse();
        assertThat(authService.validateCalls()).isOne();
        assertThat(exchange.getResponse().getStatusCode()).isEqualTo(HttpStatus.UNAUTHORIZED);
        JsonNode body = readBody(exchange);
        assertErrorEnvelope(body, "401", "Invalid or missing Bearer Token");
    }

    @Test
    void keepsPrometheusProtectedWhenManagementTokenIsNotConfigured() {
        CountingAuthService authService = new CountingAuthService();
        AuthWebFilter filter = newFilter(authService, managementProperties(""));
        MockServerWebExchange exchange = MockServerWebExchange.from(MockServerHttpRequest
                .get("/actuator/prometheus")
                .header(ManagementAccessProperties.DEFAULT_METRICS_TOKEN_HEADER, METRICS_TOKEN));

        filter.filter(exchange, currentExchange -> Mono.empty()).block();

        assertThat(authService.validateCalls()).isOne();
        assertThat(exchange.getResponse().getStatusCode()).isEqualTo(HttpStatus.UNAUTHORIZED);
    }

    @Test
    void writesLegacySessionExpiredForCorporateProxySessionExpiry() {
        CountingAuthService authService = new CountingAuthService(ErrorCode.SESSION_EXPIRED);
        AuthWebFilter filter = newFilter(authService, managementProperties(""));
        AtomicBoolean chainCalled = new AtomicBoolean(false);
        MockServerWebExchange exchange = MockServerWebExchange.from(MockServerHttpRequest
                .post("/corporate/v1/approval/center/user/userProfile")
                .header("Authorization", "Bearer stale-token"));

        filter.filter(exchange, currentExchange -> {
            chainCalled.set(true);
            return Mono.empty();
        }).block();

        assertThat(chainCalled).isFalse();
        assertThat(exchange.getResponse().getStatusCode()).isEqualTo(HttpStatus.OK);
        JsonNode body = readBody(exchange);
        assertThat(body.path("status").asText()).isEqualTo("419");
        assertThat(body.path("code").asText()).isEqualTo("419");
        assertThat(body.path("message").asText()).isEqualTo("Session Expired");
        assertThat(body.has("traceId")).isFalse();
    }

    @Test
    void writesLegacySessionExpiredForBcoProxySessionExpiry() {
        CountingAuthService authService = new CountingAuthService(ErrorCode.SESSION_EXPIRED);
        AuthWebFilter filter = newFilter(authService, managementProperties(""));
        AtomicBoolean chainCalled = new AtomicBoolean(false);
        MockServerWebExchange exchange = MockServerWebExchange.from(MockServerHttpRequest
                .post("/digx/v1/private")
                .header("Authorization", "Bearer stale-token"));

        filter.filter(exchange, currentExchange -> {
            chainCalled.set(true);
            return Mono.empty();
        }).block();

        assertThat(chainCalled).isFalse();
        assertThat(exchange.getResponse().getStatusCode()).isEqualTo(HttpStatus.OK);
        JsonNode body = readBody(exchange);
        assertThat(body.path("status").asText()).isEqualTo("419");
        assertThat(body.path("code").asText()).isEqualTo("419");
        assertThat(body.path("message").asText()).isEqualTo("Session Expired");
    }

    @Test
    void writesLegacySessionExpiredForBcoNonceSessionExpiry() {
        CountingAuthService authService = new CountingAuthService(ErrorCode.SESSION_EXPIRED);
        AuthWebFilter filter = newFilter(authService, managementProperties(""));
        AtomicBoolean chainCalled = new AtomicBoolean(false);
        MockServerWebExchange exchange = MockServerWebExchange.from(MockServerHttpRequest
                .post("/digx/v1/session/nonce")
                .header("Authorization", "Bearer stale-token"));

        filter.filter(exchange, currentExchange -> {
            chainCalled.set(true);
            currentExchange.getResponse().setStatusCode(HttpStatus.OK);
            return Mono.empty();
        }).block();

        assertThat(chainCalled).isFalse();
        assertThat(exchange.getResponse().getStatusCode()).isEqualTo(HttpStatus.OK);
        JsonNode body = readBody(exchange);
        assertThat(body.path("status").asText()).isEqualTo("419");
        assertThat(body.path("code").asText()).isEqualTo("419");
        assertThat(body.path("message").asText()).isEqualTo("Session Expired");
    }

    private static AuthWebFilter newFilter(AuthService authService, ManagementAccessProperties properties) {
        AuthorizationPolicyService authorizationPolicyService = new AuthorizationPolicyService(
                new AuthorizationPolicyProperties(),
                session -> Mono.just(EntitlementContext.fromSession(session)));
        return new AuthWebFilter(
                authService,
                authorizationPolicyService,
                properties,
                new BcoProxyProperties(),
                new BcmProxyProperties(),
                new BffErrorResponseWriter(OBJECT_MAPPER));
    }

    private static JsonNode readBody(MockServerWebExchange exchange) {
        try {
            return OBJECT_MAPPER.readTree(exchange.getResponse().getBodyAsString().block());
        } catch (Exception error) {
            throw new AssertionError("Failed to read response body", error);
        }
    }

    private static ManagementAccessProperties managementProperties(String metricsToken) {
        ManagementAccessProperties properties = new ManagementAccessProperties();
        properties.setMetricsToken(metricsToken);
        return properties;
    }

    private static final class CountingAuthService implements AuthService {
        private final AtomicInteger validateCalls = new AtomicInteger();
        private final ErrorCode validationError;

        CountingAuthService() {
            this(ErrorCode.UNAUTHORIZED);
        }

        CountingAuthService(ErrorCode validationError) {
            this.validationError = validationError;
        }

        int validateCalls() {
            return validateCalls.get();
        }

        @Override
        public Mono<AuthResult> login(LoginCommand command) {
            return Mono.error(new UnsupportedOperationException());
        }

        @Override
        public Mono<TokenPair> refresh(RefreshCommand command) {
            return Mono.error(new UnsupportedOperationException());
        }

        @Override
        public Mono<SessionRecord> validateAccessToken(String authorizationHeader) {
            validateCalls.incrementAndGet();
            return Mono.error(new BffException(validationError));
        }

        @Override
        public Mono<Void> logout(String authorizationHeader) {
            return Mono.error(new UnsupportedOperationException());
        }

        @Override
        public Mono<Void> logout(SessionRecord session) {
            return Mono.error(new UnsupportedOperationException());
        }
    }
}

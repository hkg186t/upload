package com.hkbea.bcm.bff.bootstrap.web.proxy;

import com.hkbea.bcm.bff.bootstrap.test.BffRandomPortSpringBootTest;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.Test;
import org.springframework.test.context.DynamicPropertyRegistry;
import org.springframework.test.context.DynamicPropertySource;

import java.time.Duration;

import static org.assertj.core.api.Assertions.assertThat;

@BffRandomPortSpringBootTest(properties = {
        "bff.proxy.health-check.startup-enabled=true",
        "bff.proxy.health-check.scheduled-enabled=false",
        "bff.proxy.bcm.health-check.enabled=false",
        "bff.proxy.bco.prefer-fallback-ip=true",
        "bff.proxy.bco.health-check.path=/digx/cz/v1/publicKey",
        "bff.proxy.bco.health-check.method=GET"
})
class BcoProxyHealthCheckIntegrationTest {
    private static final MockBcmUpstream UPSTREAM = MockBcmUpstream.start();

    @DynamicPropertySource
    static void proxyProperties(DynamicPropertyRegistry registry) {
        registry.add("bff.proxy.bco.base-url", () -> "http://unresolvable-bco-health.test:" + UPSTREAM.port());
        registry.add("bff.proxy.bco.fallback-ip", () -> "127.0.0.1");
    }

    @AfterAll
    static void stopUpstream() {
        UPSTREAM.stop();
    }

    @Test
    void startupHealthCheckPrewarmsPreferredBcoFallbackPath() {
        MockBcmUpstream.CapturedRequest captured = awaitStartupHealthCheck();

        assertThat(captured.method()).isEqualTo("GET");
        assertThat(captured.path()).isEqualTo("/digx/cz/v1/publicKey");
        assertThat(captured.header("Host")).isEqualTo("unresolvable-bco-health.test:" + UPSTREAM.port());
        assertThat(captured.header("Accept")).isNull();
    }

    private static MockBcmUpstream.CapturedRequest awaitStartupHealthCheck() {
        long deadline = System.nanoTime() + Duration.ofSeconds(5).toNanos();
        while (System.nanoTime() < deadline) {
            var captured = UPSTREAM.lastCapturedRequest();
            if (captured.isPresent()) {
                return captured.get();
            }
            sleep();
        }
        throw new AssertionError("BCO startup health check did not reach fallback upstream");
    }

    private static void sleep() {
        try {
            Thread.sleep(50);
        } catch (InterruptedException error) {
            Thread.currentThread().interrupt();
            throw new AssertionError("Interrupted while waiting for BCO startup health check", error);
        }
    }
}

package com.hkbea.bcm.bff.bootstrap.contract;

import org.yaml.snakeyaml.Yaml;

import java.io.IOException;
import java.io.InputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.stream.Stream;

final class OpenApiContractSnapshot {
    private static final Set<String> HTTP_METHODS = Set.of(
            "delete", "get", "head", "options", "patch", "post", "put", "trace"
    );
    private static final Yaml YAML = new Yaml();

    private final Path openApiDirectory;
    private final Map<String, Object> root;

    private OpenApiContractSnapshot(Path openApiDirectory, Map<String, Object> root) {
        this.openApiDirectory = openApiDirectory;
        this.root = root;
    }

    static OpenApiContractSnapshot load() {
        Path openApiDirectory = resolveOpenApiDirectory();
        return new OpenApiContractSnapshot(openApiDirectory, readYaml(openApiDirectory.resolve("root.yaml")));
    }

    List<ApiOperation> operations() {
        return operationSnapshots().stream()
                .map(operation -> new ApiOperation(operation.method(), operation.path()))
                .toList();
    }

    List<ApiSecurity> operationSecurity() {
        return operationSnapshots().stream()
                .map(operation -> new ApiSecurity(
                        new ApiOperation(operation.method(), operation.path()),
                        hasBearerAuth(effectiveSecurity(operation))))
                .toList();
    }

    List<ApiHandler> apiHandlers() {
        return operationSnapshots().stream()
                .map(operation -> new ApiHandler(
                        new ApiOperation(operation.method(), operation.path()),
                        requiredText(operation.operation(), "operationId", "OpenAPI operation", operation),
                        stringList(operation.operation().get("tags"))))
                .toList();
    }

    List<ApiParameters> apiParameters() {
        return operationSnapshots().stream()
                .map(operation -> new ApiParameters(
                        new ApiOperation(operation.method(), operation.path()),
                        parameterIds(operation.operation().get("parameters"))))
                .toList();
    }

    List<ApiResponseHeaders> successResponseHeaders() {
        return operationSnapshots().stream()
                .flatMap(operation -> mapAt(operation.operation(), "responses").entrySet().stream()
                        .filter(response -> isSuccessStatus(response.getKey()))
                        .map(response -> new ApiResponseHeaders(
                                new ApiOperation(operation.method(), operation.path()),
                                response.getKey(),
                                headerNames(asMap(response.getValue()).get("headers")))))
                .toList();
    }

    List<ApiSuccessEnvelope> successEnvelopes() {
        return operationSnapshots().stream()
                .flatMap(operation -> mapAt(operation.operation(), "responses").entrySet().stream()
                        .filter(response -> isSuccessStatus(response.getKey()))
                        .flatMap(response -> successEnvelope(
                                operation,
                                response.getKey(),
                                asMap(response.getValue())).stream()))
                .toList();
    }

    List<ApiErrorResponse> errorResponses() {
        return operationSnapshots().stream()
                .flatMap(operation -> mapAt(operation.operation(), "responses").entrySet().stream()
                        .filter(response -> isErrorStatus(response.getKey()))
                        .map(response -> errorResponse(operation, response.getKey(), asMap(response.getValue()))))
                .toList();
    }

    List<String> errorSchemaRequiredFields() {
        Map<String, Object> common = readYaml(openApiDirectory.resolve("common.yaml"));
        return stringList(mapAt(common, "components", "schemas", "Error").get("required"));
    }

    List<CommonErrorResponse> commonErrorResponses() {
        Map<String, Object> common = readYaml(openApiDirectory.resolve("common.yaml"));
        return mapAt(common, "components", "responses").entrySet().stream()
                .map(response -> commonErrorResponse(response.getKey(), asMap(response.getValue())))
                .toList();
    }

    List<AccessRule> accessRules() {
        return operationSnapshots().stream()
                .flatMap(operation -> {
                    Map<String, Object> extension = optionalMapAt(operation.operation(), "x-bcm-bff-access");
                    if (extension == null) {
                        return Stream.empty();
                    }
                    return Stream.of(new AccessRule(
                            requiredText(extension, "ruleId", "x-bcm-bff-access", operation),
                            text(extension, "method", operation.method()).toUpperCase(Locale.ROOT),
                            text(extension, "path", operation.path()),
                            stringList(extension.get("requiredRoles")),
                            stringList(extension.get("requiredScopes")),
                            stringList(extension.get("allowedDeviceOs"))));
                })
                .toList();
    }

    List<ProxyRoute> proxyRoutes() {
        return operationSnapshots().stream()
                .flatMap(operation -> {
                    Map<String, Object> extension = optionalMapAt(operation.operation(), "x-bcm-bff-route");
                    if (extension == null) {
                        return Stream.empty();
                    }
                    return Stream.of(new ProxyRoute(
                            requiredText(extension, "routeId", "x-bcm-bff-route", operation),
                            text(extension, "publicMethod", operation.method()).toUpperCase(Locale.ROOT),
                            text(extension, "publicPath", operation.path()),
                            text(extension, "upstreamMethod", text(extension, "method", "POST"))
                                    .toUpperCase(Locale.ROOT),
                            requiredText(extension, "upstreamPath", "x-bcm-bff-route", operation),
                            number(extension, "responseTimeoutMillis", 30000),
                            bool(extension, "htmlResponseMeansSessionExpired", true),
                            integer(extension, "retryMaxAttempts", 1),
                            number(extension, "retryBackoffMillis", 100),
                            integer(extension, "bulkheadMaxConcurrentRequests", 200),
                            bool(extension, "circuitBreakerEnabled", true),
                            integer(extension, "circuitBreakerFailureThreshold", 5),
                            number(extension, "circuitBreakerOpenMillis", 30000),
                            stringList(extension.get("requiredRoles")),
                            stringList(extension.get("requiredScopes")),
                            stringList(extension.get("allowedDeviceOs"))));
                })
                .toList();
    }

    List<AggregationRoute> aggregationRoutes() {
        return operationSnapshots().stream()
                .flatMap(operation -> {
                    Map<String, Object> extension = optionalMapAt(operation.operation(), "x-bcm-bff-aggregation");
                    if (extension == null) {
                        return Stream.empty();
                    }
                    return Stream.of(new AggregationRoute(
                            requiredText(extension, "aggregationId", "x-bcm-bff-aggregation", operation),
                            text(extension, "publicMethod", operation.method()).toUpperCase(Locale.ROOT),
                            text(extension, "publicPath", operation.path()),
                            number(extension, "responseTimeoutMillis", 30000),
                            bool(extension, "partialResponseEnabled", true),
                            integer(extension, "maxConcurrentSteps", 4),
                            aggregationSteps(extension.get("steps"), operation),
                            stringList(extension.get("requiredRoles")),
                            stringList(extension.get("requiredScopes")),
                            stringList(extension.get("allowedDeviceOs"))));
                })
                .toList();
    }

    Set<String> responseStatuses(String method, String path) {
        Map<String, Object> pathItem = mapAt(root, "paths", path);
        pathItem = resolveRefIfNeeded(pathItem, rootFile()).value();
        Map<String, Object> operation = mapAt(pathItem, method.toLowerCase(Locale.ROOT));
        Map<String, Object> responses = mapAt(operation, "responses");
        return responses.keySet();
    }

    private List<OpenApiOperation> operationSnapshots() {
        return mapAt(root, "paths").entrySet().stream()
                .flatMap(entry -> {
                    String path = entry.getKey();
                    ResolvedMap pathItem = resolveRefIfNeeded(asMap(entry.getValue()), rootFile());
                    return pathItem.entrySet().stream()
                            .filter(methodEntry -> isHttpMethod(methodEntry.getKey()))
                            .map(methodEntry -> new OpenApiOperation(
                                    methodEntry.getKey().toUpperCase(Locale.ROOT),
                                    path,
                                    asMap(methodEntry.getValue()),
                                    pathItem.sourceFile()));
                })
                .toList();
    }

    private static boolean isHttpMethod(String key) {
        return HTTP_METHODS.contains(key.toLowerCase(Locale.ROOT));
    }

    private Object effectiveSecurity(OpenApiOperation operation) {
        if (operation.operation().containsKey("security")) {
            return operation.operation().get("security");
        }
        return root.get("security");
    }

    private static boolean hasBearerAuth(Object security) {
        if (security == null) {
            return false;
        }
        if (!(security instanceof List<?> requirements)) {
            throw new IllegalStateException("Invalid OpenAPI security declaration: " + security);
        }
        return requirements.stream()
                .map(OpenApiContractSnapshot::asMap)
                .anyMatch(requirement -> requirement.containsKey("bearerAuth"));
    }

    private static boolean isSuccessStatus(String status) {
        return status.length() == 3 && status.startsWith("2");
    }

    private static boolean isErrorStatus(String status) {
        return status.length() == 3 && !status.startsWith("2");
    }

    private List<ApiSuccessEnvelope> successEnvelope(OpenApiOperation operation, String status, Map<String, Object> value) {
        Map<String, Object> response = resolveRefIfNeeded(value, operation.sourceFile()).value();
        Map<String, Object> content = optionalMapAt(response, "content");
        if (content == null || !content.containsKey("application/json")) {
            return List.of();
        }

        Map<String, Object> json = mapAt(content, "application/json");
        Map<String, Object> schemaRef = mapAt(json, "schema");
        ResolvedMap schema = resolveRefIfNeeded(schemaRef, operation.sourceFile());
        List<Map<String, Object>> allOf = allOf(schema.value());
        if (allOf.stream().noneMatch(OpenApiContractSnapshot::isSuccessResponseBaseRef)) {
            return List.of();
        }

        Map<String, Object> example = optionalMapAt(json, "example");
        return List.of(new ApiSuccessEnvelope(
                new ApiOperation(operation.method(), operation.path()),
                status,
                refName(schemaRef),
                successEnvelopeRequiredFields(allOf, schema.sourceFile()),
                textOrBlank(example, "code"),
                textOrBlank(example, "message")));
    }

    private ApiErrorResponse errorResponse(OpenApiOperation operation, String status, Map<String, Object> value) {
        Map<String, Object> response = resolveRefIfNeeded(value, operation.sourceFile()).value();
        Map<String, Object> content = optionalMapAt(response, "content");
        List<String> contentTypes = content == null ? List.of() : content.keySet().stream()
                .map(Object::toString)
                .toList();
        String schemaRef = "";
        if (content != null && content.containsKey("application/json")) {
            schemaRef = refAt(content, "application/json", "schema");
        }
        return new ApiErrorResponse(
                new ApiOperation(operation.method(), operation.path()),
                status,
                contentTypes,
                schemaRef);
    }

    private static CommonErrorResponse commonErrorResponse(String name, Map<String, Object> response) {
        Map<String, Object> example = mapAt(response, "content", "application/json", "example");
        return new CommonErrorResponse(
                name,
                text(example, "status", ""),
                text(example, "code", ""),
                text(example, "message", ""));
    }

    private List<String> successEnvelopeRequiredFields(List<Map<String, Object>> allOf, Path baseFile) {
        return allOf.stream()
                .flatMap(schemaPart -> stringList(resolveRefIfNeeded(schemaPart, baseFile).value().get("required")).stream())
                .distinct()
                .toList();
    }

    private Path rootFile() {
        return openApiDirectory.resolve("root.yaml");
    }

    private ResolvedMap resolveRefIfNeeded(Map<String, Object> value, Path baseFile) {
        Object ref = value.get("$ref");
        if (ref == null) {
            return new ResolvedMap(value, baseFile);
        }
        return resolveRef(ref.toString(), baseFile);
    }

    private ResolvedMap resolveRef(String ref, Path baseFile) {
        String[] parts = ref.split("#", 2);
        Path file = parts[0].isBlank()
                ? baseFile
                : baseFile.getParent().resolve(parts[0].replaceFirst("^\\./", "")).normalize();
        Map<String, Object> document = readYaml(file);
        if (parts.length == 1 || parts[1].isBlank()) {
            return new ResolvedMap(document, file);
        }

        Object current = document;
        for (String token : parts[1].replaceFirst("^/", "").split("/")) {
            current = asMap(current).get(decodeJsonPointerToken(token));
        }
        return new ResolvedMap(asMap(current), file);
    }

    private static Path resolveOpenApiDirectory() {
        Path current = Path.of("").toAbsolutePath();
        for (Path candidate : List.of(
                current.resolve("bff-contract-adapter/src/main/openapi"),
                current.resolve("../bff-contract-adapter/src/main/openapi")
        )) {
            if (Files.isRegularFile(candidate.resolve("root.yaml"))) {
                return candidate.normalize();
            }
        }
        throw new IllegalStateException("Unable to locate bff-contract-adapter/src/main/openapi");
    }

    private static Map<String, Object> readYaml(Path path) {
        try (InputStream input = Files.newInputStream(path)) {
            return asMap(YAML.load(input));
        } catch (IOException error) {
            throw new IllegalStateException("Failed to read OpenAPI YAML: " + path, error);
        }
    }

    private static Map<String, Object> mapAt(Map<String, Object> map, String key) {
        return asMap(map.get(key));
    }

    private static Map<String, Object> mapAt(Map<String, Object> map, String firstKey, String secondKey) {
        return mapAt(mapAt(map, firstKey), secondKey);
    }

    private static Map<String, Object> mapAt(
            Map<String, Object> map,
            String firstKey,
            String secondKey,
            String thirdKey
    ) {
        return mapAt(mapAt(map, firstKey, secondKey), thirdKey);
    }

    private static Map<String, Object> optionalMapAt(Map<String, Object> map, String key) {
        Object value = map.get(key);
        return value == null ? null : asMap(value);
    }

    private static String requiredText(
            Map<String, Object> extension,
            String key,
            String extensionName,
            OpenApiOperation operation
    ) {
        String value = text(extension, key, "");
        if (value.isBlank()) {
            throw new IllegalStateException("Missing " + key + " in " + extensionName
                    + " for " + operation.method() + " " + operation.path());
        }
        return value;
    }

    private static String text(Map<String, Object> extension, String key, String defaultValue) {
        Object value = extension.get(key);
        if (value == null) {
            return defaultValue;
        }
        return value.toString().trim();
    }

    private static String textOrBlank(Map<String, Object> extension, String key) {
        return extension == null ? "" : text(extension, key, "");
    }

    private static long number(Map<String, Object> extension, String key, long defaultValue) {
        Object value = extension.get(key);
        if (value == null || value.toString().isBlank()) {
            return defaultValue;
        }
        if (value instanceof Number number) {
            return number.longValue();
        }
        return Long.parseLong(value.toString().trim());
    }

    private static int integer(Map<String, Object> extension, String key, int defaultValue) {
        long value = number(extension, key, defaultValue);
        if (value > Integer.MAX_VALUE) {
            throw new IllegalStateException("Integer value is too large for " + key + ": " + value);
        }
        return (int) value;
    }

    private static boolean bool(Map<String, Object> extension, String key, boolean defaultValue) {
        Object value = extension.get(key);
        if (value == null || value.toString().isBlank()) {
            return defaultValue;
        }
        if (value instanceof Boolean bool) {
            return bool;
        }
        return Boolean.parseBoolean(value.toString().trim());
    }

    private static List<String> stringList(Object value) {
        if (value == null || value.toString().isBlank()) {
            return List.of();
        }
        if (value instanceof List<?> list) {
            return list.stream()
                    .map(Object::toString)
                    .map(String::trim)
                    .filter(item -> !item.isBlank())
                    .toList();
        }
        return Stream.of(value.toString().split(","))
                .map(String::trim)
                .filter(item -> !item.isBlank())
                .toList();
    }

    private static List<String> parameterIds(Object value) {
        if (value == null) {
            return List.of();
        }
        if (!(value instanceof List<?> parameters)) {
            throw new IllegalStateException("Invalid OpenAPI parameters declaration: " + value);
        }
        return parameters.stream()
                .map(OpenApiContractSnapshot::parameterId)
                .toList();
    }

    private static String parameterId(Object value) {
        Map<String, Object> parameter = asMap(value);
        Object ref = parameter.get("$ref");
        if (ref != null) {
            return decodeJsonPointerToken(ref.toString().replaceFirst("^.*#/", "").replaceFirst("^.*/", ""));
        }
        return text(parameter, "name", "");
    }

    private static List<String> headerNames(Object value) {
        if (value == null) {
            return List.of();
        }
        return asMap(value).keySet().stream()
                .map(Object::toString)
                .toList();
    }

    private static String refAt(Map<String, Object> map, String firstKey, String secondKey) {
        return text(mapAt(map, firstKey, secondKey), "$ref", "");
    }

    private static List<Map<String, Object>> allOf(Map<String, Object> schema) {
        Object value = schema.get("allOf");
        if (value == null) {
            return List.of();
        }
        if (!(value instanceof List<?> allOf)) {
            throw new IllegalStateException("Invalid OpenAPI allOf declaration: " + value);
        }
        return allOf.stream()
                .map(OpenApiContractSnapshot::asMap)
                .toList();
    }

    private static boolean isSuccessResponseBaseRef(Map<String, Object> value) {
        return "SuccessResponseBase".equals(refName(value));
    }

    private static String refName(Map<String, Object> value) {
        Object ref = value.get("$ref");
        if (ref == null) {
            return "";
        }
        return decodeJsonPointerToken(ref.toString().replaceFirst("^.*#/", "").replaceFirst("^.*/", ""));
    }

    private static List<AggregationStep> aggregationSteps(Object value, OpenApiOperation operation) {
        List<String> rawSteps = stringList(value);
        if (rawSteps.isEmpty()) {
            throw new IllegalStateException("Missing steps in x-bcm-bff-aggregation for "
                    + operation.method() + " " + operation.path());
        }
        return rawSteps.stream()
                .map(OpenApiContractSnapshot::aggregationStep)
                .toList();
    }

    private static AggregationStep aggregationStep(String rawStep) {
        String[] parts = Stream.of(rawStep.split(":"))
                .map(String::trim)
                .filter(part -> !part.isBlank())
                .toArray(String[]::new);
        if (parts.length < 2 || parts.length > 3) {
            throw new IllegalStateException("Invalid x-bcm-bff-aggregation step: " + rawStep);
        }
        return new AggregationStep(
                parts[0],
                parts[1],
                parts.length == 2 || requiredAggregationStep(parts[2]));
    }

    private static boolean requiredAggregationStep(String value) {
        return switch (value.toLowerCase(Locale.ROOT)) {
            case "required", "true" -> true;
            case "optional", "false" -> false;
            default -> throw new IllegalStateException("Invalid aggregation step required flag: " + value);
        };
    }

    @SuppressWarnings("unchecked")
    private static Map<String, Object> asMap(Object value) {
        return (Map<String, Object>) value;
    }

    private static String decodeJsonPointerToken(String token) {
        return token.replace("~1", "/").replace("~0", "~");
    }

    record ApiOperation(String method, String path) {
    }

    record ApiSecurity(ApiOperation operation, boolean bearerAuthRequired) {
    }

    record ApiHandler(ApiOperation operation, String operationId, List<String> tags) {
    }

    record ApiParameters(ApiOperation operation, List<String> parameterIds) {
    }

    record ApiResponseHeaders(ApiOperation operation, String status, List<String> headerNames) {
    }

    record ApiSuccessEnvelope(
            ApiOperation operation,
            String status,
            String schemaName,
            List<String> requiredFields,
            String exampleCode,
            String exampleMessage
    ) {
    }

    record ApiErrorResponse(ApiOperation operation, String status, List<String> contentTypes, String schemaRef) {
    }

    record CommonErrorResponse(String name, String status, String code, String message) {
    }

    record AccessRule(
            String ruleId,
            String method,
            String path,
            List<String> requiredRoles,
            List<String> requiredScopes,
            List<String> allowedDeviceOs
    ) {
    }

    record ProxyRoute(
            String routeId,
            String publicMethod,
            String publicPath,
            String method,
            String upstreamPath,
            long responseTimeoutMillis,
            boolean htmlResponseMeansSessionExpired,
            int retryMaxAttempts,
            long retryBackoffMillis,
            int bulkheadMaxConcurrentRequests,
            boolean circuitBreakerEnabled,
            int circuitBreakerFailureThreshold,
            long circuitBreakerOpenMillis,
            List<String> requiredRoles,
            List<String> requiredScopes,
            List<String> allowedDeviceOs
    ) {
    }

    record AggregationRoute(
            String aggregationId,
            String publicMethod,
            String publicPath,
            long responseTimeoutMillis,
            boolean partialResponseEnabled,
            int maxConcurrentSteps,
            List<AggregationStep> steps,
            List<String> requiredRoles,
            List<String> requiredScopes,
            List<String> allowedDeviceOs
    ) {
    }

    record AggregationStep(
            String name,
            String proxyRouteId,
            boolean required
    ) {
    }

    private record OpenApiOperation(String method, String path, Map<String, Object> operation, Path sourceFile) {
    }

    private record ResolvedMap(Map<String, Object> value, Path sourceFile) {
        Set<Map.Entry<String, Object>> entrySet() {
            return value.entrySet();
        }
    }
}

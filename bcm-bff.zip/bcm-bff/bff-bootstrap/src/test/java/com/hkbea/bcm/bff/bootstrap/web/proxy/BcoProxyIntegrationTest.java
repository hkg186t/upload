package com.hkbea.bcm.bff.bootstrap.web.proxy;

import com.fasterxml.jackson.databind.JsonNode;
import com.hkbea.bcm.bff.access.model.SessionRecord;
import com.hkbea.bcm.bff.access.token.JwtTokenService;
import com.hkbea.bcm.bff.access.token.TokenUse;
import com.hkbea.bcm.bff.bootstrap.test.BffRandomPortSpringBootTest;
import com.hkbea.bcm.bff.bootstrap.web.ContractTestHeaders;
import com.hkbea.bcm.bff.shared.session.SessionState;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.system.CapturedOutput;
import org.springframework.boot.test.system.OutputCaptureExtension;
import org.springframework.http.MediaType;
import org.springframework.test.context.DynamicPropertyRegistry;
import org.springframework.test.context.DynamicPropertySource;
import org.springframework.test.web.reactive.server.WebTestClient;

import java.time.Instant;
import java.util.List;
import java.util.UUID;

import static org.assertj.core.api.Assertions.assertThat;

@BffRandomPortSpringBootTest(properties = {
        "bff.proxy.health-check.startup-enabled=false",
        "bff.proxy.health-check.scheduled-enabled=false",
        "bff.proxy.bco.response-timeout-millis=100",
        "bff.proxy.bco.public-key-retry-max-attempts=2",
        "bff.proxy.bco.public-key-retry-backoff-millis=10",
        "logging.level.com.hkbea.bcm.bff.proxy.service.WebClientBcoProxyService=DEBUG"
})
@ExtendWith(OutputCaptureExtension.class)
class BcoProxyIntegrationTest {
    private static final MockBcmUpstream UPSTREAM = MockBcmUpstream.start();

    @Autowired
    private WebTestClient webTestClient;

    @Autowired
    private JwtTokenService jwtTokenService;

    @DynamicPropertySource
    static void proxyProperties(DynamicPropertyRegistry registry) {
        registry.add("bff.proxy.bco.base-url", () -> "http://unresolvable-bco.test:" + UPSTREAM.port());
        registry.add("bff.proxy.bco.fallback-ip", () -> "127.0.0.1");
    }

    @AfterAll
    static void stopUpstream() {
        UPSTREAM.stop();
    }

    @Test
    void legacyLoginStoresBcoCookiesAndNonceInjectsSessionCookie(CapturedOutput output) {
        String loginTraceId = "bco-login-" + UUID.randomUUID();

        JsonNode loginBody = ContractTestHeaders.withRequiredHeaders(webTestClient.post()
                        .uri("/api/login?locale=en"), loginTraceId)
                .header("User-Agent", "Android_Ant_Client")
                .header("X-Device-Id", "device-1")
                .header("X-Device-Os", "Android")
                .header("RSAKeyIndicator", "CDC010")
                .header("loginType", "customer")
                .header("Login-Auth-Type", "password")
                .header("Login-Auth-Data", "encrypted-auth-data")
                .header("token", "44501692")
                .contentType(MediaType.APPLICATION_FORM_URLENCODED)
                .bodyValue("j_username=KYLEWENG%40015521104095930&j_password=encrypted-password")
                .exchange()
                .expectStatus().isOk()
                .expectBody(JsonNode.class)
                .returnResult()
                .getResponseBody();

        assertThat(loginBody).isNotNull();
        String accessToken = loginBody.path("accessToken").asText();
        assertThat(accessToken).isNotBlank();

        MockBcmUpstream.CapturedRequest loginCaptured = UPSTREAM.lastCapturedRequest().orElseThrow();
        assertThat(loginCaptured.method()).isEqualTo("POST");
        assertThat(loginCaptured.path()).isEqualTo("/digx/j_security_check");
        assertThat(loginCaptured.query()).isEqualTo("locale=en");
        assertThat(loginCaptured.header("User-Agent")).isEqualTo("Android_Ant_Client");
        assertThat(loginCaptured.header("Locale")).isEqualTo("en");
        assertThat(loginCaptured.header("RSAKeyIndicator")).isEqualTo("CDC010");
        assertThat(loginCaptured.header("loginType")).isEqualTo("customer");
        assertThat(loginCaptured.header("Login-Auth-Type")).isEqualTo("password");
        assertThat(loginCaptured.header("Login-Auth-Data")).isEqualTo("encrypted-auth-data");
        assertThat(loginCaptured.header("token")).isEqualTo("44501692");
        assertThat(loginCaptured.header("Content-Type")).isEqualTo(MediaType.APPLICATION_FORM_URLENCODED_VALUE);
        assertThat(loginCaptured.header("Authorization")).isNull();
        assertThat(loginCaptured.header("Cookie")).isNull();
        assertThat(loginCaptured.body()).contains("j_username=KYLEWENG%40015521104095930");
        assertThat(loginCaptured.body()).contains("j_password=encrypted-password");
        assertThat(loginCaptured.body()).contains("locale=en");

        String nonceTraceId = "bco-nonce-" + UUID.randomUUID();
        JsonNode nonceBody = ContractTestHeaders.withRequiredHeaders(webTestClient.post()
                        .uri("/digx/v1/session/nonce?locale=en"), nonceTraceId)
                .header("Authorization", "Bearer " + accessToken)
                .header("User-Agent", "Android_Ant_Client")
                .header("X-Noncecount", "50")
                .contentType(MediaType.APPLICATION_JSON)
                .bodyValue("{}")
                .exchange()
                .expectStatus().isOk()
                .expectBody(JsonNode.class)
                .returnResult()
                .getResponseBody();

        assertThat(nonceBody).isNotNull();
        assertThat(nonceBody.path("status").asInt()).isEqualTo(200);
        assertThat(nonceBody.path("headers").path("X-Nonce").get(0).asText())
                .isEqualTo("{\"nonce\":[\"nonce-1\",\"nonce-2\"]}");
        assertThat(nonceBody.path("body").asText()).isEqualTo("{\"ok\":true,\"system\":\"bco\"}");

        MockBcmUpstream.CapturedRequest nonceCaptured = UPSTREAM.lastCapturedRequest().orElseThrow();
        assertThat(nonceCaptured.method()).isEqualTo("POST");
        assertThat(nonceCaptured.path()).isEqualTo("/digx/v1/session/nonce");
        assertThat(nonceCaptured.query()).isEqualTo("locale=en");
        assertThat(nonceCaptured.header("User-Agent")).isEqualTo("Android_Ant_Client");
        assertThat(nonceCaptured.header("Locale")).isEqualTo("en");
        assertThat(nonceCaptured.header("x-noncecount")).isEqualTo("50");
        assertThat(nonceCaptured.header("Content-Type")).isEqualTo(MediaType.APPLICATION_JSON_VALUE);
        assertThat(nonceCaptured.header("Authorization")).isNull();
        assertThat(nonceCaptured.header("Cookie"))
                .isEqualTo("JSESSIONID=test-jsession!NONE; _WL_AUTHCOOKIE_JSESSIONID=test-wl-auth");
        assertThat(output)
                .contains("BFF_PROXY_PREFER_FALLBACK system=BCO traceId=" + loginTraceId)
                .contains("BCO_PROXY_RESPONSE traceId=" + loginTraceId)
                .contains("BFF_PROXY_PREFER_FALLBACK system=BCO traceId=" + nonceTraceId)
                .contains("BCO_PROXY_RESPONSE traceId=" + nonceTraceId)
                .contains("upstreamStatus=200")
                .contains("fallback=true")
                .contains("body={\"ok\":true,\"system\":\"bco\"}");
        assertThat(output).doesNotContain("BFF_PROXY_FALLBACK system=BCO traceId=" + loginTraceId);
        assertThat(output).doesNotContain("BFF_PROXY_FALLBACK system=BCO traceId=" + nonceTraceId);
    }

    @Test
    void nonceWithExpiredBffSessionReturnsLegacySessionExpiredBody(CapturedOutput output) {
        String traceId = "bco-nonce-expired-" + UUID.randomUUID();

        JsonNode body = ContractTestHeaders.withRequiredHeaders(webTestClient.post()
                        .uri("/digx/v1/session/nonce?locale=en"), traceId)
                .header("Authorization", "Bearer " + expiredAccessToken())
                .header("User-Agent", "Android_Ant_Client")
                .header("X-Noncecount", "50")
                .contentType(MediaType.APPLICATION_JSON)
                .bodyValue("{}")
                .exchange()
                .expectStatus().isOk()
                .expectBody(JsonNode.class)
                .returnResult()
                .getResponseBody();

        assertThat(body).isNotNull();
        assertThat(body.path("status").asText()).isEqualTo("419");
        assertThat(body.path("code").asText()).isEqualTo("419");
        assertThat(body.path("message").asText()).isEqualTo("Session Expired");
        assertThat(body.has("headers")).isFalse();
        assertThat(body.has("body")).isFalse();
        assertThat(output).doesNotContain("BCO_PROXY_REQUEST traceId=" + traceId);
    }

    @Test
    void publicBcoRequestUsesLegacyGoHeaderWhitelist() {
        String traceId = "bco-public-key-" + UUID.randomUUID();

        JsonNode body = ContractTestHeaders.withRequiredHeaders(webTestClient.get()
                        .uri("/digx/cz/v1/publicKey?locale=en"), traceId)
                .header("User-Agent", "Android_Ant_Client")
                .header("Content-Type", "application/json")
                .header("Accept", "application/json")
                .header("Authorization", "Bearer must-not-forward")
                .header("Cookie", "client-cookie=must-not-forward")
                .header("sign", "must-not-forward")
                .header("appid", "must-not-forward")
                .header("workspaceid", "must-not-forward")
                .header("RSAKeyIndicator", "rsa-key-indicator")
                .header("loginType", "mobile")
                .header("Login-Auth-Type", "public-auth")
                .header("Login-Auth-Data", "public-auth-data")
                .header("token", "legacy-token")
                .exchange()
                .expectStatus().isOk()
                .expectBody(JsonNode.class)
                .returnResult()
                .getResponseBody();

        assertThat(body).isNotNull();
        assertThat(body.path("status").asInt()).isEqualTo(200);
        assertThat(body.path("headers").path("Content-Type").get(0).asText()).isEqualTo("application/json");
        assertThat(body.path("body").asText()).isEqualTo("{\"ok\":true,\"system\":\"bco\",\"key\":\"public\"}");

        MockBcmUpstream.CapturedRequest captured = UPSTREAM.lastCapturedRequest().orElseThrow();
        assertThat(captured.method()).isEqualTo("GET");
        assertThat(captured.path()).isEqualTo("/digx/cz/v1/publicKey");
        assertThat(captured.query()).isEqualTo("locale=en");
        assertThat(captured.header("User-Agent")).isEqualTo("Android_Ant_Client");
        assertThat(captured.header("RSAKeyIndicator")).isEqualTo("rsa-key-indicator");
        assertThat(captured.header("loginType")).isEqualTo("mobile");
        assertThat(captured.header("Login-Auth-Type")).isEqualTo("public-auth");
        assertThat(captured.header("Login-Auth-Data")).isEqualTo("public-auth-data");
        assertThat(captured.header("token")).isEqualTo("legacy-token");
        assertThat(captured.header("Locale")).isEqualTo("en");
        assertThat(captured.header("Content-Type")).isNull();
        assertThat(captured.header("Accept")).isNull();
        assertThat(captured.header("Authorization")).isNull();
        assertThat(captured.header("Cookie")).isNull();
        assertThat(captured.header("sign")).isNull();
        assertThat(captured.header("appid")).isNull();
        assertThat(captured.header("workspaceid")).isNull();
        assertThat(captured.header("X-Request-Id")).isNull();
        assertThat(captured.header("X-Correlation-Id")).isNull();
        assertThat(captured.header("X-Channel")).isNull();
        assertThat(captured.header("X-App-Id")).isNull();
    }

    @Test
    void publicKeyRetriesRetryableTimeoutOnce(CapturedOutput output) {
        String traceId = "bco-public-key-retry-" + UUID.randomUUID();
        String retryKey = UUID.randomUUID().toString();

        JsonNode body = ContractTestHeaders.withRequiredHeaders(webTestClient.get()
                        .uri("/digx/cz/v1/publicKey?locale=en&mode=slow-once&retryKey=" + retryKey), traceId)
                .header("User-Agent", "Android_Ant_Client")
                .exchange()
                .expectStatus().isOk()
                .expectBody(JsonNode.class)
                .returnResult()
                .getResponseBody();

        assertThat(body).isNotNull();
        assertThat(body.path("status").asInt()).isEqualTo(200);
        assertThat(body.path("body").asText()).isEqualTo("{\"ok\":true,\"system\":\"bco\",\"key\":\"public\"}");
        assertThat(UPSTREAM.bcoPublicKeyAttempts(retryKey)).isEqualTo(2);
        assertThat(output)
                .contains("BCO_PROXY_RETRY traceId=" + traceId)
                .contains("retryAttempt=1")
                .contains("errorType=TimeoutException");
    }

    private String expiredAccessToken() {
        Instant now = Instant.now();
        SessionRecord session = new SessionRecord(
                "expired-bco-nonce-session",
                "KYLEWENG@015521104095930",
                "015521104095930",
                "device-1",
                "Android",
                List.of(),
                List.of(),
                "JSESSIONID=expired-jsession; _WL_AUTHCOOKIE_JSESSIONID=expired-wl-auth",
                SessionState.ACTIVE,
                1,
                "expired-refresh-token-id",
                now.minusSeconds(120),
                now.minusSeconds(120));
        return jwtTokenService.issue(session, TokenUse.ACCESS, -60);
    }
}

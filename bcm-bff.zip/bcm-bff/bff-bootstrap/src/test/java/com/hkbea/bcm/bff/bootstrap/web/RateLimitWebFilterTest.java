package com.hkbea.bcm.bff.bootstrap.web;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.JsonNode;
import com.hkbea.bcm.bff.bootstrap.config.RateLimitProperties;
import org.junit.jupiter.api.Test;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.mock.http.server.reactive.MockServerHttpRequest;
import org.springframework.mock.web.server.MockServerWebExchange;
import org.springframework.web.server.WebFilterChain;
import reactor.core.publisher.Mono;

import java.net.InetSocketAddress;
import java.time.Clock;
import java.time.Instant;
import java.time.ZoneOffset;
import java.util.List;
import java.util.concurrent.atomic.AtomicInteger;

import static com.hkbea.bcm.bff.bootstrap.web.RuntimeEnvelopeAssertions.assertErrorEnvelope;
import static org.assertj.core.api.Assertions.assertThat;

class RateLimitWebFilterTest {
    private static final Clock CLOCK = Clock.fixed(Instant.parse("2026-05-17T00:00:00Z"), ZoneOffset.UTC);
    private static final ObjectMapper OBJECT_MAPPER = new ObjectMapper();

    @Test
    void rejectsRequestsAboveRuleLimitForSameIp() {
        RateLimitWebFilter filter = new RateLimitWebFilter(properties("/auth/", 2), errorWriter(), CLOCK);
        AtomicInteger chainCalls = new AtomicInteger();
        WebFilterChain chain = exchange -> {
            chainCalls.incrementAndGet();
            return Mono.empty();
        };

        MockServerWebExchange first = exchange("/auth/login", "203.0.113.1");
        MockServerWebExchange second = exchange("/auth/login", "203.0.113.1");
        MockServerWebExchange third = exchange("/auth/login", "203.0.113.1");

        filter.filter(first, chain).block();
        filter.filter(second, chain).block();
        filter.filter(third, chain).block();

        assertThat(chainCalls).hasValue(2);
        assertThat(third.getResponse().getStatusCode()).isEqualTo(HttpStatus.TOO_MANY_REQUESTS);
        assertThat(third.getResponse().getHeaders().getFirst("X-RateLimit-Remaining")).isEqualTo("0");
        JsonNode body = readBody(third);
        assertErrorEnvelope(body, "429", "Rate limit exceeded");
    }

    @Test
    void bearerTokensUseSeparateBucketsBeforeAuthentication() {
        RateLimitWebFilter filter = new RateLimitWebFilter(properties("/bcm/", 1), errorWriter(), CLOCK);
        AtomicInteger chainCalls = new AtomicInteger();
        WebFilterChain chain = exchange -> {
            chainCalls.incrementAndGet();
            return Mono.empty();
        };

        MockServerWebExchange firstToken = exchangeWithBearer("/bcm/demo/user-profile", "203.0.113.1", "token-one");
        MockServerWebExchange secondToken = exchangeWithBearer("/bcm/demo/user-profile", "203.0.113.1", "token-two");
        MockServerWebExchange firstTokenAgain = exchangeWithBearer("/bcm/demo/user-profile", "203.0.113.1", "token-one");

        filter.filter(firstToken, chain).block();
        filter.filter(secondToken, chain).block();
        filter.filter(firstTokenAgain, chain).block();

        assertThat(chainCalls).hasValue(2);
        assertThat(firstTokenAgain.getResponse().getStatusCode()).isEqualTo(HttpStatus.TOO_MANY_REQUESTS);
    }

    @Test
    void ignoresPathsWithoutMatchingRule() {
        RateLimitWebFilter filter = new RateLimitWebFilter(properties("/auth/", 1), errorWriter(), CLOCK);
        AtomicInteger chainCalls = new AtomicInteger();
        WebFilterChain chain = exchange -> {
            chainCalls.incrementAndGet();
            return Mono.empty();
        };

        filter.filter(exchange("/health", "203.0.113.1"), chain).block();
        filter.filter(exchange("/health", "203.0.113.1"), chain).block();
        filter.filter(exchange("/health", "203.0.113.1"), chain).block();

        assertThat(chainCalls).hasValue(3);
    }

    @Test
    void ignoresForwardedForWhenItIsNotTrusted() {
        RateLimitProperties properties = properties("/auth/", 1);
        properties.setTrustXForwardedFor(false);
        RateLimitWebFilter filter = new RateLimitWebFilter(properties, errorWriter(), CLOCK);
        AtomicInteger chainCalls = new AtomicInteger();
        WebFilterChain chain = exchange -> {
            chainCalls.incrementAndGet();
            return Mono.empty();
        };

        filter.filter(exchange("/auth/login", "203.0.113.1", "10.0.0.5"), chain).block();
        filter.filter(exchange("/auth/login", "203.0.113.2", "10.0.0.5"), chain).block();

        assertThat(chainCalls).hasValue(1);
    }

    private static RateLimitProperties properties(String pathPrefix, int maxRequests) {
        RateLimitProperties properties = new RateLimitProperties();
        properties.setTrustXForwardedFor(true);
        properties.setRules(List.of(new RateLimitProperties.Rule("test", pathPrefix, maxRequests, 60)));
        return properties;
    }

    private static BffErrorResponseWriter errorWriter() {
        return new BffErrorResponseWriter(OBJECT_MAPPER);
    }

    private static JsonNode readBody(MockServerWebExchange exchange) {
        try {
            return OBJECT_MAPPER.readTree(exchange.getResponse().getBodyAsString().block());
        } catch (Exception error) {
            throw new AssertionError("Failed to read response body", error);
        }
    }

    private static MockServerWebExchange exchange(String path, String clientIp) {
        return exchange(path, clientIp, "192.0.2.10");
    }

    private static MockServerWebExchange exchangeWithBearer(String path, String clientIp, String token) {
        return MockServerWebExchange.from(MockServerHttpRequest
                .post(path)
                .header("X-Forwarded-For", clientIp)
                .header(HttpHeaders.AUTHORIZATION, "Bearer " + token));
    }

    private static MockServerWebExchange exchange(String path, String clientIp, String remoteAddress) {
        return MockServerWebExchange.from(MockServerHttpRequest
                .get(path)
                .remoteAddress(new InetSocketAddress(remoteAddress, 12345))
                .header("X-Forwarded-For", clientIp));
    }
}

package com.hkbea.bcm.bff.bootstrap.ratelimit;

import com.hkbea.bcm.bff.bootstrap.config.RateLimitProperties;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.data.redis.connection.RedisStandaloneConfiguration;
import org.springframework.data.redis.connection.lettuce.LettuceConnectionFactory;
import org.springframework.data.redis.core.ReactiveStringRedisTemplate;
import org.testcontainers.containers.GenericContainer;
import org.testcontainers.junit.jupiter.Container;
import org.testcontainers.junit.jupiter.Testcontainers;
import org.testcontainers.utility.DockerImageName;

import java.time.Duration;
import java.time.Instant;
import java.util.UUID;

import static org.assertj.core.api.Assertions.assertThat;

@Testcontainers(disabledWithoutDocker = true)
class RedisRateLimitStoreIntegrationTest {
    private static final DockerImageName REDIS_IMAGE = DockerImageName.parse("redis:7-alpine");
    private static final long NOW_MILLIS = Instant.parse("2026-05-17T00:00:00Z").toEpochMilli();

    @Container
    static final GenericContainer<?> redis = new GenericContainer<>(REDIS_IMAGE)
            .withExposedPorts(6379);

    private LettuceConnectionFactory connectionFactory;
    private ReactiveStringRedisTemplate redisTemplate;
    private RateLimitProperties properties;
    private RateLimitProperties.Rule rule;

    @BeforeEach
    void setUp() {
        RedisStandaloneConfiguration redisConfig = new RedisStandaloneConfiguration(
                redis.getHost(),
                redis.getMappedPort(6379));
        connectionFactory = new LettuceConnectionFactory(redisConfig);
        connectionFactory.afterPropertiesSet();
        redisTemplate = new ReactiveStringRedisTemplate(connectionFactory);

        properties = new RateLimitProperties();
        properties.setStore(RateLimitProperties.Store.REDIS);
        properties.setRedisKeyPrefix("bcm-bff-rl-it:" + UUID.randomUUID());
        rule = new RateLimitProperties.Rule("test", "/bcm/", 2, 60);
    }

    @AfterEach
    void tearDown() {
        if (connectionFactory != null) {
            connectionFactory.destroy();
        }
    }

    @Test
    void recordsRequestsAcrossInstancesWithSharedRedisBucket() {
        RedisRateLimitStore firstInstance = new RedisRateLimitStore(redisTemplate, properties);
        RedisRateLimitStore secondInstance = new RedisRateLimitStore(redisTemplate, properties);

        RateLimitDecision first = firstInstance.record(rule, "bearer:abc123", NOW_MILLIS, 60_000, 2).block();
        RateLimitDecision second = secondInstance.record(rule, "bearer:abc123", NOW_MILLIS, 60_000, 2).block();
        RateLimitDecision third = firstInstance.record(rule, "bearer:abc123", NOW_MILLIS, 60_000, 2).block();

        assertThat(first).isNotNull();
        assertThat(first.allowed()).isTrue();
        assertThat(first.remaining()).isEqualTo(1);
        assertThat(second).isNotNull();
        assertThat(second.allowed()).isTrue();
        assertThat(second.remaining()).isEqualTo(0);
        assertThat(third).isNotNull();
        assertThat(third.allowed()).isFalse();
        assertThat(third.remaining()).isEqualTo(0);
    }

    @Test
    void keepsRateLimitBucketExpiringInRedis() {
        RedisRateLimitStore store = new RedisRateLimitStore(redisTemplate, properties);

        RateLimitDecision decision = store.record(rule, "ip:def456", NOW_MILLIS, 60_000, 2).block();

        assertThat(decision).isNotNull();
        assertThat(decision.allowed()).isTrue();
        assertThat(decision.resetAtMillis()).isGreaterThan(NOW_MILLIS);
        assertThat(decision.resetAtMillis()).isLessThanOrEqualTo(NOW_MILLIS + 60_000);

        Duration ttl = redisTemplate.getExpire(redisKey("ip:def456")).block();
        assertThat(ttl).isNotNull();
        assertThat(ttl.toMillis()).isGreaterThan(0);
        assertThat(ttl).isLessThanOrEqualTo(Duration.ofSeconds(60));
    }

    private String redisKey(String bucketKey) {
        return properties.getRedisKeyPrefix() + ":rate-limit:" + rule.getId() + ":" + bucketKey;
    }
}

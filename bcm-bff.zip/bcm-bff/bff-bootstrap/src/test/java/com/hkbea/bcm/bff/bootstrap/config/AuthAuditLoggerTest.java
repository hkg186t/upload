package com.hkbea.bcm.bff.bootstrap.config;

import com.hkbea.bcm.bff.access.audit.AuthAuditLogger;
import com.hkbea.bcm.bff.access.config.AuthProperties;
import com.hkbea.bcm.bff.access.model.LoginCommand;
import com.hkbea.bcm.bff.access.model.SessionRecord;
import com.hkbea.bcm.bff.access.token.JwtValidationException;
import com.hkbea.bcm.bff.access.token.JwtValidationFailure;
import com.hkbea.bcm.bff.shared.api.BffException;
import com.hkbea.bcm.bff.shared.api.ErrorCode;
import com.hkbea.bcm.bff.shared.session.SessionState;
import io.micrometer.core.instrument.Counter;
import io.micrometer.core.instrument.simple.SimpleMeterRegistry;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.boot.test.system.CapturedOutput;
import org.springframework.boot.test.system.OutputCaptureExtension;

import java.time.Instant;
import java.util.List;

import static org.assertj.core.api.Assertions.assertThat;

@ExtendWith(OutputCaptureExtension.class)
class AuthAuditLoggerTest {
    private static final String JWT_FAILURE_METRIC = "bcm.bff.auth.jwt.validation.failures";

    @Test
    void logsLoginSuccessWithoutRawSensitiveValues(CapturedOutput output) {
        AuthAuditLogger auditLogger = new AuthAuditLogger();

        auditLogger.loginSuccess(AuthProperties.LoginProvider.LOCAL, loginCommand(), session(), 12);

        assertThat(output).contains("BCM_AUTH_ACCESS");
        assertThat(output).contains("event=login");
        assertThat(output).contains("outcome=success");
        assertThat(output).contains("provider=LOCAL");
        assertThat(output).contains("rolesCount=1");
        assertThat(output).contains("scopesCount=1");
        assertThat(output).doesNotContain("KYLEWENG");
        assertThat(output).doesNotContain("super-secret-password");
        assertThat(output).doesNotContain("015521104095930");
        assertThat(output).doesNotContain("session-id");
        assertThat(output).doesNotContain("device-1");
    }

    @Test
    void logsAccessTokenFailureWithoutRawToken(CapturedOutput output) {
        SimpleMeterRegistry registry = new SimpleMeterRegistry();
        AuthAuditLogger auditLogger = new AuthAuditLogger(registry);

        auditLogger.accessTokenFailure(
                "Bearer raw.jwt.token",
                new JwtValidationException(ErrorCode.UNAUTHORIZED, JwtValidationFailure.INVALID_SIGNATURE),
                5);

        assertThat(output).contains("event=access_token");
        assertThat(output).contains("outcome=error");
        assertThat(output).contains("tokenPresent=true");
        assertThat(output).contains("errorCode=401");
        assertThat(output).contains("failureReason=invalid_signature");
        assertThat(output).doesNotContain("raw.jwt.token");

        Counter counter = registry.find(JWT_FAILURE_METRIC)
                .tag("event", "access_token")
                .tag("errorCode", "401")
                .tag("failureReason", "invalid_signature")
                .counter();
        assertThat(counter).isNotNull();
        assertThat(counter.count()).isEqualTo(1);
    }

    @Test
    void logsNonJwtFailureReasonAsNone(CapturedOutput output) {
        SimpleMeterRegistry registry = new SimpleMeterRegistry();
        AuthAuditLogger auditLogger = new AuthAuditLogger(registry);

        auditLogger.logoutFailure("Bearer raw.jwt.token", new BffException(ErrorCode.SESSION_EXPIRED), 7);

        assertThat(output).contains("event=logout");
        assertThat(output).contains("errorCode=419");
        assertThat(output).contains("failureReason=none");
        assertThat(output).doesNotContain("raw.jwt.token");
        assertThat(registry.find(JWT_FAILURE_METRIC).counter()).isNull();
    }

    @Test
    void recordsRefreshJwtFailureMetric(CapturedOutput output) {
        SimpleMeterRegistry registry = new SimpleMeterRegistry();
        AuthAuditLogger auditLogger = new AuthAuditLogger(registry);

        auditLogger.refreshFailure(
                "raw.refresh.jwt",
                "device-1",
                new JwtValidationException(ErrorCode.SESSION_EXPIRED, JwtValidationFailure.MALFORMED_TOKEN),
                9);

        assertThat(output).contains("event=refresh");
        assertThat(output).contains("errorCode=419");
        assertThat(output).contains("failureReason=malformed_token");
        assertThat(output).doesNotContain("raw.refresh.jwt");

        Counter counter = registry.find(JWT_FAILURE_METRIC)
                .tag("event", "refresh")
                .tag("errorCode", "419")
                .tag("failureReason", "malformed_token")
                .counter();
        assertThat(counter).isNotNull();
        assertThat(counter.count()).isEqualTo(1);
    }

    private static LoginCommand loginCommand() {
        return new LoginCommand(
                "KYLEWENG",
                "super-secret-password",
                "015521104095930",
                "device-1",
                "Android",
                "1.0.35",
                "en",
                List.of("BCM_USER"),
                List.of("bcm:proxy"));
    }

    private static SessionRecord session() {
        Instant now = Instant.parse("2026-05-17T00:00:00Z");
        return new SessionRecord(
                "session-id",
                "KYLEWENG@015521104095930",
                "015521104095930",
                "device-1",
                "Android",
                List.of("BCM_USER"),
                List.of("bcm:proxy"),
                null,
                SessionState.ACTIVE,
                1,
                "refresh-token-id",
                now,
                now);
    }
}

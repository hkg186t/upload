package com.hkbea.bcm.bff.bootstrap.web.proxy;

import com.sun.net.httpserver.HttpExchange;
import com.sun.net.httpserver.HttpServer;

import java.io.IOException;
import java.io.UncheckedIOException;
import java.net.InetSocketAddress;
import java.net.URLDecoder;
import java.nio.charset.StandardCharsets;
import java.util.HashMap;
import java.util.Map;
import java.util.Optional;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.atomic.AtomicReference;

final class MockBcmUpstream {
    private static final String BCM_INTERNAL_BASE_PATH = "/hkbea/sit-int";
    private static final String USER_PROFILE_PATH = "/corporate/v1/approval/center/user/userProfile";
    private static final String OPTIONAL_FAILURE_PATH = "/mock/optionalFailure";
    private static final String BCO_NONCE_PATH = "/digx/v1/session/nonce";
    private static final String BCO_PUBLIC_KEY_PATH = "/digx/cz/v1/publicKey";
    private static final String BCO_LOGIN_PATH = "/digx/j_security_check";

    private final HttpServer server;
    private final ExecutorService executor;
    private final Map<String, Integer> retryAttempts = new ConcurrentHashMap<>();
    private final Map<String, Integer> bcoPublicKeyAttempts = new ConcurrentHashMap<>();
    private final Map<String, CapturedRequest> capturedRequests = new ConcurrentHashMap<>();
    private final AtomicReference<CapturedRequest> lastCapturedRequest = new AtomicReference<>();

    private MockBcmUpstream() {
        try {
            this.server = HttpServer.create(new InetSocketAddress("127.0.0.1", 0), 0);
        } catch (IOException error) {
            throw new UncheckedIOException(error);
        }
        this.executor = Executors.newCachedThreadPool();
        this.server.setExecutor(executor);
        this.server.createContext(USER_PROFILE_PATH, this::handleUserProfile);
        this.server.createContext(BCM_INTERNAL_BASE_PATH + USER_PROFILE_PATH, this::handleUserProfile);
        this.server.createContext(OPTIONAL_FAILURE_PATH, this::handleOptionalFailure);
        this.server.createContext(BCO_NONCE_PATH, this::handleBcoNonce);
        this.server.createContext(BCO_PUBLIC_KEY_PATH, this::handleBcoPublicKey);
        this.server.createContext(BCO_LOGIN_PATH, this::handleBcoLogin);
        this.server.start();
    }

    static MockBcmUpstream start() {
        return new MockBcmUpstream();
    }

    String baseUrl() {
        return "http://127.0.0.1:" + server.getAddress().getPort();
    }

    String internalApicBaseUrl() {
        return baseUrl() + BCM_INTERNAL_BASE_PATH + "/";
    }

    String optionalFailurePath() {
        return OPTIONAL_FAILURE_PATH;
    }

    int port() {
        return server.getAddress().getPort();
    }

    Optional<CapturedRequest> capturedRequest(String requestId) {
        return Optional.ofNullable(capturedRequests.get(requestId));
    }

    Optional<CapturedRequest> lastCapturedRequest() {
        return Optional.ofNullable(lastCapturedRequest.get());
    }

    int bcoPublicKeyAttempts(String retryKey) {
        return bcoPublicKeyAttempts.getOrDefault(retryKey, 0);
    }

    void stop() {
        server.stop(0);
        executor.shutdownNow();
    }

    private void handleUserProfile(HttpExchange exchange) throws IOException {
        String body = new String(exchange.getRequestBody().readAllBytes(), StandardCharsets.UTF_8);
        capture(exchange, body);

        if (body.contains("html")) {
            write(exchange, 200, "text/html; charset=utf-8",
                    "<html><title>Server Upgrade</title><body>Temporary Suspension of Service</body></html>");
            return;
        }

        if (body.contains("slow")) {
            sleep(600);
            writeJson(exchange, 200, "{\"ok\":true,\"mode\":\"slow\"}");
            return;
        }

        if (body.contains("retry")) {
            String requestId = exchange.getRequestHeaders().getFirst("X-Request-Id");
            int attempt = retryAttempts.merge(requestId, 1, Integer::sum);
            if (attempt == 1) {
                writeJson(exchange, 500, "{\"ok\":false,\"mode\":\"retry\",\"attempt\":1}");
                return;
            }
            writeJson(exchange, 200, "{\"ok\":true,\"mode\":\"retry\",\"attempt\":" + attempt + "}");
            return;
        }

        if (body.contains("upstream500")) {
            writeJson(exchange, 500, "{\"ok\":false,\"mode\":\"upstream500\"}");
            return;
        }

        writeJson(exchange, 200, "{\"ok\":true,\"mode\":\"normal\"}");
    }

    private void handleOptionalFailure(HttpExchange exchange) throws IOException {
        capture(exchange);
        writeJson(exchange, 500, "{\"ok\":false,\"mode\":\"optionalFailure\"}");
    }

    private void handleBcoNonce(HttpExchange exchange) throws IOException {
        capture(exchange);
        if ("session-expired".equals(queryValue(exchange, "mode"))) {
            write(exchange, 419, "text/html; charset=UTF-8", "User session expired.");
            return;
        }
        exchange.getResponseHeaders().set("X-Nonce", "{\"nonce\":[\"nonce-1\",\"nonce-2\"]}");
        writeJson(exchange, 200, "{\"ok\":true,\"system\":\"bco\"}");
    }

    private void handleBcoPublicKey(HttpExchange exchange) throws IOException {
        capture(exchange);
        String retryKey = queryValue(exchange, "retryKey");
        if (retryKey != null && !retryKey.isBlank()) {
            int attempt = bcoPublicKeyAttempts.merge(retryKey, 1, Integer::sum);
            if (attempt == 1 && "slow-once".equals(queryValue(exchange, "mode"))) {
                sleep(250);
            }
        }
        writeJson(exchange, 200, "{\"ok\":true,\"system\":\"bco\",\"key\":\"public\"}");
    }

    private void handleBcoLogin(HttpExchange exchange) throws IOException {
        String body = new String(exchange.getRequestBody().readAllBytes(), StandardCharsets.UTF_8);
        capture(exchange, body);
        exchange.getResponseHeaders().add("Set-Cookie", "JSESSIONID=test-jsession!NONE; path=/; secure; HttpOnly");
        exchange.getResponseHeaders().add("Set-Cookie", "_WL_AUTHCOOKIE_JSESSIONID=test-wl-auth; path=/; secure; HttpOnly");
        exchange.getResponseHeaders().set("Location", "https://cdcuat-cmapp1.intranet.hkbea.com:9443/digx");
        write(exchange, 303, "text/html; charset=UTF-8", "");
    }

    private void capture(HttpExchange exchange) {
        capture(exchange, "");
    }

    private void capture(HttpExchange exchange, String body) {
        String requestId = exchange.getRequestHeaders().getFirst("X-Request-Id");
        Map<String, String> headers = new HashMap<>();
        exchange.getRequestHeaders().forEach((name, values) -> {
            if (values != null && !values.isEmpty()) {
                headers.put(name, values.get(0));
            }
        });
        CapturedRequest captured = new CapturedRequest(
                exchange.getRequestMethod(),
                exchange.getRequestURI().getPath(),
                exchange.getRequestURI().getRawQuery(),
                headers,
                body
        );
        lastCapturedRequest.set(captured);
        if (requestId != null && !requestId.isBlank()) {
            capturedRequests.put(requestId, captured);
        }
    }

    private static void writeJson(HttpExchange exchange, int statusCode, String body) throws IOException {
        write(exchange, statusCode, "application/json", body);
    }

    private static void write(HttpExchange exchange, int statusCode, String contentType, String body) throws IOException {
        byte[] bytes = body.getBytes(StandardCharsets.UTF_8);
        exchange.getResponseHeaders().set("content-type", contentType);
        exchange.sendResponseHeaders(statusCode, bytes.length);
        exchange.getResponseBody().write(bytes);
        exchange.close();
    }

    private static void sleep(long millis) {
        try {
            Thread.sleep(millis);
        } catch (InterruptedException error) {
            Thread.currentThread().interrupt();
        }
    }

    private static String queryValue(HttpExchange exchange, String name) {
        String rawQuery = exchange.getRequestURI().getRawQuery();
        if (rawQuery == null || rawQuery.isBlank()) {
            return null;
        }
        for (String pair : rawQuery.split("&")) {
            int separator = pair.indexOf('=');
            String rawName = separator >= 0 ? pair.substring(0, separator) : pair;
            if (name.equals(decode(rawName))) {
                return separator >= 0 ? decode(pair.substring(separator + 1)) : "";
            }
        }
        return null;
    }

    private static String decode(String value) {
        try {
            return URLDecoder.decode(value, StandardCharsets.UTF_8);
        } catch (IllegalArgumentException error) {
            return value;
        }
    }

    record CapturedRequest(
            String method,
            String path,
            String query,
            Map<String, String> headers,
            String body
    ) {
        String header(String name) {
            return headers.entrySet()
                    .stream()
                    .filter(entry -> entry.getKey().equalsIgnoreCase(name))
                    .map(Map.Entry::getValue)
                    .findFirst()
                    .orElse(null);
        }
    }
}

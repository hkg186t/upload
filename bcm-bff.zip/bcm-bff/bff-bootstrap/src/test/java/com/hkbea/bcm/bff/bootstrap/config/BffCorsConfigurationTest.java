package com.hkbea.bcm.bff.bootstrap.config;

import org.junit.jupiter.api.Test;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.boot.test.context.runner.ApplicationContextRunner;
import org.springframework.context.annotation.Import;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.mock.http.server.reactive.MockServerHttpRequest;
import org.springframework.mock.web.server.MockServerWebExchange;
import org.springframework.web.cors.reactive.CorsWebFilter;
import reactor.core.publisher.Mono;

import java.util.concurrent.atomic.AtomicInteger;

import static org.assertj.core.api.Assertions.assertThat;

class BffCorsConfigurationTest {
    private final ApplicationContextRunner contextRunner = new ApplicationContextRunner()
            .withUserConfiguration(TestConfiguration.class);

    @Test
    void doesNotCreateCorsFilterWhenCorsIsDisabled() {
        contextRunner
                .withPropertyValues("bff.cors.enabled=false")
                .run(context -> assertThat(context).doesNotHaveBean(CorsWebFilter.class));
    }

    @Test
    void createsCorsFilterWhenCorsIsEnabled() {
        contextRunner
                .withPropertyValues(
                        "bff.cors.enabled=true",
                        "bff.cors.allowed-origins=https://bcm.example.com")
                .run(context -> assertThat(context).hasSingleBean(CorsWebFilter.class));
    }

    @Test
    void allowsConfiguredPreflightOrigin() {
        CorsProperties properties = new CorsProperties();
        properties.setEnabled(true);
        properties.setAllowedOrigins(java.util.List.of("https://bcm.example.com"));
        CorsWebFilter filter = new BffCorsConfiguration().corsWebFilter(properties);
        MockServerWebExchange exchange = MockServerWebExchange.from(MockServerHttpRequest
                .options("https://api.example.com/bcm/demo/user-profile")
                .header(HttpHeaders.ORIGIN, "https://bcm.example.com")
                .header(HttpHeaders.ACCESS_CONTROL_REQUEST_METHOD, HttpMethod.POST.name()));
        AtomicInteger chainCalls = new AtomicInteger();

        filter.filter(exchange, currentExchange -> {
            chainCalls.incrementAndGet();
            return Mono.empty();
        }).block();

        assertThat(chainCalls).hasValue(0);
        assertThat(exchange.getResponse().getHeaders().getFirst(HttpHeaders.ACCESS_CONTROL_ALLOW_ORIGIN))
                .isEqualTo("https://bcm.example.com");
        assertThat(exchange.getResponse().getHeaders().getFirst(HttpHeaders.ACCESS_CONTROL_ALLOW_METHODS))
                .contains("POST");
    }

    @Import(BffCorsConfiguration.class)
    @EnableConfigurationProperties(CorsProperties.class)
    static class TestConfiguration {
    }
}

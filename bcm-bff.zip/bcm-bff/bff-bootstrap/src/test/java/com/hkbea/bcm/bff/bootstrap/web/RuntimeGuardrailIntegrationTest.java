package com.hkbea.bcm.bff.bootstrap.web;

import com.fasterxml.jackson.databind.JsonNode;
import com.hkbea.bcm.bff.bootstrap.test.BffRandomPortSpringBootTest;
import com.hkbea.bcm.bff.shared.http.HeaderConstants;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.test.web.reactive.server.EntityExchangeResult;
import org.springframework.test.web.reactive.server.WebTestClient;

import java.util.Map;

import static com.hkbea.bcm.bff.bootstrap.web.RuntimeEnvelopeAssertions.assertErrorEnvelope;
import static com.hkbea.bcm.bff.bootstrap.web.RuntimeEnvelopeAssertions.assertSecurityHeaders;
import static com.hkbea.bcm.bff.bootstrap.web.RuntimeEnvelopeAssertions.assertTraceHeaders;
import static org.assertj.core.api.Assertions.assertThat;
import static org.springframework.http.MediaType.APPLICATION_JSON;

@BffRandomPortSpringBootTest(properties = {
        "bff.auth.jwt-secret=test-secret-for-runtime-guardrails",
        "bff.rate-limit.trust-x-forwarded-for=true",
        "bff.rate-limit.rules[0].id=health",
        "bff.rate-limit.rules[0].path-prefix=/health",
        "bff.rate-limit.rules[0].max-requests=1",
        "bff.rate-limit.rules[0].window-seconds=60",
        "bff.request-size-limit.rules[0].id=tiny-auth-login",
        "bff.request-size-limit.rules[0].path-prefix=/auth/login",
        "bff.request-size-limit.rules[0].max-bytes=8"
})
class RuntimeGuardrailIntegrationTest {

    @Autowired
    private WebTestClient webTestClient;

    @Test
    void rateLimitRejectionKeepsRuntimeErrorEnvelopeAndHeaders() {
        String clientIp = "198.51.100.25";

        webTestClient.get()
                .uri("/health")
                .header(HeaderConstants.X_REQUEST_ID, "guardrail-rate-ok")
                .header("X-Forwarded-For", clientIp)
                .exchange()
                .expectStatus().isOk();

        String traceId = "guardrail-rate-limit";
        EntityExchangeResult<JsonNode> result = webTestClient.get()
                .uri("/health")
                .header(HeaderConstants.X_REQUEST_ID, traceId)
                .header("X-Forwarded-For", clientIp)
                .exchange()
                .expectStatus().isEqualTo(429)
                .expectBody(JsonNode.class)
                .returnResult();

        HttpHeaders headers = result.getResponseHeaders();
        assertSecurityHeaders(headers);
        assertTraceHeaders(headers, traceId);
        assertThat(headers.getFirst(HttpHeaders.RETRY_AFTER)).isNotBlank();
        assertThat(headers.getFirst("X-RateLimit-Limit")).isEqualTo("1");
        assertThat(headers.getFirst("X-RateLimit-Remaining")).isEqualTo("0");
        assertThat(headers.getFirst("X-RateLimit-Reset")).isNotBlank();
        assertErrorEnvelope(result.getResponseBody(), "429", "Rate limit exceeded", traceId);
    }

    @Test
    void payloadTooLargeRejectionKeepsRuntimeErrorEnvelopeAndHeaders() {
        String traceId = "guardrail-payload-large";

        EntityExchangeResult<JsonNode> result = ContractTestHeaders.withRequiredHeaders(webTestClient.post()
                .uri("/auth/login"), traceId)
                .contentType(APPLICATION_JSON)
                .bodyValue(Map.of("payload", "too-large"))
                .exchange()
                .expectStatus().isEqualTo(413)
                .expectBody(JsonNode.class)
                .returnResult();

        assertSecurityHeaders(result.getResponseHeaders());
        assertTraceHeaders(result.getResponseHeaders(), traceId);
        assertErrorEnvelope(result.getResponseBody(), "413", "Request Entity Too Large", traceId);
    }
}

package com.hkbea.bcm.bff.bootstrap.config;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.hkbea.bcm.bff.access.config.AuthProperties;
import com.hkbea.bcm.bff.access.login.LocalLoginAuthenticator;
import com.hkbea.bcm.bff.access.model.AuthResult;
import com.hkbea.bcm.bff.access.model.LoginCommand;
import com.hkbea.bcm.bff.access.model.RefreshCommand;
import com.hkbea.bcm.bff.access.model.SessionRecord;
import com.hkbea.bcm.bff.access.model.TokenPair;
import com.hkbea.bcm.bff.access.service.DefaultAuthService;
import com.hkbea.bcm.bff.access.service.InMemorySessionService;
import com.hkbea.bcm.bff.access.token.JwtTokenService;
import com.hkbea.bcm.bff.access.token.JwtValidationException;
import com.hkbea.bcm.bff.access.token.JwtValidationFailure;
import com.hkbea.bcm.bff.access.token.TokenUse;
import com.hkbea.bcm.bff.shared.api.BffException;
import com.hkbea.bcm.bff.shared.api.ErrorCode;
import com.hkbea.bcm.bff.shared.session.SessionState;
import org.junit.jupiter.api.Test;
import reactor.test.StepVerifier;

import java.time.Instant;
import java.util.List;
import java.util.concurrent.atomic.AtomicReference;

import static org.assertj.core.api.Assertions.assertThat;

class DefaultAuthServiceTest {
    @Test
    void rejectsLocalLoginWhenDisabled() {
        AuthProperties properties = new AuthProperties();
        properties.setLocalLoginEnabled(false);
        properties.setJwtSecret("test-secret-test-secret-test-secret-32");
        DefaultAuthService authService = new DefaultAuthService(
                new InMemorySessionService(),
                new JwtTokenService(properties, new ObjectMapper()),
                properties,
                new LocalLoginAuthenticator(properties));

        StepVerifier.create(authService.login(loginCommand()))
                .expectErrorSatisfies(error -> {
                    assertThat(error).isInstanceOf(BffException.class);
                    BffException bffError = (BffException) error;
                    assertThat(bffError.errorCode()).isEqualTo(ErrorCode.FORBIDDEN);
                    assertThat(bffError).hasMessage("Local login is disabled for this environment");
                })
                .verify();
    }

    @Test
    void allowsLocalLoginWhenEnabled() {
        DefaultAuthService authService = authService();

        StepVerifier.create(authService.login(loginCommand()))
                .assertNext(result -> {
                    assertThat(result.tokenPair().accessToken()).isNotBlank();
                    assertThat(result.user().username()).isEqualTo("KYLEWENG@015521104095930");
                })
                .verifyComplete();
    }

    @Test
    void rotatesRefreshTokenAfterUse() {
        DefaultAuthService authService = authService();
        AtomicReference<TokenPair> loginTokens = new AtomicReference<>();
        AtomicReference<TokenPair> rotatedTokens = new AtomicReference<>();

        StepVerifier.create(authService.login(loginCommand()).map(AuthResult::tokenPair))
                .assertNext(loginTokens::set)
                .verifyComplete();

        StepVerifier.create(authService.refresh(new RefreshCommand(loginTokens.get().refreshToken(), "device-1")))
                .assertNext(tokens -> {
                    assertThat(tokens.accessToken()).isNotBlank();
                    assertThat(tokens.refreshToken()).isNotEqualTo(loginTokens.get().refreshToken());
                    rotatedTokens.set(tokens);
                })
                .verifyComplete();

        StepVerifier.create(authService.refresh(new RefreshCommand(loginTokens.get().refreshToken(), "device-1")))
                .expectErrorSatisfies(DefaultAuthServiceTest::assertSessionExpired)
                .verify();

        StepVerifier.create(authService.refresh(new RefreshCommand(rotatedTokens.get().refreshToken(), "device-1")))
                .assertNext(tokens -> assertThat(tokens.refreshToken()).isNotEqualTo(rotatedTokens.get().refreshToken()))
                .verifyComplete();
    }

    @Test
    void secondLoginInvalidatesPreviousTokens() {
        DefaultAuthService authService = authService();
        AtomicReference<AuthResult> firstLogin = new AtomicReference<>();

        StepVerifier.create(authService.login(loginCommand()))
                .assertNext(firstLogin::set)
                .verifyComplete();

        StepVerifier.create(authService.login(loginCommand()))
                .assertNext(result -> assertThat(result.sessionId()).isNotEqualTo(firstLogin.get().sessionId()))
                .verifyComplete();

        TokenPair staleTokens = firstLogin.get().tokenPair();
        StepVerifier.create(authService.validateAccessToken("Bearer " + staleTokens.accessToken()))
                .expectErrorSatisfies(DefaultAuthServiceTest::assertSessionExpired)
                .verify();

        StepVerifier.create(authService.refresh(new RefreshCommand(staleTokens.refreshToken(), "device-1")))
                .expectErrorSatisfies(DefaultAuthServiceTest::assertSessionExpired)
                .verify();
    }

    @Test
    void accessTokenFailureIncludesMissingBearerReason() {
        DefaultAuthService authService = authService();

        StepVerifier.create(authService.validateAccessToken(""))
                .expectErrorSatisfies(error -> {
                    assertThat(error).isInstanceOf(JwtValidationException.class);
                    JwtValidationException jwtError = (JwtValidationException) error;
                    assertThat(jwtError.errorCode()).isEqualTo(ErrorCode.UNAUTHORIZED);
                    assertThat(jwtError.failure()).isEqualTo(JwtValidationFailure.MISSING_BEARER_TOKEN);
                })
                .verify();
    }

    @Test
    void refreshFailurePreservesJwtReasonWhileReturningSessionExpired() {
        DefaultAuthService authService = authService();

        StepVerifier.create(authService.refresh(new RefreshCommand("not-a-jwt", "device-1")))
                .expectErrorSatisfies(error -> {
                    assertThat(error).isInstanceOf(JwtValidationException.class);
                    JwtValidationException jwtError = (JwtValidationException) error;
                    assertThat(jwtError.errorCode()).isEqualTo(ErrorCode.SESSION_EXPIRED);
                    assertThat(jwtError.failure()).isEqualTo(JwtValidationFailure.MALFORMED_TOKEN);
                })
                .verify();
    }

    @Test
    void refreshInitializesRotationForLegacySessionWithoutRefreshTokenId() {
        AuthProperties properties = authProperties();
        InMemorySessionService sessionService = new InMemorySessionService();
        JwtTokenService jwtTokenService = new JwtTokenService(properties, new ObjectMapper());
        DefaultAuthService authService = new DefaultAuthService(
                sessionService,
                jwtTokenService,
                properties,
                new LocalLoginAuthenticator(properties));
        Instant now = Instant.now();
        SessionRecord legacySession = new SessionRecord(
                "legacy-session-id",
                "KYLEWENG@015521104095930",
                "015521104095930",
                "device-1",
                "Android",
                List.of("BCM_USER"),
                List.of("bcm:proxy"),
                null,
                SessionState.ACTIVE,
                1,
                null,
                now,
                now);
        sessionService.save(legacySession).block();
        String legacyRefreshToken = jwtTokenService.issue(
                legacySession,
                TokenUse.REFRESH,
                properties.getRefreshTokenTtlSeconds());
        AtomicReference<TokenPair> rotatedTokens = new AtomicReference<>();

        StepVerifier.create(authService.refresh(new RefreshCommand(legacyRefreshToken, "device-1")))
                .assertNext(tokens -> {
                    assertThat(tokens.refreshToken()).isNotEqualTo(legacyRefreshToken);
                    rotatedTokens.set(tokens);
                })
                .verifyComplete();

        StepVerifier.create(authService.refresh(new RefreshCommand(legacyRefreshToken, "device-1")))
                .expectErrorSatisfies(DefaultAuthServiceTest::assertSessionExpired)
                .verify();

        StepVerifier.create(authService.refresh(new RefreshCommand(rotatedTokens.get().refreshToken(), "device-1")))
                .assertNext(tokens -> assertThat(tokens.refreshToken()).isNotEqualTo(rotatedTokens.get().refreshToken()))
                .verifyComplete();
    }

    private static DefaultAuthService authService() {
        AuthProperties properties = authProperties();
        return new DefaultAuthService(
                new InMemorySessionService(),
                new JwtTokenService(properties, new ObjectMapper()),
                properties,
                new LocalLoginAuthenticator(properties));
    }

    private static AuthProperties authProperties() {
        AuthProperties properties = new AuthProperties();
        properties.setJwtSecret("test-secret-test-secret-test-secret-32");
        return properties;
    }

    private static void assertSessionExpired(Throwable error) {
        assertThat(error).isInstanceOf(BffException.class);
        BffException bffError = (BffException) error;
        assertThat(bffError.errorCode()).isEqualTo(ErrorCode.SESSION_EXPIRED);
    }

    private static LoginCommand loginCommand() {
        return new LoginCommand(
                "KYLEWENG",
                "password",
                "015521104095930",
                "device-1",
                "Android",
                "1.0.35",
                "en",
                null,
                null);
    }
}

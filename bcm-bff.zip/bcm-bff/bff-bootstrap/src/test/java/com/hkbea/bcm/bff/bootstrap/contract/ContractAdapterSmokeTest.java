package com.hkbea.bcm.bff.bootstrap.contract;

import com.hkbea.bcm.bff.contract.api.AccountsApi;
import com.hkbea.bcm.bff.contract.api.AuthApi;
import com.hkbea.bcm.bff.contract.api.BcmProxyApi;
import com.hkbea.bcm.bff.contract.api.BffAggregationApi;
import org.junit.jupiter.api.Test;

import java.lang.reflect.Method;

import static org.assertj.core.api.Assertions.assertThat;

class ContractAdapterSmokeTest {
    @Test
    void generatedContractAdapterContainsCurrentBffEntryPoints() {
        assertThat(methodNames(AuthApi.class))
                .containsExactlyInAnyOrder("login", "logout", "refreshToken");
        assertThat(methodNames(BcmProxyApi.class))
                .containsExactly("proxyUserProfileDemo");
        assertThat(methodNames(BffAggregationApi.class))
                .containsExactly("aggregateHomeSummaryDemo");
        assertThat(methodNames(AccountsApi.class))
                .containsExactly("getAccount");
    }

    private static String[] methodNames(Class<?> apiType) {
        return java.util.Arrays.stream(apiType.getDeclaredMethods())
                .map(Method::getName)
                .sorted()
                .toArray(String[]::new);
    }
}

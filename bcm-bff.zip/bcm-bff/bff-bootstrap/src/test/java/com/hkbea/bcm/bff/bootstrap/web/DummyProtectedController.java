package com.hkbea.bcm.bff.bootstrap.web;

import reactor.core.publisher.Mono;

public class DummyProtectedController {
    public Mono<Void> account() {
        return Mono.empty();
    }

    public Mono<Void> auth() {
        return Mono.empty();
    }

    public Mono<Void> health() {
        return Mono.empty();
    }

    public Mono<Void> proxy() {
        return Mono.empty();
    }

    public Mono<Void> aggregation() {
        return Mono.empty();
    }
}

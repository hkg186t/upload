package com.hkbea.bcm.bff.bootstrap.web.proxy;

import com.fasterxml.jackson.databind.JsonNode;
import com.hkbea.bcm.bff.bootstrap.test.BffRandomPortSpringBootTest;
import com.hkbea.bcm.bff.bootstrap.web.ContractTestHeaders;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.DynamicPropertyRegistry;
import org.springframework.test.context.DynamicPropertySource;
import org.springframework.test.web.reactive.server.WebTestClient;

import java.util.List;
import java.util.Map;
import java.util.UUID;

import static org.assertj.core.api.Assertions.assertThat;
import static org.springframework.http.MediaType.APPLICATION_JSON;

@BffRandomPortSpringBootTest(properties = {
        "bff.auth.jwt-secret=test-secret-for-bcm-proxy-legacy-migration",
        "bff.auth.local-bcm-session-id=legacy-jsession-id",
        "bff.proxy.bcm.ibm-client-id=test-ibm-client-id",
        "bff.proxy.bcm.ibm-client-secret=test-ibm-client-secret"
})
class BcmProxyLegacyMigrationIntegrationTest {
    private static final MockBcmUpstream UPSTREAM = MockBcmUpstream.start();

    @Autowired
    private WebTestClient webTestClient;

    @DynamicPropertySource
    static void proxyProperties(DynamicPropertyRegistry registry) {
        registry.add("bff.proxy.bcm.base-url", UPSTREAM::internalApicBaseUrl);
    }

    @AfterAll
    static void stopUpstream() {
        UPSTREAM.stop();
    }

    @Test
    void legacyCorporatePathUsesJwtSessionToCallBcmLikeOldProxy() {
        String token = login();
        String traceId = "legacy-bcm-" + UUID.randomUUID();

        JsonNode body = ContractTestHeaders.withRequiredHeaders(webTestClient.post()
                        .uri("/corporate/v1/approval/center/user/userProfile?source=legacy"), traceId)
                .contentType(APPLICATION_JSON)
                .header("Authorization", "Bearer " + token)
                .header("Cookie", "client-cookie=must-not-forward")
                .header("Operation-Type", "com.hkbea.bcm.userProfile")
                .header("X-Ut", "client-x-ut")
                .bodyValue(Map.of("mode", "normal"))
                .exchange()
                .expectStatus().isOk()
                .expectBody(JsonNode.class)
                .returnResult()
                .getResponseBody();

        assertThat(body).isNotNull();
        assertThat(body.path("ok").asBoolean()).isTrue();
        assertThat(body.path("mode").asText()).isEqualTo("normal");
        assertThat(body.has("data")).isFalse();
        MockBcmUpstream.CapturedRequest captured = UPSTREAM.capturedRequest(traceId).orElseThrow();
        assertThat(captured.method()).isEqualTo("POST");
        assertThat(captured.path()).isEqualTo("/hkbea/sit-int/corporate/v1/approval/center/user/userProfile");
        assertThat(captured.query()).isEqualTo("source=legacy");
        assertThat(captured.header("Authorization")).isEqualTo("Bearer legacy-jsession-id");
        assertThat(captured.header("X-User-Id")).startsWith("LEGACY-");
        assertThat(captured.header("x-ibm-client-id")).isEqualTo("test-ibm-client-id");
        assertThat(captured.header("x-ibm-client-secret")).isEqualTo("test-ibm-client-secret");
        assertThat(captured.header("Accept")).isNotEqualTo("application/json");
        assertThat(captured.header("Operation-Type")).isEqualTo("com.hkbea.bcm.userProfile");
        assertThat(captured.header("X-Ut")).isEqualTo("client-x-ut");
        assertThat(captured.header("Cookie")).isNull();
    }

    @Test
    void legacyCorporateGetDoesNotForwardSyntheticJsonBodyButPreservesClientContentType() {
        String token = login();
        String traceId = "legacy-bcm-get-" + UUID.randomUUID();

        JsonNode body = ContractTestHeaders.withRequiredHeaders(webTestClient.get()
                        .uri("/corporate/v1/approval/center/user/userProfile?source=legacy-get"), traceId)
                .header("Authorization", "Bearer " + token)
                .header("Content-Type", "application/json")
                .header("Operation-Type", "com.hkbea.bcm.userProfile")
                .exchange()
                .expectStatus().isOk()
                .expectBody(JsonNode.class)
                .returnResult()
                .getResponseBody();

        assertThat(body).isNotNull();
        assertThat(body.path("ok").asBoolean()).isTrue();
        assertThat(body.path("mode").asText()).isEqualTo("normal");
        assertThat(body.has("data")).isFalse();
        MockBcmUpstream.CapturedRequest captured = UPSTREAM.capturedRequest(traceId).orElseThrow();
        assertThat(captured.method()).isEqualTo("GET");
        assertThat(captured.path()).isEqualTo("/hkbea/sit-int/corporate/v1/approval/center/user/userProfile");
        assertThat(captured.query()).isEqualTo("source=legacy-get");
        assertThat(captured.body()).isEmpty();
        assertThat(captured.header("Content-Type")).isEqualTo("application/json");
        assertThat(captured.header("Accept")).isNotEqualTo("application/json");
        assertThat(captured.header("Authorization")).isEqualTo("Bearer legacy-jsession-id");
        assertThat(captured.header("x-ibm-client-id")).isEqualTo("test-ibm-client-id");
        assertThat(captured.header("x-ibm-client-secret")).isEqualTo("test-ibm-client-secret");
    }

    @Test
    void legacyCorporatePathRawPassesUpstreamServerError() {
        String token = login();
        String traceId = "legacy-bcm-500-" + UUID.randomUUID();

        JsonNode body = ContractTestHeaders.withRequiredHeaders(webTestClient.post()
                        .uri("/corporate/v1/approval/center/user/userProfile"), traceId)
                .contentType(APPLICATION_JSON)
                .header("Authorization", "Bearer " + token)
                .bodyValue(Map.of("mode", "upstream500"))
                .exchange()
                .expectStatus().isEqualTo(500)
                .expectBody(JsonNode.class)
                .returnResult()
                .getResponseBody();

        assertThat(body).isNotNull();
        assertThat(body.path("ok").asBoolean()).isFalse();
        assertThat(body.path("mode").asText()).isEqualTo("upstream500");
    }

    @Test
    void legacyCorporateHtmlSessionExpiredUsesGoCompatibleBody() {
        String token = login();
        String traceId = "legacy-bcm-html-" + UUID.randomUUID();

        JsonNode body = ContractTestHeaders.withRequiredHeaders(webTestClient.post()
                        .uri("/corporate/v1/approval/center/user/userProfile"), traceId)
                .contentType(APPLICATION_JSON)
                .header("Authorization", "Bearer " + token)
                .bodyValue(Map.of("mode", "html"))
                .exchange()
                .expectStatus().isOk()
                .expectBody(JsonNode.class)
                .returnResult()
                .getResponseBody();

        assertThat(body).isNotNull();
        assertThat(body.path("status").asText()).isEqualTo("419");
        assertThat(body.path("code").asText()).isEqualTo("419");
        assertThat(body.path("message").asText()).isEqualTo("Session Expired");

        JsonNode expired = ContractTestHeaders.withRequiredHeaders(webTestClient.post()
                        .uri("/corporate/v1/approval/center/user/userProfile"))
                .contentType(APPLICATION_JSON)
                .header("Authorization", "Bearer " + token)
                .bodyValue(Map.of("mode", "normal"))
                .exchange()
                .expectStatus().isOk()
                .expectBody(JsonNode.class)
                .returnResult()
                .getResponseBody();

        assertThat(expired).isNotNull();
        assertThat(expired.path("status").asText()).isEqualTo("419");
        assertThat(expired.path("code").asText()).isEqualTo("419");
        assertThat(expired.path("message").asText()).isEqualTo("Session Expired");
    }

    @Test
    void dspLegacyCorporatePathBypassesBffJwtAndRawPassesToBcm() {
        String traceId = "dsp-legacy-bcm-" + UUID.randomUUID();
        String mpaasToken = "mpaas-access-token";

        JsonNode body = ContractTestHeaders.withRequiredHeaders(webTestClient.post()
                        .uri("/dsp/corporate/v1/approval/center/user/userProfile?source=dsp"), traceId)
                .contentType(APPLICATION_JSON)
                .header("Authorization", "Bearer " + mpaasToken)
                .header("Cookie", "client-cookie=must-not-forward")
                .header("Operation-Type", "com.hkbea.bcm.userProfile")
                .header("X-User-Id", "SYLVIAZHANG@015521104096512")
                .header("X-Ut", "client-x-ut")
                .bodyValue(Map.of("mode", "normal"))
                .exchange()
                .expectStatus().isOk()
                .expectBody(JsonNode.class)
                .returnResult()
                .getResponseBody();

        assertThat(body).isNotNull();
        assertThat(body.path("ok").asBoolean()).isTrue();
        assertThat(body.path("mode").asText()).isEqualTo("normal");
        assertThat(body.has("data")).isFalse();
        MockBcmUpstream.CapturedRequest captured = UPSTREAM.capturedRequest(traceId).orElseThrow();
        assertThat(captured.method()).isEqualTo("POST");
        assertThat(captured.path()).isEqualTo("/hkbea/sit-int/corporate/v1/approval/center/user/userProfile");
        assertThat(captured.query()).isEqualTo("source=dsp");
        assertThat(captured.header("Authorization")).isEqualTo("Bearer " + mpaasToken);
        assertThat(captured.header("X-User-Id")).isEqualTo("SYLVIAZHANG@015521104096512");
        assertThat(captured.header("x-ibm-client-id")).isEqualTo("test-ibm-client-id");
        assertThat(captured.header("x-ibm-client-secret")).isEqualTo("test-ibm-client-secret");
        assertThat(captured.header("Operation-Type")).isEqualTo("com.hkbea.bcm.userProfile");
        assertThat(captured.header("X-Ut")).isEqualTo("client-x-ut");
        assertThat(captured.header("Cookie")).isNull();
    }

    private String login() {
        JsonNode body = ContractTestHeaders.withRequiredHeaders(webTestClient.post()
                        .uri("/auth/login"))
                .contentType(APPLICATION_JSON)
                .bodyValue(Map.of(
                        "username", "LEGACY-" + UUID.randomUUID(),
                        "password", "demo",
                        "parentAccountId", "015521104095930",
                        "deviceId", "test-device-" + UUID.randomUUID(),
                        "deviceOs", "Android",
                        "locale", "en",
                        "roles", List.of("BCM_USER"),
                        "scopes", List.of("bcm:proxy")))
                .exchange()
                .expectStatus().isOk()
                .expectBody(JsonNode.class)
                .returnResult()
                .getResponseBody();

        assertThat(body).isNotNull();
        return body.path("data").path("accessToken").asText();
    }
}

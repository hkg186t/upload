package com.hkbea.bcm.bff.bootstrap.config;

import com.hkbea.bcm.bff.access.config.AuthProperties;
import com.hkbea.bcm.bff.access.login.AuthenticatedUser;
import com.hkbea.bcm.bff.access.login.DisabledLoginAuthenticator;
import com.hkbea.bcm.bff.access.login.IamLoginAuthenticator;
import com.hkbea.bcm.bff.access.login.IamLoginClient;
import com.hkbea.bcm.bff.access.login.LocalLoginAuthenticator;
import com.hkbea.bcm.bff.access.login.LoginAuthenticator;
import com.hkbea.bcm.bff.access.login.LoginAuthenticatorConfiguration;
import org.junit.jupiter.api.Test;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.boot.test.context.runner.ApplicationContextRunner;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Import;
import reactor.core.publisher.Mono;

import java.util.List;

import static org.assertj.core.api.Assertions.assertThat;

class LoginAuthenticatorConfigurationTest {
    private final ApplicationContextRunner contextRunner = new ApplicationContextRunner()
            .withUserConfiguration(TestConfiguration.class);

    @Test
    void usesLocalLoginProviderByDefault() {
        contextRunner.run(context -> assertThat(context)
                .hasSingleBean(LoginAuthenticator.class)
                .getBean(LoginAuthenticator.class)
                .isInstanceOf(LocalLoginAuthenticator.class));
    }

    @Test
    void usesDisabledLoginProviderWhenConfigured() {
        contextRunner
                .withPropertyValues("bff.auth.login-provider=disabled")
                .run(context -> assertThat(context)
                        .hasSingleBean(LoginAuthenticator.class)
                        .getBean(LoginAuthenticator.class)
                        .isInstanceOf(DisabledLoginAuthenticator.class));
    }

    @Test
    void failsFastForIamProviderWithoutClient() {
        contextRunner
                .withPropertyValues("bff.auth.login-provider=iam")
                .run(context -> {
                    assertThat(context).hasFailed();
                    assertThat(context.getStartupFailure())
                            .hasMessageContaining("BFF auth login provider 'IAM' requires an IamLoginClient");
                });
    }

    @Test
    void usesIamLoginProviderWhenClientExists() {
        new ApplicationContextRunner()
                .withUserConfiguration(TestConfiguration.class, IamClientConfiguration.class)
                .withPropertyValues("bff.auth.login-provider=iam")
                .run(context -> assertThat(context)
                        .hasSingleBean(LoginAuthenticator.class)
                        .getBean(LoginAuthenticator.class)
                        .isInstanceOf(IamLoginAuthenticator.class));
    }

    @Import(LoginAuthenticatorConfiguration.class)
    @EnableConfigurationProperties(AuthProperties.class)
    static class TestConfiguration {
    }

    @Configuration(proxyBeanMethods = false)
    static class IamClientConfiguration {
        @Bean
        IamLoginClient iamLoginClient() {
            return ignored -> Mono.just(new AuthenticatedUser(
                    "IAM_USER",
                    "IAM User",
                    "CUSTOMER",
                    List.of("BCM_USER"),
                    List.of("bcm:proxy"),
                    null));
        }
    }
}

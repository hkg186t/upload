package com.hkbea.bcm.bff.bootstrap.web.proxy;

import com.fasterxml.jackson.databind.JsonNode;
import com.hkbea.bcm.bff.bootstrap.test.BffRandomPortSpringBootTest;
import com.hkbea.bcm.bff.bootstrap.web.ContractTestHeaders;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.DynamicPropertyRegistry;
import org.springframework.test.context.DynamicPropertySource;
import org.springframework.test.web.reactive.server.WebTestClient;

import java.util.List;
import java.util.Map;
import java.util.UUID;

import static com.hkbea.bcm.bff.bootstrap.web.RuntimeEnvelopeAssertions.assertErrorEnvelope;
import static com.hkbea.bcm.bff.bootstrap.web.RuntimeEnvelopeAssertions.assertSuccessEnvelope;
import static org.assertj.core.api.Assertions.assertThat;
import static org.springframework.http.MediaType.APPLICATION_JSON;

@BffRandomPortSpringBootTest(properties = {
        "bff.auth.jwt-secret=test-secret-for-bcm-proxy-authorization"
})
class BcmProxyAuthorizationPolicyIntegrationTest {
    private static final MockBcmUpstream UPSTREAM = MockBcmUpstream.start();

    @Autowired
    private WebTestClient webTestClient;

    @DynamicPropertySource
    static void proxyProperties(DynamicPropertyRegistry registry) {
        registry.add("bff.proxy.bcm.base-url", UPSTREAM::baseUrl);
    }

    @AfterAll
    static void stopUpstream() {
        UPSTREAM.stop();
    }

    @Test
    void allowsSessionThatMatchesRoutePolicy() {
        String token = login("Android", List.of("BCM_USER"), List.of("bcm:proxy"));

        JsonNode body = proxy(token, 200);

        assertSuccessEnvelope(body);
    }

    @Test
    void rejectsSessionWithoutRequiredRole() {
        String token = login("Android", List.of("VIEW_ONLY"), List.of("bcm:proxy"));

        JsonNode body = proxy(token, 403);

        assertErrorEnvelope(body, "403", "Missing required role");
    }

    @Test
    void rejectsSessionWithoutRequiredScope() {
        String token = login("Android", List.of("BCM_USER"), List.of("profile:read"));

        JsonNode body = proxy(token, 403);

        assertErrorEnvelope(body, "403", "Missing required scope");
    }

    @Test
    void rejectsSessionFromDisallowedDeviceOs() {
        String token = login("Web", List.of("BCM_USER"), List.of("bcm:proxy"));

        JsonNode body = proxy(token, 403);

        assertErrorEnvelope(body, "403", "Device OS is not allowed");
    }

    private String login(String deviceOs, List<String> roles, List<String> scopes) {
        JsonNode body = ContractTestHeaders.withRequiredHeaders(webTestClient.post()
                .uri("/auth/login"))
                .contentType(APPLICATION_JSON)
                .bodyValue(Map.of(
                        "username", "AUTHZ-" + UUID.randomUUID(),
                        "password", "demo",
                        "parentAccountId", "015521104095930",
                        "deviceId", "test-device-" + UUID.randomUUID(),
                        "deviceOs", deviceOs,
                        "locale", "en",
                        "roles", roles,
                        "scopes", scopes))
                .exchange()
                .expectStatus().isOk()
                .expectBody(JsonNode.class)
                .returnResult()
                .getResponseBody();

        assertThat(body).isNotNull();
        return body.path("data").path("accessToken").asText();
    }

    private JsonNode proxy(String token, int expectedStatus) {
        String requestId = "authz-" + UUID.randomUUID();
        JsonNode body = ContractTestHeaders.withRequiredHeaders(webTestClient.post()
                .uri("/bcm/demo/user-profile"), requestId)
                .contentType(APPLICATION_JSON)
                .header("Authorization", "Bearer " + token)
                .bodyValue(Map.of("mode", "normal"))
                .exchange()
                .expectStatus().isEqualTo(expectedStatus)
                .expectBody(JsonNode.class)
                .returnResult()
                .getResponseBody();

        assertThat(body).isNotNull();
        return body;
    }
}

package com.hkbea.bcm.bff.bootstrap.web;

import com.hkbea.bcm.bff.bootstrap.config.SecurityHeadersProperties;
import org.junit.jupiter.api.Test;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.mock.http.server.reactive.MockServerHttpRequest;
import org.springframework.mock.web.server.MockServerWebExchange;
import org.springframework.web.server.WebFilterChain;
import reactor.core.publisher.Mono;

import static org.assertj.core.api.Assertions.assertThat;

class SecurityHeadersWebFilterTest {

    @Test
    void writesSecurityHeadersForSuccessfulResponses() {
        SecurityHeadersWebFilter filter = new SecurityHeadersWebFilter(defaultProperties());
        MockServerWebExchange exchange = MockServerWebExchange.from(MockServerHttpRequest.get("/health"));
        WebFilterChain chain = currentExchange -> {
            currentExchange.getResponse().setStatusCode(HttpStatus.OK);
            return Mono.empty();
        };

        filter.filter(exchange, chain).block();

        assertSecurityHeaders(exchange.getResponse().getHeaders());
    }

    @Test
    void writesSecurityHeadersForRejectedResponses() {
        SecurityHeadersWebFilter filter = new SecurityHeadersWebFilter(defaultProperties());
        MockServerWebExchange exchange = MockServerWebExchange.from(MockServerHttpRequest.post("/bcm/demo/user-profile"));
        WebFilterChain chain = currentExchange -> {
            currentExchange.getResponse().setStatusCode(HttpStatus.UNAUTHORIZED);
            return Mono.empty();
        };

        filter.filter(exchange, chain).block();

        assertSecurityHeaders(exchange.getResponse().getHeaders());
    }

    @Test
    void omitsStrictTransportSecurityWhenHstsIsDisabled() {
        SecurityHeadersWebFilter filter = new SecurityHeadersWebFilter(defaultProperties());
        MockServerWebExchange exchange = MockServerWebExchange.from(MockServerHttpRequest.get("/health"));

        filter.filter(exchange, currentExchange -> Mono.empty()).block();

        assertThat(exchange.getResponse().getHeaders().getFirst(SecurityHeadersWebFilter.STRICT_TRANSPORT_SECURITY))
                .isNull();
    }

    @Test
    void writesStrictTransportSecurityWhenHstsIsEnabled() {
        SecurityHeadersProperties properties = defaultProperties();
        properties.getHsts().setEnabled(true);
        properties.getHsts().setMaxAgeSeconds(63_072_000);
        properties.getHsts().setPreload(true);
        SecurityHeadersWebFilter filter = new SecurityHeadersWebFilter(properties);
        MockServerWebExchange exchange = MockServerWebExchange.from(MockServerHttpRequest.get("/health"));

        filter.filter(exchange, currentExchange -> Mono.empty()).block();

        assertThat(exchange.getResponse().getHeaders().getFirst(SecurityHeadersWebFilter.STRICT_TRANSPORT_SECURITY))
                .isEqualTo("max-age=63072000; includeSubDomains; preload");
    }

    private static void assertSecurityHeaders(HttpHeaders headers) {
        assertThat(headers.getCacheControl()).isEqualTo(SecurityHeadersWebFilter.CACHE_CONTROL_VALUE);
        assertThat(headers.getFirst(SecurityHeadersWebFilter.PRAGMA)).isEqualTo("no-cache");
        assertThat(headers.getFirst(SecurityHeadersWebFilter.EXPIRES)).isEqualTo("0");
        assertThat(headers.getFirst(SecurityHeadersWebFilter.X_CONTENT_TYPE_OPTIONS)).isEqualTo("nosniff");
        assertThat(headers.getFirst(SecurityHeadersWebFilter.X_FRAME_OPTIONS)).isEqualTo("DENY");
        assertThat(headers.getFirst(SecurityHeadersWebFilter.REFERRER_POLICY)).isEqualTo("no-referrer");
    }

    private static SecurityHeadersProperties defaultProperties() {
        return new SecurityHeadersProperties();
    }
}

package com.hkbea.bcm.bff.bootstrap.web;

import com.fasterxml.jackson.databind.JsonNode;
import com.hkbea.bcm.bff.bootstrap.test.BffRandomPortSpringBootTest;
import com.hkbea.bcm.bff.shared.http.HeaderConstants;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.test.web.reactive.server.EntityExchangeResult;
import org.springframework.test.web.reactive.server.WebTestClient;

import static com.hkbea.bcm.bff.bootstrap.web.RuntimeEnvelopeAssertions.assertGeneratedTraceHeaders;
import static com.hkbea.bcm.bff.bootstrap.web.RuntimeEnvelopeAssertions.assertSecurityHeaders;
import static com.hkbea.bcm.bff.bootstrap.web.RuntimeEnvelopeAssertions.assertTraceHeaders;
import static org.assertj.core.api.Assertions.assertThat;

@BffRandomPortSpringBootTest(properties = {
        "bff.auth.jwt-secret=test-secret-for-runtime-cors",
        "bff.cors.enabled=true",
        "bff.cors.allowed-origins=https://bcm.example.com",
        "bff.cors.max-age-seconds=1800"
})
class RuntimeCorsIntegrationTest {
    private static final String ALLOWED_ORIGIN = "https://bcm.example.com";
    private static final String REJECTED_ORIGIN = "https://evil.example.com";

    @Autowired
    private WebTestClient webTestClient;

    @Test
    void preflightAllowsConfiguredOriginWithoutRequiringAuthorization() {
        EntityExchangeResult<byte[]> result = webTestClient.options()
                .uri("/bcm/demo/user-profile")
                .header(HttpHeaders.ORIGIN, ALLOWED_ORIGIN)
                .header(HttpHeaders.ACCESS_CONTROL_REQUEST_METHOD, "POST")
                .header(HttpHeaders.ACCESS_CONTROL_REQUEST_HEADERS,
                        "Authorization, X-Request-Id, X-Correlation-Id")
                .exchange()
                .expectStatus().isOk()
                .expectBody()
                .returnResult();

        HttpHeaders headers = result.getResponseHeaders();
        assertSecurityHeaders(headers);
        assertGeneratedTraceHeaders(headers, "");
        assertThat(headers.getFirst(HttpHeaders.ACCESS_CONTROL_ALLOW_ORIGIN)).isEqualTo(ALLOWED_ORIGIN);
        assertThat(headers.getFirst(HttpHeaders.ACCESS_CONTROL_ALLOW_METHODS)).contains("POST");
        assertThat(headers.getFirst(HttpHeaders.ACCESS_CONTROL_ALLOW_HEADERS))
                .contains("Authorization")
                .contains("X-Request-Id")
                .contains("X-Correlation-Id");
        assertThat(headers.getFirst(HttpHeaders.ACCESS_CONTROL_MAX_AGE)).isEqualTo("1800");
    }

    @Test
    void actualCorsResponseExposesFrontendDiagnosticHeaders() {
        String traceId = "cors-health-trace";

        EntityExchangeResult<JsonNode> result = webTestClient.get()
                .uri("/health")
                .header(HttpHeaders.ORIGIN, ALLOWED_ORIGIN)
                .header(HeaderConstants.X_REQUEST_ID, traceId)
                .exchange()
                .expectStatus().isOk()
                .expectBody(JsonNode.class)
                .returnResult();

        HttpHeaders headers = result.getResponseHeaders();
        assertSecurityHeaders(headers);
        assertTraceHeaders(headers, traceId);
        assertThat(headers.getFirst(HttpHeaders.ACCESS_CONTROL_ALLOW_ORIGIN)).isEqualTo(ALLOWED_ORIGIN);
        assertThat(headers.getFirst(HttpHeaders.ACCESS_CONTROL_EXPOSE_HEADERS))
                .contains(HeaderConstants.X_REQUEST_ID)
                .contains(HeaderConstants.X_CORRELATION_ID)
                .contains(HttpHeaders.RETRY_AFTER)
                .contains("X-RateLimit-Limit");
        JsonNode body = result.getResponseBody();
        assertThat(body.path("status").asText()).isEqualTo("UP");
        assertThat(body.path("service").asText()).isEqualTo("bcm-bff");
        assertThat(body.path("checks").path("application").asText()).isEqualTo("UP");
        assertThat(body.path("traceId").asText()).isEqualTo(traceId);
    }

    @Test
    void preflightRejectsUnconfiguredOrigin() {
        webTestClient.options()
                .uri("/bcm/demo/user-profile")
                .header(HttpHeaders.ORIGIN, REJECTED_ORIGIN)
                .header(HttpHeaders.ACCESS_CONTROL_REQUEST_METHOD, "POST")
                .exchange()
                .expectStatus().isForbidden()
                .expectHeader().doesNotExist(HttpHeaders.ACCESS_CONTROL_ALLOW_ORIGIN);
    }
}

package com.hkbea.bcm.bff.bootstrap.web;

import com.fasterxml.jackson.databind.JsonNode;
import com.hkbea.bcm.bff.bootstrap.test.BffRandomPortSpringBootTest;
import com.hkbea.bcm.bff.shared.http.HeaderConstants;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.web.reactive.server.EntityExchangeResult;
import org.springframework.test.web.reactive.server.WebTestClient;

import java.util.Map;

import static com.hkbea.bcm.bff.bootstrap.web.RuntimeEnvelopeAssertions.assertErrorEnvelope;
import static com.hkbea.bcm.bff.bootstrap.web.RuntimeEnvelopeAssertions.assertGeneratedTraceHeaders;
import static com.hkbea.bcm.bff.bootstrap.web.RuntimeEnvelopeAssertions.assertSecurityHeaders;
import static com.hkbea.bcm.bff.bootstrap.web.RuntimeEnvelopeAssertions.assertTraceHeaders;
import static org.assertj.core.api.Assertions.assertThat;
import static org.springframework.http.MediaType.APPLICATION_JSON;

@BffRandomPortSpringBootTest(properties = {
        "bff.auth.jwt-secret=test-secret-for-runtime-gateway-headers"
})
class RuntimeGatewayHeadersIntegrationTest {

    @Autowired
    private WebTestClient webTestClient;

    @Test
    void successResponseKeepsTraceHeadersSecurityHeadersAndBodyTraceAligned() {
        String traceId = "gateway-success-trace";

        EntityExchangeResult<JsonNode> result = webTestClient.get()
                .uri("/health")
                .header(HeaderConstants.X_REQUEST_ID, traceId)
                .exchange()
                .expectStatus().isOk()
                .expectBody(JsonNode.class)
                .returnResult();

        assertSecurityHeaders(result.getResponseHeaders());
        assertTraceHeaders(result.getResponseHeaders(), traceId);
        JsonNode body = result.getResponseBody();
        assertThat(body.path("status").asText()).isEqualTo("UP");
        assertThat(body.path("service").asText()).isEqualTo("bcm-bff");
        assertThat(body.path("checks").path("application").asText()).isEqualTo("UP");
        assertThat(body.path("traceId").asText()).isEqualTo(traceId);
    }

    @Test
    void rootPathSupportsAlbDefaultHealthChecks() {
        String traceId = "gateway-root-health";

        EntityExchangeResult<JsonNode> getResult = webTestClient.get()
                .uri("/")
                .header(HeaderConstants.X_REQUEST_ID, traceId)
                .exchange()
                .expectStatus().isOk()
                .expectBody(JsonNode.class)
                .returnResult();

        assertSecurityHeaders(getResult.getResponseHeaders());
        assertTraceHeaders(getResult.getResponseHeaders(), traceId);
        assertThat(getResult.getResponseBody().path("status").asText()).isEqualTo("UP");

        webTestClient.head()
                .uri("/")
                .exchange()
                .expectStatus().isOk()
                .expectBody().isEmpty();
    }

    @Test
    void errorResponseReplacesUnsafeTraceAndKeepsRuntimeHeadersAligned() {
        String unsafeTraceId = "a".repeat(TraceIdWebFilter.MAX_TRACE_ID_LENGTH + 1);

        EntityExchangeResult<JsonNode> result = webTestClient.post()
                .uri("/auth/refresh")
                .header(HeaderConstants.X_REQUEST_ID, unsafeTraceId)
                .header(HeaderConstants.X_CORRELATION_ID, "null")
                .header("X-Channel", "MOBILE")
                .header("X-App-Id", "bcm-bff-test")
                .contentType(APPLICATION_JSON)
                .bodyValue(Map.of(
                        "refreshToken", "not-a-jwt",
                        "deviceId", "gateway-device"))
                .exchange()
                .expectStatus().isEqualTo(419)
                .expectBody(JsonNode.class)
                .returnResult();

        assertSecurityHeaders(result.getResponseHeaders());
        String traceId = assertGeneratedTraceHeaders(result.getResponseHeaders(), unsafeTraceId);
        assertErrorEnvelope(result.getResponseBody(), "419", "Session Expired", traceId);
    }
}

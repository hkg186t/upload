package com.hkbea.bcm.bff.bootstrap.web;

import com.hkbea.bcm.bff.shared.api.BffException;
import com.hkbea.bcm.bff.shared.api.ErrorCode;
import com.hkbea.bcm.bff.shared.http.HeaderConstants;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.boot.test.system.CapturedOutput;
import org.springframework.boot.test.system.OutputCaptureExtension;
import org.springframework.http.HttpStatus;
import org.springframework.mock.http.server.reactive.MockServerHttpRequest;
import org.springframework.mock.web.server.MockServerWebExchange;
import org.springframework.web.server.WebFilterChain;
import reactor.core.publisher.Mono;

import java.net.InetSocketAddress;
import java.time.Clock;
import java.time.Instant;
import java.time.ZoneOffset;

import static org.assertj.core.api.Assertions.assertThat;

@ExtendWith(OutputCaptureExtension.class)
class AccessLogWebFilterTest {
    private static final Clock CLOCK = Clock.fixed(Instant.parse("2026-05-17T00:00:00Z"), ZoneOffset.UTC);

    @Test
    void logsSuccessfulRequestWithoutQueryString(CapturedOutput output) {
        AccessLogWebFilter filter = new AccessLogWebFilter(CLOCK);
        MockServerWebExchange exchange = MockServerWebExchange.from(MockServerHttpRequest
                .get("/bcm/demo/user-profile?accountId=should-not-log")
                .header(HeaderConstants.X_REQUEST_ID, "trace-123")
                .header("Host", "bff.example.test")
                .header("User-Agent", "manual-bff-test")
                .header("X-Forwarded-For", "203.0.113.10")
                .remoteAddress(new InetSocketAddress("198.51.100.20", 45678)));
        WebFilterChain chain = currentExchange -> {
            currentExchange.getResponse().setStatusCode(HttpStatus.OK);
            return Mono.empty();
        };

        filter.filter(exchange, chain).block();

        assertThat(output).contains("BCM_HTTP_ACCESS");
        assertThat(output).contains("traceId=trace-123");
        assertThat(output).contains("method=GET");
        assertThat(output).contains("path=/bcm/demo/user-profile");
        assertThat(output).contains("status=200");
        assertThat(output).contains("outcome=success");
        assertThat(output).contains("remoteAddress=198.51.100.20");
        assertThat(output).contains("host=bff.example.test");
        assertThat(output).contains("forwardedFor=203.0.113.10");
        assertThat(output).contains("userAgent=manual-bff-test");
        assertThat(output).doesNotContain("accountId=should-not-log");
    }

    @Test
    void suppressesSlbHealthCheckAccessLogs(CapturedOutput output) {
        AccessLogWebFilter filter = new AccessLogWebFilter(CLOCK);
        MockServerWebExchange exchange = MockServerWebExchange.from(MockServerHttpRequest
                .head("/")
                .header(HeaderConstants.X_REQUEST_ID, "trace-slb-health-check")
                .header("User-Agent", "SLBHealthCheck"));
        WebFilterChain chain = currentExchange -> {
            currentExchange.getResponse().setStatusCode(HttpStatus.OK);
            return Mono.empty();
        };

        filter.filter(exchange, chain).block();

        assertThat(output).doesNotContain("BCM_HTTP_ACCESS");
        assertThat(output).doesNotContain("trace-slb-health-check");
        assertThat(output).doesNotContain("SLBHealthCheck");
    }

    @Test
    void suppressesLocalCurlHealthProbeLogs(CapturedOutput output) {
        AccessLogWebFilter filter = new AccessLogWebFilter(CLOCK);
        WebFilterChain chain = currentExchange -> {
            currentExchange.getResponse().setStatusCode(HttpStatus.OK);
            return Mono.empty();
        };

        for (String path : new String[] {"/health", "/actuator/health/readiness", "/actuator/health/liveness"}) {
            MockServerWebExchange exchange = MockServerWebExchange.from(MockServerHttpRequest
                    .get(path)
                    .header(HeaderConstants.X_REQUEST_ID, "trace-local-curl-health")
                    .header("Host", "127.0.0.1:8080")
                    .header("User-Agent", "curl/8.18.0")
                    .remoteAddress(new InetSocketAddress("127.0.0.1", 51234)));

            filter.filter(exchange, chain).block();
        }

        assertThat(output).doesNotContain("BCM_HTTP_ACCESS");
        assertThat(output).doesNotContain("trace-local-curl-health");
        assertThat(output).doesNotContain("curl/8.18.0");
    }

    @Test
    void logsExternalCurlHealthRequests(CapturedOutput output) {
        AccessLogWebFilter filter = new AccessLogWebFilter(CLOCK);
        MockServerWebExchange exchange = MockServerWebExchange.from(MockServerHttpRequest
                .get("/health")
                .header(HeaderConstants.X_REQUEST_ID, "trace-external-curl-health")
                .header("Host", "alb.example.test")
                .header("User-Agent", "curl/8.18.0")
                .remoteAddress(new InetSocketAddress("203.0.113.10", 51234)));
        WebFilterChain chain = currentExchange -> {
            currentExchange.getResponse().setStatusCode(HttpStatus.OK);
            return Mono.empty();
        };

        filter.filter(exchange, chain).block();

        assertThat(output).contains("BCM_HTTP_ACCESS");
        assertThat(output).contains("trace-external-curl-health");
        assertThat(output).contains("path=/health");
        assertThat(output).contains("remoteAddress=203.0.113.10");
        assertThat(output).contains("userAgent=curl/8.18.0");
    }

    @Test
    void logsRejectedStatusAsRejected(CapturedOutput output) {
        AccessLogWebFilter filter = new AccessLogWebFilter(CLOCK);
        MockServerWebExchange exchange = MockServerWebExchange.from(MockServerHttpRequest
                .post("/auth/logout")
                .header(HeaderConstants.X_REQUEST_ID, "trace-419"));
        WebFilterChain chain = currentExchange -> {
            currentExchange.getResponse().setStatusCode(HttpStatus.valueOf(419));
            return Mono.empty();
        };

        filter.filter(exchange, chain).block();

        assertThat(output).contains("traceId=trace-419");
        assertThat(output).contains("status=419");
        assertThat(output).contains("outcome=rejected");
        assertThat(output).contains("errorCode=419");
    }

    @Test
    void logsUnhandledBffExceptionWithItsErrorCode(CapturedOutput output) {
        AccessLogWebFilter filter = new AccessLogWebFilter(CLOCK);
        MockServerWebExchange exchange = MockServerWebExchange.from(MockServerHttpRequest
                .post("/bcm/demo/user-profile")
                .header(HeaderConstants.X_REQUEST_ID, "trace-error"));
        WebFilterChain chain = currentExchange -> Mono.error(new BffException(ErrorCode.BAD_GATEWAY));

        filter.filter(exchange, chain)
                .onErrorResume(error -> Mono.empty())
                .block();

        assertThat(output).contains("traceId=trace-error");
        assertThat(output).contains("status=502");
        assertThat(output).contains("outcome=error");
        assertThat(output).contains("errorCode=502");
    }
}

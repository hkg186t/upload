package com.hkbea.bcm.bff.bootstrap.config;

import com.hkbea.bcm.bff.access.config.EntitlementProperties.Iam;
import com.hkbea.bcm.bff.access.entitlement.EntitlementContext;
import com.hkbea.bcm.bff.access.entitlement.IamEntitlementProvider;
import com.hkbea.bcm.bff.access.model.SessionRecord;
import com.hkbea.bcm.bff.shared.api.BffException;
import com.hkbea.bcm.bff.shared.api.ErrorCode;
import com.hkbea.bcm.bff.shared.session.SessionState;
import io.micrometer.core.instrument.Timer;
import io.micrometer.core.instrument.simple.SimpleMeterRegistry;
import org.junit.jupiter.api.Test;
import reactor.core.publisher.Mono;
import reactor.test.StepVerifier;

import java.time.Instant;
import java.util.List;
import java.util.concurrent.atomic.AtomicInteger;

import static org.assertj.core.api.Assertions.assertThat;

class IamEntitlementProviderTest {
    private static final String METRIC_NAME = "bcm.bff.entitlement.duration";

    @Test
    void delegatesToIamClient() {
        IamEntitlementProvider provider = new IamEntitlementProvider(
                ignored -> Mono.just(new EntitlementContext(
                        "iam-user",
                        "iam-customer",
                        "iam-device",
                        "iOS",
                        List.of("BCM_USER"),
                        List.of("bcm:proxy"))),
                new Iam());

        StepVerifier.create(provider.resolve(session()))
                .assertNext(entitlement -> {
                    assertThat(entitlement.userId()).isEqualTo("iam-user");
                    assertThat(entitlement.roles()).containsExactly("BCM_USER");
                    assertThat(entitlement.scopes()).containsExactly("bcm:proxy");
                })
                .verifyComplete();
    }

    @Test
    void mapsIamLookupTimeoutToGatewayTimeout() {
        Iam properties = new Iam();
        properties.setRequestTimeoutMillis(10);
        IamEntitlementProvider provider = new IamEntitlementProvider(
                ignored -> Mono.never(),
                properties);

        StepVerifier.create(provider.resolve(session()))
                .expectErrorSatisfies(error -> {
                    assertThat(error).isInstanceOf(BffException.class);
                    assertThat(((BffException) error).errorCode()).isEqualTo(ErrorCode.UPSTREAM_TIMEOUT);
                    assertThat(error).hasMessage("IAM entitlement lookup timed out");
                })
                .verify();
    }

    @Test
    void opensCircuitAfterConfiguredFailures() {
        Iam properties = new Iam();
        properties.setCircuitBreakerFailureThreshold(1);
        properties.setCircuitBreakerOpenMillis(30000);
        AtomicInteger attempts = new AtomicInteger();
        IamEntitlementProvider provider = new IamEntitlementProvider(
                ignored -> {
                    attempts.incrementAndGet();
                    return Mono.error(new IllegalStateException("iam down"));
                },
                properties);

        StepVerifier.create(provider.resolve(session()))
                .expectErrorSatisfies(error -> {
                    assertThat(error).isInstanceOf(BffException.class);
                    assertThat(((BffException) error).errorCode()).isEqualTo(ErrorCode.BAD_GATEWAY);
                    assertThat(error).hasMessage("IAM entitlement lookup failed");
                })
                .verify();

        StepVerifier.create(provider.resolve(session()))
                .expectErrorSatisfies(error -> {
                    assertThat(error).isInstanceOf(BffException.class);
                    assertThat(((BffException) error).errorCode()).isEqualTo(ErrorCode.BAD_GATEWAY);
                    assertThat(error).hasMessage("IAM entitlement circuit is open");
                })
                .verify();

        assertThat(attempts.get()).isEqualTo(1);
    }

    @Test
    void recordsEntitlementMetrics() {
        SimpleMeterRegistry registry = new SimpleMeterRegistry();
        IamEntitlementProvider successProvider = new IamEntitlementProvider(
                ignored -> Mono.just(EntitlementContext.fromSession(session())),
                new Iam(),
                registry);
        IamEntitlementProvider failureProvider = new IamEntitlementProvider(
                ignored -> Mono.error(new IllegalStateException("iam down")),
                new Iam(),
                registry);

        StepVerifier.create(successProvider.resolve(session()))
                .expectNextCount(1)
                .verifyComplete();
        StepVerifier.create(failureProvider.resolve(session()))
                .expectError(BffException.class)
                .verify();

        Timer successTimer = registry.find(METRIC_NAME)
                .tag("provider", "iam")
                .tag("outcome", "success")
                .tag("errorCode", "none")
                .timer();
        Timer failureTimer = registry.find(METRIC_NAME)
                .tag("provider", "iam")
                .tag("outcome", "error")
                .tag("errorCode", "502")
                .timer();

        assertThat(successTimer).isNotNull();
        assertThat(successTimer.count()).isEqualTo(1);
        assertThat(failureTimer).isNotNull();
        assertThat(failureTimer.count()).isEqualTo(1);
    }

    private static SessionRecord session() {
        Instant now = Instant.parse("2026-05-17T00:00:00Z");
        return new SessionRecord(
                "sid",
                "session-user",
                "session-customer",
                "session-device",
                "Android",
                List.of("SESSION_ROLE"),
                List.of("session:scope"),
                null,
                SessionState.ACTIVE,
                1,
                "refresh-token-id",
                now,
                now);
    }
}

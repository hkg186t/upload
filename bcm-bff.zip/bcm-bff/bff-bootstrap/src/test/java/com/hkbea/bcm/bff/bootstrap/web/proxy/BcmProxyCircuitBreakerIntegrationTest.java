package com.hkbea.bcm.bff.bootstrap.web.proxy;

import com.fasterxml.jackson.databind.JsonNode;
import com.hkbea.bcm.bff.bootstrap.test.BffRandomPortSpringBootTest;
import com.hkbea.bcm.bff.bootstrap.web.ContractTestHeaders;
import io.micrometer.core.instrument.MeterRegistry;
import io.micrometer.core.instrument.Timer;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.DynamicPropertyRegistry;
import org.springframework.test.context.DynamicPropertySource;
import org.springframework.test.web.reactive.server.WebTestClient;

import java.util.Map;
import java.util.UUID;

import static com.hkbea.bcm.bff.bootstrap.web.RuntimeEnvelopeAssertions.assertErrorEnvelope;
import static org.assertj.core.api.Assertions.assertThat;
import static org.springframework.http.MediaType.APPLICATION_JSON;

@BffRandomPortSpringBootTest(properties = {
        "bff.auth.jwt-secret=test-secret-for-bcm-proxy-circuit",
        "bff.proxy.bcm.routes.user-profile.retry-max-attempts=1",
        "bff.proxy.bcm.routes.user-profile.bulkhead-max-concurrent-requests=10",
        "bff.proxy.bcm.routes.user-profile.circuit-breaker-failure-threshold=2",
        "bff.proxy.bcm.routes.user-profile.circuit-breaker-open-millis=30000"
})
class BcmProxyCircuitBreakerIntegrationTest {
    private static final String PROXY_DURATION_METRIC = "bcm.bff.proxy.duration";
    private static final MockBcmUpstream UPSTREAM = MockBcmUpstream.start();

    @Autowired
    private WebTestClient webTestClient;

    @Autowired
    private MeterRegistry meterRegistry;

    @DynamicPropertySource
    static void proxyProperties(DynamicPropertyRegistry registry) {
        registry.add("bff.proxy.bcm.base-url", UPSTREAM::baseUrl);
    }

    @AfterAll
    static void stopUpstream() {
        UPSTREAM.stop();
    }

    @Test
    void opensCircuitAfterConsecutiveUpstreamFailures() {
        String token = login();

        assertErrorEnvelope(proxy(token, "test-circuit-fail-1", Map.of("mode", "upstream500"), 502),
                "502", "Upstream service error");
        assertErrorEnvelope(proxy(token, "test-circuit-fail-2", Map.of("mode", "upstream500"), 502),
                "502", "Upstream service error");

        JsonNode openCircuit = proxy(token, "test-circuit-open", Map.of("mode", "normal"), 502);

        assertErrorEnvelope(openCircuit, "502", "BCM proxy circuit is open");
        assertProxyTimer("error", "502", "none", "circuit_open");
    }

    private String login() {
        JsonNode body = ContractTestHeaders.withRequiredHeaders(webTestClient.post()
                .uri("/auth/login"))
                .contentType(APPLICATION_JSON)
                .bodyValue(Map.of(
                        "username", "CIRCUIT-" + UUID.randomUUID(),
                        "password", "demo",
                        "parentAccountId", "015521104095930",
                        "deviceId", "test-device",
                        "deviceOs", "Android",
                        "locale", "en"))
                .exchange()
                .expectStatus().isOk()
                .expectBody(JsonNode.class)
                .returnResult()
                .getResponseBody();

        assertThat(body).isNotNull();
        return body.path("data").path("accessToken").asText();
    }

    private JsonNode proxy(String token, String requestId, Map<String, String> payload, int expectedStatus) {
        JsonNode body = ContractTestHeaders.withRequiredHeaders(webTestClient.post()
                .uri("/bcm/demo/user-profile"), requestId)
                .contentType(APPLICATION_JSON)
                .header("Authorization", "Bearer " + token)
                .bodyValue(payload)
                .exchange()
                .expectStatus().isEqualTo(expectedStatus)
                .expectBody(JsonNode.class)
                .returnResult()
                .getResponseBody();

        assertThat(body).isNotNull();
        return body;
    }

    private void assertProxyTimer(String outcome, String errorCode, String upstreamStatus, String failureReason) {
        Timer timer = meterRegistry.find(PROXY_DURATION_METRIC)
                .tag("routeId", "user-profile")
                .tag("method", "POST")
                .tag("outcome", outcome)
                .tag("errorCode", errorCode)
                .tag("upstreamStatus", upstreamStatus)
                .tag("failureReason", failureReason)
                .timer();

        assertThat(timer).isNotNull();
        assertThat(timer.count()).isPositive();
    }
}

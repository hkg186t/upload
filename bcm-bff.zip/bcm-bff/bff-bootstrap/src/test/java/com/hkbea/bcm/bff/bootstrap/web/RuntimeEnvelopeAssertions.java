package com.hkbea.bcm.bff.bootstrap.web;

import com.fasterxml.jackson.databind.JsonNode;
import com.hkbea.bcm.bff.shared.http.HeaderConstants;
import org.springframework.http.HttpHeaders;

import static org.assertj.core.api.Assertions.assertThat;

public final class RuntimeEnvelopeAssertions {
    private RuntimeEnvelopeAssertions() {
    }

    public static JsonNode assertSuccessEnvelope(JsonNode body) {
        assertThat(body).isNotNull();
        assertThat(body.path("code").asText()).isEqualTo("0000");
        assertThat(body.path("message").asText()).isEqualTo("success");
        assertThat(body.path("data").isMissingNode()).isFalse();
        assertThat(body.path("status").isMissingNode()).isTrue();
        return body.path("data");
    }

    public static JsonNode assertSuccessEnvelope(JsonNode body, String traceId) {
        JsonNode data = assertSuccessEnvelope(body);
        assertThat(body.path("traceId").asText()).isEqualTo(traceId);
        return data;
    }

    public static JsonNode assertErrorEnvelope(JsonNode body, String code, String message) {
        assertThat(body).isNotNull();
        assertThat(body.path("status").asText()).isEqualTo(code);
        assertThat(body.path("code").asText()).isEqualTo(code);
        assertThat(body.path("message").asText()).isEqualTo(message);
        assertThat(body.path("data").isMissingNode()).isTrue();
        return body;
    }

    public static JsonNode assertErrorEnvelope(JsonNode body, String code, String message, String traceId) {
        JsonNode envelope = assertErrorEnvelope(body, code, message);
        assertThat(envelope.path("traceId").asText()).isEqualTo(traceId);
        return envelope;
    }

    public static void assertSecurityHeaders(HttpHeaders headers) {
        assertThat(headers.getCacheControl()).isEqualTo(SecurityHeadersWebFilter.CACHE_CONTROL_VALUE);
        assertThat(headers.getFirst(SecurityHeadersWebFilter.PRAGMA)).isEqualTo("no-cache");
        assertThat(headers.getFirst(SecurityHeadersWebFilter.EXPIRES)).isEqualTo("0");
        assertThat(headers.getFirst(SecurityHeadersWebFilter.X_CONTENT_TYPE_OPTIONS)).isEqualTo("nosniff");
        assertThat(headers.getFirst(SecurityHeadersWebFilter.X_FRAME_OPTIONS)).isEqualTo("DENY");
        assertThat(headers.getFirst(SecurityHeadersWebFilter.REFERRER_POLICY)).isEqualTo("no-referrer");
    }

    public static void assertTraceHeaders(HttpHeaders headers, String traceId) {
        assertThat(headers.getFirst(HeaderConstants.X_REQUEST_ID)).isEqualTo(traceId);
        assertThat(headers.getFirst(HeaderConstants.X_CORRELATION_ID)).isEqualTo(traceId);
    }

    public static String assertGeneratedTraceHeaders(HttpHeaders headers, String rejectedTraceId) {
        String traceId = headers.getFirst(HeaderConstants.X_REQUEST_ID);
        assertThat(traceId)
                .isNotBlank()
                .isNotEqualTo(rejectedTraceId)
                .hasSizeLessThanOrEqualTo(TraceIdWebFilter.MAX_TRACE_ID_LENGTH);
        assertThat(headers.getFirst(HeaderConstants.X_CORRELATION_ID)).isEqualTo(traceId);
        return traceId;
    }
}

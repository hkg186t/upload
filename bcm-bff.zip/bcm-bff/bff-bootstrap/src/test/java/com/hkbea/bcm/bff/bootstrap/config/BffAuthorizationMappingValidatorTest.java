package com.hkbea.bcm.bff.bootstrap.config;

import com.hkbea.bcm.bff.access.config.AuthorizationPolicyProperties;
import com.hkbea.bcm.bff.bootstrap.web.DummyProtectedController;
import org.junit.jupiter.api.Test;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.reactive.result.method.RequestMappingInfo;
import org.springframework.web.reactive.result.method.annotation.RequestMappingHandlerMapping;

import java.lang.reflect.Method;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import static org.assertj.core.api.Assertions.assertThatCode;
import static org.assertj.core.api.Assertions.assertThatThrownBy;

class BffAuthorizationMappingValidatorTest {
    @Test
    void acceptsProtectedBusinessMappingWithAuthorizationRule() throws Exception {
        AuthorizationPolicyProperties properties = propertiesWithRules(rule(
                "GET",
                "/accounts/{accountId}",
                List.of("BCM_USER"),
                List.of("account:read"),
                List.of("Android", "iOS")
        ));
        BffAuthorizationMappingValidator validator = new BffAuthorizationMappingValidator(
                properties,
                mappingHandler("/accounts/{accountId}", RequestMethod.GET, "account")
        );

        assertThatCode(validator::validate).doesNotThrowAnyException();
    }

    @Test
    void rejectsProtectedBusinessMappingWithoutAuthorizationRule() throws Exception {
        BffAuthorizationMappingValidator validator = new BffAuthorizationMappingValidator(
                new AuthorizationPolicyProperties(),
                mappingHandler("/accounts/{accountId}", RequestMethod.GET, "account")
        );

        assertThatThrownBy(validator::validate)
                .isInstanceOf(IllegalStateException.class)
                .hasMessageContaining("Missing authorization rule for BFF mapping GET /accounts/{accountId}");
    }

    @Test
    void rejectsMatchingRuleWithoutConstraints() throws Exception {
        AuthorizationPolicyProperties properties = propertiesWithRules(rule(
                "GET",
                "/accounts/{accountId}",
                List.of(),
                List.of(),
                List.of()
        ));
        BffAuthorizationMappingValidator validator = new BffAuthorizationMappingValidator(
                properties,
                mappingHandler("/accounts/{accountId}", RequestMethod.GET, "account")
        );

        assertThatThrownBy(validator::validate)
                .isInstanceOf(IllegalStateException.class)
                .hasMessageContaining("must define at least one required role");
    }

    @Test
    void ignoresAuthHealthAndWildcardRouteMappings() throws Exception {
        RequestMappingHandlerMapping handlerMapping = new RequestMappingHandlerMapping();
        register(handlerMapping, "/auth/logout", RequestMethod.POST, "auth");
        register(handlerMapping, "/health", RequestMethod.GET, "health");
        register(handlerMapping, "/bcm/**", RequestMethod.POST, "proxy");
        register(handlerMapping, "/bff/**", RequestMethod.POST, "aggregation");
        register(handlerMapping, "/corporate/**", RequestMethod.POST, "proxy");
        register(handlerMapping, "/dsp/corporate/**", RequestMethod.POST, "proxy");

        BffAuthorizationMappingValidator validator = new BffAuthorizationMappingValidator(
                new AuthorizationPolicyProperties(),
                handlerMapping
        );

        assertThatCode(validator::validate).doesNotThrowAnyException();
    }

    private static RequestMappingHandlerMapping mappingHandler(
            String path,
            RequestMethod method,
            String handlerMethodName
    ) throws Exception {
        RequestMappingHandlerMapping handlerMapping = new RequestMappingHandlerMapping();
        register(handlerMapping, path, method, handlerMethodName);
        return handlerMapping;
    }

    private static void register(
            RequestMappingHandlerMapping handlerMapping,
            String path,
            RequestMethod requestMethod,
            String handlerMethodName
    ) throws Exception {
        Method method = DummyProtectedController.class.getDeclaredMethod(handlerMethodName);
        RequestMappingInfo mappingInfo = RequestMappingInfo
                .paths(path)
                .methods(requestMethod)
                .build();
        handlerMapping.registerMapping(mappingInfo, new DummyProtectedController(), method);
    }

    private static AuthorizationPolicyProperties propertiesWithRules(AuthorizationPolicyProperties.Rule rule) {
        AuthorizationPolicyProperties properties = new AuthorizationPolicyProperties();
        properties.setRules(new LinkedHashMap<>(Map.of("test", rule)));
        return properties;
    }

    private static AuthorizationPolicyProperties.Rule rule(
            String method,
            String path,
            List<String> roles,
            List<String> scopes,
            List<String> deviceOs
    ) {
        AuthorizationPolicyProperties.Rule rule = new AuthorizationPolicyProperties.Rule();
        rule.setMethod(method);
        rule.setPath(path);
        rule.setRequiredRoles(roles);
        rule.setRequiredScopes(scopes);
        rule.setAllowedDeviceOs(deviceOs);
        return rule;
    }
}

package com.hkbea.bcm.bff.bootstrap.contract;

import com.hkbea.bcm.bff.access.config.AuthorizationPolicyProperties;
import com.hkbea.bcm.bff.aggregation.config.AggregationProperties;
import com.hkbea.bcm.bff.bootstrap.config.RateLimitProperties;
import com.hkbea.bcm.bff.bootstrap.config.RequestSizeLimitProperties;
import com.hkbea.bcm.bff.bootstrap.test.BffRandomPortSpringBootTest;
import com.hkbea.bcm.bff.bootstrap.web.account.AccountController;
import com.hkbea.bcm.bff.bootstrap.web.aggregation.AggregationController;
import com.hkbea.bcm.bff.bootstrap.web.auth.AuthController;
import com.hkbea.bcm.bff.bootstrap.web.proxy.BcmProxyController;
import com.hkbea.bcm.bff.contract.api.AccountsApi;
import com.hkbea.bcm.bff.contract.api.AuthApi;
import com.hkbea.bcm.bff.contract.api.BcmProxyApi;
import com.hkbea.bcm.bff.contract.api.BffAggregationApi;
import com.hkbea.bcm.bff.bootstrap.contract.OpenApiContractSnapshot.AccessRule;
import com.hkbea.bcm.bff.bootstrap.contract.OpenApiContractSnapshot.AggregationRoute;
import com.hkbea.bcm.bff.bootstrap.contract.OpenApiContractSnapshot.AggregationStep;
import com.hkbea.bcm.bff.bootstrap.contract.OpenApiContractSnapshot.ApiErrorResponse;
import com.hkbea.bcm.bff.bootstrap.contract.OpenApiContractSnapshot.ApiHandler;
import com.hkbea.bcm.bff.bootstrap.contract.OpenApiContractSnapshot.ApiOperation;
import com.hkbea.bcm.bff.bootstrap.contract.OpenApiContractSnapshot.ApiParameters;
import com.hkbea.bcm.bff.bootstrap.contract.OpenApiContractSnapshot.ApiResponseHeaders;
import com.hkbea.bcm.bff.bootstrap.contract.OpenApiContractSnapshot.ApiSecurity;
import com.hkbea.bcm.bff.bootstrap.contract.OpenApiContractSnapshot.ApiSuccessEnvelope;
import com.hkbea.bcm.bff.bootstrap.contract.OpenApiContractSnapshot.CommonErrorResponse;
import com.hkbea.bcm.bff.bootstrap.contract.OpenApiContractSnapshot.ProxyRoute;
import com.hkbea.bcm.bff.proxy.config.BcmProxyProperties;
import com.hkbea.bcm.bff.shared.api.ApiResponse;
import com.hkbea.bcm.bff.shared.api.ErrorCode;
import com.hkbea.bcm.bff.shared.api.ErrorResponse;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.ApplicationContext;
import org.springframework.web.method.HandlerMethod;
import org.springframework.web.reactive.result.method.RequestMappingInfo;
import org.springframework.web.reactive.result.method.annotation.RequestMappingHandlerMapping;

import java.lang.reflect.RecordComponent;
import java.util.Arrays;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.function.Function;
import java.util.regex.Pattern;
import java.util.stream.Collectors;

import static org.assertj.core.api.Assertions.assertThat;

@BffRandomPortSpringBootTest(properties = {
        "bff.auth.jwt-secret=test-secret-for-contract-runtime-conformance"
})
class ContractRuntimeConformanceTest {
    private static final Pattern LOWER_CAMEL_OPERATION_ID = Pattern.compile("^[a-z][A-Za-z0-9]*$");
    private static final List<String> REQUIRED_EDGE_HEADER_PARAMETERS = List.of(
            "XRequestId",
            "XCorrelationId",
            "XChannel",
            "XAppId"
    );
    private static final String USER_CONTEXT_PARAMETER = "XUserContext";
    private static final String CORRELATION_RESPONSE_HEADER = "X-Correlation-Id";
    private static final String ERROR_RESPONSE_CONTENT_TYPE = "application/json";
    private static final String ERROR_RESPONSE_SCHEMA_REF = "#/components/schemas/Error";
    private static final Set<String> NON_CONTRACT_AUTHORIZATION_RULE_IDS = Set.of(
            "legacy-bcm-proxy-get",
            "legacy-bcm-proxy-post",
            "legacy-bcm-proxy-put",
            "legacy-bcm-proxy-patch",
            "legacy-bcm-proxy-delete",
            "legacy-bco-proxy-get",
            "legacy-bco-proxy-post",
            "legacy-bco-proxy-put",
            "legacy-bco-proxy-patch",
            "legacy-bco-proxy-delete"
    );
    private static final Map<String, String> EXPECTED_TAG_BY_PATH_PREFIX = Map.of(
            "/accounts/", "Accounts",
            "/auth/", "Auth",
            "/bcm/", "BcmProxy",
            "/bff/", "BffAggregation"
    );

    @Autowired
    private ApplicationContext applicationContext;

    @Autowired
    @Qualifier("requestMappingHandlerMapping")
    private RequestMappingHandlerMapping handlerMapping;

    @Autowired
    private RequestSizeLimitProperties requestSizeLimitProperties;

    @Autowired
    private RateLimitProperties rateLimitProperties;

    @Autowired
    private AuthorizationPolicyProperties authorizationPolicyProperties;

    @Autowired
    private BcmProxyProperties proxyProperties;

    @Autowired
    private AggregationProperties aggregationProperties;

    @Test
    void generatedApiInterfacesHaveExactlyOneControllerImplementation() {
        assertSingleApiImplementation(AuthApi.class, AuthController.class);
        assertSingleApiImplementation(BcmProxyApi.class, BcmProxyController.class);
        assertSingleApiImplementation(BffAggregationApi.class, AggregationController.class);
        assertSingleApiImplementation(AccountsApi.class, AccountController.class);
    }

    @Test
    void generatedContractOperationsAreRegisteredInWebFluxMappings() {
        OpenApiContractSnapshot openApi = OpenApiContractSnapshot.load();
        List<String> mappings = handlerMapping.getHandlerMethods().entrySet().stream()
                .map(ContractRuntimeConformanceTest::mappingLabel)
                .toList();

        openApi.apiHandlers().forEach(handler -> assertMapping(mappings, handler));
    }

    @Test
    void openApiOperationIdsAreUniqueAndOwnedByExpectedApiTags() {
        OpenApiContractSnapshot openApi = OpenApiContractSnapshot.load();
        List<ApiHandler> handlers = openApi.apiHandlers();

        assertThat(handlers)
                .extracting(ApiHandler::operationId)
                .doesNotHaveDuplicates()
                .allSatisfy(operationId -> assertThat(operationId)
                        .as("OpenAPI operationId")
                        .matches(LOWER_CAMEL_OPERATION_ID));
        handlers.forEach(ContractRuntimeConformanceTest::assertExpectedApiTag);
    }

    @Test
    void openApiOperationsDeclareRequiredEdgeHeaderParameters() {
        OpenApiContractSnapshot openApi = OpenApiContractSnapshot.load();

        openApi.apiParameters().forEach(this::assertRequiredEdgeHeaders);
    }

    @Test
    void openApiSuccessResponsesDeclareCorrelationHeader() {
        OpenApiContractSnapshot openApi = OpenApiContractSnapshot.load();

        openApi.successResponseHeaders().forEach(ContractRuntimeConformanceTest::assertCorrelationHeader);
    }

    @Test
    void openApiSuccessEnvelopesMatchRuntimeApiResponseEnvelope() {
        OpenApiContractSnapshot openApi = OpenApiContractSnapshot.load();
        List<ApiSuccessEnvelope> successEnvelopes = openApi.successEnvelopes();

        assertThat(successEnvelopes)
                .as("OpenAPI success responses using SuccessResponseBase")
                .isNotEmpty();
        successEnvelopes.forEach(ContractRuntimeConformanceTest::assertSuccessEnvelope);
    }

    @Test
    void openApiErrorSchemaMatchesRuntimeErrorResponseEnvelope() {
        OpenApiContractSnapshot openApi = OpenApiContractSnapshot.load();

        assertThat(openApi.errorSchemaRequiredFields())
                .as("OpenAPI Error schema required fields")
                .containsExactlyInAnyOrderElementsOf(runtimeErrorResponseFields());
    }

    @Test
    void openApiCommonErrorResponseCodesMatchRuntimeErrorCodes() {
        OpenApiContractSnapshot openApi = OpenApiContractSnapshot.load();
        Map<String, CommonErrorResponse> contractResponsesByCode = indexBy(
                openApi.commonErrorResponses(),
                CommonErrorResponse::code);
        Map<String, ErrorCode> runtimeErrorCodes = indexBy(runtimeErrorCodes(), ErrorCode::code);

        openApi.commonErrorResponses().forEach(ContractRuntimeConformanceTest::assertCommonErrorResponseCode);
        assertThat(contractResponsesByCode.keySet())
                .as("OpenAPI common error response codes")
                .containsExactlyInAnyOrderElementsOf(runtimeErrorCodes.keySet());
    }

    @Test
    void openApiErrorResponsesUseStandardErrorEnvelope() {
        OpenApiContractSnapshot openApi = OpenApiContractSnapshot.load();

        openApi.errorResponses().forEach(ContractRuntimeConformanceTest::assertStandardErrorEnvelope);
    }

    @Test
    void runtimeEdgeErrorResponsesAreDeclaredInOpenApi() {
        OpenApiContractSnapshot openApi = OpenApiContractSnapshot.load();

        assertRuntimeGuardrailResponses(openApi, openApi.operations());
        assertOperationResponses(openApi, "POST", "/auth/login", "400", "401", "502", "504");
        assertOperationResponses(openApi, "POST", "/auth/refresh", "400", "419", "502", "504");
        assertOperationResponses(openApi, "POST", "/auth/logout", "502", "504");
        assertOperationResponses(openApi, "POST", "/bcm/demo/user-profile", "502", "504");
        assertOperationResponses(openApi, "POST", "/bff/demo/home-summary", "502", "504");
        assertOperationResponses(openApi, "GET", "/accounts/{accountId}", "400", "404", "500");
    }

    @Test
    void openApiSecurityMatchesRuntimeAuthBoundary() {
        OpenApiContractSnapshot openApi = OpenApiContractSnapshot.load();

        openApi.operationSecurity().forEach(this::assertOperationSecurity);
    }

    @Test
    void openApiBffExtensionsMatchRuntimeRouteConfiguration() {
        OpenApiContractSnapshot openApi = OpenApiContractSnapshot.load();
        Map<String, AccessRule> accessRules = indexBy(openApi.accessRules(), AccessRule::ruleId);
        Map<String, ProxyRoute> proxyRoutes = indexBy(openApi.proxyRoutes(), ProxyRoute::routeId);
        Map<String, AggregationRoute> aggregationRoutes = indexBy(
                openApi.aggregationRoutes(),
                AggregationRoute::aggregationId
        );

        assertAuthorizationRules(accessRules, proxyRoutes, aggregationRoutes);
        assertProxyRoutes(proxyRoutes);
        assertAggregationRoutes(aggregationRoutes);
    }

    private <T> void assertSingleApiImplementation(Class<T> apiType, Class<? extends T> expectedImplementation) {
        Map<String, T> beans = applicationContext.getBeansOfType(apiType);

        assertThat(beans)
                .as("Spring beans implementing " + apiType.getSimpleName())
                .hasSize(1);
        assertThat(beans.values().iterator().next())
                .isInstanceOf(expectedImplementation);
    }

    private static void assertMapping(List<String> mappings, ApiHandler handler) {
        ApiOperation operation = handler.operation();

        assertThat(mappings)
                .as("WebFlux mapping for " + operation.method() + " " + operation.path()
                        + " -> operationId " + handler.operationId())
                .anySatisfy(mapping -> assertThat(mapping)
                        .contains(operation.method())
                        .contains(operation.path())
                        .contains("#" + handler.operationId()));
    }

    private void assertRequiredEdgeHeaders(ApiParameters apiParameters) {
        ApiOperation operation = apiParameters.operation();

        assertThat(apiParameters.parameterIds())
                .as("OpenAPI edge header parameters for " + operation.method() + " " + operation.path())
                .containsAll(REQUIRED_EDGE_HEADER_PARAMETERS);
        if (requiresUserContext(operation)) {
            assertThat(apiParameters.parameterIds())
                    .as("OpenAPI user context header for protected business operation "
                            + operation.method() + " " + operation.path())
                    .contains(USER_CONTEXT_PARAMETER);
        } else {
            assertThat(apiParameters.parameterIds())
                    .as("OpenAPI user context header for operation "
                            + operation.method() + " " + operation.path())
                    .doesNotContain(USER_CONTEXT_PARAMETER);
        }
    }

    private boolean requiresUserContext(ApiOperation operation) {
        return requiresBearerSession(operation) && !operation.path().startsWith("/auth/");
    }

    private static void assertCorrelationHeader(ApiResponseHeaders responseHeaders) {
        ApiOperation operation = responseHeaders.operation();

        assertThat(responseHeaders.headerNames())
                .as("OpenAPI success response headers for " + operation.method() + " "
                        + operation.path() + " status " + responseHeaders.status())
                .contains(CORRELATION_RESPONSE_HEADER);
    }

    private static List<String> runtimeErrorResponseFields() {
        return Arrays.stream(ErrorResponse.class.getRecordComponents())
                .map(RecordComponent::getName)
                .toList();
    }

    private static List<String> runtimeSuccessResponseFields() {
        return Arrays.stream(ApiResponse.class.getRecordComponents())
                .map(RecordComponent::getName)
                .toList();
    }

    private static void assertSuccessEnvelope(ApiSuccessEnvelope successEnvelope) {
        ApiOperation operation = successEnvelope.operation();
        String label = operation.method() + " " + operation.path()
                + " status " + successEnvelope.status()
                + " schema " + successEnvelope.schemaName();

        assertThat(successEnvelope.requiredFields())
                .as("OpenAPI success envelope required fields for " + label)
                .containsExactlyInAnyOrderElementsOf(runtimeSuccessResponseFields());
        assertThat(successEnvelope.exampleCode())
                .as("OpenAPI success envelope example code for " + label)
                .isEqualTo(ErrorCode.SUCCESS.code());
        assertThat(successEnvelope.exampleMessage())
                .as("OpenAPI success envelope example message for " + label)
                .isEqualTo(ErrorCode.SUCCESS.defaultMessage());
    }

    private static List<ErrorCode> runtimeErrorCodes() {
        return Arrays.stream(ErrorCode.values())
                .filter(errorCode -> errorCode != ErrorCode.SUCCESS)
                .toList();
    }

    private static void assertCommonErrorResponseCode(CommonErrorResponse errorResponse) {
        assertThat(errorResponse.code())
                .as("OpenAPI common error response code for " + errorResponse.name())
                .isNotBlank();
        assertThat(errorResponse.status())
                .as("OpenAPI common error response status for " + errorResponse.name())
                .isEqualTo(errorResponse.code());
    }

    private static void assertStandardErrorEnvelope(ApiErrorResponse errorResponse) {
        ApiOperation operation = errorResponse.operation();
        String label = operation.method() + " " + operation.path() + " status " + errorResponse.status();

        assertThat(errorResponse.contentTypes())
                .as("OpenAPI error response content types for " + label)
                .containsExactly(ERROR_RESPONSE_CONTENT_TYPE);
        assertThat(errorResponse.schemaRef())
                .as("OpenAPI error response schema for " + label)
                .isEqualTo(ERROR_RESPONSE_SCHEMA_REF);
    }

    private static void assertExpectedApiTag(ApiHandler handler) {
        ApiOperation operation = handler.operation();
        String expectedTag = expectedTag(operation);

        assertThat(handler.tags())
                .as("OpenAPI tags for " + operation.method() + " " + operation.path())
                .containsExactly(expectedTag);
    }

    private static String expectedTag(ApiOperation operation) {
        return EXPECTED_TAG_BY_PATH_PREFIX.entrySet().stream()
                .filter(entry -> operation.path().startsWith(entry.getKey()))
                .map(Map.Entry::getValue)
                .findFirst()
                .orElseThrow(() -> new IllegalStateException("No expected OpenAPI tag for "
                        + operation.method() + " " + operation.path()));
    }

    private static void assertResponses(OpenApiContractSnapshot openApi, String method, String path, String... statuses) {
        assertThat(openApi.responseStatuses(method, path))
                .as("OpenAPI responses for " + method + " " + path)
                .contains(statuses);
    }

    private void assertRuntimeGuardrailResponses(OpenApiContractSnapshot openApi, List<ApiOperation> operations) {
        operations.forEach(operation -> {
            if (requiresBearerSession(operation)) {
                assertOperationResponses(openApi, operation, "401", "419");
            }
            if (hasAuthorizationPolicy(operation)) {
                assertOperationResponses(openApi, operation, "403");
            }
            if (hasRequestSizeLimit(operation)) {
                assertOperationResponses(openApi, operation, "413");
            }
            if (hasRateLimit(operation)) {
                assertOperationResponses(openApi, operation, "429");
            }
        });
    }

    private boolean requiresBearerSession(ApiOperation operation) {
        return !isPublicAuthOperation(operation);
    }

    private static boolean isPublicAuthOperation(ApiOperation operation) {
        return "POST".equals(operation.method())
                && Set.of("/auth/login", "/auth/refresh").contains(operation.path());
    }

    private boolean hasAuthorizationPolicy(ApiOperation operation) {
        return authorizationPolicyProperties.isEnabled()
                && authorizationPolicyProperties.resolve(operation.method(), operation.path()).isPresent();
    }

    private boolean hasRequestSizeLimit(ApiOperation operation) {
        return requestSizeLimitProperties.isEnabled()
                && !Set.of("GET", "DELETE", "OPTIONS").contains(operation.method())
                && requestSizeLimitProperties.resolveRule(operation.path()).isPresent();
    }

    private boolean hasRateLimit(ApiOperation operation) {
        return rateLimitProperties.isEnabled()
                && !"OPTIONS".equals(operation.method())
                && rateLimitProperties.resolveRule(operation.path()).isPresent();
    }

    private static void assertOperationResponses(
            OpenApiContractSnapshot openApi,
            ApiOperation operation,
            String... statuses
    ) {
        assertOperationResponses(openApi, operation.method(), operation.path(), statuses);
    }

    private static void assertOperationResponses(
            OpenApiContractSnapshot openApi,
            String method,
            String path,
            String... statuses
    ) {
        assertResponses(openApi, method, path, statuses);
    }

    private void assertOperationSecurity(ApiSecurity apiSecurity) {
        ApiOperation operation = apiSecurity.operation();

        assertThat(apiSecurity.bearerAuthRequired())
                .as("OpenAPI bearerAuth declaration for " + operation.method() + " " + operation.path())
                .isEqualTo(requiresBearerSession(operation));
    }

    private void assertAuthorizationRules(
            Map<String, AccessRule> accessRules,
            Map<String, ProxyRoute> proxyRoutes,
            Map<String, AggregationRoute> aggregationRoutes
    ) {
        Set<String> expectedRuleIds = new LinkedHashSet<>();
        expectedRuleIds.addAll(accessRules.keySet());
        expectedRuleIds.addAll(proxyRoutes.keySet());
        aggregationRoutes.keySet().stream()
                .map(ContractRuntimeConformanceTest::aggregationRuleId)
                .forEach(expectedRuleIds::add);

        Set<String> contractManagedRuleIds = authorizationPolicyProperties.getRules().keySet()
                .stream()
                .filter(ruleId -> !NON_CONTRACT_AUTHORIZATION_RULE_IDS.contains(ruleId))
                .collect(Collectors.toCollection(LinkedHashSet::new));

        assertThat(contractManagedRuleIds)
                .as("runtime authorization rule ids generated from OpenAPI BFF extensions")
                .containsExactlyInAnyOrderElementsOf(expectedRuleIds);

        accessRules.values().stream()
                .map(rule -> new ContractAuthorizationRule(
                        rule.ruleId(),
                        rule.method(),
                        rule.path(),
                        rule.requiredRoles(),
                        rule.requiredScopes(),
                        rule.allowedDeviceOs()))
                .forEach(this::assertAuthorizationRule);
        proxyRoutes.values().stream()
                .map(route -> new ContractAuthorizationRule(
                        route.routeId(),
                        route.publicMethod(),
                        route.publicPath(),
                        route.requiredRoles(),
                        route.requiredScopes(),
                        route.allowedDeviceOs()))
                .forEach(this::assertAuthorizationRule);
        aggregationRoutes.values().stream()
                .map(route -> new ContractAuthorizationRule(
                        aggregationRuleId(route.aggregationId()),
                        route.publicMethod(),
                        route.publicPath(),
                        route.requiredRoles(),
                        route.requiredScopes(),
                        route.allowedDeviceOs()))
                .forEach(this::assertAuthorizationRule);
    }

    private void assertAuthorizationRule(ContractAuthorizationRule expected) {
        AuthorizationPolicyProperties.Rule actual = authorizationPolicyProperties.getRules().get(expected.ruleId());

        assertThat(actual)
                .as("authorization rule " + expected.ruleId())
                .isNotNull();
        assertThat(actual.getMethod()).as(expected.ruleId() + " method").isEqualTo(expected.method());
        assertThat(actual.getPath()).as(expected.ruleId() + " path").isEqualTo(expected.path());
        assertThat(actual.getRequiredRoles())
                .as(expected.ruleId() + " required roles")
                .containsExactlyElementsOf(expected.requiredRoles());
        assertThat(actual.getRequiredScopes())
                .as(expected.ruleId() + " required scopes")
                .containsExactlyElementsOf(expected.requiredScopes());
        assertThat(actual.getAllowedDeviceOs())
                .as(expected.ruleId() + " allowed device OS")
                .containsExactlyElementsOf(expected.allowedDeviceOs());
    }

    private void assertProxyRoutes(Map<String, ProxyRoute> expectedRoutes) {
        assertThat(proxyProperties.getRoutes().keySet())
                .as("runtime proxy route ids generated from OpenAPI x-bcm-bff-route extensions")
                .containsExactlyInAnyOrderElementsOf(expectedRoutes.keySet());

        expectedRoutes.forEach((routeId, expected) -> {
            BcmProxyProperties.Route actual = proxyProperties.resolveRoute(routeId);

            assertThat(actual.getPublicMethod()).as(routeId + " public method").isEqualTo(expected.publicMethod());
            assertThat(actual.getPublicPath()).as(routeId + " public path").isEqualTo(expected.publicPath());
            assertThat(actual.getMethod()).as(routeId + " upstream method").isEqualTo(expected.method());
            assertThat(actual.getUpstreamPath()).as(routeId + " upstream path").isEqualTo(expected.upstreamPath());
            assertThat(actual.getResponseTimeoutMillis())
                    .as(routeId + " response timeout")
                    .isEqualTo(expected.responseTimeoutMillis());
            assertThat(actual.isHtmlResponseMeansSessionExpired())
                    .as(routeId + " html session expiry handling")
                    .isEqualTo(expected.htmlResponseMeansSessionExpired());
            assertThat(actual.getRetryMaxAttempts())
                    .as(routeId + " retry max attempts")
                    .isEqualTo(expected.retryMaxAttempts());
            assertThat(actual.getRetryBackoffMillis())
                    .as(routeId + " retry backoff")
                    .isEqualTo(expected.retryBackoffMillis());
            assertThat(actual.getBulkheadMaxConcurrentRequests())
                    .as(routeId + " bulkhead max concurrency")
                    .isEqualTo(expected.bulkheadMaxConcurrentRequests());
            assertThat(actual.isCircuitBreakerEnabled())
                    .as(routeId + " circuit breaker enabled")
                    .isEqualTo(expected.circuitBreakerEnabled());
            assertThat(actual.getCircuitBreakerFailureThreshold())
                    .as(routeId + " circuit breaker failure threshold")
                    .isEqualTo(expected.circuitBreakerFailureThreshold());
            assertThat(actual.getCircuitBreakerOpenMillis())
                    .as(routeId + " circuit breaker open duration")
                    .isEqualTo(expected.circuitBreakerOpenMillis());
        });
    }

    private void assertAggregationRoutes(Map<String, AggregationRoute> expectedRoutes) {
        assertThat(aggregationProperties.getRoutes().keySet())
                .as("runtime aggregation route ids generated from OpenAPI x-bcm-bff-aggregation extensions")
                .containsExactlyInAnyOrderElementsOf(expectedRoutes.keySet());

        expectedRoutes.forEach((aggregationId, expected) -> {
            AggregationProperties.Route actual = aggregationProperties.resolveRoute(aggregationId);
            List<AggregationStep> actualSteps = actual.getSteps().stream()
                    .map(step -> new AggregationStep(
                            step.getName(),
                            step.getProxyRouteId(),
                            step.isRequired()))
                    .toList();

            assertThat(actual.getPublicMethod()).as(aggregationId + " public method").isEqualTo(expected.publicMethod());
            assertThat(actual.getPublicPath()).as(aggregationId + " public path").isEqualTo(expected.publicPath());
            assertThat(actual.getResponseTimeoutMillis())
                    .as(aggregationId + " response timeout")
                    .isEqualTo(expected.responseTimeoutMillis());
            assertThat(actual.isPartialResponseEnabled())
                    .as(aggregationId + " partial response")
                    .isEqualTo(expected.partialResponseEnabled());
            assertThat(actual.getMaxConcurrentSteps())
                    .as(aggregationId + " max concurrent steps")
                    .isEqualTo(expected.maxConcurrentSteps());
            assertThat(actualSteps)
                    .as(aggregationId + " aggregation steps")
                    .containsExactlyElementsOf(expected.steps());
        });
    }

    private static <T> Map<String, T> indexBy(List<T> values, Function<T, String> keyExtractor) {
        return values.stream()
                .collect(Collectors.toMap(
                        keyExtractor,
                        Function.identity(),
                        (left, right) -> {
                            throw new IllegalStateException("Duplicate OpenAPI BFF extension id: "
                                    + keyExtractor.apply(left));
                        },
                        LinkedHashMap::new));
    }

    private static String aggregationRuleId(String aggregationId) {
        return "aggregation-" + aggregationId;
    }

    private static String mappingLabel(Map.Entry<RequestMappingInfo, HandlerMethod> entry) {
        HandlerMethod handlerMethod = entry.getValue();
        return entry.getKey() + " -> "
                + handlerMethod.getBeanType().getSimpleName()
                + "#"
                + handlerMethod.getMethod().getName();
    }

    private record ContractAuthorizationRule(
            String ruleId,
            String method,
            String path,
            List<String> requiredRoles,
            List<String> requiredScopes,
            List<String> allowedDeviceOs
    ) {
    }
}

package com.hkbea.bcm.bff.bootstrap.web;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.hkbea.bcm.bff.shared.api.ErrorCode;
import com.hkbea.bcm.bff.shared.http.HeaderConstants;
import org.junit.jupiter.api.Test;
import org.springframework.http.HttpStatus;
import org.springframework.mock.http.server.reactive.MockServerHttpRequest;
import org.springframework.mock.web.server.MockServerWebExchange;

import static com.hkbea.bcm.bff.bootstrap.web.RuntimeEnvelopeAssertions.assertErrorEnvelope;
import static org.assertj.core.api.Assertions.assertThat;

class BffErrorResponseWriterTest {
    private static final ObjectMapper OBJECT_MAPPER = new ObjectMapper();

    @Test
    void writesStableJsonBodyAndTraceHeaders() throws Exception {
        BffErrorResponseWriter writer = new BffErrorResponseWriter(OBJECT_MAPPER);
        MockServerWebExchange exchange = MockServerWebExchange.from(MockServerHttpRequest
                .post("/bcm/demo/user-profile")
                .header(HeaderConstants.X_REQUEST_ID, "trace-error-1"));

        writer.write(exchange, ErrorCode.SESSION_EXPIRED, "Session Expired").block();

        JsonNode body = OBJECT_MAPPER.readTree(exchange.getResponse().getBodyAsString().block());
        assertThat(exchange.getResponse().getStatusCode()).isEqualTo(HttpStatus.valueOf(419));
        assertThat(exchange.getResponse().getHeaders().getFirst(HeaderConstants.X_REQUEST_ID))
                .isEqualTo("trace-error-1");
        assertThat(exchange.getResponse().getHeaders().getFirst(HeaderConstants.X_CORRELATION_ID))
                .isEqualTo("trace-error-1");
        assertErrorEnvelope(body, "419", "Session Expired", "trace-error-1");
    }

    @Test
    void writesLegacySessionExpiredWithHttpOk() throws Exception {
        BffErrorResponseWriter writer = new BffErrorResponseWriter(OBJECT_MAPPER);
        MockServerWebExchange exchange = MockServerWebExchange.from(MockServerHttpRequest
                .post("/corporate/v1/approval/center/user/userProfile"));

        writer.writeLegacySessionExpired(exchange).block();

        JsonNode body = OBJECT_MAPPER.readTree(exchange.getResponse().getBodyAsString().block());
        assertThat(exchange.getResponse().getStatusCode()).isEqualTo(HttpStatus.OK);
        assertThat(body.path("status").asText()).isEqualTo("419");
        assertThat(body.path("code").asText()).isEqualTo("419");
        assertThat(body.path("message").asText()).isEqualTo("Session Expired");
        assertThat(body.has("traceId")).isFalse();
    }
}

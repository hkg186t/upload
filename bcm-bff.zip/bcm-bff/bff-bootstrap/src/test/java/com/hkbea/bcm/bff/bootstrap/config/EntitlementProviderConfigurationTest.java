package com.hkbea.bcm.bff.bootstrap.config;

import com.hkbea.bcm.bff.access.config.EntitlementProperties;
import com.hkbea.bcm.bff.access.entitlement.EntitlementProvider;
import com.hkbea.bcm.bff.access.entitlement.EntitlementProviderConfiguration;
import com.hkbea.bcm.bff.access.entitlement.IamEntitlementProvider;
import com.hkbea.bcm.bff.access.entitlement.SessionEntitlementProvider;
import org.junit.jupiter.api.Test;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.boot.test.context.runner.ApplicationContextRunner;
import org.springframework.context.annotation.Import;

import static org.assertj.core.api.Assertions.assertThat;

class EntitlementProviderConfigurationTest {
    private final ApplicationContextRunner contextRunner = new ApplicationContextRunner()
            .withUserConfiguration(TestConfiguration.class);

    @Test
    void usesSessionEntitlementProviderByDefault() {
        contextRunner.run(context -> assertThat(context)
                .hasSingleBean(EntitlementProvider.class)
                .getBean(EntitlementProvider.class)
                .isInstanceOf(SessionEntitlementProvider.class));
    }

    @Test
    void usesMockIamEntitlementProviderWhenExplicitlyEnabled() {
        contextRunner
                .withPropertyValues("bff.entitlement.provider=iam")
                .withPropertyValues("bff.entitlement.iam.mock-enabled=true")
                .run(context -> assertThat(context)
                        .hasSingleBean(EntitlementProvider.class)
                        .getBean(EntitlementProvider.class)
                        .isInstanceOf(IamEntitlementProvider.class));
    }

    @Test
    void failsFastForIamProviderWithoutClient() {
        contextRunner
                .withPropertyValues("bff.entitlement.provider=iam")
                .run(context -> {
                    assertThat(context).hasFailed();
                    assertThat(context.getStartupFailure())
                            .hasMessageContaining("BFF entitlement provider 'IAM' requires an IamEntitlementClient");
                });
    }

    @Test
    void failsFastForReservedProviderModes() {
        contextRunner
                .withPropertyValues("bff.entitlement.provider=casbin")
                .run(context -> {
                    assertThat(context).hasFailed();
                    assertThat(context.getStartupFailure())
                            .hasMessageContaining("BFF entitlement provider 'CASBIN' is reserved but not implemented yet");
                });
    }

    @Import(EntitlementProviderConfiguration.class)
    @EnableConfigurationProperties(EntitlementProperties.class)
    static class TestConfiguration {
    }
}

package com.hkbea.bcm.bff.bootstrap.web.proxy;

import com.fasterxml.jackson.databind.JsonNode;
import com.hkbea.bcm.bff.bootstrap.test.BffRandomPortSpringBootTest;
import com.hkbea.bcm.bff.bootstrap.web.ContractTestHeaders;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.DynamicPropertyRegistry;
import org.springframework.test.context.DynamicPropertySource;
import org.springframework.test.web.reactive.server.WebTestClient;

import java.util.List;
import java.util.Map;
import java.util.UUID;

import static com.hkbea.bcm.bff.bootstrap.web.RuntimeEnvelopeAssertions.assertErrorEnvelope;
import static org.assertj.core.api.Assertions.assertThat;
import static org.springframework.http.MediaType.APPLICATION_JSON;

@BffRandomPortSpringBootTest(properties = {
        "bff.auth.jwt-secret=test-secret-for-error-envelope",
        "bff.proxy.bcm.routes.user-profile.retry-max-attempts=1",
        "bff.proxy.bcm.routes.user-profile.bulkhead-max-concurrent-requests=10",
        "bff.proxy.bcm.routes.user-profile.circuit-breaker-failure-threshold=100",
        "bff.proxy.bcm.routes.user-profile.response-timeout-millis=100"
})
class ErrorEnvelopeIntegrationTest {
    private static final MockBcmUpstream UPSTREAM = MockBcmUpstream.start();

    @Autowired
    private WebTestClient webTestClient;

    @DynamicPropertySource
    static void proxyProperties(DynamicPropertyRegistry registry) {
        registry.add("bff.proxy.bcm.base-url", UPSTREAM::baseUrl);
    }

    @AfterAll
    static void stopUpstream() {
        UPSTREAM.stop();
    }

    @Test
    void refreshRejectsRotatedRefreshTokenWithRuntimeErrorEnvelope() {
        String deviceId = "error-refresh-device-" + UUID.randomUUID();
        JsonNode loginBody = login("error-refresh-login-" + UUID.randomUUID(), deviceId);
        String staleRefreshToken = loginBody.path("data").path("refreshToken").asText();
        String firstRefreshTraceId = "error-refresh-first-" + UUID.randomUUID();

        refresh(staleRefreshToken, deviceId, firstRefreshTraceId, 200);

        String traceId = "error-refresh-stale-" + UUID.randomUUID();
        JsonNode body = refresh(staleRefreshToken, deviceId, traceId, 419);

        assertErrorEnvelope(body, "419", "Session Expired", traceId);
    }

    @Test
    void proxyHtmlSessionExpiredKeepsRuntimeErrorEnvelopeTraceId() {
        String token = login("error-html-login-" + UUID.randomUUID()).path("data").path("accessToken").asText();
        String traceId = "error-html-" + UUID.randomUUID();

        JsonNode body = proxy(token, traceId, Map.of("mode", "html"), 419);

        assertErrorEnvelope(body, "419", "Session Expired", traceId);
    }

    @Test
    void proxyUpstreamFailureKeepsRuntimeErrorEnvelopeTraceId() {
        String token = login("error-upstream-login-" + UUID.randomUUID()).path("data").path("accessToken").asText();
        String traceId = "error-upstream-" + UUID.randomUUID();

        JsonNode body = proxy(token, traceId, Map.of("mode", "upstream500"), 502);

        assertErrorEnvelope(body, "502", "Upstream service error", traceId);
    }

    @Test
    void proxyTimeoutKeepsRuntimeErrorEnvelopeTraceId() {
        String token = login("error-timeout-login-" + UUID.randomUUID()).path("data").path("accessToken").asText();
        String traceId = "error-timeout-" + UUID.randomUUID();

        JsonNode body = proxy(token, traceId, Map.of("mode", "slow"), 504);

        assertErrorEnvelope(body, "504", "Upstream Timeout", traceId);
    }

    private JsonNode login(String traceId) {
        return login(traceId, "error-device-" + UUID.randomUUID());
    }

    private JsonNode login(String traceId, String deviceId) {
        JsonNode body = ContractTestHeaders.withRequiredHeaders(webTestClient.post()
                .uri("/auth/login"), traceId)
                .contentType(APPLICATION_JSON)
                .bodyValue(Map.of(
                        "username", "ERROR-" + UUID.randomUUID(),
                        "password", "demo",
                        "parentAccountId", "015521104095930",
                        "deviceId", deviceId,
                        "deviceOs", "Android",
                        "locale", "en",
                        "roles", List.of("BCM_USER"),
                        "scopes", List.of("bcm:proxy", "bcm:aggregate")))
                .exchange()
                .expectStatus().isOk()
                .expectHeader().valueEquals("X-Correlation-Id", traceId)
                .expectBody(JsonNode.class)
                .returnResult()
                .getResponseBody();

        assertThat(body).isNotNull();
        return body;
    }

    private JsonNode refresh(String refreshToken, String deviceId, String traceId, int expectedStatus) {
        JsonNode body = ContractTestHeaders.withRequiredHeaders(webTestClient.post()
                .uri("/auth/refresh"), traceId)
                .contentType(APPLICATION_JSON)
                .bodyValue(Map.of(
                        "refreshToken", refreshToken,
                        "deviceId", deviceId))
                .exchange()
                .expectStatus().isEqualTo(expectedStatus)
                .expectHeader().valueEquals("X-Correlation-Id", traceId)
                .expectBody(JsonNode.class)
                .returnResult()
                .getResponseBody();

        assertThat(body).isNotNull();
        return body;
    }

    private JsonNode proxy(String token, String traceId, Map<String, String> payload, int expectedStatus) {
        JsonNode body = ContractTestHeaders.withRequiredHeaders(webTestClient.post()
                .uri("/bcm/demo/user-profile"), traceId)
                .contentType(APPLICATION_JSON)
                .header("Authorization", "Bearer " + token)
                .bodyValue(payload)
                .exchange()
                .expectStatus().isEqualTo(expectedStatus)
                .expectHeader().valueEquals("X-Correlation-Id", traceId)
                .expectBody(JsonNode.class)
                .returnResult()
                .getResponseBody();

        assertThat(body).isNotNull();
        return body;
    }
}

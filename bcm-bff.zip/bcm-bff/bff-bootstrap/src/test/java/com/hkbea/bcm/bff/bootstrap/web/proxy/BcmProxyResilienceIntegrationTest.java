package com.hkbea.bcm.bff.bootstrap.web.proxy;

import com.fasterxml.jackson.databind.JsonNode;
import com.hkbea.bcm.bff.bootstrap.test.BffRandomPortSpringBootTest;
import com.hkbea.bcm.bff.bootstrap.web.ContractTestHeaders;
import io.micrometer.core.instrument.MeterRegistry;
import io.micrometer.core.instrument.Timer;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.DynamicPropertyRegistry;
import org.springframework.test.context.DynamicPropertySource;
import org.springframework.test.web.reactive.server.WebTestClient;
import org.springframework.test.web.reactive.server.EntityExchangeResult;

import java.util.Map;
import java.util.UUID;
import java.util.concurrent.CompletableFuture;

import static com.hkbea.bcm.bff.bootstrap.web.RuntimeEnvelopeAssertions.assertErrorEnvelope;
import static com.hkbea.bcm.bff.bootstrap.web.RuntimeEnvelopeAssertions.assertSuccessEnvelope;
import static org.assertj.core.api.Assertions.assertThat;
import static org.springframework.http.MediaType.APPLICATION_JSON;

@BffRandomPortSpringBootTest(properties = {
        "bff.auth.jwt-secret=test-secret-for-bcm-proxy-resilience",
        "bff.proxy.bcm.routes.user-profile.retry-max-attempts=2",
        "bff.proxy.bcm.routes.user-profile.retry-backoff-millis=10",
        "bff.proxy.bcm.routes.user-profile.bulkhead-max-concurrent-requests=1",
        "bff.proxy.bcm.routes.user-profile.circuit-breaker-failure-threshold=100",
        "bff.proxy.bcm.routes.user-profile.response-timeout-millis=1500"
})
class BcmProxyResilienceIntegrationTest {
    private static final String PROXY_DURATION_METRIC = "bcm.bff.proxy.duration";
    private static final MockBcmUpstream UPSTREAM = MockBcmUpstream.start();

    @Autowired
    private WebTestClient webTestClient;

    @Autowired
    private MeterRegistry meterRegistry;

    @DynamicPropertySource
    static void proxyProperties(DynamicPropertyRegistry registry) {
        registry.add("bff.proxy.bcm.base-url", UPSTREAM::baseUrl);
    }

    @AfterAll
    static void stopUpstream() {
        UPSTREAM.stop();
    }

    @Test
    void mapsHtmlUpstreamResponseToSessionExpired() {
        String token = login();

        JsonNode body = proxy(token, "test-html", Map.of("mode", "html"), 419);

        assertErrorEnvelope(body, "419", "Session Expired");
        assertProxyTimer("error", "419", "200", "html_session_expired");
    }

    @Test
    void mapsUpstreamServerErrorToBadGateway() {
        String token = login();

        JsonNode body = proxy(token, "test-upstream-500", Map.of("mode", "upstream500"), 502);

        assertErrorEnvelope(body, "502", "Upstream service error");
        assertProxyTimer("error", "502", "500", "upstream_status_error");
    }

    @Test
    void retriesRetryableUpstreamFailure() {
        String token = login();

        JsonNode body = proxy(token, "test-retry-" + UUID.randomUUID(), Map.of("mode", "retry"), 200);

        JsonNode data = assertSuccessEnvelope(body);
        assertThat(data.path("attempt").asInt()).isEqualTo(2);
        assertProxyTimer("success", "none", "200", "none");
    }

    @Test
    void rejectsWhenBulkheadIsFull() {
        String token = login();

        CompletableFuture<JsonNode> slowRequest = CompletableFuture.supplyAsync(() ->
                proxy(token, "test-slow", Map.of("mode", "slow"), 200));
        sleep(50);

        JsonNode busy = proxy(token, "test-busy", Map.of("mode", "normal"), 429);

        assertErrorEnvelope(busy, "429", "BCM proxy route is busy");
        assertProxyTimer("error", "429", "none", "bulkhead_rejected");
        assertSuccessEnvelope(slowRequest.join());
    }

    private String login() {
        JsonNode body = ContractTestHeaders.withRequiredHeaders(webTestClient.post()
                .uri("/auth/login"))
                .contentType(APPLICATION_JSON)
                .bodyValue(Map.of(
                        "username", "TEST-" + UUID.randomUUID(),
                        "password", "demo",
                        "parentAccountId", "015521104095930",
                        "deviceId", "test-device",
                        "deviceOs", "Android",
                        "locale", "en"))
                .exchange()
                .expectStatus().isOk()
                .expectBody(JsonNode.class)
                .returnResult()
                .getResponseBody();

        assertThat(body).isNotNull();
        return body.path("data").path("accessToken").asText();
    }

    private JsonNode proxy(String token, String requestId, Map<String, String> payload, int expectedStatus) {
        EntityExchangeResult<JsonNode> result = ContractTestHeaders.withRequiredHeaders(webTestClient.post()
                .uri("/bcm/demo/user-profile"), requestId)
                .contentType(APPLICATION_JSON)
                .header("Authorization", "Bearer " + token)
                .bodyValue(payload)
                .exchange()
                .expectStatus().isEqualTo(expectedStatus)
                .expectBody(JsonNode.class)
                .returnResult();

        JsonNode body = result.getResponseBody();
        assertThat(body).isNotNull();
        return body;
    }

    private void assertProxyTimer(String outcome, String errorCode, String upstreamStatus, String failureReason) {
        Timer timer = meterRegistry.find(PROXY_DURATION_METRIC)
                .tag("routeId", "user-profile")
                .tag("method", "POST")
                .tag("outcome", outcome)
                .tag("errorCode", errorCode)
                .tag("upstreamStatus", upstreamStatus)
                .tag("failureReason", failureReason)
                .timer();

        assertThat(timer).isNotNull();
        assertThat(timer.count()).isPositive();
    }

    private static void sleep(long millis) {
        try {
            Thread.sleep(millis);
        } catch (InterruptedException error) {
            Thread.currentThread().interrupt();
        }
    }
}

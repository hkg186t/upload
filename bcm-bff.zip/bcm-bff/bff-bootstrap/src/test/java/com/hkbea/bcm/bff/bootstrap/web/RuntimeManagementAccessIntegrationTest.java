package com.hkbea.bcm.bff.bootstrap.web;

import com.fasterxml.jackson.databind.JsonNode;
import com.hkbea.bcm.bff.bootstrap.config.ManagementAccessProperties;
import com.hkbea.bcm.bff.bootstrap.test.BffRandomPortSpringBootTest;
import com.hkbea.bcm.bff.shared.http.HeaderConstants;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.test.web.reactive.server.EntityExchangeResult;
import org.springframework.test.web.reactive.server.WebTestClient;

import static com.hkbea.bcm.bff.bootstrap.web.RuntimeEnvelopeAssertions.assertErrorEnvelope;
import static com.hkbea.bcm.bff.bootstrap.web.RuntimeEnvelopeAssertions.assertSecurityHeaders;
import static com.hkbea.bcm.bff.bootstrap.web.RuntimeEnvelopeAssertions.assertTraceHeaders;
import static org.assertj.core.api.Assertions.assertThat;

@BffRandomPortSpringBootTest(properties = {
        "bff.auth.jwt-secret=test-secret-for-runtime-management-access",
        "bff.management-access.metrics-token=monitoring-token-monitoring-token-32"
})
class RuntimeManagementAccessIntegrationTest {
    private static final String METRICS_TOKEN = "monitoring-token-monitoring-token-32";

    @Autowired
    private WebTestClient webTestClient;

    @Test
    void prometheusAllowsConfiguredManagementTokenWithoutUserBearer() {
        String traceId = "management-prometheus-ok";

        EntityExchangeResult<String> result = webTestClient.get()
                .uri("/actuator/prometheus")
                .header(HeaderConstants.X_REQUEST_ID, traceId)
                .header(ManagementAccessProperties.DEFAULT_METRICS_TOKEN_HEADER, METRICS_TOKEN)
                .exchange()
                .expectStatus().isOk()
                .expectBody(String.class)
                .returnResult();

        HttpHeaders headers = result.getResponseHeaders();
        assertSecurityHeaders(headers);
        assertTraceHeaders(headers, traceId);
        assertThat(headers.getContentType()).isNotNull();
        assertThat(headers.getContentType().isCompatibleWith(MediaType.TEXT_PLAIN)).isTrue();
        assertThat(result.getResponseBody()).isNotBlank();
    }

    @Test
    void prometheusRejectsMissingManagementTokenWithRuntimeErrorEnvelope() {
        String traceId = "management-prometheus-missing";

        EntityExchangeResult<JsonNode> result = webTestClient.get()
                .uri("/actuator/prometheus")
                .header(HeaderConstants.X_REQUEST_ID, traceId)
                .exchange()
                .expectStatus().isUnauthorized()
                .expectBody(JsonNode.class)
                .returnResult();

        assertSecurityHeaders(result.getResponseHeaders());
        assertTraceHeaders(result.getResponseHeaders(), traceId);
        assertErrorEnvelope(result.getResponseBody(), "401", "Invalid or missing Bearer Token", traceId);
    }

    @Test
    void prometheusRejectsWrongManagementTokenWithRuntimeErrorEnvelope() {
        String traceId = "management-prometheus-wrong";

        EntityExchangeResult<JsonNode> result = webTestClient.get()
                .uri("/actuator/prometheus")
                .header(HeaderConstants.X_REQUEST_ID, traceId)
                .header(ManagementAccessProperties.DEFAULT_METRICS_TOKEN_HEADER, "wrong-token")
                .exchange()
                .expectStatus().isUnauthorized()
                .expectBody(JsonNode.class)
                .returnResult();

        assertSecurityHeaders(result.getResponseHeaders());
        assertTraceHeaders(result.getResponseHeaders(), traceId);
        assertErrorEnvelope(result.getResponseBody(), "401", "Invalid or missing Bearer Token", traceId);
    }
}

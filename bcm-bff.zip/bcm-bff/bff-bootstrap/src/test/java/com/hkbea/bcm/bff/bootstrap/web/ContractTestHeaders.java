package com.hkbea.bcm.bff.bootstrap.web;

import org.springframework.test.web.reactive.server.WebTestClient;

import java.util.UUID;

public final class ContractTestHeaders {
    private ContractTestHeaders() {
    }

    public static WebTestClient.RequestBodySpec withRequiredHeaders(WebTestClient.RequestBodySpec request) {
        return withRequiredHeaders(request, UUID.randomUUID().toString());
    }

    public static WebTestClient.RequestBodySpec withRequiredHeaders(
            WebTestClient.RequestBodySpec request,
            String traceId
    ) {
        return request
                .header("X-Request-Id", traceId)
                .header("X-Correlation-Id", traceId)
                .header("X-Channel", "MOBILE")
                .header("X-App-Id", "bcm-bff-test");
    }

    public static WebTestClient.RequestHeadersSpec<?> withRequiredHeaders(
            WebTestClient.RequestHeadersSpec<?> request,
            String traceId
    ) {
        return request
                .header("X-Request-Id", traceId)
                .header("X-Correlation-Id", traceId)
                .header("X-Channel", "MOBILE")
                .header("X-App-Id", "bcm-bff-test");
    }
}

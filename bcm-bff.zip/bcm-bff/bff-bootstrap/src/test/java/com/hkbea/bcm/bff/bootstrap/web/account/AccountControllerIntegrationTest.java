package com.hkbea.bcm.bff.bootstrap.web.account;

import com.fasterxml.jackson.databind.JsonNode;
import com.hkbea.bcm.bff.bootstrap.test.BffRandomPortSpringBootTest;
import com.hkbea.bcm.bff.bootstrap.web.ContractTestHeaders;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.web.reactive.server.WebTestClient;

import java.util.List;
import java.util.Map;
import java.util.UUID;

import static com.hkbea.bcm.bff.bootstrap.web.RuntimeEnvelopeAssertions.assertErrorEnvelope;
import static org.assertj.core.api.Assertions.assertThat;
import static org.springframework.http.MediaType.APPLICATION_JSON;

@BffRandomPortSpringBootTest(properties = {
        "bff.auth.jwt-secret=test-secret-for-account-controller"
})
class AccountControllerIntegrationTest {
    @Autowired
    private WebTestClient webTestClient;

    @Test
    void returnsAccountForAuthorizedSession() {
        String token = login(List.of("BCM_USER"), List.of("account:read"), "Android");

        JsonNode body = ContractTestHeaders.withRequiredHeaders(webTestClient.get()
                .uri("/accounts/{accountId}", "1234567890"), "account-read-ok")
                .header("Authorization", "Bearer " + token)
                .exchange()
                .expectStatus().isOk()
                .expectHeader().valueEquals("X-Correlation-Id", "account-read-ok")
                .expectBody(JsonNode.class)
                .returnResult()
                .getResponseBody();

        assertThat(body).isNotNull();
        assertThat(body.path("accountId").asText()).isEqualTo("1234567890");
        assertThat(body.path("balance").path("value").asText()).isEqualTo("1000.50");
        assertThat(body.path("balance").path("currency").asText()).isEqualTo("HKD");
    }

    @Test
    void rejectsSessionWithoutAccountReadScope() {
        String token = login(List.of("BCM_USER"), List.of("bcm:proxy"), "Android");

        JsonNode body = ContractTestHeaders.withRequiredHeaders(webTestClient.get()
                .uri("/accounts/{accountId}", "1234567890"), "account-read-forbidden")
                .header("Authorization", "Bearer " + token)
                .exchange()
                .expectStatus().isForbidden()
                .expectBody(JsonNode.class)
                .returnResult()
                .getResponseBody();

        assertErrorEnvelope(body, "403", "Missing required scope", "account-read-forbidden");
    }

    @Test
    void validatesAccountIdAgainstContractShape() {
        String token = login(List.of("BCM_USER"), List.of("account:read"), "Android");

        JsonNode body = ContractTestHeaders.withRequiredHeaders(webTestClient.get()
                .uri("/accounts/{accountId}", "abc"), "account-read-bad-id")
                .header("Authorization", "Bearer " + token)
                .exchange()
                .expectStatus().isBadRequest()
                .expectBody(JsonNode.class)
                .returnResult()
                .getResponseBody();

        assertErrorEnvelope(body, "400", "Invalid accountId", "account-read-bad-id");
    }

    private String login(List<String> roles, List<String> scopes, String deviceOs) {
        JsonNode body = ContractTestHeaders.withRequiredHeaders(webTestClient.post()
                .uri("/auth/login"))
                .contentType(APPLICATION_JSON)
                .bodyValue(Map.of(
                        "username", "ACCOUNT-" + UUID.randomUUID(),
                        "password", "demo",
                        "parentAccountId", "015521104095930",
                        "deviceId", "test-device-" + UUID.randomUUID(),
                        "deviceOs", deviceOs,
                        "locale", "en",
                        "roles", roles,
                        "scopes", scopes))
                .exchange()
                .expectStatus().isOk()
                .expectBody(JsonNode.class)
                .returnResult()
                .getResponseBody();

        assertThat(body).isNotNull();
        return body.path("data").path("accessToken").asText();
    }
}

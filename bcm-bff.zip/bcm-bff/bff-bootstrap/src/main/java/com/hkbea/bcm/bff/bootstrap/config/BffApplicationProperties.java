package com.hkbea.bcm.bff.bootstrap.config;

import org.springframework.boot.context.properties.ConfigurationProperties;

@ConfigurationProperties(prefix = "bff")
public class BffApplicationProperties {
    private String serviceName = "bcm-bff";
    private String contractsPath = "../bcm-contracts";

    public String getServiceName() {
        return serviceName;
    }

    public void setServiceName(String serviceName) {
        this.serviceName = serviceName;
    }

    public String getContractsPath() {
        return contractsPath;
    }

    public void setContractsPath(String contractsPath) {
        this.contractsPath = contractsPath;
    }
}

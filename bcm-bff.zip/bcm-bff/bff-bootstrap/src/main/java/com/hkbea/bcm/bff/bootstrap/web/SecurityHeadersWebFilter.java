package com.hkbea.bcm.bff.bootstrap.web;

import com.hkbea.bcm.bff.bootstrap.config.SecurityHeadersProperties;
import org.springframework.core.Ordered;
import org.springframework.http.HttpHeaders;
import org.springframework.stereotype.Component;
import org.springframework.web.server.ServerWebExchange;
import org.springframework.web.server.WebFilter;
import org.springframework.web.server.WebFilterChain;
import reactor.core.publisher.Mono;

@Component
public class SecurityHeadersWebFilter implements WebFilter, Ordered {
    static final String CACHE_CONTROL_VALUE = "no-store, no-cache, max-age=0, must-revalidate";
    static final String EXPIRES = "Expires";
    static final String PRAGMA = "Pragma";
    static final String REFERRER_POLICY = "Referrer-Policy";
    static final String STRICT_TRANSPORT_SECURITY = "Strict-Transport-Security";
    static final String X_CONTENT_TYPE_OPTIONS = "X-Content-Type-Options";
    static final String X_FRAME_OPTIONS = "X-Frame-Options";

    private final SecurityHeadersProperties properties;

    public SecurityHeadersWebFilter(SecurityHeadersProperties properties) {
        this.properties = properties;
    }

    @Override
    public Mono<Void> filter(ServerWebExchange exchange, WebFilterChain chain) {
        HttpHeaders headers = exchange.getResponse().getHeaders();
        headers.setCacheControl(CACHE_CONTROL_VALUE);
        headers.set(PRAGMA, "no-cache");
        headers.set(EXPIRES, "0");
        headers.set(X_CONTENT_TYPE_OPTIONS, "nosniff");
        headers.set(X_FRAME_OPTIONS, "DENY");
        headers.set(REFERRER_POLICY, "no-referrer");
        writeStrictTransportSecurity(headers);
        return chain.filter(exchange);
    }

    @Override
    public int getOrder() {
        return Ordered.HIGHEST_PRECEDENCE + 2;
    }

    private void writeStrictTransportSecurity(HttpHeaders headers) {
        SecurityHeadersProperties.Hsts hsts = properties.getHsts();
        if (!hsts.isEnabled()) {
            headers.remove(STRICT_TRANSPORT_SECURITY);
            return;
        }

        StringBuilder value = new StringBuilder("max-age=")
                .append(hsts.getMaxAgeSeconds());
        if (hsts.isIncludeSubDomains()) {
            value.append("; includeSubDomains");
        }
        if (hsts.isPreload()) {
            value.append("; preload");
        }
        headers.set(STRICT_TRANSPORT_SECURITY, value.toString());
    }
}

package com.hkbea.bcm.bff.bootstrap.web;

import com.hkbea.bcm.bff.shared.api.ErrorCode;
import com.hkbea.bcm.bff.shared.api.ErrorResponse;
import com.hkbea.bcm.bff.shared.http.HeaderConstants;
import org.springframework.http.HttpStatusCode;
import org.springframework.web.server.ServerWebExchange;

final class BffErrorResponses {
    private BffErrorResponses() {
    }

    static ErrorResponse of(ErrorCode errorCode, String message, ServerWebExchange exchange) {
        return ErrorResponse.of(errorCode, message, traceId(exchange));
    }

    static ErrorResponse of(HttpStatusCode statusCode, String message, ServerWebExchange exchange) {
        String code = Integer.toString(statusCode.value());
        return new ErrorResponse(code, code, message, traceId(exchange));
    }

    static String traceId(ServerWebExchange exchange) {
        String traceId = firstNonBlank(
                exchange.getResponse().getHeaders().getFirst(HeaderConstants.X_REQUEST_ID),
                exchange.getResponse().getHeaders().getFirst(HeaderConstants.X_CORRELATION_ID),
                exchange.getRequest().getHeaders().getFirst(HeaderConstants.X_REQUEST_ID),
                exchange.getRequest().getHeaders().getFirst(HeaderConstants.X_CORRELATION_ID)
        );
        return traceId == null ? "" : traceId;
    }

    private static String firstNonBlank(String... values) {
        for (String value : values) {
            if (value != null && !value.isBlank()) {
                return value.trim();
            }
        }
        return null;
    }
}

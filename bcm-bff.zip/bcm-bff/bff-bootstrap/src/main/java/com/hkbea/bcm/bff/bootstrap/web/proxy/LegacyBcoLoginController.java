package com.hkbea.bcm.bff.bootstrap.web.proxy;

import com.hkbea.bcm.bff.access.config.AuthProperties;
import com.hkbea.bcm.bff.access.model.SessionRecord;
import com.hkbea.bcm.bff.access.model.TokenPair;
import com.hkbea.bcm.bff.access.service.SessionService;
import com.hkbea.bcm.bff.access.token.JwtTokenService;
import com.hkbea.bcm.bff.access.token.TokenUse;
import com.hkbea.bcm.bff.proxy.config.BcoProxyProperties;
import com.hkbea.bcm.bff.proxy.model.RawProxyRequestContext;
import com.hkbea.bcm.bff.proxy.model.RawProxyResult;
import com.hkbea.bcm.bff.proxy.service.BcoProxyService;
import com.hkbea.bcm.bff.shared.api.BffException;
import com.hkbea.bcm.bff.shared.api.ErrorCode;
import com.hkbea.bcm.bff.shared.http.HeaderConstants;
import com.hkbea.bcm.bff.shared.session.SessionState;
import org.springframework.core.io.buffer.DataBufferUtils;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.server.ServerWebExchange;
import reactor.core.publisher.Mono;

import java.net.URLDecoder;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.time.Instant;
import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.UUID;

@RestController
public class LegacyBcoLoginController {
    private static final String LEGACY_LOGIN_PATH = "/digx/j_security_check";
    private static final String DEFAULT_LOCALE = "en";
    private static final String LOGIN_TYPE_HEADER = "loginType";
    private static final String RSA_KEY_INDICATOR_HEADER = "RSAKeyIndicator";
    private static final String TOKEN_HEADER = "token";
    private static final List<String> DEFAULT_ROLES = List.of("BCM_USER");
    private static final List<String> DEFAULT_SCOPES = List.of("bcm:proxy");
    private static final ZoneId HONG_KONG = ZoneId.of("Asia/Hong_Kong");
    private static final DateTimeFormatter DISPLAY_TIME_FORMAT = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");

    private final BcoProxyService proxyService;
    private final BcoProxyProperties properties;
    private final SessionService sessionService;
    private final JwtTokenService jwtTokenService;
    private final AuthProperties authProperties;

    public LegacyBcoLoginController(
            BcoProxyService proxyService,
            BcoProxyProperties properties,
            SessionService sessionService,
            JwtTokenService jwtTokenService,
            AuthProperties authProperties
    ) {
        this.proxyService = proxyService;
        this.properties = properties;
        this.sessionService = sessionService;
        this.jwtTokenService = jwtTokenService;
        this.authProperties = authProperties;
    }

    @RequestMapping(method = RequestMethod.POST, path = {"/api/login", LEGACY_LOGIN_PATH})
    Mono<ResponseEntity<Map<String, Object>>> login(ServerWebExchange exchange) {
        if (!properties.isEnabled()) {
            return Mono.just(ResponseEntity.notFound().build());
        }

        return readBody(exchange)
                .flatMap(body -> {
                    String locale = locale(exchange);
                    LoginForm form = loginForm(body, locale);
                    RawProxyRequestContext context = new RawProxyRequestContext(
                            traceId(exchange),
                            RequestMethod.POST.name(),
                            LEGACY_LOGIN_PATH,
                            localeQuery(locale),
                            loginHeaders(exchange, locale),
                            null
                    );
                    return proxyService.proxy(form.encodedBody(), context)
                            .flatMap(result -> loginResponse(result, form.username(), exchange));
                });
    }

    private Mono<ResponseEntity<Map<String, Object>>> loginResponse(
            RawProxyResult result,
            String username,
            ServerWebExchange exchange
    ) {
        if (result.statusCode() != 303) {
            return Mono.just(ResponseEntity.ok(upstreamLoginFailure(result)));
        }

        String cookieString = sessionCookieString(result.headers());
        if (!hasText(cookieString)) {
            return Mono.error(new BffException(ErrorCode.INTERNAL_ERROR, "login failed: missing session cookies"));
        }

        return createSession(username, cookieString, exchange)
                .map(session -> ResponseEntity.ok(upstreamLoginSuccess(result, session)));
    }

    private Mono<LoginSession> createSession(String username, String cookieString, ServerWebExchange exchange) {
        String userId = normalizeUserId(username);
        Instant now = Instant.now();
        SessionRecord session = new SessionRecord(
                UUID.randomUUID().toString(),
                userId,
                customerId(userId),
                deviceId(exchange),
                deviceOs(exchange),
                DEFAULT_ROLES,
                DEFAULT_SCOPES,
                cookieString,
                SessionState.ACTIVE,
                1,
                UUID.randomUUID().toString(),
                now,
                now
        );

        return sessionService.replaceActiveSessionsForUser(userId)
                .then(sessionService.save(session))
                .map(savedSession -> new LoginSession(savedSession, issueTokenPair(savedSession)));
    }

    private TokenPair issueTokenPair(SessionRecord session) {
        long accessTtl = authProperties.getAccessTokenTtlSeconds();
        long refreshTtl = authProperties.getRefreshTokenTtlSeconds();
        return TokenPair.bearer(
                jwtTokenService.issue(session, TokenUse.ACCESS, accessTtl),
                jwtTokenService.issue(session, TokenUse.REFRESH, refreshTtl, session.refreshTokenId()),
                accessTtl,
                refreshTtl
        );
    }

    private static Map<String, Object> upstreamLoginSuccess(RawProxyResult result, LoginSession session) {
        Map<String, Object> response = new LinkedHashMap<>();
        TokenPair tokens = session.tokenPair();
        response.put("accessToken", tokens.accessToken());
        response.put("refreshToken", tokens.refreshToken());
        response.put("tokenType", tokens.tokenType());
        response.put("expiresIn", tokens.expiresIn());
        response.put("refreshExpiresIn", tokens.refreshExpiresIn());
        response.put("sessionId", session.session().sid());
        response.put("loginTime", loginTime());
        response.put("headers", headersToMap(result.headers()));
        if (result.body() != null && result.body().length > 0) {
            response.put("body", new String(result.body(), StandardCharsets.UTF_8));
        }
        return response;
    }

    private static Map<String, Object> upstreamLoginFailure(RawProxyResult result) {
        Map<String, Object> response = new LinkedHashMap<>();
        response.put("success", false);
        response.put("statusCode", result.statusCode());
        response.put("headers", headersToMap(result.headers()));
        if (result.body() != null && result.body().length > 0) {
            response.put("body", new String(result.body(), StandardCharsets.UTF_8));
        }
        return response;
    }

    private static Map<String, Object> loginTime() {
        ZonedDateTime now = ZonedDateTime.now(HONG_KONG);
        Map<String, Object> time = new LinkedHashMap<>();
        time.put("iso", now.format(DateTimeFormatter.ISO_OFFSET_DATE_TIME));
        time.put("display", now.format(DISPLAY_TIME_FORMAT));
        time.put("unix", Long.toString(now.toEpochSecond()));
        return time;
    }

    private static LoginForm loginForm(byte[] body, String locale) {
        MultiValueMap<String, String> form = parseForm(body);
        String username = firstValue(form, "j_username");
        if (!hasText(username)) {
            throw new BffException(ErrorCode.BAD_REQUEST, "j_username is required");
        }
        form.set("locale", locale);
        return new LoginForm(username.trim(), encodeForm(form).getBytes(StandardCharsets.UTF_8));
    }

    private static MultiValueMap<String, String> parseForm(byte[] body) {
        MultiValueMap<String, String> form = new LinkedMultiValueMap<>();
        if (body == null || body.length == 0) {
            return form;
        }

        String rawBody = new String(body, StandardCharsets.UTF_8);
        for (String pair : rawBody.split("&")) {
            if (pair.isBlank()) {
                continue;
            }
            int separator = pair.indexOf('=');
            String name = separator >= 0 ? pair.substring(0, separator) : pair;
            String value = separator >= 0 ? pair.substring(separator + 1) : "";
            form.add(decode(name), decode(value));
        }
        return form;
    }

    private static String encodeForm(MultiValueMap<String, String> form) {
        StringBuilder encoded = new StringBuilder();
        form.forEach((name, values) -> {
            List<String> safeValues = values == null || values.isEmpty() ? List.of("") : values;
            for (String value : safeValues) {
                if (encoded.length() > 0) {
                    encoded.append('&');
                }
                encoded.append(encode(name)).append('=').append(encode(value));
            }
        });
        return encoded.toString();
    }

    private static HttpHeaders loginHeaders(ServerWebExchange exchange, String locale) {
        HttpHeaders headers = new HttpHeaders();
        headers.addAll(exchange.getRequest().getHeaders());
        headers.setContentType(MediaType.APPLICATION_FORM_URLENCODED);
        headers.set(HeaderConstants.LOCALE, locale);
        copyCaseInsensitive(exchange.getRequest().getHeaders(), headers, LOGIN_TYPE_HEADER);
        copyCaseInsensitive(exchange.getRequest().getHeaders(), headers, RSA_KEY_INDICATOR_HEADER);
        copyCaseInsensitive(exchange.getRequest().getHeaders(), headers, TOKEN_HEADER);
        return headers;
    }

    private static void copyCaseInsensitive(HttpHeaders source, HttpHeaders target, String headerName) {
        List<String> values = source.entrySet()
                .stream()
                .filter(entry -> entry.getKey().equalsIgnoreCase(headerName))
                .map(Map.Entry::getValue)
                .findFirst()
                .orElse(List.of());
        if (!values.isEmpty()) {
            target.put(headerName, values);
        }
    }

    private static String sessionCookieString(HttpHeaders headers) {
        Map<String, String> cookies = new LinkedHashMap<>();
        List<String> setCookies = headers == null ? List.of() : headers.getOrEmpty(HttpHeaders.SET_COOKIE);
        for (String setCookie : setCookies) {
            int end = setCookie.indexOf(';');
            String cookie = end >= 0 ? setCookie.substring(0, end) : setCookie;
            int separator = cookie.indexOf('=');
            if (separator <= 0) {
                continue;
            }
            String name = cookie.substring(0, separator).trim();
            String value = cookie.substring(separator + 1).trim();
            if ("JSESSIONID".equalsIgnoreCase(name) || "_WL_AUTHCOOKIE_JSESSIONID".equalsIgnoreCase(name)) {
                cookies.put(name, value);
            }
        }

        String jsessionId = firstCookie(cookies, "JSESSIONID");
        String wlAuthCookie = firstCookie(cookies, "_WL_AUTHCOOKIE_JSESSIONID");
        if (!hasText(jsessionId) || !hasText(wlAuthCookie)) {
            return "";
        }
        return "JSESSIONID=" + jsessionId + "; _WL_AUTHCOOKIE_JSESSIONID=" + wlAuthCookie;
    }

    private static String firstCookie(Map<String, String> cookies, String name) {
        return cookies.entrySet()
                .stream()
                .filter(entry -> entry.getKey().equalsIgnoreCase(name))
                .map(Map.Entry::getValue)
                .findFirst()
                .orElse("");
    }

    private static Map<String, List<String>> headersToMap(HttpHeaders headers) {
        Map<String, List<String>> result = new LinkedHashMap<>();
        if (headers != null) {
            headers.forEach((name, values) -> result.put(canonicalHeaderName(name), List.copyOf(values)));
        }
        return result;
    }

    private static String canonicalHeaderName(String name) {
        if (name == null || name.isBlank()) {
            return name;
        }
        String[] parts = name.split("-", -1);
        for (int i = 0; i < parts.length; i++) {
            String part = parts[i];
            if (!part.isEmpty()) {
                parts[i] = part.substring(0, 1).toUpperCase(Locale.ROOT)
                        + part.substring(1).toLowerCase(Locale.ROOT);
            }
        }
        return String.join("-", parts);
    }

    private static String locale(ServerWebExchange exchange) {
        String locale = firstNonBlank(
                exchange.getRequest().getQueryParams().getFirst("locale"),
                exchange.getRequest().getHeaders().getFirst(HeaderConstants.LOCALE)
        );
        return hasText(locale) ? locale.trim() : DEFAULT_LOCALE;
    }

    private static String localeQuery(String locale) {
        return "locale=" + encode(locale);
    }

    private static String deviceId(ServerWebExchange exchange) {
        return firstNonBlank(
                exchange.getRequest().getHeaders().getFirst(HeaderConstants.X_DEVICE_ID),
                exchange.getRequest().getHeaders().getFirst("uuid"),
                exchange.getRequest().getHeaders().getFirst("did"),
                UUID.randomUUID().toString()
        );
    }

    private static String deviceOs(ServerWebExchange exchange) {
        String raw = firstNonBlank(
                exchange.getRequest().getHeaders().getFirst(HeaderConstants.X_DEVICE_OS),
                exchange.getRequest().getHeaders().getFirst("platform")
        );
        if (!hasText(raw)) {
            String userAgent = exchange.getRequest().getHeaders().getFirst(HttpHeaders.USER_AGENT);
            return hasText(userAgent) && userAgent.toLowerCase(Locale.ROOT).contains("darwin") ? "iOS" : "Android";
        }
        String normalized = raw.trim().toLowerCase(Locale.ROOT);
        if (normalized.equals("ios")) {
            return "iOS";
        }
        if (normalized.equals("android")) {
            return "Android";
        }
        return raw.trim();
    }

    private static String normalizeUserId(String username) {
        return username.trim().toUpperCase(Locale.ROOT);
    }

    private static String customerId(String userId) {
        int separator = userId.indexOf('@');
        return separator >= 0 && separator < userId.length() - 1 ? userId.substring(separator + 1) : null;
    }

    private static String firstValue(MultiValueMap<String, String> form, String name) {
        return form.entrySet()
                .stream()
                .filter(entry -> entry.getKey().equals(name))
                .map(entry -> entry.getValue().isEmpty() ? "" : entry.getValue().get(0))
                .findFirst()
                .orElse("");
    }

    private static Mono<byte[]> readBody(ServerWebExchange exchange) {
        return DataBufferUtils.join(exchange.getRequest().getBody())
                .map(buffer -> {
                    byte[] bytes = new byte[buffer.readableByteCount()];
                    buffer.read(bytes);
                    DataBufferUtils.release(buffer);
                    return bytes;
                })
                .defaultIfEmpty(new byte[0]);
    }

    private static String traceId(ServerWebExchange exchange) {
        return exchange.getResponse().getHeaders().getFirst(HeaderConstants.X_REQUEST_ID);
    }

    private static String decode(String value) {
        return URLDecoder.decode(value, StandardCharsets.UTF_8);
    }

    private static String encode(String value) {
        return URLEncoder.encode(value == null ? "" : value, StandardCharsets.UTF_8);
    }

    private static String firstNonBlank(String... values) {
        for (String value : values) {
            if (hasText(value)) {
                return value.trim();
            }
        }
        return "";
    }

    private static boolean hasText(String value) {
        return value != null && !value.isBlank();
    }

    private record LoginForm(String username, byte[] encodedBody) {
    }

    private record LoginSession(SessionRecord session, TokenPair tokenPair) {
    }
}

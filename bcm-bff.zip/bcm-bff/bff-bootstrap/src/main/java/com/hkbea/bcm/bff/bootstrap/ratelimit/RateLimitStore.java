package com.hkbea.bcm.bff.bootstrap.ratelimit;

import com.hkbea.bcm.bff.bootstrap.config.RateLimitProperties;
import reactor.core.publisher.Mono;

public interface RateLimitStore {
    Mono<RateLimitDecision> record(
            RateLimitProperties.Rule rule,
            String bucketKey,
            long nowMillis,
            long windowMillis,
            int maxRequests
    );
}

package com.hkbea.bcm.bff.bootstrap.web;

import com.hkbea.bcm.bff.shared.http.HeaderConstants;
import com.hkbea.bcm.bff.shared.logging.DebugLogSanitizer;
import org.slf4j.Logger;
import org.springframework.web.server.ServerWebExchange;

public final class DebugRequestLogger {
    private DebugRequestLogger() {
    }

    public static void logBody(Logger log, ServerWebExchange exchange, Object body) {
        if (!log.isDebugEnabled()) {
            return;
        }

        log.debug(
                "BCM_HTTP_REQUEST_BODY traceId={} method={} path={} body={}",
                traceId(exchange),
                exchange.getRequest().getMethod(),
                exchange.getRequest().getPath().pathWithinApplication().value(),
                DebugLogSanitizer.body(body)
        );
    }

    public static void logBody(Logger log, ServerWebExchange exchange, byte[] body) {
        if (!log.isDebugEnabled()) {
            return;
        }

        log.debug(
                "BCM_HTTP_REQUEST_BODY traceId={} method={} path={} body={}",
                traceId(exchange),
                exchange.getRequest().getMethod(),
                exchange.getRequest().getPath().pathWithinApplication().value(),
                DebugLogSanitizer.body(body)
        );
    }

    private static String traceId(ServerWebExchange exchange) {
        String traceId = exchange.getResponse().getHeaders().getFirst(HeaderConstants.X_REQUEST_ID);
        return traceId == null ? "none" : traceId;
    }
}

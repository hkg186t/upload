package com.hkbea.bcm.bff.bootstrap;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.context.properties.ConfigurationPropertiesScan;
import org.springframework.scheduling.annotation.EnableScheduling;

@EnableScheduling
@SpringBootApplication(scanBasePackages = "com.hkbea.bcm.bff")
@ConfigurationPropertiesScan(basePackages = "com.hkbea.bcm.bff")
public class BcmBffApplication {
    public static void main(String[] args) {
        SpringApplication.run(BcmBffApplication.class, args);
    }
}

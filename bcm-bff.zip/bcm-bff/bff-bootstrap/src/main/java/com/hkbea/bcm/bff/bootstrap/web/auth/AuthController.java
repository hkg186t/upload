package com.hkbea.bcm.bff.bootstrap.web.auth;

import com.hkbea.bcm.bff.access.model.AuthResult;
import com.hkbea.bcm.bff.access.model.LoginCommand;
import com.hkbea.bcm.bff.access.model.RefreshCommand;
import com.hkbea.bcm.bff.access.model.SessionRecord;
import com.hkbea.bcm.bff.access.model.TokenPair;
import com.hkbea.bcm.bff.access.service.AuthService;
import com.hkbea.bcm.bff.bootstrap.web.DebugRequestLogger;
import com.hkbea.bcm.bff.contract.api.AuthApi;
import com.hkbea.bcm.bff.contract.model.LoginTokenData;
import com.hkbea.bcm.bff.contract.model.LogoutData;
import com.hkbea.bcm.bff.contract.model.TokenData;
import com.hkbea.bcm.bff.contract.model.UserSummary;
import com.hkbea.bcm.bff.shared.context.RequestContextKeys;
import com.hkbea.bcm.bff.shared.http.HeaderConstants;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.server.ServerWebExchange;
import reactor.core.publisher.Mono;

@RestController
public class AuthController implements AuthApi {
    private static final Logger log = LoggerFactory.getLogger(AuthController.class);

    private final AuthService authService;

    public AuthController(AuthService authService) {
        this.authService = authService;
    }

    @Override
    public Mono<ResponseEntity<com.hkbea.bcm.bff.contract.model.LoginResponse>> login(
            String xRequestId,
            String xCorrelationId,
            String xChannel,
            String xAppId,
            Mono<com.hkbea.bcm.bff.contract.model.LoginRequest> loginRequest,
            ServerWebExchange exchange
    ) {
        return loginRequest
                .doOnNext(request -> DebugRequestLogger.logBody(log, exchange, request))
                .flatMap(request -> authService.login(toCommand(request)))
                .map(result -> ResponseEntity.ok(loginResponse(result, traceId(exchange))));
    }

    @Override
    public Mono<ResponseEntity<com.hkbea.bcm.bff.contract.model.RefreshResponse>> refreshToken(
            String xRequestId,
            String xCorrelationId,
            String xChannel,
            String xAppId,
            Mono<com.hkbea.bcm.bff.contract.model.RefreshRequest> refreshRequest,
            ServerWebExchange exchange
    ) {
        return refreshRequest
                .doOnNext(request -> DebugRequestLogger.logBody(log, exchange, request))
                .flatMap(request -> authService.refresh(new RefreshCommand(request.getRefreshToken(), request.getDeviceId())))
                .map(tokenPair -> ResponseEntity.ok(refreshResponse(tokenPair, traceId(exchange))));
    }

    @Override
    public Mono<ResponseEntity<com.hkbea.bcm.bff.contract.model.LogoutResponse>> logout(
            String xRequestId,
            String xCorrelationId,
            String xChannel,
            String xAppId,
            ServerWebExchange exchange
    ) {
        SessionRecord session = exchange.getAttribute(RequestContextKeys.SESSION_RECORD);
        String authorization = exchange.getRequest().getHeaders().getFirst(HeaderConstants.AUTHORIZATION);
        Mono<Void> logout = session == null ? authService.logout(authorization) : authService.logout(session);
        return logout.thenReturn(ResponseEntity.ok(logoutResponse(traceId(exchange))));
    }

    private static LoginCommand toCommand(com.hkbea.bcm.bff.contract.model.LoginRequest request) {
        return new LoginCommand(
                request.getUsername(),
                request.getPassword(),
                request.getParentAccountId(),
                request.getDeviceId(),
                request.getDeviceOs() == null ? null : request.getDeviceOs().getValue(),
                request.getAppVersion(),
                request.getLocale(),
                request.getRoles(),
                request.getScopes()
        );
    }

    private static com.hkbea.bcm.bff.contract.model.LoginResponse loginResponse(AuthResult result, String traceId) {
        TokenPair tokenPair = result.tokenPair();
        LoginTokenData data = new LoginTokenData(
                LoginTokenData.TokenTypeEnum.BEARER,
                tokenPair.accessToken(),
                tokenPair.refreshToken(),
                tokenPair.expiresIn(),
                tokenPair.refreshExpiresIn(),
                result.sessionId(),
                userSummary(result.user())
        );
        return new com.hkbea.bcm.bff.contract.model.LoginResponse("0000", "success", traceId, data);
    }

    private static com.hkbea.bcm.bff.contract.model.RefreshResponse refreshResponse(TokenPair tokenPair, String traceId) {
        TokenData data = new TokenData(
                TokenData.TokenTypeEnum.BEARER,
                tokenPair.accessToken(),
                tokenPair.refreshToken(),
                tokenPair.expiresIn(),
                tokenPair.refreshExpiresIn()
        );
        return new com.hkbea.bcm.bff.contract.model.RefreshResponse("0000", "success", traceId, data);
    }

    private static com.hkbea.bcm.bff.contract.model.LogoutResponse logoutResponse(String traceId) {
        return new com.hkbea.bcm.bff.contract.model.LogoutResponse(
                "0000",
                "success",
                traceId,
                new LogoutData(true)
        );
    }

    private static UserSummary userSummary(com.hkbea.bcm.bff.access.model.UserSummary user) {
        return new UserSummary(user.username())
                .displayName(user.displayName())
                .parentAccountId(user.parentAccountId())
                .roles(user.roles())
                .scopes(user.scopes());
    }

    private static String traceId(ServerWebExchange exchange) {
        return exchange.getResponse().getHeaders().getFirst(HeaderConstants.X_REQUEST_ID);
    }
}

package com.hkbea.bcm.bff.bootstrap.web.proxy;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.core.type.TypeReference;
import com.hkbea.bcm.bff.access.model.SessionRecord;
import com.hkbea.bcm.bff.bootstrap.web.DebugRequestLogger;
import com.hkbea.bcm.bff.contract.api.BcmProxyApi;
import com.hkbea.bcm.bff.contract.model.BcmProxyDemoResponse;
import com.hkbea.bcm.bff.proxy.config.BcmProxyProperties;
import com.hkbea.bcm.bff.proxy.model.ProxyRequestContext;
import com.hkbea.bcm.bff.proxy.model.RawProxyResult;
import com.hkbea.bcm.bff.proxy.service.BcmProxyService;
import com.hkbea.bcm.bff.shared.api.ApiResponse;
import com.hkbea.bcm.bff.shared.api.BffException;
import com.hkbea.bcm.bff.shared.api.ErrorCode;
import com.hkbea.bcm.bff.shared.context.RequestContextKeys;
import com.hkbea.bcm.bff.shared.http.HeaderConstants;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.core.io.buffer.DataBufferUtils;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.server.ServerWebExchange;
import reactor.core.publisher.Mono;

import java.util.Map;

@RestController
public class BcmProxyController implements BcmProxyApi {
    private static final Logger log = LoggerFactory.getLogger(BcmProxyController.class);
    private static final TypeReference<Map<String, Object>> MAP_TYPE = new TypeReference<>() {
    };

    private final BcmProxyService proxyService;
    private final BcmProxyProperties proxyProperties;
    private final ObjectMapper objectMapper;

    public BcmProxyController(
            BcmProxyService proxyService,
            BcmProxyProperties proxyProperties,
            ObjectMapper objectMapper
    ) {
        this.proxyService = proxyService;
        this.proxyProperties = proxyProperties;
        this.objectMapper = objectMapper;
    }

    @RequestMapping(method = {
            RequestMethod.GET,
            RequestMethod.POST,
            RequestMethod.PUT,
            RequestMethod.PATCH,
            RequestMethod.DELETE
    }, path = "/bcm/**")
    Mono<ApiResponse<JsonNode>> proxy(
            @RequestBody(required = false) Mono<JsonNode> requestBody,
            ServerWebExchange exchange
    ) {
        return requestBody
                .doOnNext(body -> DebugRequestLogger.logBody(log, exchange, body))
                .switchIfEmpty(emptyProxyBody(exchange))
                .flatMap(body -> proxyService.proxy(routeId(exchange), body, proxyContext(exchange)))
                .map(result -> ApiResponse.success(result.body(), traceId(exchange)));
    }

    @RequestMapping(method = {
            RequestMethod.GET,
            RequestMethod.POST,
            RequestMethod.PUT,
            RequestMethod.PATCH,
            RequestMethod.DELETE
    }, path = "/corporate/**")
    Mono<ResponseEntity<byte[]>> legacyCorporateProxy(ServerWebExchange exchange) {
        return readBody(exchange)
                .doOnNext(body -> DebugRequestLogger.logBody(log, exchange, body))
                .flatMap(body -> proxyService.proxyRaw(routeId(exchange), body, proxyContext(exchange)))
                .map(this::toRawResponse);
    }

    @Override
    public Mono<ResponseEntity<BcmProxyDemoResponse>> proxyUserProfileDemo(
            String xRequestId,
            String xCorrelationId,
            String xChannel,
            String xAppId,
            Mono<Map<String, Object>> requestBody,
            String xUserContext,
            ServerWebExchange exchange
    ) {
        return requestBody
                .map(body -> (JsonNode) objectMapper.valueToTree(body))
                .doOnNext(body -> DebugRequestLogger.logBody(log, exchange, body))
                .flatMap(body -> proxyService.proxy(routeId(exchange), body, proxyContext(exchange)))
                .map(result -> ResponseEntity.ok(new BcmProxyDemoResponse(
                        "0000",
                        "success",
                        traceId(exchange),
                        objectMapper.convertValue(result.body(), MAP_TYPE)
                )));
    }

    private String routeId(ServerWebExchange exchange) {
        return proxyProperties.resolveRouteId(
                exchange.getRequest().getMethod().name(),
                exchange.getRequest().getPath().pathWithinApplication().value()
        );
    }

    private ProxyRequestContext proxyContext(ServerWebExchange exchange) {
        SessionRecord session = exchange.getAttribute(RequestContextKeys.SESSION_RECORD);
        if (session == null) {
            throw new BffException(ErrorCode.UNAUTHORIZED);
        }

        return new ProxyRequestContext(
                traceId(exchange),
                session,
                exchange.getRequest().getMethod().name(),
                exchange.getRequest().getPath().pathWithinApplication().value(),
                exchange.getRequest().getHeaders(),
                exchange.getRequest().getHeaders().getFirst(HeaderConstants.X_DEVICE_ID),
                exchange.getRequest().getHeaders().getFirst(HeaderConstants.X_DEVICE_OS),
                exchange.getRequest().getHeaders().getFirst(HeaderConstants.LOCALE),
                exchange.getRequest().getURI().getRawQuery()
        );
    }

    private Mono<JsonNode> emptyProxyBody(ServerWebExchange exchange) {
        return Mono.fromRunnable(() -> DebugRequestLogger.logBody(log, exchange, new byte[0]))
                .thenReturn(objectMapper.createObjectNode());
    }

    private ResponseEntity<byte[]> toRawResponse(RawProxyResult result) {
        return ResponseEntity
                .status(result.statusCode())
                .headers(result.headers())
                .body(result.body());
    }

    private static Mono<byte[]> readBody(ServerWebExchange exchange) {
        return DataBufferUtils.join(exchange.getRequest().getBody())
                .map(buffer -> {
                    byte[] bytes = new byte[buffer.readableByteCount()];
                    buffer.read(bytes);
                    DataBufferUtils.release(buffer);
                    return bytes;
                })
                .defaultIfEmpty(new byte[0]);
    }

    private static String traceId(ServerWebExchange exchange) {
        return exchange.getResponse().getHeaders().getFirst(HeaderConstants.X_REQUEST_ID);
    }
}

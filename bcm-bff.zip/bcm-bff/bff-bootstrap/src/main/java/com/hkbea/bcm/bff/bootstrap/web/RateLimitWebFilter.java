package com.hkbea.bcm.bff.bootstrap.web;

import com.hkbea.bcm.bff.bootstrap.config.RateLimitProperties;
import com.hkbea.bcm.bff.bootstrap.ratelimit.InMemoryRateLimitStore;
import com.hkbea.bcm.bff.bootstrap.ratelimit.RateLimitDecision;
import com.hkbea.bcm.bff.bootstrap.ratelimit.RateLimitStore;
import com.hkbea.bcm.bff.shared.api.ErrorCode;
import com.hkbea.bcm.bff.shared.http.HeaderConstants;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.Ordered;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.server.reactive.ServerHttpResponse;
import org.springframework.stereotype.Component;
import org.springframework.web.server.ServerWebExchange;
import org.springframework.web.server.WebFilter;
import org.springframework.web.server.WebFilterChain;
import reactor.core.publisher.Mono;

import java.net.InetSocketAddress;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.time.Clock;
import java.util.HexFormat;

@Component
public class RateLimitWebFilter implements WebFilter, Ordered {
    private static final Logger log = LoggerFactory.getLogger(RateLimitWebFilter.class);
    private static final String BEARER_PREFIX = "Bearer ";

    private final RateLimitProperties properties;
    private final BffErrorResponseWriter errorResponseWriter;
    private final Clock clock;
    private final RateLimitStore rateLimitStore;

    @Autowired
    public RateLimitWebFilter(
            RateLimitProperties properties,
            BffErrorResponseWriter errorResponseWriter,
            RateLimitStore rateLimitStore
    ) {
        this(properties, errorResponseWriter, Clock.systemUTC(), rateLimitStore);
    }

    RateLimitWebFilter(RateLimitProperties properties, BffErrorResponseWriter errorResponseWriter, Clock clock) {
        this(properties, errorResponseWriter, clock, new InMemoryRateLimitStore(properties));
    }

    RateLimitWebFilter(
            RateLimitProperties properties,
            BffErrorResponseWriter errorResponseWriter,
            Clock clock,
            RateLimitStore rateLimitStore
    ) {
        this.properties = properties;
        this.errorResponseWriter = errorResponseWriter;
        this.clock = clock;
        this.rateLimitStore = rateLimitStore;
    }

    @Override
    public Mono<Void> filter(ServerWebExchange exchange, WebFilterChain chain) {
        if (!properties.isEnabled()
                || exchange.getRequest().getMethod() == HttpMethod.OPTIONS) {
            return chain.filter(exchange);
        }

        String path = exchange.getRequest().getPath().pathWithinApplication().value();
        return properties.resolveRule(path)
                .map(rule -> applyRateLimit(exchange, chain, rule))
                .orElseGet(() -> chain.filter(exchange));
    }

    @Override
    public int getOrder() {
        return Ordered.HIGHEST_PRECEDENCE + 10;
    }

    private Mono<Void> applyRateLimit(
            ServerWebExchange exchange,
            WebFilterChain chain,
            RateLimitProperties.Rule rule
    ) {
        KeyParts keyParts = keyParts(exchange);
        long nowMillis = clock.millis();
        long windowMillis = Math.max(1, rule.getWindowSeconds()) * 1000;
        int maxRequests = Math.max(1, rule.getMaxRequests());

        return rateLimitStore.record(rule, keyParts.bucketKey(), nowMillis, windowMillis, maxRequests)
                .flatMap(decision -> {
                    writeRateLimitHeaders(exchange.getResponse().getHeaders(), decision);
                    if (decision.allowed()) {
                        return chain.filter(exchange);
                    }
                    return reject(exchange, rule, keyParts, decision);
                });
    }

    private Mono<Void> reject(
            ServerWebExchange exchange,
            RateLimitProperties.Rule rule,
            KeyParts keyParts,
            RateLimitDecision decision
    ) {
        ServerHttpResponse response = exchange.getResponse();
        response.setStatusCode(HttpStatus.TOO_MANY_REQUESTS);
        response.getHeaders().set(HttpHeaders.RETRY_AFTER, String.valueOf(decision.retryAfterSeconds(clock.millis())));
        writeRateLimitHeaders(response.getHeaders(), decision);

        log.warn("BCM_RATE_LIMIT_ACCESS outcome=rejected ruleId={} keyType={} keyHash={} path={} limit={} resetAtMillis={}",
                rule.getId(),
                keyParts.keyType(),
                keyParts.safeKeyHash(),
                exchange.getRequest().getPath().pathWithinApplication().value(),
                decision.limit(),
                decision.resetAtMillis());
        return errorResponseWriter.write(exchange, ErrorCode.TOO_MANY_REQUESTS, "Rate limit exceeded");
    }

    private static void writeRateLimitHeaders(HttpHeaders headers, RateLimitDecision decision) {
        headers.set("X-RateLimit-Limit", String.valueOf(decision.limit()));
        headers.set("X-RateLimit-Remaining", String.valueOf(Math.max(0, decision.remaining())));
        headers.set("X-RateLimit-Reset", String.valueOf(decision.resetAtMillis()));
    }

    private KeyParts keyParts(ServerWebExchange exchange) {
        String authorization = exchange.getRequest().getHeaders().getFirst(HeaderConstants.AUTHORIZATION);
        if (authorization != null && authorization.regionMatches(true, 0, BEARER_PREFIX, 0, BEARER_PREFIX.length())) {
            String token = authorization.substring(BEARER_PREFIX.length()).trim();
            if (!token.isBlank()) {
                String hash = shortSha256(token);
                return new KeyParts("bearer", hash, "bearer:" + hash);
            }
        }

        String ip = clientIp(exchange);
        String hash = shortSha256(ip);
        return new KeyParts("ip", hash, "ip:" + hash);
    }

    private String clientIp(ServerWebExchange exchange) {
        if (properties.isTrustXForwardedFor()) {
            String forwardedFor = exchange.getRequest().getHeaders().getFirst("X-Forwarded-For");
            String forwardedClientIp = firstForwardedFor(forwardedFor);
            if (forwardedClientIp != null) {
                return forwardedClientIp;
            }
        }

        InetSocketAddress remoteAddress = exchange.getRequest().getRemoteAddress();
        if (remoteAddress != null && remoteAddress.getAddress() != null) {
            return remoteAddress.getAddress().getHostAddress();
        }
        if (remoteAddress != null && remoteAddress.getHostString() != null) {
            return remoteAddress.getHostString();
        }
        return "unknown";
    }

    private static String firstForwardedFor(String forwardedFor) {
        if (forwardedFor == null || forwardedFor.isBlank()) {
            return null;
        }
        String first = forwardedFor.split(",")[0].trim();
        return first.isBlank() ? null : first;
    }

    private static String shortSha256(String value) {
        try {
            byte[] digest = MessageDigest.getInstance("SHA-256")
                    .digest(value.getBytes(StandardCharsets.UTF_8));
            return HexFormat.of().formatHex(digest, 0, 8);
        } catch (Exception error) {
            throw new IllegalStateException("Failed to hash rate limit key", error);
        }
    }

    private record KeyParts(
            String keyType,
            String safeKeyHash,
            String bucketKey
    ) {
    }
}

package com.hkbea.bcm.bff.bootstrap.web.account;

import com.hkbea.bcm.bff.contract.api.AccountsApi;
import com.hkbea.bcm.bff.contract.model.Account;
import com.hkbea.bcm.bff.contract.model.Money;
import com.hkbea.bcm.bff.shared.api.BffException;
import com.hkbea.bcm.bff.shared.api.ErrorCode;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.server.ServerWebExchange;
import reactor.core.publisher.Mono;

import java.util.regex.Pattern;

@RestController
public class AccountController implements AccountsApi {
    private static final Pattern ACCOUNT_ID_PATTERN = Pattern.compile("^\\d{10}$");

    @Override
    public Mono<ResponseEntity<Account>> getAccount(
            String xRequestId,
            String xCorrelationId,
            String xChannel,
            String xAppId,
            String accountId,
            String xUserContext,
            ServerWebExchange exchange
    ) {
        if (!ACCOUNT_ID_PATTERN.matcher(accountId).matches()) {
            throw new BffException(ErrorCode.BAD_REQUEST, "Invalid accountId");
        }

        Account account = new Account(accountId, new Money("1000.50", "HKD"));
        return Mono.just(ResponseEntity.ok()
                .header("X-Correlation-Id", xCorrelationId)
                .body(account));
    }
}

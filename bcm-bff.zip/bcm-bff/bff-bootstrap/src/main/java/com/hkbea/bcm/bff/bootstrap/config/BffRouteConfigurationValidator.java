package com.hkbea.bcm.bff.bootstrap.config;

import com.hkbea.bcm.bff.access.config.AuthorizationPolicyProperties;
import com.hkbea.bcm.bff.aggregation.config.AggregationProperties;
import com.hkbea.bcm.bff.proxy.config.BcmProxyProperties;
import com.hkbea.bcm.bff.shared.api.BffException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.SmartInitializingSingleton;
import org.springframework.stereotype.Component;

import java.util.LinkedHashMap;
import java.util.Locale;
import java.util.Map;

@Component
public class BffRouteConfigurationValidator implements SmartInitializingSingleton {
    private static final Logger log = LoggerFactory.getLogger(BffRouteConfigurationValidator.class);

    private final BcmProxyProperties proxyProperties;
    private final AggregationProperties aggregationProperties;
    private final AuthorizationPolicyProperties authorizationPolicyProperties;

    public BffRouteConfigurationValidator(
            BcmProxyProperties proxyProperties,
            AggregationProperties aggregationProperties,
            AuthorizationPolicyProperties authorizationPolicyProperties
    ) {
        this.proxyProperties = proxyProperties;
        this.aggregationProperties = aggregationProperties;
        this.authorizationPolicyProperties = authorizationPolicyProperties;
    }

    @Override
    public void afterSingletonsInstantiated() {
        validate();
    }

    void validate() {
        Map<String, String> publicRoutes = new LinkedHashMap<>();
        int proxyRouteCount = validateProxyRoutes(publicRoutes);
        AggregationStats aggregationStats = validateAggregationRoutes(publicRoutes);

        log.info("BCM_ROUTE_CONFIG_VALIDATION outcome=success proxyRouteCount={} aggregationRouteCount={} aggregationStepCount={}",
                proxyRouteCount,
                aggregationStats.routeCount(),
                aggregationStats.stepCount());
    }

    private int validateProxyRoutes(Map<String, String> publicRoutes) {
        int routeCount = 0;
        for (String routeId : proxyProperties.getRoutes().keySet()) {
            BcmProxyProperties.Route route = resolveProxyRoute(routeId);
            if (hasText(route.getPublicPath())) {
                requirePathPrefix("proxy", routeId, route.getPublicPath(), "/bcm/");
                requireAuthorizationRule("proxy", routeId, route.getPublicMethod(), route.getPublicPath());
                recordPublicRoute(publicRoutes, "proxy:" + routeId, route.getPublicMethod(), route.getPublicPath());
            }
            routeCount++;
        }
        return routeCount;
    }

    private AggregationStats validateAggregationRoutes(Map<String, String> publicRoutes) {
        int routeCount = 0;
        int stepCount = 0;
        for (String aggregationId : aggregationProperties.getRoutes().keySet()) {
            AggregationProperties.Route route = resolveAggregationRoute(aggregationId);
            requirePathPrefix("aggregation", aggregationId, route.getPublicPath(), "/bff/");
            requireAuthorizationRule("aggregation", aggregationId, route.getPublicMethod(), route.getPublicPath());
            recordPublicRoute(publicRoutes, "aggregation:" + aggregationId, route.getPublicMethod(), route.getPublicPath());

            for (AggregationProperties.Step step : route.getSteps()) {
                resolveProxyRoute(step.getProxyRouteId());
                stepCount++;
            }
            routeCount++;
        }
        return new AggregationStats(routeCount, stepCount);
    }

    private BcmProxyProperties.Route resolveProxyRoute(String routeId) {
        try {
            return proxyProperties.resolveRoute(routeId);
        } catch (BffException error) {
            throw new IllegalStateException("Invalid BCM proxy route configuration: " + routeId
                    + " - " + error.getMessage(), error);
        }
    }

    private AggregationProperties.Route resolveAggregationRoute(String aggregationId) {
        try {
            return aggregationProperties.resolveRoute(aggregationId);
        } catch (BffException error) {
            throw new IllegalStateException("Invalid BFF aggregation route configuration: " + aggregationId
                    + " - " + error.getMessage(), error);
        }
    }

    private static void requirePathPrefix(String routeType, String routeId, String path, String requiredPrefix) {
        if (path == null || !path.startsWith(requiredPrefix)) {
            throw new IllegalStateException("Invalid " + routeType + " public path for " + routeId
                    + ": expected prefix " + requiredPrefix + ", got " + path);
        }
    }

    private static void recordPublicRoute(
            Map<String, String> publicRoutes,
            String owner,
            String method,
            String path
    ) {
        String key = normalizeMethod(method) + " " + normalizePath(path);
        String existingOwner = publicRoutes.putIfAbsent(key, owner);
        if (existingOwner != null) {
            throw new IllegalStateException("Duplicate BFF public route: " + key
                    + " owned by " + existingOwner + " and " + owner);
        }
    }

    private void requireAuthorizationRule(String routeType, String routeId, String method, String path) {
        if (!authorizationPolicyProperties.isEnabled()) {
            return;
        }

        AuthorizationPolicyProperties.Rule rule = authorizationPolicyProperties
                .resolve(method, path)
                .orElseThrow(() -> new IllegalStateException("Missing authorization rule for " + routeType
                        + " route " + routeId + ": " + normalizeMethod(method) + " " + normalizePath(path)));

        if (isEmpty(rule.getRequiredRoles())
                && isEmpty(rule.getRequiredScopes())
                && isEmpty(rule.getAllowedDeviceOs())) {
            throw new IllegalStateException("Authorization rule for " + routeType + " route " + routeId
                    + " must define at least one required role, required scope, or allowed device OS");
        }
    }

    private static String normalizeMethod(String method) {
        return method == null ? "" : method.trim().toUpperCase(Locale.ROOT);
    }

    private static boolean isEmpty(Iterable<String> values) {
        if (values == null) {
            return true;
        }
        for (String value : values) {
            if (hasText(value)) {
                return false;
            }
        }
        return true;
    }

    private static boolean hasText(String value) {
        return value != null && !value.isBlank();
    }

    private static String normalizePath(String path) {
        if (path == null || path.isBlank()) {
            return "";
        }
        String normalized = path.trim();
        if (normalized.length() > 1 && normalized.endsWith("/")) {
            return normalized.substring(0, normalized.length() - 1);
        }
        return normalized;
    }

    private record AggregationStats(
            int routeCount,
            int stepCount
    ) {
    }
}

package com.hkbea.bcm.bff.bootstrap.ratelimit;

import com.hkbea.bcm.bff.bootstrap.config.RateLimitProperties;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.data.redis.core.ReactiveStringRedisTemplate;
import org.springframework.data.redis.core.script.RedisScript;
import org.springframework.stereotype.Component;
import reactor.core.publisher.Mono;

import java.util.List;

@Component
@ConditionalOnProperty(prefix = "bff.rate-limit", name = "store", havingValue = "redis")
public class RedisRateLimitStore implements RateLimitStore {
    private static final RedisScript<List> RECORD_SCRIPT = RedisScript.of("""
            local count = redis.call('INCR', KEYS[1])
            if count == 1 then
              redis.call('PEXPIRE', KEYS[1], ARGV[1])
            end

            local ttl = redis.call('PTTL', KEYS[1])
            if ttl < 0 then
              redis.call('PEXPIRE', KEYS[1], ARGV[1])
              ttl = tonumber(ARGV[1])
            end

            local limit = tonumber(ARGV[2])
            local allowed = 0
            if count <= limit then
              allowed = 1
            end

            local remaining = limit - count
            if remaining < 0 then
              remaining = 0
            end

            return {allowed, remaining, ttl}
            """, List.class);

    private final ReactiveStringRedisTemplate redisTemplate;
    private final RateLimitProperties properties;

    public RedisRateLimitStore(
            ReactiveStringRedisTemplate redisTemplate,
            RateLimitProperties properties
    ) {
        this.redisTemplate = redisTemplate;
        this.properties = properties;
    }

    @Override
    public Mono<RateLimitDecision> record(
            RateLimitProperties.Rule rule,
            String bucketKey,
            long nowMillis,
            long windowMillis,
            int maxRequests
    ) {
        String redisKey = redisKey(rule, bucketKey);
        return redisTemplate.execute(
                        RECORD_SCRIPT,
                        List.of(redisKey),
                        List.of(
                                Long.toString(windowMillis),
                                Integer.toString(maxRequests)))
                .next()
                .map(values -> decision(values, nowMillis, maxRequests));
    }

    private RateLimitDecision decision(List<?> values, long nowMillis, int maxRequests) {
        boolean allowed = numberAt(values, 0).longValue() == 1L;
        int remaining = numberAt(values, 1).intValue();
        long ttlMillis = Math.max(1, numberAt(values, 2).longValue());
        long resetAtMillis = nowMillis + ttlMillis;
        if (allowed) {
            return RateLimitDecision.allowed(maxRequests, remaining, resetAtMillis);
        }
        return RateLimitDecision.rejected(maxRequests, remaining, resetAtMillis);
    }

    private String redisKey(RateLimitProperties.Rule rule, String bucketKey) {
        return properties.getRedisKeyPrefix() + ":rate-limit:" + rule.getId() + ":" + bucketKey;
    }

    private static Number numberAt(List<?> values, int index) {
        Object value = values.get(index);
        if (value instanceof Number number) {
            return number;
        }
        return Long.parseLong(String.valueOf(value));
    }
}

package com.hkbea.bcm.bff.bootstrap.web;

import com.hkbea.bcm.bff.shared.context.RequestContextKeys;
import com.hkbea.bcm.bff.shared.http.HeaderConstants;
import org.springframework.core.Ordered;
import org.springframework.http.server.reactive.ServerHttpRequest;
import org.springframework.stereotype.Component;
import org.springframework.web.server.ServerWebExchange;
import org.springframework.web.server.WebFilter;
import org.springframework.web.server.WebFilterChain;
import reactor.core.publisher.Mono;

import java.util.Locale;
import java.util.UUID;
import java.util.function.Supplier;
import java.util.regex.Pattern;

@Component
public class TraceIdWebFilter implements WebFilter, Ordered {
    static final int MAX_TRACE_ID_LENGTH = 128;
    private static final Pattern SAFE_TRACE_ID = Pattern.compile("[A-Za-z0-9._:-]{1," + MAX_TRACE_ID_LENGTH + "}");

    private final Supplier<String> fallbackTraceIdSupplier;

    public TraceIdWebFilter() {
        this(() -> UUID.randomUUID().toString());
    }

    TraceIdWebFilter(Supplier<String> fallbackTraceIdSupplier) {
        this.fallbackTraceIdSupplier = fallbackTraceIdSupplier;
    }

    @Override
    public Mono<Void> filter(ServerWebExchange exchange, WebFilterChain chain) {
        String traceId = firstNonBlank(
                exchange.getRequest().getHeaders().getFirst(HeaderConstants.X_REQUEST_ID),
                exchange.getRequest().getHeaders().getFirst(HeaderConstants.X_CORRELATION_ID),
                fallbackTraceIdSupplier.get()
        );

        ServerHttpRequest request = exchange.getRequest().mutate()
                .headers(headers -> {
                    headers.set(HeaderConstants.X_REQUEST_ID, traceId);
                    headers.set(HeaderConstants.X_CORRELATION_ID, traceId);
                })
                .build();

        ServerWebExchange mutatedExchange = exchange.mutate().request(request).build();
        mutatedExchange.getResponse().getHeaders().set(HeaderConstants.X_REQUEST_ID, traceId);
        mutatedExchange.getResponse().getHeaders().set(HeaderConstants.X_CORRELATION_ID, traceId);

        return chain.filter(mutatedExchange).contextWrite(context -> context.put(RequestContextKeys.TRACE_ID, traceId));
    }

    @Override
    public int getOrder() {
        return Ordered.HIGHEST_PRECEDENCE;
    }

    private static String firstNonBlank(String... values) {
        for (String value : values) {
            String traceId = normalizeTraceId(value);
            if (traceId != null) {
                return traceId;
            }
        }
        return UUID.randomUUID().toString();
    }

    private static String normalizeTraceId(String value) {
        if (value == null) {
            return null;
        }

        String traceId = value.trim();
        if (traceId.isBlank() || traceId.toLowerCase(Locale.ROOT).equals("null")) {
            return null;
        }
        if (traceId.length() > MAX_TRACE_ID_LENGTH || !SAFE_TRACE_ID.matcher(traceId).matches()) {
            return null;
        }
        return traceId;
    }
}

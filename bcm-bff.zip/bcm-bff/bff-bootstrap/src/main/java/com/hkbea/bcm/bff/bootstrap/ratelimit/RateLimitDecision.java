package com.hkbea.bcm.bff.bootstrap.ratelimit;

public record RateLimitDecision(
        boolean allowed,
        int limit,
        int remaining,
        long resetAtMillis
) {
    public static RateLimitDecision allowed(int limit, int remaining, long resetAtMillis) {
        return new RateLimitDecision(true, limit, remaining, resetAtMillis);
    }

    public static RateLimitDecision rejected(int limit, int remaining, long resetAtMillis) {
        return new RateLimitDecision(false, limit, remaining, resetAtMillis);
    }

    public long retryAfterSeconds(long nowMillis) {
        return Math.max(1, (resetAtMillis - nowMillis + 999) / 1000);
    }
}

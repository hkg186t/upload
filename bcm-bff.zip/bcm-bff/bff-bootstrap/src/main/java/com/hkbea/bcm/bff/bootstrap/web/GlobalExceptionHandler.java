package com.hkbea.bcm.bff.bootstrap.web;

import com.hkbea.bcm.bff.shared.api.BffException;
import com.hkbea.bcm.bff.shared.api.ErrorCode;
import com.hkbea.bcm.bff.shared.api.ErrorResponse;
import org.springframework.core.Ordered;
import org.springframework.core.annotation.Order;
import org.springframework.http.HttpStatus;
import org.springframework.http.HttpStatusCode;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;
import org.springframework.web.server.ServerWebInputException;
import org.springframework.web.server.ResponseStatusException;
import org.springframework.web.server.ServerWebExchange;

@RestControllerAdvice
@Order(Ordered.HIGHEST_PRECEDENCE)
public class GlobalExceptionHandler {
    @ExceptionHandler(BffException.class)
    ResponseEntity<ErrorResponse> handleBffException(BffException error, ServerWebExchange exchange) {
        return ResponseEntity
                .status(HttpStatusCode.valueOf(error.httpStatus()))
                .body(BffErrorResponses.of(error.errorCode(), error.getMessage(), exchange));
    }

    @ExceptionHandler(ServerWebInputException.class)
    ResponseEntity<ErrorResponse> handleBadRequest(ServerWebInputException error, ServerWebExchange exchange) {
        return ResponseEntity
                .status(HttpStatus.BAD_REQUEST)
                .body(BffErrorResponses.of(ErrorCode.BAD_REQUEST, ErrorCode.BAD_REQUEST.defaultMessage(), exchange));
    }

    @ExceptionHandler(ResponseStatusException.class)
    ResponseEntity<ErrorResponse> handleResponseStatusException(
            ResponseStatusException error,
            ServerWebExchange exchange
    ) {
        HttpStatusCode statusCode = error.getStatusCode();
        ErrorCode errorCode = errorCode(statusCode);
        return ResponseEntity
                .status(statusCode)
                .body(BffErrorResponses.of(statusCode, message(statusCode, errorCode), exchange));
    }

    @ExceptionHandler(Throwable.class)
    ResponseEntity<ErrorResponse> handleUnexpected(Throwable error, ServerWebExchange exchange) {
        return ResponseEntity
                .status(HttpStatus.INTERNAL_SERVER_ERROR)
                .body(BffErrorResponses.of(ErrorCode.INTERNAL_ERROR, ErrorCode.INTERNAL_ERROR.defaultMessage(), exchange));
    }

    private static ErrorCode errorCode(HttpStatusCode statusCode) {
        if (statusCode.value() == HttpStatus.BAD_REQUEST.value()) {
            return ErrorCode.BAD_REQUEST;
        }
        if (statusCode.value() == HttpStatus.UNAUTHORIZED.value()) {
            return ErrorCode.UNAUTHORIZED;
        }
        if (statusCode.value() == HttpStatus.FORBIDDEN.value()) {
            return ErrorCode.FORBIDDEN;
        }
        if (statusCode.value() == HttpStatus.NOT_FOUND.value()) {
            return ErrorCode.NOT_FOUND;
        }
        if (statusCode.value() == HttpStatus.PAYLOAD_TOO_LARGE.value()) {
            return ErrorCode.PAYLOAD_TOO_LARGE;
        }
        if (statusCode.value() == HttpStatus.TOO_MANY_REQUESTS.value()) {
            return ErrorCode.TOO_MANY_REQUESTS;
        }
        return ErrorCode.INTERNAL_ERROR;
    }

    private static String message(HttpStatusCode statusCode, ErrorCode errorCode) {
        if (errorCode != ErrorCode.INTERNAL_ERROR) {
            return errorCode.defaultMessage();
        }
        if (statusCode instanceof HttpStatus httpStatus) {
            return httpStatus.getReasonPhrase();
        }
        return ErrorCode.INTERNAL_ERROR.defaultMessage();
    }
}

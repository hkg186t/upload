package com.hkbea.bcm.bff.bootstrap.config;

import org.springframework.boot.context.properties.ConfigurationProperties;

@ConfigurationProperties(prefix = "bff.management-access")
public class ManagementAccessProperties {
    public static final String DEFAULT_METRICS_TOKEN_HEADER = "X-BFF-Monitoring-Token";

    private String metricsToken = "";
    private String metricsTokenHeader = DEFAULT_METRICS_TOKEN_HEADER;

    public String getMetricsToken() {
        return metricsToken;
    }

    public void setMetricsToken(String metricsToken) {
        this.metricsToken = metricsToken == null ? "" : metricsToken;
    }

    public String getMetricsTokenHeader() {
        return metricsTokenHeader;
    }

    public void setMetricsTokenHeader(String metricsTokenHeader) {
        this.metricsTokenHeader = hasText(metricsTokenHeader) ? metricsTokenHeader.trim() : DEFAULT_METRICS_TOKEN_HEADER;
    }

    public boolean isMetricsTokenConfigured() {
        return hasText(metricsToken);
    }

    private static boolean hasText(String value) {
        return value != null && !value.isBlank();
    }
}

package com.hkbea.bcm.bff.bootstrap.config;

import org.springframework.boot.context.properties.ConfigurationProperties;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Optional;

@ConfigurationProperties(prefix = "bff.rate-limit")
public class RateLimitProperties {
    private boolean enabled = true;
    private Store store = Store.MEMORY;
    private int maxBuckets = 10000;
    private String redisKeyPrefix = "bcm-bff";
    private boolean trustXForwardedFor;
    private List<Rule> rules = defaultRules();

    public boolean isEnabled() {
        return enabled;
    }

    public void setEnabled(boolean enabled) {
        this.enabled = enabled;
    }

    public Store getStore() {
        return store;
    }

    public void setStore(Store store) {
        this.store = store == null ? Store.MEMORY : store;
    }

    public int getMaxBuckets() {
        return maxBuckets;
    }

    public void setMaxBuckets(int maxBuckets) {
        this.maxBuckets = maxBuckets;
    }

    public String getRedisKeyPrefix() {
        return redisKeyPrefix;
    }

    public void setRedisKeyPrefix(String redisKeyPrefix) {
        this.redisKeyPrefix = redisKeyPrefix;
    }

    public boolean isTrustXForwardedFor() {
        return trustXForwardedFor;
    }

    public void setTrustXForwardedFor(boolean trustXForwardedFor) {
        this.trustXForwardedFor = trustXForwardedFor;
    }

    public List<Rule> getRules() {
        return rules;
    }

    public void setRules(List<Rule> rules) {
        this.rules = rules == null ? List.of() : new ArrayList<>(rules);
    }

    public Optional<Rule> resolveRule(String path) {
        if (path == null || path.isBlank()) {
            return Optional.empty();
        }

        return rules.stream()
                .filter(rule -> rule.isEnabled())
                .filter(rule -> path.startsWith(rule.getPathPrefix()))
                .max(Comparator.comparingInt(rule -> rule.getPathPrefix().length()));
    }

    private static List<Rule> defaultRules() {
        return List.of(
                new Rule("auth", "/auth/", 30, 60),
                new Rule("bcm", "/bcm/", 600, 60),
                new Rule("bff", "/bff/", 300, 60)
        );
    }

    public enum Store {
        MEMORY,
        REDIS
    }

    public static class Rule {
        private String id;
        private String pathPrefix;
        private int maxRequests;
        private long windowSeconds;
        private boolean enabled = true;

        public Rule() {
        }

        public Rule(String id, String pathPrefix, int maxRequests, long windowSeconds) {
            this.id = id;
            this.pathPrefix = pathPrefix;
            this.maxRequests = maxRequests;
            this.windowSeconds = windowSeconds;
        }

        public String getId() {
            return id;
        }

        public void setId(String id) {
            this.id = id;
        }

        public String getPathPrefix() {
            return pathPrefix;
        }

        public void setPathPrefix(String pathPrefix) {
            this.pathPrefix = pathPrefix;
        }

        public int getMaxRequests() {
            return maxRequests;
        }

        public void setMaxRequests(int maxRequests) {
            this.maxRequests = maxRequests;
        }

        public long getWindowSeconds() {
            return windowSeconds;
        }

        public void setWindowSeconds(long windowSeconds) {
            this.windowSeconds = windowSeconds;
        }

        public boolean isEnabled() {
            return enabled;
        }

        public void setEnabled(boolean enabled) {
            this.enabled = enabled;
        }
    }
}

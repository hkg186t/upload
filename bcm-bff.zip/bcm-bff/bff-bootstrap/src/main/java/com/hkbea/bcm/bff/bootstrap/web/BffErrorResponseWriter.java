package com.hkbea.bcm.bff.bootstrap.web;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.hkbea.bcm.bff.shared.api.BffException;
import com.hkbea.bcm.bff.shared.api.ErrorCode;
import com.hkbea.bcm.bff.shared.api.ErrorResponse;
import com.hkbea.bcm.bff.shared.http.HeaderConstants;
import org.springframework.http.HttpStatus;
import org.springframework.http.HttpStatusCode;
import org.springframework.http.MediaType;
import org.springframework.http.server.reactive.ServerHttpResponse;
import org.springframework.stereotype.Component;
import org.springframework.web.server.ServerWebExchange;
import reactor.core.publisher.Mono;

import java.util.LinkedHashMap;
import java.util.Map;

@Component
public class BffErrorResponseWriter {
    private final ObjectMapper objectMapper;

    public BffErrorResponseWriter(ObjectMapper objectMapper) {
        this.objectMapper = objectMapper;
    }

    public Mono<Void> write(ServerWebExchange exchange, BffException error) {
        return write(exchange, HttpStatusCode.valueOf(error.httpStatus()), error.errorCode(), error.getMessage());
    }

    public Mono<Void> writeLegacySessionExpired(ServerWebExchange exchange) {
        ServerHttpResponse response = exchange.getResponse();
        if (response.isCommitted()) {
            return Mono.error(new BffException(ErrorCode.SESSION_EXPIRED));
        }

        response.setStatusCode(HttpStatus.OK);
        response.getHeaders().setContentType(MediaType.APPLICATION_JSON);
        Map<String, String> body = new LinkedHashMap<>();
        body.put("status", ErrorCode.SESSION_EXPIRED.code());
        body.put("code", ErrorCode.SESSION_EXPIRED.code());
        body.put("message", ErrorCode.SESSION_EXPIRED.defaultMessage());
        return Mono.fromCallable(() -> objectMapper.writeValueAsBytes(body))
                .flatMap(bytes -> response.writeWith(Mono.just(response.bufferFactory().wrap(bytes))));
    }

    public Mono<Void> write(ServerWebExchange exchange, ErrorCode errorCode, String message) {
        return write(exchange, HttpStatusCode.valueOf(Integer.parseInt(errorCode.code())), errorCode, message);
    }

    public Mono<Void> write(
            ServerWebExchange exchange,
            HttpStatusCode status,
            ErrorCode errorCode,
            String message
    ) {
        ServerHttpResponse response = exchange.getResponse();
        if (response.isCommitted()) {
            return Mono.error(new BffException(errorCode, message));
        }

        String traceId = BffErrorResponses.traceId(exchange);
        response.setStatusCode(status);
        response.getHeaders().setContentType(MediaType.APPLICATION_JSON);
        if (!traceId.isBlank()) {
            response.getHeaders().set(HeaderConstants.X_REQUEST_ID, traceId);
            response.getHeaders().set(HeaderConstants.X_CORRELATION_ID, traceId);
        }

        ErrorResponse body = ErrorResponse.of(errorCode, message, traceId);
        return Mono.fromCallable(() -> objectMapper.writeValueAsBytes(body))
                .flatMap(bytes -> response.writeWith(Mono.just(response.bufferFactory().wrap(bytes))));
    }
}

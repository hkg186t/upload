package com.hkbea.bcm.bff.bootstrap.config;

import org.springframework.boot.context.properties.ConfigurationProperties;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Optional;

@ConfigurationProperties(prefix = "bff.request-size-limit")
public class RequestSizeLimitProperties {
    private boolean enabled = true;
    private List<Rule> rules = defaultRules();

    public boolean isEnabled() {
        return enabled;
    }

    public void setEnabled(boolean enabled) {
        this.enabled = enabled;
    }

    public List<Rule> getRules() {
        return rules;
    }

    public void setRules(List<Rule> rules) {
        this.rules = rules == null ? List.of() : new ArrayList<>(rules);
    }

    public Optional<Rule> resolveRule(String path) {
        if (path == null || path.isBlank()) {
            return Optional.empty();
        }

        return rules.stream()
                .filter(Rule::isEnabled)
                .filter(rule -> path.startsWith(rule.getPathPrefix()))
                .max(Comparator.comparingInt(rule -> rule.getPathPrefix().length()));
    }

    private static List<Rule> defaultRules() {
        return List.of(
                new Rule("auth", "/auth/", 65_536),
                new Rule("bcm", "/bcm/", 1_048_576),
                new Rule("bff", "/bff/", 1_048_576)
        );
    }

    public static class Rule {
        private String id;
        private String pathPrefix;
        private long maxBytes;
        private boolean enabled = true;

        public Rule() {
        }

        public Rule(String id, String pathPrefix, long maxBytes) {
            this.id = id;
            this.pathPrefix = pathPrefix;
            this.maxBytes = maxBytes;
        }

        public String getId() {
            return id;
        }

        public void setId(String id) {
            this.id = id;
        }

        public String getPathPrefix() {
            return pathPrefix;
        }

        public void setPathPrefix(String pathPrefix) {
            this.pathPrefix = pathPrefix;
        }

        public long getMaxBytes() {
            return maxBytes;
        }

        public void setMaxBytes(long maxBytes) {
            this.maxBytes = maxBytes;
        }

        public boolean isEnabled() {
            return enabled;
        }

        public void setEnabled(boolean enabled) {
            this.enabled = enabled;
        }
    }
}

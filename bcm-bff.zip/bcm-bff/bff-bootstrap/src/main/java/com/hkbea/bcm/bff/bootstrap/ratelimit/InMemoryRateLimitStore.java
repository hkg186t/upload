package com.hkbea.bcm.bff.bootstrap.ratelimit;

import com.hkbea.bcm.bff.bootstrap.config.RateLimitProperties;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.stereotype.Component;
import reactor.core.publisher.Mono;

import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.atomic.AtomicReference;

@Component
@ConditionalOnProperty(prefix = "bff.rate-limit", name = "store", havingValue = "memory", matchIfMissing = true)
public class InMemoryRateLimitStore implements RateLimitStore {
    private final RateLimitProperties properties;
    private final Map<String, BucketState> buckets = new ConcurrentHashMap<>();

    public InMemoryRateLimitStore(RateLimitProperties properties) {
        this.properties = properties;
    }

    @Override
    public Mono<RateLimitDecision> record(
            RateLimitProperties.Rule rule,
            String bucketKey,
            long nowMillis,
            long windowMillis,
            int maxRequests
    ) {
        if (shouldRejectNewBucket(rule, bucketKey, nowMillis, windowMillis)) {
            return Mono.just(RateLimitDecision.rejected(maxRequests, 0, nowMillis + windowMillis));
        }

        AtomicReference<RateLimitDecision> decisionRef = new AtomicReference<>();
        buckets.compute(qualifiedBucketKey(rule, bucketKey), (ignored, current) -> {
            if (current == null || current.isExpired(nowMillis, windowMillis)) {
                BucketState next = new BucketState(nowMillis, 1);
                decisionRef.set(RateLimitDecision.allowed(maxRequests, maxRequests - 1, nowMillis + windowMillis));
                return next;
            }

            long resetAtMillis = current.windowStartMillis() + windowMillis;
            if (current.count() >= maxRequests) {
                decisionRef.set(RateLimitDecision.rejected(maxRequests, 0, resetAtMillis));
                return current;
            }

            int nextCount = current.count() + 1;
            decisionRef.set(RateLimitDecision.allowed(maxRequests, maxRequests - nextCount, resetAtMillis));
            return new BucketState(current.windowStartMillis(), nextCount);
        });

        return Mono.just(decisionRef.get());
    }

    private boolean shouldRejectNewBucket(
            RateLimitProperties.Rule rule,
            String bucketKey,
            long nowMillis,
            long windowMillis
    ) {
        String qualifiedBucketKey = qualifiedBucketKey(rule, bucketKey);
        if (buckets.containsKey(qualifiedBucketKey) || buckets.size() < Math.max(1, properties.getMaxBuckets())) {
            return false;
        }

        buckets.entrySet().removeIf(entry -> entry.getValue().isExpired(nowMillis, windowMillis));
        return !buckets.containsKey(qualifiedBucketKey) && buckets.size() >= Math.max(1, properties.getMaxBuckets());
    }

    private static String qualifiedBucketKey(RateLimitProperties.Rule rule, String bucketKey) {
        return rule.getId() + ":" + bucketKey;
    }

    private record BucketState(
            long windowStartMillis,
            int count
    ) {
        boolean isExpired(long nowMillis, long windowMillis) {
            return nowMillis - windowStartMillis >= windowMillis;
        }
    }
}

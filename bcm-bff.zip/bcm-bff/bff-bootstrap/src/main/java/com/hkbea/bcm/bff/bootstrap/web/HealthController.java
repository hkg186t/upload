package com.hkbea.bcm.bff.bootstrap.web;

import com.hkbea.bcm.bff.shared.context.RequestContextKeys;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import reactor.core.publisher.Mono;

import java.lang.management.ManagementFactory;
import java.time.Instant;
import java.util.LinkedHashMap;
import java.util.Map;

@RestController
public class HealthController {
    private final String serviceName;

    HealthController(@Value("${bff.service-name:bcm-bff}") String serviceName) {
        this.serviceName = serviceName;
    }

    @RequestMapping(path = {"/", "/health", "/readiness", "/liveness"}, method = {
            RequestMethod.GET,
            RequestMethod.HEAD
    })
    Mono<Map<String, Object>> health() {
        return Mono.deferContextual(contextView -> {
            String traceId = contextView.getOrDefault(RequestContextKeys.TRACE_ID, "");
            Map<String, Object> response = new LinkedHashMap<>();
            response.put("status", "UP");
            response.put("service", serviceName);
            response.put("timestamp", Instant.now().toString());
            response.put("uptimeSeconds", ManagementFactory.getRuntimeMXBean().getUptime() / 1000);
            response.put("checks", Map.of("application", "UP"));
            response.put("traceId", traceId);
            return Mono.just(response);
        });
    }
}

package com.hkbea.bcm.bff.bootstrap.web.aggregation;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.hkbea.bcm.bff.access.model.SessionRecord;
import com.hkbea.bcm.bff.aggregation.config.AggregationProperties;
import com.hkbea.bcm.bff.aggregation.model.AggregationResult;
import com.hkbea.bcm.bff.aggregation.service.AggregationService;
import com.hkbea.bcm.bff.bootstrap.web.DebugRequestLogger;
import com.hkbea.bcm.bff.contract.api.BffAggregationApi;
import com.hkbea.bcm.bff.contract.model.BffAggregationDemoResponse;
import com.hkbea.bcm.bff.contract.model.BffAggregationDemoResponseAllOfData;
import com.hkbea.bcm.bff.contract.model.BffAggregationDemoResponseAllOfDataErrors;
import com.hkbea.bcm.bff.proxy.model.ProxyRequestContext;
import com.hkbea.bcm.bff.shared.api.ApiResponse;
import com.hkbea.bcm.bff.shared.api.BffException;
import com.hkbea.bcm.bff.shared.api.ErrorCode;
import com.hkbea.bcm.bff.shared.context.RequestContextKeys;
import com.hkbea.bcm.bff.shared.http.HeaderConstants;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.server.ServerWebExchange;
import reactor.core.publisher.Mono;

import java.util.Map;
import java.util.stream.Collectors;

@RestController
public class AggregationController implements BffAggregationApi {
    private static final Logger log = LoggerFactory.getLogger(AggregationController.class);

    private final AggregationService aggregationService;
    private final AggregationProperties aggregationProperties;
    private final ObjectMapper objectMapper;

    public AggregationController(
            AggregationService aggregationService,
            AggregationProperties aggregationProperties,
            ObjectMapper objectMapper
    ) {
        this.aggregationService = aggregationService;
        this.aggregationProperties = aggregationProperties;
        this.objectMapper = objectMapper;
    }

    @RequestMapping(method = {
            RequestMethod.GET,
            RequestMethod.POST,
            RequestMethod.PUT,
            RequestMethod.PATCH,
            RequestMethod.DELETE
    }, path = "/bff/**")
    Mono<ApiResponse<AggregationResult>> aggregate(
            @RequestBody(required = false) Mono<JsonNode> requestBody,
            ServerWebExchange exchange
    ) {
        return requestBody
                .defaultIfEmpty(objectMapper.createObjectNode())
                .doOnNext(body -> DebugRequestLogger.logBody(log, exchange, body))
                .flatMap(body -> aggregationService.aggregate(aggregationId(exchange), body, proxyContext(exchange)))
                .map(result -> ApiResponse.success(result, traceId(exchange)));
    }

    @Override
    public Mono<ResponseEntity<BffAggregationDemoResponse>> aggregateHomeSummaryDemo(
            String xRequestId,
            String xCorrelationId,
            String xChannel,
            String xAppId,
            String xUserContext,
            Mono<Map<String, Object>> requestBody,
            ServerWebExchange exchange
    ) {
        return requestBody
                .defaultIfEmpty(Map.of())
                .map(body -> (JsonNode) objectMapper.valueToTree(body))
                .doOnNext(body -> DebugRequestLogger.logBody(log, exchange, body))
                .flatMap(body -> aggregationService.aggregate(aggregationId(exchange), body, proxyContext(exchange)))
                .map(result -> ResponseEntity.ok(aggregationResponse(result, traceId(exchange))));
    }

    private BffAggregationDemoResponse aggregationResponse(AggregationResult result, String traceId) {
        BffAggregationDemoResponseAllOfData data = new BffAggregationDemoResponseAllOfData(
                result.items().entrySet().stream()
                        .collect(Collectors.toMap(Map.Entry::getKey, entry -> objectMapper.convertValue(entry.getValue(), Object.class))),
                result.partial(),
                result.errors().entrySet().stream()
                        .collect(Collectors.toMap(
                                Map.Entry::getKey,
                                entry -> new BffAggregationDemoResponseAllOfDataErrors(
                                        entry.getValue().code(),
                                        entry.getValue().message()
                                )
                        ))
        );
        return new BffAggregationDemoResponse("0000", "success", traceId, data);
    }

    private String aggregationId(ServerWebExchange exchange) {
        return aggregationProperties.resolveRouteId(
                exchange.getRequest().getMethod().name(),
                exchange.getRequest().getPath().pathWithinApplication().value()
        );
    }

    private ProxyRequestContext proxyContext(ServerWebExchange exchange) {
        SessionRecord session = exchange.getAttribute(RequestContextKeys.SESSION_RECORD);
        if (session == null) {
            throw new BffException(ErrorCode.UNAUTHORIZED);
        }

        return new ProxyRequestContext(
                traceId(exchange),
                session,
                exchange.getRequest().getMethod().name(),
                exchange.getRequest().getPath().pathWithinApplication().value(),
                exchange.getRequest().getHeaders(),
                exchange.getRequest().getHeaders().getFirst(HeaderConstants.X_DEVICE_ID),
                exchange.getRequest().getHeaders().getFirst(HeaderConstants.X_DEVICE_OS),
                exchange.getRequest().getHeaders().getFirst(HeaderConstants.LOCALE),
                null
        );
    }

    private static String traceId(ServerWebExchange exchange) {
        return exchange.getResponse().getHeaders().getFirst(HeaderConstants.X_REQUEST_ID);
    }
}

package com.hkbea.bcm.bff.bootstrap.web;

import com.hkbea.bcm.bff.bootstrap.config.RequestSizeLimitProperties;
import com.hkbea.bcm.bff.shared.api.BffException;
import com.hkbea.bcm.bff.shared.api.ErrorCode;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.core.Ordered;
import org.springframework.core.io.buffer.DataBuffer;
import org.springframework.core.io.buffer.DataBufferUtils;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.HttpStatusCode;
import org.springframework.http.server.reactive.ServerHttpRequest;
import org.springframework.http.server.reactive.ServerHttpRequestDecorator;
import org.springframework.http.server.reactive.ServerHttpResponse;
import org.springframework.stereotype.Component;
import org.springframework.web.server.ServerWebExchange;
import org.springframework.web.server.WebFilter;
import org.springframework.web.server.WebFilterChain;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

import java.util.concurrent.atomic.AtomicLong;

@Component
public class RequestSizeLimitWebFilter implements WebFilter, Ordered {
    private static final Logger log = LoggerFactory.getLogger(RequestSizeLimitWebFilter.class);

    private final RequestSizeLimitProperties properties;
    private final BffErrorResponseWriter errorResponseWriter;

    public RequestSizeLimitWebFilter(
            RequestSizeLimitProperties properties,
            BffErrorResponseWriter errorResponseWriter
    ) {
        this.properties = properties;
        this.errorResponseWriter = errorResponseWriter;
    }

    @Override
    public Mono<Void> filter(ServerWebExchange exchange, WebFilterChain chain) {
        if (!properties.isEnabled()
                || exchange.getRequest().getMethod() == HttpMethod.GET
                || exchange.getRequest().getMethod() == HttpMethod.DELETE
                || exchange.getRequest().getMethod() == HttpMethod.OPTIONS) {
            return chain.filter(exchange);
        }

        String path = exchange.getRequest().getPath().pathWithinApplication().value();
        return properties.resolveRule(path)
                .map(rule -> applyRequestSizeLimit(exchange, chain, rule))
                .orElseGet(() -> chain.filter(exchange));
    }

    @Override
    public int getOrder() {
        return Ordered.HIGHEST_PRECEDENCE + 8;
    }

    private Mono<Void> applyRequestSizeLimit(
            ServerWebExchange exchange,
            WebFilterChain chain,
            RequestSizeLimitProperties.Rule rule
    ) {
        long maxBytes = Math.max(1, rule.getMaxBytes());
        long contentLength = exchange.getRequest().getHeaders().getContentLength();
        if (contentLength > maxBytes) {
            return reject(exchange, rule, maxBytes, contentLength, "header");
        }

        ServerWebExchange limitedExchange = exchange.mutate()
                .request(limitedRequest(exchange.getRequest(), rule, maxBytes))
                .build();
        return chain.filter(limitedExchange)
                .onErrorResume(RequestBodyTooLargeException.class, error ->
                        reject(exchange, rule, maxBytes, error.observedBytes(), "body"));
    }

    private static ServerHttpRequest limitedRequest(
            ServerHttpRequest request,
            RequestSizeLimitProperties.Rule rule,
            long maxBytes
    ) {
        AtomicLong observedBytes = new AtomicLong();
        return new ServerHttpRequestDecorator(request) {
            @Override
            public Flux<DataBuffer> getBody() {
                return super.getBody().handle((dataBuffer, sink) -> {
                    long nextBytes = observedBytes.addAndGet(dataBuffer.readableByteCount());
                    if (nextBytes > maxBytes) {
                        DataBufferUtils.release(dataBuffer);
                        sink.error(new RequestBodyTooLargeException(rule, nextBytes));
                        return;
                    }
                    sink.next(dataBuffer);
                });
            }
        };
    }

    private Mono<Void> reject(
            ServerWebExchange exchange,
            RequestSizeLimitProperties.Rule rule,
            long maxBytes,
            long observedBytes,
            String source
    ) {
        ServerHttpResponse response = exchange.getResponse();
        if (response.isCommitted()) {
            return Mono.error(new BffException(ErrorCode.PAYLOAD_TOO_LARGE));
        }

        response.setStatusCode(HttpStatusCode.valueOf(HttpStatus.PAYLOAD_TOO_LARGE.value()));

        log.warn("BCM_REQUEST_SIZE_ACCESS outcome=rejected ruleId={} path={} source={} maxBytes={} observedBytes={}",
                rule.getId(),
                exchange.getRequest().getPath().pathWithinApplication().value(),
                source,
                maxBytes,
                observedBytes);
        return errorResponseWriter.write(exchange, ErrorCode.PAYLOAD_TOO_LARGE, ErrorCode.PAYLOAD_TOO_LARGE.defaultMessage());
    }

    private static class RequestBodyTooLargeException extends BffException {
        private final long observedBytes;

        RequestBodyTooLargeException(RequestSizeLimitProperties.Rule rule, long observedBytes) {
            super(ErrorCode.PAYLOAD_TOO_LARGE, "Request body too large for rule: " + rule.getId());
            this.observedBytes = observedBytes;
        }

        long observedBytes() {
            return observedBytes;
        }
    }
}

package com.hkbea.bcm.bff.bootstrap.web;

import com.hkbea.bcm.bff.access.model.SessionRecord;
import com.hkbea.bcm.bff.access.service.AuthService;
import com.hkbea.bcm.bff.access.service.AuthorizationPolicyService;
import com.hkbea.bcm.bff.bootstrap.config.ManagementAccessProperties;
import com.hkbea.bcm.bff.proxy.config.BcoProxyProperties;
import com.hkbea.bcm.bff.proxy.config.BcmProxyProperties;
import com.hkbea.bcm.bff.shared.api.BffException;
import com.hkbea.bcm.bff.shared.api.ErrorCode;
import com.hkbea.bcm.bff.shared.context.RequestContextKeys;
import com.hkbea.bcm.bff.shared.http.HeaderConstants;
import org.springframework.core.Ordered;
import org.springframework.http.HttpMethod;
import org.springframework.stereotype.Component;
import org.springframework.web.server.ServerWebExchange;
import org.springframework.web.server.WebFilter;
import org.springframework.web.server.WebFilterChain;
import reactor.core.publisher.Mono;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;

@Component
public class AuthWebFilter implements WebFilter, Ordered {
    private static final String PROMETHEUS_PATH = "/actuator/prometheus";
    private static final String LEGACY_LOGIN_PATH = "/api/login";
    private static final String LEGACY_BCO_LOGIN_PATH = "/digx/j_security_check";

    private final AuthService authService;
    private final AuthorizationPolicyService authorizationPolicyService;
    private final ManagementAccessProperties managementAccessProperties;
    private final BcoProxyProperties bcoProxyProperties;
    private final BcmProxyProperties bcmProxyProperties;
    private final BffErrorResponseWriter errorResponseWriter;

    public AuthWebFilter(
            AuthService authService,
            AuthorizationPolicyService authorizationPolicyService,
            ManagementAccessProperties managementAccessProperties,
            BcoProxyProperties bcoProxyProperties,
            BcmProxyProperties bcmProxyProperties,
            BffErrorResponseWriter errorResponseWriter
    ) {
        this.authService = authService;
        this.authorizationPolicyService = authorizationPolicyService;
        this.managementAccessProperties = managementAccessProperties;
        this.bcoProxyProperties = bcoProxyProperties;
        this.bcmProxyProperties = bcmProxyProperties;
        this.errorResponseWriter = errorResponseWriter;
    }

    @Override
    public Mono<Void> filter(ServerWebExchange exchange, WebFilterChain chain) {
        if (isPublic(exchange)
                || isPublicBcoProxyRequest(exchange)
                || isPublicBcmRawProxyRequest(exchange)
                || isManagementMetricsRequestAuthorized(exchange)) {
            return chain.filter(exchange);
        }

        String authorization = exchange.getRequest().getHeaders().getFirst(HeaderConstants.AUTHORIZATION);
        return authService.validateAccessToken(authorization)
                .flatMap(session -> continueWithSession(exchange, chain, session))
                .onErrorResume(BffException.class, error -> handleAuthError(exchange, error))
                .onErrorResume(error -> writeError(exchange, new BffException(ErrorCode.INTERNAL_ERROR)));
    }

    @Override
    public int getOrder() {
        return Ordered.HIGHEST_PRECEDENCE + 20;
    }

    private Mono<Void> continueWithSession(ServerWebExchange exchange, WebFilterChain chain, SessionRecord session) {
        exchange.getAttributes().put(RequestContextKeys.SESSION_RECORD, session);
        return authorizationPolicyService
                .authorize(
                        exchange.getRequest().getMethod().name(),
                        exchange.getRequest().getPath().pathWithinApplication().value(),
                        session)
                .then(chain.filter(exchange))
                .contextWrite(context -> context.put(RequestContextKeys.SESSION_RECORD, session));
    }

    private Mono<Void> writeError(ServerWebExchange exchange, BffException error) {
        return errorResponseWriter.write(exchange, error);
    }

    private Mono<Void> handleAuthError(ServerWebExchange exchange, BffException error) {
        if (error.errorCode() == ErrorCode.SESSION_EXPIRED && isLegacyProxyRequest(exchange)) {
            return errorResponseWriter.writeLegacySessionExpired(exchange);
        }
        return writeError(exchange, error);
    }

    private static boolean isPublic(ServerWebExchange exchange) {
        if (exchange.getRequest().getMethod() == HttpMethod.OPTIONS) {
            return true;
        }

        String path = exchange.getRequest().getPath().pathWithinApplication().value();
        return path.equals("/")
                || path.equals("/health")
                || path.equals("/readiness")
                || path.equals("/liveness")
                || path.startsWith("/actuator/health")
                || path.equals("/auth/login")
                || path.equals("/auth/refresh")
                || path.equals(LEGACY_LOGIN_PATH)
                || path.equals(LEGACY_BCO_LOGIN_PATH);
    }

    private boolean isPublicBcoProxyRequest(ServerWebExchange exchange) {
        if (!bcoProxyProperties.isEnabled()) {
            return false;
        }
        String path = exchange.getRequest().getPath().pathWithinApplication().value();
        return bcoProxyProperties.isPublicPath(path);
    }

    private boolean isLegacyProxyRequest(ServerWebExchange exchange) {
        String path = exchange.getRequest().getPath().pathWithinApplication().value();
        return isBcoLegacyProxyRequest(path) || isBcmLegacyProxyRequest(path);
    }

    private boolean isBcoLegacyProxyRequest(String path) {
        return bcoProxyProperties.isEnabled()
                && startsWithNormalized(path, bcoProxyProperties.getLegacyPassthroughPathPrefix());
    }

    private boolean isBcmLegacyProxyRequest(String path) {
        return bcmProxyProperties.isLegacyPassthroughEnabled()
                && startsWithNormalized(path, bcmProxyProperties.getLegacyPassthroughPathPrefix());
    }

    private boolean isPublicBcmRawProxyRequest(ServerWebExchange exchange) {
        String path = exchange.getRequest().getPath().pathWithinApplication().value();
        return bcmProxyProperties.isDspLegacyPassthroughPath(path);
    }

    private boolean isManagementMetricsRequestAuthorized(ServerWebExchange exchange) {
        if (!managementAccessProperties.isMetricsTokenConfigured()) {
            return false;
        }
        if (exchange.getRequest().getMethod() != HttpMethod.GET) {
            return false;
        }

        String path = exchange.getRequest().getPath().pathWithinApplication().value();
        if (!PROMETHEUS_PATH.equals(path)) {
            return false;
        }

        String suppliedToken = exchange.getRequest()
                .getHeaders()
                .getFirst(managementAccessProperties.getMetricsTokenHeader());
        return constantTimeEquals(suppliedToken, managementAccessProperties.getMetricsToken());
    }

    private static boolean constantTimeEquals(String left, String right) {
        if (left == null || right == null) {
            return false;
        }
        byte[] leftBytes = left.getBytes(StandardCharsets.UTF_8);
        byte[] rightBytes = right.getBytes(StandardCharsets.UTF_8);
        return MessageDigest.isEqual(leftBytes, rightBytes);
    }

    private static String normalizePath(String path) {
        if (path == null || path.isBlank()) {
            return "";
        }
        String normalized = path.trim();
        if (normalized.length() > 1 && normalized.endsWith("/")) {
            return normalized.substring(0, normalized.length() - 1);
        }
        return normalized;
    }

    private static boolean startsWithNormalized(String path, String prefix) {
        String normalizedPath = normalizePath(path);
        String normalizedPrefix = normalizePath(prefix);
        return !normalizedPrefix.isBlank()
                && (normalizedPath.equals(normalizedPrefix)
                || normalizedPath.startsWith(normalizedPrefix + "/"));
    }
}

package com.hkbea.bcm.bff.bootstrap.web.proxy;

import com.hkbea.bcm.bff.access.model.SessionRecord;
import com.hkbea.bcm.bff.proxy.config.BcoProxyProperties;
import com.hkbea.bcm.bff.proxy.model.RawProxyRequestContext;
import com.hkbea.bcm.bff.proxy.model.RawProxyResult;
import com.hkbea.bcm.bff.proxy.service.BcoProxyService;
import com.hkbea.bcm.bff.bootstrap.web.DebugRequestLogger;
import com.hkbea.bcm.bff.shared.context.RequestContextKeys;
import com.hkbea.bcm.bff.shared.http.HeaderConstants;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.core.io.buffer.DataBufferUtils;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.server.ServerWebExchange;
import reactor.core.publisher.Mono;

import java.nio.charset.StandardCharsets;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

@RestController
public class BcoProxyController {
    private static final Logger log = LoggerFactory.getLogger(BcoProxyController.class);

    private final BcoProxyService proxyService;
    private final BcoProxyProperties properties;

    public BcoProxyController(BcoProxyService proxyService, BcoProxyProperties properties) {
        this.proxyService = proxyService;
        this.properties = properties;
    }

    @RequestMapping(method = {
            RequestMethod.GET,
            RequestMethod.POST,
            RequestMethod.PUT,
            RequestMethod.PATCH,
            RequestMethod.DELETE
    }, path = "/digx/**")
    Mono<ResponseEntity<Map<String, Object>>> proxy(ServerWebExchange exchange) {
        if (!properties.isEnabled()) {
            return Mono.just(ResponseEntity.notFound().build());
        }
        return readBody(exchange)
                .doOnNext(body -> DebugRequestLogger.logBody(log, exchange, body))
                .flatMap(body -> proxyService.proxy(body, proxyContext(exchange)))
                .map(this::toResponse);
    }

    private ResponseEntity<Map<String, Object>> toResponse(RawProxyResult result) {
        Map<String, Object> response = new LinkedHashMap<>();
        response.put("status", result.statusCode());
        response.put("headers", headersToMap(result.headers()));
        if (result.body() != null && result.body().length > 0) {
            response.put("body", new String(result.body(), StandardCharsets.UTF_8));
        }
        return ResponseEntity.ok(response);
    }

    private static Map<String, List<String>> headersToMap(org.springframework.http.HttpHeaders headers) {
        Map<String, List<String>> result = new LinkedHashMap<>();
        if (headers != null) {
            headers.forEach((name, values) -> result.put(canonicalHeaderName(name), List.copyOf(values)));
        }
        return result;
    }

    private static String canonicalHeaderName(String name) {
        if (name == null || name.isBlank()) {
            return name;
        }
        String[] parts = name.split("-", -1);
        for (int i = 0; i < parts.length; i++) {
            String part = parts[i];
            if (!part.isEmpty()) {
                parts[i] = part.substring(0, 1).toUpperCase(Locale.ROOT)
                        + part.substring(1).toLowerCase(Locale.ROOT);
            }
        }
        return String.join("-", parts);
    }

    private RawProxyRequestContext proxyContext(ServerWebExchange exchange) {
        SessionRecord session = exchange.getAttribute(RequestContextKeys.SESSION_RECORD);
        return new RawProxyRequestContext(
                traceId(exchange),
                exchange.getRequest().getMethod().name(),
                exchange.getRequest().getPath().pathWithinApplication().value(),
                exchange.getRequest().getURI().getRawQuery(),
                exchange.getRequest().getHeaders(),
                session
        );
    }

    private static Mono<byte[]> readBody(ServerWebExchange exchange) {
        return DataBufferUtils.join(exchange.getRequest().getBody())
                .map(buffer -> {
                    byte[] bytes = new byte[buffer.readableByteCount()];
                    buffer.read(bytes);
                    DataBufferUtils.release(buffer);
                    return bytes;
                })
                .defaultIfEmpty(new byte[0]);
    }

    private static String traceId(ServerWebExchange exchange) {
        return exchange.getResponse().getHeaders().getFirst(HeaderConstants.X_REQUEST_ID);
    }
}

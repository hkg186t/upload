package com.hkbea.bcm.bff.bootstrap.config;

import com.hkbea.bcm.bff.access.config.AuthProperties;
import com.hkbea.bcm.bff.access.config.EntitlementProperties;
import com.hkbea.bcm.bff.access.config.SessionStoreProperties;
import com.hkbea.bcm.bff.proxy.config.BcoProxyProperties;
import com.hkbea.bcm.bff.proxy.config.BcmProxyProperties;
import org.springframework.boot.autoconfigure.data.redis.RedisProperties;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.SmartInitializingSingleton;
import org.springframework.context.annotation.Profile;
import org.springframework.stereotype.Component;

import java.net.URI;
import java.net.URISyntaxException;
import java.util.Locale;
import java.util.Set;

@Component
@Profile("prod")
public class ProductionRuntimeConfigurationValidator implements SmartInitializingSingleton {
    private static final Logger log = LoggerFactory.getLogger(ProductionRuntimeConfigurationValidator.class);
    private static final String LOCAL_DEFAULT_JWT_SECRET = "local-dev-change-me-at-least-32-bytes";
    private static final String LOCAL_DEFAULT_JWT_KEY_ID = "local";
    private static final int MIN_JWT_SECRET_LENGTH = 32;
    private static final int MIN_MANAGEMENT_TOKEN_LENGTH = 32;
    private static final Set<String> LOCAL_UPSTREAM_HOSTS = Set.of(
            "localhost",
            "127.0.0.1",
            "0.0.0.0",
            "::1"
    );

    private final AuthProperties authProperties;
    private final SessionStoreProperties sessionStoreProperties;
    private final BcmProxyProperties proxyProperties;
    private final BcoProxyProperties bcoProxyProperties;
    private final EntitlementProperties entitlementProperties;
    private final ManagementAccessProperties managementAccessProperties;
    private final RateLimitProperties rateLimitProperties;
    private final SecurityHeadersProperties securityHeadersProperties;
    private final CorsProperties corsProperties;
    private final RedisProperties redisProperties;

    public ProductionRuntimeConfigurationValidator(
            AuthProperties authProperties,
            SessionStoreProperties sessionStoreProperties,
            BcmProxyProperties proxyProperties,
            BcoProxyProperties bcoProxyProperties,
            EntitlementProperties entitlementProperties,
            ManagementAccessProperties managementAccessProperties,
            RateLimitProperties rateLimitProperties,
            SecurityHeadersProperties securityHeadersProperties,
            CorsProperties corsProperties,
            RedisProperties redisProperties
    ) {
        this.authProperties = authProperties;
        this.sessionStoreProperties = sessionStoreProperties;
        this.proxyProperties = proxyProperties;
        this.bcoProxyProperties = bcoProxyProperties;
        this.entitlementProperties = entitlementProperties;
        this.managementAccessProperties = managementAccessProperties;
        this.rateLimitProperties = rateLimitProperties;
        this.securityHeadersProperties = securityHeadersProperties;
        this.corsProperties = corsProperties;
        this.redisProperties = redisProperties;
    }

    @Override
    public void afterSingletonsInstantiated() {
        validate();
    }

    void validate() {
        validateJwtSecret();
        validateIssuerAndAudience();
        validateLocalLogin();
        validateLoginProvider();
        validateSessionStore();
        validateRedis();
        validateBcmUpstream();
        validateBcoUpstream();
        validateEntitlementMode();
        validateManagementAccess();
        validateRateLimitStore();
        validateSecurityHeaders();
        validateCors();

        log.info("BCM_PROD_CONFIG_VALIDATION outcome=success sessionStore={} rateLimitStore={} loginProvider={} entitlementProvider={} redisHost={} redisUsername={} bcmBaseUrlHost={} bcoBaseUrlHost={} metricsTokenConfigured={} hstsEnabled={} corsEnabled={}",
                sessionStoreProperties.getStore(),
                rateLimitProperties.getStore(),
                authProperties.getLoginProvider(),
                entitlementProperties.getProvider(),
                redisProperties.getHost(),
                redisProperties.getUsername(),
                upstreamHost(proxyProperties.getBaseUrl()),
                upstreamHost(bcoProxyProperties.getBaseUrl()),
                managementAccessProperties.isMetricsTokenConfigured(),
                securityHeadersProperties.getHsts().isEnabled(),
                corsProperties.isEnabled());
    }

    private void validateJwtSecret() {
        String jwtSecret = authProperties.getJwtSecret();
        require(hasText(jwtSecret), "BFF_JWT_SECRET is required in prod profile");
        require(jwtSecret.length() >= MIN_JWT_SECRET_LENGTH,
                "BFF_JWT_SECRET must be at least " + MIN_JWT_SECRET_LENGTH + " characters in prod profile");
        require(!LOCAL_DEFAULT_JWT_SECRET.equals(jwtSecret),
                "BFF_JWT_SECRET must not use the local development default in prod profile");

        String jwtKeyId = authProperties.getJwtKeyId();
        require(hasText(jwtKeyId), "BFF_JWT_KEY_ID is required in prod profile");
        require(!LOCAL_DEFAULT_JWT_KEY_ID.equals(jwtKeyId),
                "BFF_JWT_KEY_ID must not use the local development default in prod profile");

        try {
            authProperties.jwtPreviousKeyMap().forEach((keyId, secret) -> {
                require(!jwtKeyId.equals(keyId),
                        "BFF_JWT_PREVIOUS_KEYS must not repeat the active BFF_JWT_KEY_ID");
                require(secret.length() >= MIN_JWT_SECRET_LENGTH,
                        "BFF_JWT_PREVIOUS_KEYS secrets must be at least "
                                + MIN_JWT_SECRET_LENGTH + " characters in prod profile");
                require(!LOCAL_DEFAULT_JWT_SECRET.equals(secret),
                        "BFF_JWT_PREVIOUS_KEYS must not use the local development default in prod profile");
            });
        } catch (IllegalArgumentException error) {
            throw new IllegalStateException("BFF_JWT_PREVIOUS_KEYS must use comma-separated kid=secret entries", error);
        }
    }

    private void validateSessionStore() {
        require("redis".equalsIgnoreCase(sessionStoreProperties.getStore()),
                "BFF_SESSION_STORE must be redis in prod profile");
    }

    private void validateRedis() {
        require(hasText(redisProperties.getHost()), "SPRING_DATA_REDIS_HOST is required in prod profile");
        require(!LOCAL_UPSTREAM_HOSTS.contains(redisProperties.getHost().toLowerCase(Locale.ROOT)),
                "SPRING_DATA_REDIS_HOST must not point to a local host in prod profile");
        require(redisProperties.getPort() > 0, "SPRING_DATA_REDIS_PORT must be greater than zero in prod profile");
        require(hasText(redisProperties.getUsername()), "SPRING_DATA_REDIS_USERNAME is required in prod profile");
        require(hasText(redisProperties.getPassword()), "SPRING_DATA_REDIS_PASSWORD is required in prod profile");
    }

    private void validateIssuerAndAudience() {
        require(hasText(authProperties.getIssuer()), "BFF_AUTH_ISSUER is required in prod profile");
        require(hasText(authProperties.getAudience()), "BFF_AUTH_AUDIENCE is required in prod profile");
    }

    private void validateLocalLogin() {
        require(!authProperties.isLocalLoginEnabled(),
                "BFF_AUTH_LOCAL_LOGIN_ENABLED must be false in prod profile");
    }

    private void validateLoginProvider() {
        require(authProperties.getLoginProvider() != AuthProperties.LoginProvider.LOCAL,
                "BFF_AUTH_LOGIN_PROVIDER must not be local in prod profile");
    }

    private void validateBcmUpstream() {
        String baseUrl = proxyProperties.getBaseUrl();
        require(hasText(baseUrl), "BFF_PROXY_BCM_BASE_URL is required in prod profile");
        String host = upstreamHost(baseUrl);
        require(hasText(host), "BFF_PROXY_BCM_BASE_URL must include a valid host in prod profile");
        require(!LOCAL_UPSTREAM_HOSTS.contains(host.toLowerCase(Locale.ROOT)),
                "BFF_PROXY_BCM_BASE_URL must not point to a local host in prod profile");
        require(hasText(proxyProperties.getIbmClientId()),
                "BFF_PROXY_BCM_IBM_CLIENT_ID is required in prod profile");
        require(hasText(proxyProperties.getIbmClientSecret()),
                "BFF_PROXY_BCM_IBM_CLIENT_SECRET is required in prod profile");
        require(!proxyProperties.getTls().isInsecureSkipVerify(),
                "BFF_PROXY_BCM_TLS_INSECURE_SKIP_VERIFY must be false in prod profile");
        require(!proxyProperties.getMtls().isInsecureSkipVerify(),
                "BFF_PROXY_BCM_MTLS_INSECURE_SKIP_VERIFY must be false in prod profile");
        if (proxyProperties.getMtls().isEnabled()) {
            require(hasText(proxyProperties.getMtls().getCertFile()),
                    "BFF_PROXY_BCM_MTLS_CERT_FILE is required when BCM mTLS is enabled in prod profile");
            require(hasText(proxyProperties.getMtls().getKeyFile()),
                    "BFF_PROXY_BCM_MTLS_KEY_FILE is required when BCM mTLS is enabled in prod profile");
        }
    }

    private void validateBcoUpstream() {
        if (!bcoProxyProperties.isEnabled()) {
            return;
        }
        String baseUrl = bcoProxyProperties.getBaseUrl();
        require(hasText(baseUrl), "BFF_PROXY_BCO_BASE_URL is required in prod profile");
        String host = upstreamHost(baseUrl);
        require(hasText(host), "BFF_PROXY_BCO_BASE_URL must include a valid host in prod profile");
        require(!LOCAL_UPSTREAM_HOSTS.contains(host.toLowerCase(Locale.ROOT)),
                "BFF_PROXY_BCO_BASE_URL must not point to a local host in prod profile");
        require(!bcoProxyProperties.getTls().isInsecureSkipVerify(),
                "BFF_PROXY_BCO_TLS_INSECURE_SKIP_VERIFY must be false in prod profile");
    }

    private void validateEntitlementMode() {
        require(!entitlementProperties.getIam().isMockEnabled(),
                "BFF_ENTITLEMENT_IAM_MOCK_ENABLED must be false in prod profile");
    }

    private void validateManagementAccess() {
        if (!managementAccessProperties.isMetricsTokenConfigured()) {
            return;
        }
        require(managementAccessProperties.getMetricsToken().trim().length() >= MIN_MANAGEMENT_TOKEN_LENGTH,
                "BFF_MANAGEMENT_ACCESS_METRICS_TOKEN must be at least "
                        + MIN_MANAGEMENT_TOKEN_LENGTH + " characters when configured in prod profile");
        require(hasText(managementAccessProperties.getMetricsTokenHeader()),
                "BFF_MANAGEMENT_ACCESS_METRICS_TOKEN_HEADER must not be blank when metrics token is configured");
    }

    private void validateRateLimitStore() {
        if (!rateLimitProperties.isEnabled()) {
            return;
        }
        require(rateLimitProperties.getStore() == RateLimitProperties.Store.REDIS,
                "BFF_RATE_LIMIT_STORE must be redis in prod profile when BFF_RATE_LIMIT_ENABLED=true");
        require(rateLimitProperties.isTrustXForwardedFor(),
                "BFF_RATE_LIMIT_TRUST_X_FORWARDED_FOR must be true in prod profile when BFF_RATE_LIMIT_ENABLED=true");
    }

    private void validateSecurityHeaders() {
        SecurityHeadersProperties.Hsts hsts = securityHeadersProperties.getHsts();
        require(hsts.isEnabled(), "BFF_SECURITY_HEADERS_HSTS_ENABLED must be true in prod profile");
        require(hsts.getMaxAgeSeconds() > 0,
                "BFF_SECURITY_HEADERS_HSTS_MAX_AGE_SECONDS must be greater than zero in prod profile");
    }

    private void validateCors() {
        if (!corsProperties.isEnabled()) {
            return;
        }

        require(corsProperties.getMaxAgeSeconds() > 0,
                "BFF_CORS_MAX_AGE_SECONDS must be greater than zero when CORS is enabled in prod profile");
        long configuredOriginCount = corsProperties.getAllowedOrigins().stream()
                .filter(ProductionRuntimeConfigurationValidator::hasText)
                .count();
        require(configuredOriginCount > 0,
                "BFF_CORS_ALLOWED_ORIGINS must not be blank when CORS is enabled in prod profile");

        for (String origin : corsProperties.getAllowedOrigins()) {
            if (!hasText(origin)) {
                continue;
            }
            require(!"*".equals(origin.trim()), "BFF_CORS_ALLOWED_ORIGINS must not contain wildcard origins");
            require(origin.trim().startsWith("https://"),
                    "BFF_CORS_ALLOWED_ORIGINS must contain only https:// origins in prod profile");
            String host = upstreamHost(origin.trim());
            require(hasText(host), "BFF_CORS_ALLOWED_ORIGINS entries must include a valid host in prod profile");
            require(!LOCAL_UPSTREAM_HOSTS.contains(host.toLowerCase(Locale.ROOT)),
                    "BFF_CORS_ALLOWED_ORIGINS must not point to a local host in prod profile");
        }
    }

    private static String upstreamHost(String baseUrl) {
        try {
            URI uri = new URI(baseUrl);
            String host = uri.getHost();
            return host == null ? "" : host;
        } catch (URISyntaxException error) {
            return "";
        }
    }

    private static void require(boolean condition, String message) {
        if (!condition) {
            throw new IllegalStateException(message);
        }
    }

    private static boolean hasText(String value) {
        return value != null && !value.isBlank();
    }
}

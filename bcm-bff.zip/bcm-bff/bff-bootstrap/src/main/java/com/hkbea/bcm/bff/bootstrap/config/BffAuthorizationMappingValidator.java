package com.hkbea.bcm.bff.bootstrap.config;

import com.hkbea.bcm.bff.access.config.AuthorizationPolicyProperties;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.SmartInitializingSingleton;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.method.HandlerMethod;
import org.springframework.web.reactive.result.method.RequestMappingInfo;
import org.springframework.web.reactive.result.method.annotation.RequestMappingHandlerMapping;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.Map;

@Component
public class BffAuthorizationMappingValidator implements SmartInitializingSingleton {
    private static final Logger log = LoggerFactory.getLogger(BffAuthorizationMappingValidator.class);
    private static final String BFF_WEB_PACKAGE = "com.hkbea.bcm.bff.bootstrap.web.";

    private final AuthorizationPolicyProperties authorizationPolicyProperties;
    private final RequestMappingHandlerMapping handlerMapping;

    public BffAuthorizationMappingValidator(
            AuthorizationPolicyProperties authorizationPolicyProperties,
            @Qualifier("requestMappingHandlerMapping") RequestMappingHandlerMapping handlerMapping
    ) {
        this.authorizationPolicyProperties = authorizationPolicyProperties;
        this.handlerMapping = handlerMapping;
    }

    @Override
    public void afterSingletonsInstantiated() {
        validate();
    }

    void validate() {
        if (!authorizationPolicyProperties.isEnabled()) {
            log.info("BCM_AUTHORIZATION_MAPPING_VALIDATION outcome=skipped reason=authorization-disabled");
            return;
        }

        List<String> violations = new ArrayList<>();
        int protectedMappingCount = 0;

        for (Map.Entry<RequestMappingInfo, HandlerMethod> entry : handlerMapping.getHandlerMethods().entrySet()) {
            HandlerMethod handlerMethod = entry.getValue();
            if (!isBffWebHandler(handlerMethod)) {
                continue;
            }

            for (String path : mappingPaths(entry.getKey())) {
                if (!requiresAuthorizationRule(path)) {
                    continue;
                }

                List<RequestMethod> methods = mappingMethods(entry.getKey());
                if (methods.isEmpty()) {
                    violations.add("Protected BFF mapping must define an explicit HTTP method: "
                            + path + " -> " + handlerLabel(handlerMethod));
                    continue;
                }

                for (RequestMethod method : methods) {
                    protectedMappingCount++;
                    validateRule(method.name(), path, handlerMethod, violations);
                }
            }
        }

        if (!violations.isEmpty()) {
            throw new IllegalStateException("BFF authorization mapping validation failed: "
                    + String.join("; ", violations));
        }

        log.info("BCM_AUTHORIZATION_MAPPING_VALIDATION outcome=success protectedMappingCount={}",
                protectedMappingCount);
    }

    private void validateRule(
            String method,
            String path,
            HandlerMethod handlerMethod,
            List<String> violations
    ) {
        authorizationPolicyProperties.resolve(method, path)
                .ifPresentOrElse(rule -> {
                    if (isEmpty(rule.getRequiredRoles())
                            && isEmpty(rule.getRequiredScopes())
                            && isEmpty(rule.getAllowedDeviceOs())) {
                        violations.add("Authorization rule for BFF mapping " + normalizeMethod(method) + " "
                                + normalizePath(path) + " -> " + handlerLabel(handlerMethod)
                                + " must define at least one required role, required scope, or allowed device OS");
                    }
                }, () -> violations.add("Missing authorization rule for BFF mapping "
                        + normalizeMethod(method) + " " + normalizePath(path)
                        + " -> " + handlerLabel(handlerMethod)));
    }

    private static boolean isBffWebHandler(HandlerMethod handlerMethod) {
        return handlerMethod.getBeanType().getName().startsWith(BFF_WEB_PACKAGE);
    }

    private static List<String> mappingPaths(RequestMappingInfo mappingInfo) {
        return mappingInfo.getPatternsCondition()
                .getPatterns()
                .stream()
                .map(pattern -> normalizePath(pattern.getPatternString()))
                .toList();
    }

    private static List<RequestMethod> mappingMethods(RequestMappingInfo mappingInfo) {
        return mappingInfo.getMethodsCondition()
                .getMethods()
                .stream()
                .toList();
    }

    private static boolean requiresAuthorizationRule(String path) {
        if (!hasText(path)) {
            return false;
        }
        if (path.equals("/") || path.equals("/health") || path.equals("/readiness") || path.equals("/liveness")) {
            return false;
        }
        if (path.equals("/api/login") || path.equals("/digx/j_security_check")) {
            return false;
        }
        if (path.equals("/actuator") || path.startsWith("/actuator/")) {
            return false;
        }
        if (path.equals("/bcm/**")
                || path.equals("/bff/**")
                || path.equals("/corporate/**")
                || path.equals("/dsp/corporate/**")) {
            return false;
        }
        return !path.startsWith("/auth/");
    }

    private static String handlerLabel(HandlerMethod handlerMethod) {
        return handlerMethod.getBeanType().getSimpleName() + "#" + handlerMethod.getMethod().getName();
    }

    private static String normalizeMethod(String method) {
        return method == null ? "" : method.trim().toUpperCase(Locale.ROOT);
    }

    private static String normalizePath(String path) {
        if (path == null || path.isBlank()) {
            return "";
        }
        String normalized = path.trim();
        if (normalized.length() > 1 && normalized.endsWith("/")) {
            return normalized.substring(0, normalized.length() - 1);
        }
        return normalized;
    }

    private static boolean isEmpty(Iterable<String> values) {
        if (values == null) {
            return true;
        }
        for (String value : values) {
            if (hasText(value)) {
                return false;
            }
        }
        return true;
    }

    private static boolean hasText(String value) {
        return value != null && !value.isBlank();
    }
}

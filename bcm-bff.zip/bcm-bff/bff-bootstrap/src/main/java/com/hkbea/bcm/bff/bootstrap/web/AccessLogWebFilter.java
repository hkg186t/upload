package com.hkbea.bcm.bff.bootstrap.web;

import com.hkbea.bcm.bff.shared.api.BffException;
import com.hkbea.bcm.bff.shared.http.HeaderConstants;
import com.hkbea.bcm.bff.shared.logging.DebugLogSanitizer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.core.Ordered;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.HttpStatusCode;
import org.springframework.stereotype.Component;
import org.springframework.web.server.ServerWebExchange;
import org.springframework.web.server.WebFilter;
import org.springframework.web.server.WebFilterChain;
import reactor.core.publisher.Mono;
import reactor.core.publisher.SignalType;

import java.net.InetSocketAddress;
import java.time.Clock;
import java.util.Locale;
import java.util.concurrent.atomic.AtomicReference;

@Component
public class AccessLogWebFilter implements WebFilter, Ordered {
    private static final Logger log = LoggerFactory.getLogger(AccessLogWebFilter.class);
    private static final String SLB_HEALTH_CHECK_USER_AGENT = "SLBHealthCheck";
    private static final String CURL_USER_AGENT_PREFIX = "curl/";

    private final Clock clock;

    public AccessLogWebFilter() {
        this(Clock.systemUTC());
    }

    AccessLogWebFilter(Clock clock) {
        this.clock = clock;
    }

    @Override
    public Mono<Void> filter(ServerWebExchange exchange, WebFilterChain chain) {
        if (shouldSuppressProbeLog(exchange)) {
            return chain.filter(exchange);
        }

        long startMillis = clock.millis();
        AtomicReference<Throwable> errorRef = new AtomicReference<>();
        logRequest(exchange);
        return chain.filter(exchange)
                .doOnError(errorRef::set)
                .doFinally(signalType -> logAccess(exchange, startMillis, signalType, errorRef.get()));
    }

    @Override
    public int getOrder() {
        return Ordered.HIGHEST_PRECEDENCE + 5;
    }

    private void logAccess(
            ServerWebExchange exchange,
            long startMillis,
            SignalType signalType,
            Throwable error
    ) {
        long durationMillis = Math.max(0, clock.millis() - startMillis);
        HttpStatusCode statusCode = exchange.getResponse().getStatusCode();
        int status = statusCode != null ? statusCode.value() : fallbackStatus(error, signalType);
        String outcome = outcome(status, signalType);
        String errorCode = errorCode(status, error, signalType);

        log.info(
                "BCM_HTTP_ACCESS traceId={} method={} path={} status={} outcome={} errorCode={} durationMs={} "
                        + "remoteAddress={} host={} forwardedFor={} userAgent={}",
                traceId(exchange),
                exchange.getRequest().getMethod(),
                exchange.getRequest().getPath().pathWithinApplication().value(),
                status,
                outcome,
                errorCode,
                durationMillis,
                remoteAddress(exchange),
                header(exchange, HttpHeaders.HOST),
                header(exchange, "X-Forwarded-For"),
                header(exchange, HttpHeaders.USER_AGENT)
        );
    }

    private static void logRequest(ServerWebExchange exchange) {
        if (!log.isDebugEnabled()) {
            return;
        }

        log.debug(
                "BCM_HTTP_REQUEST traceId={} method={} path={} queryPresent={} headers={}",
                traceId(exchange),
                exchange.getRequest().getMethod(),
                exchange.getRequest().getPath().pathWithinApplication().value(),
                exchange.getRequest().getURI().getRawQuery() != null,
                DebugLogSanitizer.headers(exchange.getRequest().getHeaders())
        );
    }

    private static int fallbackStatus(Throwable error, SignalType signalType) {
        if (error instanceof BffException bffException) {
            return bffException.httpStatus();
        }
        if (signalType == SignalType.CANCEL) {
            return 499;
        }
        return HttpStatus.INTERNAL_SERVER_ERROR.value();
    }

    private static String outcome(int status, SignalType signalType) {
        if (signalType == SignalType.CANCEL) {
            return "cancelled";
        }
        if (status >= 500) {
            return "error";
        }
        if (status >= 400) {
            return "rejected";
        }
        return "success";
    }

    private static String errorCode(int status, Throwable error, SignalType signalType) {
        if (error instanceof BffException bffException) {
            return bffException.errorCode().code();
        }
        if (signalType == SignalType.CANCEL) {
            return "499";
        }
        if (status >= 400) {
            return Integer.toString(status);
        }
        return "none";
    }

    private static String traceId(ServerWebExchange exchange) {
        String traceId = firstNonBlank(
                exchange.getResponse().getHeaders().getFirst(HeaderConstants.X_REQUEST_ID),
                exchange.getRequest().getHeaders().getFirst(HeaderConstants.X_REQUEST_ID),
                exchange.getRequest().getHeaders().getFirst(HeaderConstants.X_CORRELATION_ID)
        );
        return traceId == null ? "none" : traceId;
    }

    private static String remoteAddress(ServerWebExchange exchange) {
        InetSocketAddress remoteAddress = exchange.getRequest().getRemoteAddress();
        if (remoteAddress == null || remoteAddress.getAddress() == null) {
            return "none";
        }
        return sanitize(remoteAddress.getAddress().getHostAddress());
    }

    private static String header(ServerWebExchange exchange, String name) {
        return sanitize(exchange.getRequest().getHeaders().getFirst(name));
    }

    private static boolean isSlbHealthCheck(ServerWebExchange exchange) {
        return SLB_HEALTH_CHECK_USER_AGENT.equals(exchange.getRequest().getHeaders().getFirst(HttpHeaders.USER_AGENT));
    }

    private static boolean shouldSuppressProbeLog(ServerWebExchange exchange) {
        return isSlbHealthCheck(exchange) || isLocalCurlHealthProbe(exchange);
    }

    private static boolean isLocalCurlHealthProbe(ServerWebExchange exchange) {
        String userAgent = exchange.getRequest().getHeaders().getFirst(HttpHeaders.USER_AGENT);
        if (userAgent == null || !userAgent.startsWith(CURL_USER_AGENT_PREFIX)) {
            return false;
        }
        if (!isHealthPath(exchange)) {
            return false;
        }
        return isLoopbackRemoteAddress(exchange) || isLoopbackHost(exchange);
    }

    private static boolean isHealthPath(ServerWebExchange exchange) {
        String path = exchange.getRequest().getPath().pathWithinApplication().value();
        return "/health".equals(path) || path.startsWith("/actuator/health");
    }

    private static boolean isLoopbackRemoteAddress(ServerWebExchange exchange) {
        InetSocketAddress remoteAddress = exchange.getRequest().getRemoteAddress();
        return remoteAddress != null
                && remoteAddress.getAddress() != null
                && remoteAddress.getAddress().isLoopbackAddress();
    }

    private static boolean isLoopbackHost(ServerWebExchange exchange) {
        String host = exchange.getRequest().getHeaders().getFirst(HttpHeaders.HOST);
        if (host == null || host.isBlank()) {
            return false;
        }
        String normalizedHost = host.toLowerCase(Locale.ROOT);
        return "127.0.0.1".equals(normalizedHost)
                || normalizedHost.startsWith("127.0.0.1:")
                || "localhost".equals(normalizedHost)
                || normalizedHost.startsWith("localhost:")
                || "::1".equals(normalizedHost)
                || "[::1]".equals(normalizedHost)
                || normalizedHost.startsWith("[::1]:");
    }

    private static String sanitize(String value) {
        if (value == null || value.isBlank()) {
            return "none";
        }
        String sanitized = value.replace('\r', '_').replace('\n', '_').trim();
        return sanitized.length() > 256 ? sanitized.substring(0, 256) + "...[truncated]" : sanitized;
    }

    private static String firstNonBlank(String... values) {
        for (String value : values) {
            if (value != null && !value.isBlank()) {
                return value.toLowerCase(Locale.ROOT).equals("null") ? null : value;
            }
        }
        return null;
    }
}

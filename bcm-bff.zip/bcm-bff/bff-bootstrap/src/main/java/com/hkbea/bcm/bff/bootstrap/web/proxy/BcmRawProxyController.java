package com.hkbea.bcm.bff.bootstrap.web.proxy;

import com.hkbea.bcm.bff.bootstrap.web.DebugRequestLogger;
import com.hkbea.bcm.bff.proxy.config.BcmProxyProperties;
import com.hkbea.bcm.bff.proxy.model.RawProxyRequestContext;
import com.hkbea.bcm.bff.proxy.model.RawProxyResult;
import com.hkbea.bcm.bff.proxy.service.BcmRawProxyService;
import com.hkbea.bcm.bff.shared.http.HeaderConstants;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.core.io.buffer.DataBufferUtils;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.server.ServerWebExchange;
import reactor.core.publisher.Mono;

@RestController
public class BcmRawProxyController {
    private static final Logger log = LoggerFactory.getLogger(BcmRawProxyController.class);

    private final BcmRawProxyService proxyService;
    private final BcmProxyProperties properties;

    public BcmRawProxyController(BcmRawProxyService proxyService, BcmProxyProperties properties) {
        this.proxyService = proxyService;
        this.properties = properties;
    }

    @RequestMapping(method = {
            RequestMethod.GET,
            RequestMethod.POST,
            RequestMethod.PUT,
            RequestMethod.PATCH,
            RequestMethod.DELETE
    }, path = "/dsp/corporate/**")
    Mono<ResponseEntity<byte[]>> proxy(ServerWebExchange exchange) {
        if (!properties.isDspLegacyPassthroughPath(exchange.getRequest().getPath().pathWithinApplication().value())) {
            return Mono.just(ResponseEntity.notFound().build());
        }
        return readBody(exchange)
                .doOnNext(body -> DebugRequestLogger.logBody(log, exchange, body))
                .flatMap(body -> proxyService.proxy(body, proxyContext(exchange)))
                .map(this::toResponse);
    }

    private ResponseEntity<byte[]> toResponse(RawProxyResult result) {
        return ResponseEntity
                .status(result.statusCode())
                .headers(result.headers())
                .body(result.body());
    }

    private RawProxyRequestContext proxyContext(ServerWebExchange exchange) {
        return new RawProxyRequestContext(
                traceId(exchange),
                exchange.getRequest().getMethod().name(),
                exchange.getRequest().getPath().pathWithinApplication().value(),
                exchange.getRequest().getURI().getRawQuery(),
                exchange.getRequest().getHeaders(),
                null
        );
    }

    private static Mono<byte[]> readBody(ServerWebExchange exchange) {
        return DataBufferUtils.join(exchange.getRequest().getBody())
                .map(buffer -> {
                    byte[] bytes = new byte[buffer.readableByteCount()];
                    buffer.read(bytes);
                    DataBufferUtils.release(buffer);
                    return bytes;
                })
                .defaultIfEmpty(new byte[0]);
    }

    private static String traceId(ServerWebExchange exchange) {
        return exchange.getResponse().getHeaders().getFirst(HeaderConstants.X_REQUEST_ID);
    }
}

package com.hkbea.bcm.bff.bootstrap.config;

import org.springframework.boot.context.properties.ConfigurationProperties;

import java.util.ArrayList;
import java.util.List;

@ConfigurationProperties(prefix = "bff.cors")
public class CorsProperties {
    private boolean enabled;
    private List<String> allowedOrigins = List.of();
    private List<String> allowedMethods = List.of("GET", "POST", "OPTIONS");
    private List<String> allowedHeaders = List.of(
            "Authorization",
            "Content-Type",
            "X-Request-Id",
            "X-Correlation-Id",
            "X-Device-Id",
            "X-Device-Os",
            "Locale"
    );
    private List<String> exposedHeaders = List.of(
            "X-Request-Id",
            "X-Correlation-Id",
            "Retry-After",
            "X-RateLimit-Limit",
            "X-RateLimit-Remaining",
            "X-RateLimit-Reset"
    );
    private long maxAgeSeconds = 3600;

    public boolean isEnabled() {
        return enabled;
    }

    public void setEnabled(boolean enabled) {
        this.enabled = enabled;
    }

    public List<String> getAllowedOrigins() {
        return allowedOrigins;
    }

    public void setAllowedOrigins(List<String> allowedOrigins) {
        this.allowedOrigins = copyOrEmpty(allowedOrigins);
    }

    public List<String> getAllowedMethods() {
        return allowedMethods;
    }

    public void setAllowedMethods(List<String> allowedMethods) {
        this.allowedMethods = copyOrEmpty(allowedMethods);
    }

    public List<String> getAllowedHeaders() {
        return allowedHeaders;
    }

    public void setAllowedHeaders(List<String> allowedHeaders) {
        this.allowedHeaders = copyOrEmpty(allowedHeaders);
    }

    public List<String> getExposedHeaders() {
        return exposedHeaders;
    }

    public void setExposedHeaders(List<String> exposedHeaders) {
        this.exposedHeaders = copyOrEmpty(exposedHeaders);
    }

    public long getMaxAgeSeconds() {
        return maxAgeSeconds;
    }

    public void setMaxAgeSeconds(long maxAgeSeconds) {
        this.maxAgeSeconds = maxAgeSeconds;
    }

    private static List<String> copyOrEmpty(List<String> values) {
        if (values == null) {
            return List.of();
        }
        return new ArrayList<>(values);
    }
}

package com.hkbea.bcm.bff.shared.logging;

import java.nio.charset.StandardCharsets;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.regex.Pattern;
import java.util.stream.Collectors;

public final class DebugLogSanitizer {
    public static final int DEFAULT_MAX_BODY_CHARS = 8192;

    private static final String REDACTED = "[REDACTED]";
    private static final Pattern SENSITIVE_JSON_STRING_FIELD = Pattern.compile(
            "(?i)(\"[^\"]*(?:authorization|auth.?data|client.?id|cookie|password|secret|session|token|otp|pin|account|card|customer|device.?id|user.?id|username)[^\"]*\"\\s*:\\s*)\"(?:\\\\.|[^\"])*\""
    );
    private static final Pattern SENSITIVE_FORM_FIELD = Pattern.compile(
            "(?i)(^|[&\\s])([^=&\\s]*(?:authorization|auth[-_.]?data|client[-_.]?id|cookie|password|secret|session|token|otp|pin|account|card|customer|device[-_.]?id|user[-_.]?id|username|j_username)[^=&\\s]*=)([^&\\s]*)"
    );
    private static final Pattern BEARER_TOKEN = Pattern.compile("(?i)Bearer\\s+[^\\s\"',}]+");

    private DebugLogSanitizer() {
    }

    public static String headers(Map<String, ? extends List<String>> headers) {
        if (headers == null || headers.isEmpty()) {
            return "{}";
        }

        return headers.entrySet().stream()
                .map(entry -> entry.getKey() + "=" + headerValues(entry.getKey(), entry.getValue()))
                .collect(Collectors.joining(", ", "{", "}"));
    }

    public static String body(Object body) {
        return body == null ? "<empty>" : body(body.toString());
    }

    public static String body(byte[] body) {
        if (body == null || body.length == 0) {
            return "<empty>";
        }
        return body(new String(body, StandardCharsets.UTF_8));
    }

    public static String body(String body) {
        if (body == null || body.isBlank()) {
            return "<empty>";
        }
        String sanitized = redactSensitiveBodyValues(body);
        if (sanitized.length() <= DEFAULT_MAX_BODY_CHARS) {
            return sanitized;
        }
        return sanitized.substring(0, DEFAULT_MAX_BODY_CHARS)
                + "...<truncated chars=" + (sanitized.length() - DEFAULT_MAX_BODY_CHARS) + ">";
    }

    private static List<String> headerValues(String headerName, List<String> values) {
        if (values == null || values.isEmpty()) {
            return List.of();
        }
        if (isSensitiveHeader(headerName)) {
            return List.of(REDACTED);
        }
        return values.stream()
                .map(value -> value == null ? "" : redactBearerToken(value))
                .toList();
    }

    private static boolean isSensitiveHeader(String headerName) {
        if (headerName == null) {
            return false;
        }
        String normalized = headerName.trim().toLowerCase(Locale.ROOT);
        return normalized.contains("authorization")
                || normalized.contains("auth-data")
                || normalized.contains("auth_data")
                || normalized.equals("x-ibm-client-id")
                || normalized.equals("x-user-id")
                || normalized.equals("x-device-id")
                || normalized.contains("client-id")
                || normalized.contains("customer-id")
                || normalized.contains("device-id")
                || normalized.contains("user-id")
                || normalized.contains("user-context")
                || normalized.contains("cookie")
                || normalized.contains("password")
                || normalized.contains("secret")
                || normalized.contains("session")
                || normalized.contains("token")
                || normalized.contains("otp")
                || normalized.contains("pin");
    }

    private static String redactSensitiveBodyValues(String value) {
        String sanitized = SENSITIVE_JSON_STRING_FIELD.matcher(value).replaceAll("$1\"" + REDACTED + "\"");
        sanitized = SENSITIVE_FORM_FIELD.matcher(sanitized).replaceAll("$1$2" + REDACTED);
        return redactBearerToken(sanitized);
    }

    private static String redactBearerToken(String value) {
        return BEARER_TOKEN.matcher(value).replaceAll("Bearer " + REDACTED);
    }
}

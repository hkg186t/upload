package com.hkbea.bcm.bff.shared.session;

public enum SessionState {
    ACTIVE,
    REFRESH_REQUIRED,
    LOGGED_OUT,
    REPLACED_BY_NEW_LOGIN,
    UPSTREAM_INVALID,
    EXPIRED,
    LOCKED
}

package com.hkbea.bcm.bff.shared.api;

public record ErrorResponse(
        String status,
        String code,
        String message,
        String traceId
) {
    public static ErrorResponse of(ErrorCode errorCode, String traceId) {
        return new ErrorResponse(errorCode.code(), errorCode.code(), errorCode.defaultMessage(), traceId);
    }

    public static ErrorResponse of(ErrorCode errorCode, String message, String traceId) {
        return new ErrorResponse(errorCode.code(), errorCode.code(), message, traceId);
    }
}

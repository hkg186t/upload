package com.hkbea.bcm.bff.shared.api;

public enum ErrorCode {
    SUCCESS("0000", "success"),
    BAD_REQUEST("400", "Invalid request"),
    UNAUTHORIZED("401", "Invalid or missing Bearer Token"),
    SESSION_EXPIRED("419", "Session Expired"),
    FORBIDDEN("403", "Forbidden"),
    NOT_FOUND("404", "Resource not found"),
    PAYLOAD_TOO_LARGE("413", "Request Entity Too Large"),
    TOO_MANY_REQUESTS("429", "Too Many Requests"),
    BAD_GATEWAY("502", "Bad Gateway"),
    UPSTREAM_TIMEOUT("504", "Upstream Timeout"),
    INTERNAL_ERROR("500", "Internal Server Error");

    private final String code;
    private final String defaultMessage;

    ErrorCode(String code, String defaultMessage) {
        this.code = code;
        this.defaultMessage = defaultMessage;
    }

    public String code() {
        return code;
    }

    public String defaultMessage() {
        return defaultMessage;
    }
}

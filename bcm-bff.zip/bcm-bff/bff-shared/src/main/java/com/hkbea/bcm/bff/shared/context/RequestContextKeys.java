package com.hkbea.bcm.bff.shared.context;

public final class RequestContextKeys {
    public static final String TRACE_ID = "traceId";
    public static final String SESSION_RECORD = "sessionRecord";

    private RequestContextKeys() {
    }
}

package com.hkbea.bcm.bff.shared.http;

public final class HeaderConstants {
    public static final String AUTHORIZATION = "Authorization";
    public static final String X_REQUEST_ID = "X-Request-Id";
    public static final String X_CORRELATION_ID = "X-Correlation-Id";
    public static final String X_DEVICE_ID = "X-Device-Id";
    public static final String X_DEVICE_OS = "X-Device-Os";
    public static final String LOCALE = "Locale";

    private HeaderConstants() {
    }
}

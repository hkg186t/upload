package com.hkbea.bcm.bff.shared.api;

public class BffException extends RuntimeException {
    private final ErrorCode errorCode;
    private final int httpStatus;

    public BffException(ErrorCode errorCode) {
        this(errorCode, errorCode.defaultMessage());
    }

    public BffException(ErrorCode errorCode, String message) {
        super(message);
        this.errorCode = errorCode;
        this.httpStatus = Integer.parseInt(errorCode.code());
    }

    public ErrorCode errorCode() {
        return errorCode;
    }

    public int httpStatus() {
        return httpStatus;
    }
}

package com.hkbea.bcm.bff.shared.logging;

import org.junit.jupiter.api.Test;

import java.util.List;
import java.util.Map;

import static org.assertj.core.api.Assertions.assertThat;

class DebugLogSanitizerTest {
    @Test
    void headersRedactLegacyAuthenticationData() {
        String sanitized = DebugLogSanitizer.headers(Map.of(
                "Login-Auth-Data", List.of("encrypted-auth-data"),
                "token", List.of("legacy-token"),
                "X-Device-Id", List.of("device-1"),
                "User-Agent", List.of("Android_Ant_Client")
        ));

        assertThat(sanitized)
                .contains("Login-Auth-Data=[[REDACTED]]")
                .contains("token=[[REDACTED]]")
                .contains("X-Device-Id=[[REDACTED]]")
                .contains("User-Agent=[Android_Ant_Client]")
                .doesNotContain("encrypted-auth-data")
                .doesNotContain("legacy-token")
                .doesNotContain("device-1");
    }

    @Test
    void bodyRedactsFormCredentialsAndBankIdentifiers() {
        String sanitized = DebugLogSanitizer.body(
                "j_username=KYLEWENG%40015521104095930"
                        + "&j_password=encrypted-password"
                        + "&accountId=01516868006898"
                        + "&deviceId=device-1"
                        + "&otp=123456");

        assertThat(sanitized)
                .contains("j_username=[REDACTED]")
                .contains("j_password=[REDACTED]")
                .contains("accountId=[REDACTED]")
                .contains("deviceId=[REDACTED]")
                .contains("otp=[REDACTED]")
                .doesNotContain("KYLEWENG")
                .doesNotContain("encrypted-password")
                .doesNotContain("01516868006898")
                .doesNotContain("device-1")
                .doesNotContain("123456");
    }

    @Test
    void bodyRedactsJsonAuthenticationAndAccountFields() {
        String sanitized = DebugLogSanitizer.body(
                "{\"Login-Auth-Data\":\"encrypted-auth-data\","
                        + "\"cardNumber\":\"4111111111111111\","
                        + "\"customerId\":\"015521104095930\","
                        + "\"message\":\"ok\"}");

        assertThat(sanitized)
                .contains("\"Login-Auth-Data\":\"[REDACTED]\"")
                .contains("\"cardNumber\":\"[REDACTED]\"")
                .contains("\"customerId\":\"[REDACTED]\"")
                .contains("\"message\":\"ok\"")
                .doesNotContain("encrypted-auth-data")
                .doesNotContain("4111111111111111")
                .doesNotContain("015521104095930");
    }
}

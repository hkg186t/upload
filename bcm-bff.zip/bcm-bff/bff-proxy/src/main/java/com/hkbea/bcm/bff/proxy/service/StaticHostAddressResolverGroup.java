package com.hkbea.bcm.bff.proxy.service;

import io.netty.resolver.AddressResolver;
import io.netty.resolver.AddressResolverGroup;
import io.netty.resolver.DefaultNameResolver;
import io.netty.resolver.InetSocketAddressResolver;
import io.netty.resolver.NameResolver;
import io.netty.util.concurrent.EventExecutor;
import io.netty.util.concurrent.Future;
import io.netty.util.concurrent.Promise;

import java.net.InetAddress;
import java.net.InetSocketAddress;
import java.net.UnknownHostException;
import java.util.List;
import java.util.Locale;

final class StaticHostAddressResolverGroup extends AddressResolverGroup<InetSocketAddress> {
    private final String host;
    private final InetAddress mappedAddress;

    StaticHostAddressResolverGroup(String host, String fallbackIp) {
        if (host == null || host.isBlank()) {
            throw new IllegalArgumentException("Static resolver host is required");
        }
        if (fallbackIp == null || fallbackIp.isBlank()) {
            throw new IllegalArgumentException("Static resolver fallback IP is required");
        }
        this.host = normalize(host);
        this.mappedAddress = mappedAddress(host.trim(), fallbackIp.trim());
    }

    @Override
    protected AddressResolver<InetSocketAddress> newResolver(EventExecutor executor) {
        return new InetSocketAddressResolver(executor, new StaticHostNameResolver(executor));
    }

    private boolean matches(String requestedHost) {
        return normalize(requestedHost).equals(host);
    }

    private static InetAddress mappedAddress(String host, String fallbackIp) {
        try {
            InetAddress ipAddress = InetAddress.getByName(fallbackIp);
            return InetAddress.getByAddress(host, ipAddress.getAddress());
        } catch (UnknownHostException error) {
            throw new IllegalArgumentException("Proxy fallback IP is invalid: " + fallbackIp, error);
        }
    }

    private static String normalize(String value) {
        if (value == null) {
            return "";
        }
        String normalized = value.trim().toLowerCase(Locale.ROOT);
        return normalized.endsWith(".") ? normalized.substring(0, normalized.length() - 1) : normalized;
    }

    private final class StaticHostNameResolver implements NameResolver<InetAddress> {
        private final EventExecutor executor;
        private final NameResolver<InetAddress> delegate;

        private StaticHostNameResolver(EventExecutor executor) {
            this.executor = executor;
            this.delegate = new DefaultNameResolver(executor);
        }

        @Override
        public Future<InetAddress> resolve(String inetHost) {
            return resolve(inetHost, delegatePromise());
        }

        @Override
        public Future<InetAddress> resolve(String inetHost, Promise<InetAddress> promise) {
            if (matches(inetHost)) {
                return promise.setSuccess(mappedAddress);
            }
            return delegate.resolve(inetHost, promise);
        }

        @Override
        public Future<List<InetAddress>> resolveAll(String inetHost) {
            return resolveAll(inetHost, delegateListPromise());
        }

        @Override
        public Future<List<InetAddress>> resolveAll(String inetHost, Promise<List<InetAddress>> promise) {
            if (matches(inetHost)) {
                return promise.setSuccess(List.of(mappedAddress));
            }
            return delegate.resolveAll(inetHost, promise);
        }

        @Override
        public void close() {
            delegate.close();
        }

        private Promise<InetAddress> delegatePromise() {
            return executor.newPromise();
        }

        private Promise<List<InetAddress>> delegateListPromise() {
            return executor.newPromise();
        }
    }
}

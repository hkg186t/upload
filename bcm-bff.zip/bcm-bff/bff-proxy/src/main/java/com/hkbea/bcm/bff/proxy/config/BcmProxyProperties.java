package com.hkbea.bcm.bff.proxy.config;

import com.hkbea.bcm.bff.shared.api.BffException;
import com.hkbea.bcm.bff.shared.api.ErrorCode;
import com.hkbea.bcm.bff.proxy.model.UpstreamSystem;
import org.springframework.boot.context.properties.ConfigurationProperties;

import java.util.LinkedHashMap;
import java.util.Locale;
import java.util.Map;

@ConfigurationProperties(prefix = "bff.proxy.bcm")
public class BcmProxyProperties {
    private static final long DEFAULT_RESPONSE_TIMEOUT_MILLIS = 30000;
    private static final int DEFAULT_RETRY_MAX_ATTEMPTS = 1;
    private static final long DEFAULT_RETRY_BACKOFF_MILLIS = 100;
    private static final int DEFAULT_BULKHEAD_MAX_CONCURRENT_REQUESTS = 200;
    private static final boolean DEFAULT_CIRCUIT_BREAKER_ENABLED = true;
    private static final int DEFAULT_CIRCUIT_BREAKER_FAILURE_THRESHOLD = 5;
    private static final long DEFAULT_CIRCUIT_BREAKER_OPEN_MILLIS = 30000;

    private String baseUrl = "http://127.0.0.1:19090";
    private String fallbackIp = "";
    private String userProfilePath = "/corporate/v1/approval/center/user/userProfile";
    private String ibmClientId = "";
    private String ibmClientSecret = "";
    private boolean legacyPassthroughEnabled = true;
    private String legacyPassthroughPathPrefix = "/corporate/";
    private String dspLegacyPassthroughPathPrefix = "/dsp/corporate/";
    private String dspLegacyPassthroughUpstreamPathPrefix = "/corporate/";
    private long responseTimeoutMillis = DEFAULT_RESPONSE_TIMEOUT_MILLIS;
    private Map<String, Route> routes = defaultRoutes();
    private ProxyTlsProperties tls = new ProxyTlsProperties();
    private Mtls mtls = new Mtls();
    private ProxyHealthCheckProperties healthCheck = new ProxyHealthCheckProperties();

    public String resolveRouteId(String publicMethod, String publicPath) {
        String requestedMethod = validateHttpMethod("public-request", defaultText(publicMethod, ""));
        String requestedPath = normalizePath(publicPath);

        Map<String, Route> configuredRoutes = routes == null ? defaultRoutes() : routes;
        for (Map.Entry<String, Route> entry : configuredRoutes.entrySet()) {
            Route route = resolveRoute(entry.getKey());
            String routePublicMethod = validateHttpMethod(entry.getKey(),
                    defaultText(route.getPublicMethod(), route.getMethod()));
            String routePublicPath = normalizePath(defaultText(route.getPublicPath(), defaultPublicPath(entry.getKey())));

            if (requestedMethod.equals(routePublicMethod) && requestedPath.equals(routePublicPath)) {
                return entry.getKey();
            }
        }

        if (legacyPassthroughEnabled && startsWithNormalized(requestedPath, legacyPassthroughPathPrefix)) {
            return Route.LEGACY_PASSTHROUGH_ROUTE_ID;
        }
        if (legacyPassthroughEnabled && startsWithNormalized(requestedPath, dspLegacyPassthroughPathPrefix)) {
            return Route.DSP_LEGACY_PASSTHROUGH_ROUTE_ID;
        }

        throw new BffException(ErrorCode.BAD_REQUEST, "Unknown BCM proxy public route: "
                + requestedMethod + " " + requestedPath);
    }

    public Route resolveRoute(String routeId) {
        if (Route.LEGACY_PASSTHROUGH_ROUTE_ID.equals(routeId)) {
            return legacyPassthroughRoute(legacyPassthroughPathPrefix, legacyPassthroughPathPrefix);
        }
        if (Route.DSP_LEGACY_PASSTHROUGH_ROUTE_ID.equals(routeId)) {
            return legacyPassthroughRoute(dspLegacyPassthroughPathPrefix, dspLegacyPassthroughUpstreamPathPrefix);
        }

        Map<String, Route> configuredRoutes = routes == null ? defaultRoutes() : routes;
        Route route = configuredRoutes.get(routeId);
        if (route == null) {
            throw new BffException(ErrorCode.BAD_REQUEST, "Unknown BCM proxy route: " + routeId);
        }

        String upstreamPath = defaultText(route.getUpstreamPath(), defaultUpstreamPath(routeId));
        if (upstreamPath == null || upstreamPath.isBlank()) {
            throw new BffException(ErrorCode.BAD_REQUEST, "BCM proxy route upstreamPath is required: " + routeId);
        }

        Route resolved = new Route();
        resolved.setPublicMethod(defaultText(route.getPublicMethod(), route.getMethod()));
        resolved.setPublicPath(defaultText(route.getPublicPath(), defaultPublicPath(routeId)));
        resolved.setMethod(validateHttpMethod(routeId, defaultText(route.getMethod(), "POST")));
        resolved.setUpstreamPath(upstreamPath);
        resolved.setUpstreamSystem(route.getUpstreamSystem());
        resolved.setResponseTimeoutMillis(route.getResponseTimeoutMillis() > 0
                ? route.getResponseTimeoutMillis()
                : defaultTimeoutMillis());
        resolved.setHtmlResponseMeansSessionExpired(route.isHtmlResponseMeansSessionExpired());
        resolved.setRetryMaxAttempts(route.getRetryMaxAttempts() > 0
                ? route.getRetryMaxAttempts()
                : DEFAULT_RETRY_MAX_ATTEMPTS);
        resolved.setRetryBackoffMillis(route.getRetryBackoffMillis() > 0
                ? route.getRetryBackoffMillis()
                : DEFAULT_RETRY_BACKOFF_MILLIS);
        resolved.setBulkheadMaxConcurrentRequests(route.getBulkheadMaxConcurrentRequests() > 0
                ? route.getBulkheadMaxConcurrentRequests()
                : DEFAULT_BULKHEAD_MAX_CONCURRENT_REQUESTS);
        resolved.setCircuitBreakerEnabled(route.isCircuitBreakerEnabled());
        resolved.setCircuitBreakerFailureThreshold(route.getCircuitBreakerFailureThreshold() > 0
                ? route.getCircuitBreakerFailureThreshold()
                : DEFAULT_CIRCUIT_BREAKER_FAILURE_THRESHOLD);
        resolved.setCircuitBreakerOpenMillis(route.getCircuitBreakerOpenMillis() > 0
                ? route.getCircuitBreakerOpenMillis()
                : DEFAULT_CIRCUIT_BREAKER_OPEN_MILLIS);
        resolved.setLegacyPassthrough(route.isLegacyPassthrough());
        return resolved;
    }

    public String getBaseUrl() {
        return baseUrl;
    }

    public void setBaseUrl(String baseUrl) {
        this.baseUrl = baseUrl;
    }

    public String getFallbackIp() {
        return fallbackIp;
    }

    public void setFallbackIp(String fallbackIp) {
        this.fallbackIp = fallbackIp;
    }

    public String getUserProfilePath() {
        return userProfilePath;
    }

    public void setUserProfilePath(String userProfilePath) {
        this.userProfilePath = userProfilePath;
    }

    public String getIbmClientId() {
        return ibmClientId;
    }

    public void setIbmClientId(String ibmClientId) {
        this.ibmClientId = ibmClientId;
    }

    public String getIbmClientSecret() {
        return ibmClientSecret;
    }

    public void setIbmClientSecret(String ibmClientSecret) {
        this.ibmClientSecret = ibmClientSecret;
    }

    public boolean isLegacyPassthroughEnabled() {
        return legacyPassthroughEnabled;
    }

    public void setLegacyPassthroughEnabled(boolean legacyPassthroughEnabled) {
        this.legacyPassthroughEnabled = legacyPassthroughEnabled;
    }

    public String getLegacyPassthroughPathPrefix() {
        return legacyPassthroughPathPrefix;
    }

    public void setLegacyPassthroughPathPrefix(String legacyPassthroughPathPrefix) {
        this.legacyPassthroughPathPrefix = legacyPassthroughPathPrefix;
    }

    public String getDspLegacyPassthroughPathPrefix() {
        return dspLegacyPassthroughPathPrefix;
    }

    public void setDspLegacyPassthroughPathPrefix(String dspLegacyPassthroughPathPrefix) {
        this.dspLegacyPassthroughPathPrefix = dspLegacyPassthroughPathPrefix;
    }

    public String getDspLegacyPassthroughUpstreamPathPrefix() {
        return dspLegacyPassthroughUpstreamPathPrefix;
    }

    public void setDspLegacyPassthroughUpstreamPathPrefix(String dspLegacyPassthroughUpstreamPathPrefix) {
        this.dspLegacyPassthroughUpstreamPathPrefix = dspLegacyPassthroughUpstreamPathPrefix;
    }

    public boolean isDspLegacyPassthroughPath(String path) {
        return legacyPassthroughEnabled && startsWithNormalized(path, dspLegacyPassthroughPathPrefix);
    }

    public long getResponseTimeoutMillis() {
        return responseTimeoutMillis;
    }

    public void setResponseTimeoutMillis(long responseTimeoutMillis) {
        this.responseTimeoutMillis = responseTimeoutMillis;
    }

    public Map<String, Route> getRoutes() {
        return routes;
    }

    public void setRoutes(Map<String, Route> routes) {
        this.routes = routes;
    }

    public Mtls getMtls() {
        return mtls;
    }

    public ProxyTlsProperties getTls() {
        return tls;
    }

    public void setTls(ProxyTlsProperties tls) {
        this.tls = tls == null ? new ProxyTlsProperties() : tls;
    }

    public void setMtls(Mtls mtls) {
        this.mtls = mtls == null ? new Mtls() : mtls;
    }

    public ProxyHealthCheckProperties getHealthCheck() {
        return healthCheck;
    }

    public void setHealthCheck(ProxyHealthCheckProperties healthCheck) {
        this.healthCheck = healthCheck == null ? new ProxyHealthCheckProperties() : healthCheck;
    }

    private String defaultUpstreamPath(String routeId) {
        if ("user-profile".equals(routeId)) {
            return userProfilePath;
        }
        return null;
    }

    private String defaultPublicPath(String routeId) {
        if ("user-profile".equals(routeId)) {
            return "/bcm/demo/user-profile";
        }
        return null;
    }

    private static Map<String, Route> defaultRoutes() {
        Map<String, Route> defaultRoutes = new LinkedHashMap<>();
        Route userProfile = new Route();
        userProfile.setPublicMethod("POST");
        userProfile.setPublicPath("/bcm/demo/user-profile");
        userProfile.setMethod("POST");
        userProfile.setUpstreamSystem(UpstreamSystem.BCM);
        userProfile.setCircuitBreakerEnabled(DEFAULT_CIRCUIT_BREAKER_ENABLED);
        defaultRoutes.put("user-profile", userProfile);
        return defaultRoutes;
    }

    private Route legacyPassthroughRoute(String publicPathPrefix, String upstreamPathPrefix) {
        Route route = new Route();
        route.setPublicMethod("POST");
        route.setPublicPath(pathPrefixWithWildcard(publicPathPrefix));
        route.setMethod("POST");
        route.setUpstreamPath(defaultText(upstreamPathPrefix, publicPathPrefix));
        route.setUpstreamSystem(UpstreamSystem.BCM);
        route.setLegacyPassthrough(true);
        route.setResponseTimeoutMillis(defaultTimeoutMillis());
        route.setHtmlResponseMeansSessionExpired(true);
        route.setRetryMaxAttempts(DEFAULT_RETRY_MAX_ATTEMPTS);
        route.setRetryBackoffMillis(DEFAULT_RETRY_BACKOFF_MILLIS);
        route.setBulkheadMaxConcurrentRequests(DEFAULT_BULKHEAD_MAX_CONCURRENT_REQUESTS);
        route.setCircuitBreakerEnabled(DEFAULT_CIRCUIT_BREAKER_ENABLED);
        route.setCircuitBreakerFailureThreshold(DEFAULT_CIRCUIT_BREAKER_FAILURE_THRESHOLD);
        route.setCircuitBreakerOpenMillis(DEFAULT_CIRCUIT_BREAKER_OPEN_MILLIS);
        return route;
    }

    private static String defaultText(String value, String defaultValue) {
        if (value == null || value.isBlank()) {
            return defaultValue;
        }
        return value.trim();
    }

    private long defaultTimeoutMillis() {
        return responseTimeoutMillis > 0 ? responseTimeoutMillis : DEFAULT_RESPONSE_TIMEOUT_MILLIS;
    }

    private static String validateHttpMethod(String routeId, String method) {
        return switch (method) {
            case "GET", "POST", "PUT", "PATCH", "DELETE" -> method;
            default -> throw new BffException(ErrorCode.BAD_REQUEST,
                    "Unsupported BCM proxy route method: " + routeId + " " + method);
        };
    }

    private static String normalizePath(String path) {
        String normalized = defaultText(path, "");
        if (normalized.length() > 1 && normalized.endsWith("/")) {
            return normalized.substring(0, normalized.length() - 1);
        }
        return normalized;
    }

    private static boolean startsWithNormalized(String path, String prefix) {
        String normalizedPath = normalizePath(path);
        String normalizedPrefix = normalizePath(prefix);
        if (normalizedPrefix.isBlank()) {
            return false;
        }
        if (normalizedPath.equals(normalizedPrefix)) {
            return true;
        }
        String prefixWithSlash = normalizedPrefix.endsWith("/") ? normalizedPrefix : normalizedPrefix + "/";
        return normalizedPath.startsWith(prefixWithSlash);
    }

    private static String pathPrefixWithWildcard(String prefix) {
        String normalizedPrefix = normalizePath(prefix);
        if (normalizedPrefix.isBlank() || "/".equals(normalizedPrefix)) {
            return "/**";
        }
        return normalizedPrefix + "/**";
    }

    public static class Mtls {
        private boolean enabled;
        private String certFile = "";
        private String keyFile = "";
        private boolean insecureSkipVerify;

        public boolean isEnabled() {
            return enabled;
        }

        public void setEnabled(boolean enabled) {
            this.enabled = enabled;
        }

        public String getCertFile() {
            return certFile;
        }

        public void setCertFile(String certFile) {
            this.certFile = certFile;
        }

        public String getKeyFile() {
            return keyFile;
        }

        public void setKeyFile(String keyFile) {
            this.keyFile = keyFile;
        }

        public boolean isInsecureSkipVerify() {
            return insecureSkipVerify;
        }

        public void setInsecureSkipVerify(boolean insecureSkipVerify) {
            this.insecureSkipVerify = insecureSkipVerify;
        }
    }

    public static class Route {
        public static final String LEGACY_PASSTHROUGH_ROUTE_ID = "legacy-passthrough";
        public static final String DSP_LEGACY_PASSTHROUGH_ROUTE_ID = "dsp-legacy-passthrough";

        private String publicMethod;
        private String publicPath;
        private String method = "POST";
        private String upstreamPath;
        private UpstreamSystem upstreamSystem = UpstreamSystem.BCM;
        private boolean legacyPassthrough;
        private long responseTimeoutMillis;
        private boolean htmlResponseMeansSessionExpired = true;
        private int retryMaxAttempts = DEFAULT_RETRY_MAX_ATTEMPTS;
        private long retryBackoffMillis = DEFAULT_RETRY_BACKOFF_MILLIS;
        private int bulkheadMaxConcurrentRequests = DEFAULT_BULKHEAD_MAX_CONCURRENT_REQUESTS;
        private boolean circuitBreakerEnabled = DEFAULT_CIRCUIT_BREAKER_ENABLED;
        private int circuitBreakerFailureThreshold = DEFAULT_CIRCUIT_BREAKER_FAILURE_THRESHOLD;
        private long circuitBreakerOpenMillis = DEFAULT_CIRCUIT_BREAKER_OPEN_MILLIS;

        public String getPublicMethod() {
            return publicMethod;
        }

        public void setPublicMethod(String publicMethod) {
            this.publicMethod = publicMethod == null ? null : publicMethod.toUpperCase(Locale.ROOT);
        }

        public String getPublicPath() {
            return publicPath;
        }

        public void setPublicPath(String publicPath) {
            this.publicPath = publicPath;
        }

        public String getMethod() {
            return method;
        }

        public void setMethod(String method) {
            this.method = method == null ? null : method.toUpperCase(Locale.ROOT);
        }

        public String getUpstreamPath() {
            return upstreamPath;
        }

        public void setUpstreamPath(String upstreamPath) {
            this.upstreamPath = upstreamPath;
        }

        public UpstreamSystem getUpstreamSystem() {
            return upstreamSystem;
        }

        public void setUpstreamSystem(UpstreamSystem upstreamSystem) {
            this.upstreamSystem = upstreamSystem == null ? UpstreamSystem.BCM : upstreamSystem;
        }

        public boolean isLegacyPassthrough() {
            return legacyPassthrough;
        }

        public void setLegacyPassthrough(boolean legacyPassthrough) {
            this.legacyPassthrough = legacyPassthrough;
        }

        public long getResponseTimeoutMillis() {
            return responseTimeoutMillis;
        }

        public void setResponseTimeoutMillis(long responseTimeoutMillis) {
            this.responseTimeoutMillis = responseTimeoutMillis;
        }

        public boolean isHtmlResponseMeansSessionExpired() {
            return htmlResponseMeansSessionExpired;
        }

        public void setHtmlResponseMeansSessionExpired(boolean htmlResponseMeansSessionExpired) {
            this.htmlResponseMeansSessionExpired = htmlResponseMeansSessionExpired;
        }

        public int getRetryMaxAttempts() {
            return retryMaxAttempts;
        }

        public void setRetryMaxAttempts(int retryMaxAttempts) {
            this.retryMaxAttempts = retryMaxAttempts;
        }

        public long getRetryBackoffMillis() {
            return retryBackoffMillis;
        }

        public void setRetryBackoffMillis(long retryBackoffMillis) {
            this.retryBackoffMillis = retryBackoffMillis;
        }

        public int getBulkheadMaxConcurrentRequests() {
            return bulkheadMaxConcurrentRequests;
        }

        public void setBulkheadMaxConcurrentRequests(int bulkheadMaxConcurrentRequests) {
            this.bulkheadMaxConcurrentRequests = bulkheadMaxConcurrentRequests;
        }

        public boolean isCircuitBreakerEnabled() {
            return circuitBreakerEnabled;
        }

        public void setCircuitBreakerEnabled(boolean circuitBreakerEnabled) {
            this.circuitBreakerEnabled = circuitBreakerEnabled;
        }

        public int getCircuitBreakerFailureThreshold() {
            return circuitBreakerFailureThreshold;
        }

        public void setCircuitBreakerFailureThreshold(int circuitBreakerFailureThreshold) {
            this.circuitBreakerFailureThreshold = circuitBreakerFailureThreshold;
        }

        public long getCircuitBreakerOpenMillis() {
            return circuitBreakerOpenMillis;
        }

        public void setCircuitBreakerOpenMillis(long circuitBreakerOpenMillis) {
            this.circuitBreakerOpenMillis = circuitBreakerOpenMillis;
        }
    }
}

package com.hkbea.bcm.bff.proxy.service;

import com.hkbea.bcm.bff.proxy.config.BcmProxyProperties;
import com.hkbea.bcm.bff.proxy.config.ProxyTlsProperties;
import io.netty.handler.codec.http.HttpHeaderNames;
import io.netty.handler.ssl.SslContext;
import io.netty.handler.ssl.SslContextBuilder;
import io.netty.handler.ssl.util.InsecureTrustManagerFactory;
import org.springframework.http.client.reactive.ReactorClientHttpConnector;
import org.springframework.web.reactive.function.client.WebClient;
import reactor.netty.http.client.HttpClient;

import java.io.File;

final class ProxyWebClientFactory {
    private ProxyWebClientFactory() {
    }

    static WebClient bcmWebClient(WebClient.Builder builder, BcmProxyProperties properties) {
        return bcmWebClient(builder, properties, null);
    }

    static WebClient bcmWebClient(WebClient.Builder builder, BcmProxyProperties properties, ProxyEndpoint fallbackEndpoint) {
        WebClient.Builder configured = builder.clone();
        HttpClient httpClient = httpClient(fallbackEndpoint);
        BcmProxyProperties.Mtls mtls = properties.getMtls();
        if (!mtls.isEnabled() && !hasTlsOverride(properties.getTls())) {
            return httpClient == null
                    ? configured.build()
                    : configured.clientConnector(new ReactorClientHttpConnector(httpClient)).build();
        }

        try {
            SslContextBuilder sslContextBuilder = SslContextBuilder.forClient();
            if (mtls.isEnabled()) {
                if (!hasText(mtls.getCertFile()) || !hasText(mtls.getKeyFile())) {
                    throw new IllegalStateException("BCM proxy mTLS requires cert-file and key-file");
                }
                sslContextBuilder.keyManager(new File(mtls.getCertFile()), new File(mtls.getKeyFile()));
            }
            applyTrust(sslContextBuilder, properties.getTls(), mtls.isInsecureSkipVerify());
            return configured.clientConnector(new ReactorClientHttpConnector(secure(httpClient, sslContextBuilder))).build();
        } catch (Exception error) {
            throw new IllegalStateException("Failed to configure BCM proxy TLS client", error);
        }
    }

    static WebClient standardWebClient(WebClient.Builder builder) {
        return builder.clone().build();
    }

    static WebClient standardWebClient(WebClient.Builder builder, ProxyTlsProperties tls) {
        return standardWebClient(builder, null, tls);
    }

    static WebClient standardWebClient(WebClient.Builder builder, ProxyEndpoint fallbackEndpoint) {
        return standardWebClient(builder, fallbackEndpoint, null);
    }

    static WebClient standardWebClient(WebClient.Builder builder, ProxyEndpoint fallbackEndpoint, ProxyTlsProperties tls) {
        HttpClient httpClient = httpClient(fallbackEndpoint);
        if (!hasTlsOverride(tls)) {
            return httpClient == null
                    ? builder.clone().build()
                    : builder.clone().clientConnector(new ReactorClientHttpConnector(httpClient)).build();
        }

        try {
            SslContextBuilder sslContextBuilder = SslContextBuilder.forClient();
            applyTrust(sslContextBuilder, tls, false);
            return builder.clone().clientConnector(new ReactorClientHttpConnector(secure(httpClient, sslContextBuilder))).build();
        } catch (Exception error) {
            throw new IllegalStateException("Failed to configure proxy TLS client", error);
        }
    }

    static WebClient bcoLegacyWebClient(WebClient.Builder builder, ProxyTlsProperties tls) {
        return bcoLegacyWebClient(builder, null, tls);
    }

    static WebClient bcoLegacyWebClient(WebClient.Builder builder, ProxyEndpoint fallbackEndpoint, ProxyTlsProperties tls) {
        HttpClient httpClient = legacyGoBcoHttpClient(fallbackEndpoint);
        if (!hasTlsOverride(tls)) {
            return builder.clone().clientConnector(new ReactorClientHttpConnector(httpClient)).build();
        }

        try {
            SslContextBuilder sslContextBuilder = SslContextBuilder.forClient();
            applyTrust(sslContextBuilder, tls, false);
            return builder.clone().clientConnector(new ReactorClientHttpConnector(secure(httpClient, sslContextBuilder))).build();
        } catch (Exception error) {
            throw new IllegalStateException("Failed to configure BCO proxy TLS client", error);
        }
    }

    private static HttpClient httpClient(ProxyEndpoint fallbackEndpoint) {
        if (fallbackEndpoint == null || !fallbackEndpoint.hasFallback()) {
            return null;
        }
        return HttpClient.create()
                .resolver(new StaticHostAddressResolverGroup(
                        fallbackEndpoint.primaryHost(),
                        fallbackEndpoint.fallbackIp()));
    }

    private static HttpClient legacyGoBcoHttpClient(ProxyEndpoint fallbackEndpoint) {
        HttpClient httpClient = httpClient(fallbackEndpoint);
        return (httpClient == null ? HttpClient.create() : httpClient)
                .doOnRequest((request, ignored) -> request.requestHeaders().remove(HttpHeaderNames.ACCEPT));
    }

    private static boolean hasText(String value) {
        return value != null && !value.isBlank();
    }

    private static boolean hasTlsOverride(ProxyTlsProperties tls) {
        return tls != null && (hasText(tls.getTrustCertFile()) || tls.isInsecureSkipVerify());
    }

    private static void applyTrust(
            SslContextBuilder sslContextBuilder,
            ProxyTlsProperties tls,
            boolean legacyMtlsInsecureSkipVerify
    ) {
        if (tls != null && tls.isInsecureSkipVerify() || legacyMtlsInsecureSkipVerify) {
            sslContextBuilder.trustManager(InsecureTrustManagerFactory.INSTANCE);
            return;
        }
        if (tls != null && hasText(tls.getTrustCertFile())) {
            sslContextBuilder.trustManager(new File(tls.getTrustCertFile()));
        }
    }

    private static HttpClient secure(HttpClient httpClient, SslContextBuilder sslContextBuilder) throws Exception {
        SslContext sslContext = sslContextBuilder.build();
        return (httpClient == null ? HttpClient.create() : httpClient)
                .secure(sslSpec -> sslSpec.sslContext(sslContext));
    }
}

package com.hkbea.bcm.bff.proxy.model;

import com.hkbea.bcm.bff.access.model.SessionRecord;
import org.springframework.http.HttpHeaders;

public record ProxyRequestContext(
        String traceId,
        SessionRecord session,
        String method,
        String path,
        HttpHeaders requestHeaders,
        String deviceId,
        String deviceOs,
        String locale,
        String query
) {
}

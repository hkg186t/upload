package com.hkbea.bcm.bff.proxy.model;

import com.fasterxml.jackson.databind.JsonNode;

public record ProxyResult(
        int upstreamStatus,
        String contentType,
        JsonNode body
) {
}

package com.hkbea.bcm.bff.proxy.service;

import java.net.URI;
import java.net.URISyntaxException;

final class ProxyEndpointSupport {
    private ProxyEndpointSupport() {
    }

    static URI parseBaseUri(String systemName, String baseUrl) {
        if (baseUrl == null || baseUrl.isBlank()) {
            throw new IllegalStateException(systemName + " proxy base-url is required");
        }
        try {
            URI uri = new URI(baseUrl.trim());
            if (uri.getScheme() == null || uri.getHost() == null) {
                throw new IllegalStateException(systemName + " proxy base-url must include scheme and host");
            }
            return uri;
        } catch (URISyntaxException error) {
            throw new IllegalStateException(systemName + " proxy base-url is invalid", error);
        }
    }

    static URI fallbackBaseUri(URI primaryBaseUri, String fallbackIp) {
        if (fallbackIp == null || fallbackIp.isBlank()) {
            return null;
        }
        try {
            return new URI(
                    primaryBaseUri.getScheme(),
                    primaryBaseUri.getRawUserInfo(),
                    fallbackIp.trim(),
                    primaryBaseUri.getPort(),
                    normalizedBasePath(primaryBaseUri),
                    null,
                    null);
        } catch (URISyntaxException error) {
            throw new IllegalStateException("Proxy fallback IP is invalid: " + fallbackIp, error);
        }
    }

    static URI resolveAgainstBase(URI baseUri, String pathAndQuery) {
        String rawPathAndQuery = (pathAndQuery == null || pathAndQuery.isBlank()) ? "/" : pathAndQuery.trim();
        String rawPath = rawPathAndQuery;
        String rawQuery = null;
        int queryStart = rawPathAndQuery.indexOf('?');
        if (queryStart >= 0) {
            rawPath = rawPathAndQuery.substring(0, queryStart);
            rawQuery = rawPathAndQuery.substring(queryStart + 1);
        }

        String combinedPath = joinPaths(normalizedBasePath(baseUri), rawPath);
        try {
            StringBuilder uri = new StringBuilder();
            uri.append(baseUri.getScheme()).append("://");
            if (baseUri.getRawUserInfo() != null && !baseUri.getRawUserInfo().isBlank()) {
                uri.append(baseUri.getRawUserInfo()).append('@');
            }
            uri.append(hostForUri(baseUri));
            if (baseUri.getPort() >= 0) {
                uri.append(':').append(baseUri.getPort());
            }
            uri.append(combinedPath);
            if (rawQuery != null) {
                uri.append('?').append(rawQuery);
            }
            return new URI(uri.toString());
        } catch (URISyntaxException error) {
            throw new IllegalStateException("Proxy upstream URI is invalid: " + pathAndQuery, error);
        }
    }

    static String hostHeader(URI primaryBaseUri) {
        int port = primaryBaseUri.getPort();
        if (port < 0 || isDefaultPort(primaryBaseUri.getScheme(), port)) {
            return primaryBaseUri.getHost();
        }
        return primaryBaseUri.getHost() + ":" + port;
    }

    static String safeUriForLog(URI uri) {
        if (uri == null) {
            return "";
        }
        return uri.getScheme() + "://" + hostHeader(uri) + normalizedBasePath(uri);
    }

    private static String normalizedBasePath(URI uri) {
        String path = uri.getRawPath();
        if (path == null || path.isBlank() || "/".equals(path)) {
            return "";
        }
        return trimTrailingSlash(path);
    }

    private static String joinPaths(String basePath, String requestPath) {
        String normalizedRequestPath = requestPath == null || requestPath.isBlank() ? "/" : requestPath;
        if (!normalizedRequestPath.startsWith("/")) {
            normalizedRequestPath = "/" + normalizedRequestPath;
        }
        if (basePath == null || basePath.isBlank()) {
            return normalizedRequestPath;
        }
        return trimTrailingSlash(basePath) + normalizedRequestPath;
    }

    private static String trimTrailingSlash(String path) {
        String trimmed = path;
        while (trimmed.length() > 1 && trimmed.endsWith("/")) {
            trimmed = trimmed.substring(0, trimmed.length() - 1);
        }
        return trimmed;
    }

    private static boolean isDefaultPort(String scheme, int port) {
        return ("http".equalsIgnoreCase(scheme) && port == 80)
                || ("https".equalsIgnoreCase(scheme) && port == 443);
    }

    private static String hostForUri(URI uri) {
        String host = uri.getHost();
        if (host == null) {
            return "";
        }
        return host.contains(":") ? "[" + host + "]" : host;
    }
}

package com.hkbea.bcm.bff.proxy.service;

import com.hkbea.bcm.bff.proxy.config.BcoProxyProperties;
import com.hkbea.bcm.bff.proxy.config.BcmProxyProperties;
import com.hkbea.bcm.bff.proxy.config.ProxyHealthCheckProperties;
import com.hkbea.bcm.bff.proxy.config.ProxyRuntimeHealthCheckProperties;
import com.hkbea.bcm.bff.proxy.model.UpstreamSystem;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.context.event.ApplicationReadyEvent;
import org.springframework.context.event.EventListener;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;
import org.springframework.web.reactive.function.client.ClientResponse;
import org.springframework.web.reactive.function.client.WebClient;
import org.springframework.web.reactive.function.client.WebClient.RequestBodySpec;
import reactor.core.publisher.Mono;

import java.net.URI;
import java.time.Duration;
import java.util.function.Function;

@Service
public class ProxyUpstreamHealthChecker {
    private static final Logger log = LoggerFactory.getLogger(ProxyUpstreamHealthChecker.class);
    private static final String IBM_CLIENT_ID = "x-ibm-client-id";
    private static final String IBM_CLIENT_SECRET = "x-ibm-client-secret";

    private final ProxyRuntimeHealthCheckProperties runtimeProperties;
    private final BcmProxyProperties bcmProperties;
    private final BcoProxyProperties bcoProperties;
    private final ProxyEndpoint bcmEndpoint;
    private final ProxyEndpoint bcoEndpoint;
    private final WebClient bcmWebClient;
    private final WebClient bcmFallbackWebClient;
    private final WebClient bcoWebClient;
    private final WebClient bcoFallbackWebClient;

    public ProxyUpstreamHealthChecker(
            ProxyRuntimeHealthCheckProperties runtimeProperties,
            BcmProxyProperties bcmProperties,
            BcoProxyProperties bcoProperties,
            WebClient.Builder webClientBuilder
    ) {
        this.runtimeProperties = runtimeProperties;
        this.bcmProperties = bcmProperties;
        this.bcoProperties = bcoProperties;
        this.bcmEndpoint = new ProxyEndpoint(UpstreamSystem.BCM.name(), bcmProperties.getBaseUrl(), bcmProperties.getFallbackIp());
        this.bcoEndpoint = new ProxyEndpoint(UpstreamSystem.BCO.name(), bcoProperties.getBaseUrl(), bcoProperties.getFallbackIp());
        this.bcmWebClient = ProxyWebClientFactory.bcmWebClient(webClientBuilder, bcmProperties);
        this.bcmFallbackWebClient = ProxyWebClientFactory.bcmWebClient(webClientBuilder, bcmProperties, bcmEndpoint);
        this.bcoWebClient = ProxyWebClientFactory.bcoLegacyWebClient(webClientBuilder, bcoProperties.getTls());
        this.bcoFallbackWebClient = ProxyWebClientFactory.bcoLegacyWebClient(webClientBuilder, bcoEndpoint, bcoProperties.getTls());
    }

    @EventListener(ApplicationReadyEvent.class)
    public void runStartupChecks() {
        if (!runtimeProperties.isStartupEnabled()) {
            return;
        }
        checkAll("startup").subscribe();
    }

    @Scheduled(
            initialDelayString = "${bff.proxy.health-check.initial-delay-millis:60000}",
            fixedDelayString = "${bff.proxy.health-check.interval-millis:60000}"
    )
    public void runScheduledChecks() {
        if (!runtimeProperties.isScheduledEnabled()) {
            return;
        }
        checkAll("scheduled").subscribe();
    }

    Mono<Void> checkAll(String trigger) {
        return Mono.when(
                checkOne(trigger, UpstreamSystem.BCM, bcmEndpoint, bcmWebClient, bcmFallbackWebClient,
                        bcmProperties.getHealthCheck(), false),
                checkOne(trigger, UpstreamSystem.BCO, bcoEndpoint, bcoWebClient, bcoFallbackWebClient,
                        bcoProperties.getHealthCheck(), bcoProperties.isPreferFallbackIp())
        );
    }

    private Mono<Void> checkOne(
            String trigger,
            UpstreamSystem system,
            ProxyEndpoint endpoint,
            WebClient webClient,
            WebClient fallbackWebClient,
            ProxyHealthCheckProperties properties,
            boolean preferFallback
    ) {
        if (!properties.isEnabled()) {
            log.info("BFF_PROXY_HEALTHCHECK trigger={} system={} enabled=false", trigger, system);
            return Mono.empty();
        }

        long startedAtNanos = System.nanoTime();
        boolean useFallback = preferFallback && endpoint.hasFallback();
        WebClient selectedWebClient = useFallback ? fallbackWebClient : webClient;
        URI selectedUri = useFallback
                ? endpoint.fallbackUri(properties.getPath())
                : endpoint.primaryUri(properties.getPath());
        return requestHealth(system, selectedWebClient, endpoint, selectedUri, properties, useFallback)
                .onErrorResume(error -> !useFallback && endpoint.hasFallback()
                        ? requestHealthWithFallback(trigger, system, endpoint, fallbackWebClient, properties, error)
                        : Mono.error(error))
                .doOnSuccess(result -> log.info(
                        "BFF_PROXY_HEALTHCHECK trigger={} system={} outcome=reachable method={} path={} target={} fallbackUsed={} status={} durationMs={}",
                        trigger,
                        system,
                        properties.getMethod(),
                        properties.getPath(),
                        result.target(),
                        result.fallbackUsed(),
                        result.status(),
                        elapsedMillis(startedAtNanos)))
                .doOnError(error -> log.warn(
                        "BFF_PROXY_HEALTHCHECK trigger={} system={} outcome=unreachable method={} path={} primaryTarget={} fallbackTarget={} errorType={} message={} durationMs={}",
                        trigger,
                        system,
                        properties.getMethod(),
                        properties.getPath(),
                        healthTargetForLog(endpoint, properties, false),
                        healthTargetForLog(endpoint, properties, true),
                        error.getClass().getSimpleName(),
                        sanitize(error.getMessage()),
                        elapsedMillis(startedAtNanos)))
                .onErrorResume(error -> Mono.empty())
                .then();
    }

    private Mono<HealthCheckResult> requestHealthWithFallback(
            String trigger,
            UpstreamSystem system,
            ProxyEndpoint endpoint,
            WebClient fallbackWebClient,
            ProxyHealthCheckProperties properties,
            Throwable primaryError
    ) {
        log.warn("BFF_PROXY_HEALTHCHECK_FALLBACK trigger={} system={} method={} path={} primaryTarget={} fallbackTarget={} reason={}",
                trigger,
                system,
                properties.getMethod(),
                properties.getPath(),
                healthTargetForLog(endpoint, properties, false),
                healthTargetForLog(endpoint, properties, true),
                primaryError.getClass().getSimpleName());
        return requestHealth(system, fallbackWebClient, endpoint, endpoint.fallbackUri(properties.getPath()), properties, true);
    }

    private Mono<HealthCheckResult> requestHealth(
            UpstreamSystem system,
            WebClient webClient,
            ProxyEndpoint endpoint,
            URI uri,
            ProxyHealthCheckProperties properties,
            boolean fallback
    ) {
        RequestBodySpec requestSpec = webClient
                .method(HttpMethod.valueOf(properties.getMethod()))
                .uri(uri)
                .headers(headers -> {
                    applySystemHeaders(system, headers);
                    applyContentType(headers, properties);
                    if (fallback) {
                        endpoint.applyFallbackHostHeader(headers);
                    }
                });

        Mono<HealthCheckResult> response = hasText(properties.getBody())
                ? requestSpec.bodyValue(properties.getBody()).exchangeToMono(responseSpec(uri, fallback))
                : requestSpec.exchangeToMono(responseSpec(uri, fallback));

        return response
                .timeout(Duration.ofMillis(properties.getTimeoutMillis()));
    }

    private Function<ClientResponse, Mono<HealthCheckResult>> responseSpec(
            URI uri,
            boolean fallback
    ) {
        return response -> response.releaseBody().thenReturn(new HealthCheckResult(
                ProxyEndpointSupport.safeUriForLog(uri),
                fallback,
                response.statusCode().value()));
    }

    private void applySystemHeaders(UpstreamSystem system, HttpHeaders headers) {
        if (system != UpstreamSystem.BCM) {
            return;
        }
        setIfPresent(headers, IBM_CLIENT_ID, bcmProperties.getIbmClientId());
        setIfPresent(headers, IBM_CLIENT_SECRET, bcmProperties.getIbmClientSecret());
    }

    private static void applyContentType(HttpHeaders headers, ProxyHealthCheckProperties properties) {
        if (!hasText(properties.getBody())) {
            return;
        }
        headers.setContentType(MediaType.parseMediaType(properties.getContentType()));
    }

    private static void setIfPresent(HttpHeaders headers, String name, String value) {
        if (hasText(value)) {
            headers.set(name, value);
        }
    }

    private static long elapsedMillis(long startedAtNanos) {
        return Duration.ofNanos(System.nanoTime() - startedAtNanos).toMillis();
    }

    private static String healthTargetForLog(
            ProxyEndpoint endpoint,
            ProxyHealthCheckProperties properties,
            boolean fallback
    ) {
        if (fallback && !endpoint.hasFallback()) {
            return "";
        }
        URI uri = fallback ? endpoint.fallbackUri(properties.getPath()) : endpoint.primaryUri(properties.getPath());
        String target = ProxyEndpointSupport.safeUriForLog(uri);
        return fallback ? target + " via " + endpoint.fallbackIp() : target;
    }

    private static boolean hasText(String value) {
        return value != null && !value.isBlank();
    }

    private static String sanitize(String message) {
        if (message == null || message.isBlank()) {
            return "";
        }
        return message.replace('\n', ' ').replace('\r', ' ');
    }

    private record HealthCheckResult(String target, boolean fallbackUsed, int status) {
    }
}

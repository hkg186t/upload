package com.hkbea.bcm.bff.proxy.model;

public record ProxyExchangeContext(
        String traceId,
        String path,
        String method,
        UpstreamSystem upstreamSystem
) {
}

package com.hkbea.bcm.bff.proxy.service;

import com.fasterxml.jackson.databind.JsonNode;
import com.hkbea.bcm.bff.proxy.model.ProxyRequestContext;
import com.hkbea.bcm.bff.proxy.model.ProxyResult;
import com.hkbea.bcm.bff.proxy.model.RawProxyResult;
import reactor.core.publisher.Mono;

public interface BcmProxyService {
    Mono<ProxyResult> proxy(String routeId, JsonNode requestBody, ProxyRequestContext context);

    Mono<RawProxyResult> proxyRaw(String routeId, byte[] requestBody, ProxyRequestContext context);
}

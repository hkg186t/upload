package com.hkbea.bcm.bff.proxy.service;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.hkbea.bcm.bff.access.service.SessionService;
import com.hkbea.bcm.bff.proxy.config.BcoProxyProperties;
import com.hkbea.bcm.bff.proxy.config.BcmProxyProperties;
import com.hkbea.bcm.bff.proxy.config.BcmProxyProperties.Route;
import com.hkbea.bcm.bff.proxy.model.ProxyRequestContext;
import com.hkbea.bcm.bff.proxy.model.ProxyResult;
import com.hkbea.bcm.bff.proxy.model.RawProxyResult;
import com.hkbea.bcm.bff.proxy.model.UpstreamSystem;
import com.hkbea.bcm.bff.shared.api.BffException;
import com.hkbea.bcm.bff.shared.api.ErrorCode;
import com.hkbea.bcm.bff.shared.http.HeaderConstants;
import com.hkbea.bcm.bff.shared.logging.DebugLogSanitizer;
import io.micrometer.core.instrument.MeterRegistry;
import io.micrometer.core.instrument.Timer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.ObjectProvider;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatusCode;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Service;
import org.springframework.web.reactive.function.client.WebClient;
import org.springframework.web.reactive.function.client.WebClientRequestException;
import org.springframework.web.reactive.function.client.WebClientResponseException;
import reactor.core.publisher.Mono;
import reactor.util.retry.Retry;

import java.net.URI;
import java.nio.charset.StandardCharsets;
import java.time.Duration;
import java.util.List;
import java.util.Locale;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentMap;
import java.util.concurrent.Semaphore;
import java.util.concurrent.TimeoutException;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.concurrent.atomic.AtomicLong;

@Service
public class WebClientBcmProxyService implements BcmProxyService {
    private static final Logger log = LoggerFactory.getLogger(WebClientBcmProxyService.class);
    private static final String METRIC_PROXY_DURATION = "bcm.bff.proxy.duration";
    private static final String X_USER_ID = "X-User-Id";
    private static final String IBM_CLIENT_ID = "x-ibm-client-id";
    private static final String IBM_CLIENT_SECRET = "x-ibm-client-secret";
    private static final String STATUS_NONE = "none";
    private static final String FAILURE_NONE = "none";
    private static final String FAILURE_BULKHEAD_REJECTED = "bulkhead_rejected";
    private static final String FAILURE_CIRCUIT_OPEN = "circuit_open";
    private static final String FAILURE_HTML_SESSION_EXPIRED = "html_session_expired";
    private static final String FAILURE_INVALID_JSON = "invalid_json";
    private static final String FAILURE_TIMEOUT = "timeout";
    private static final String FAILURE_UPSTREAM_REQUEST_ERROR = "upstream_request_error";
    private static final String FAILURE_UPSTREAM_STATUS_ERROR = "upstream_status_error";
    private static final String FAILURE_UNKNOWN = "unknown";
    private static final byte[] LEGACY_SESSION_EXPIRED_BODY =
            "{\"status\":\"419\",\"code\":\"419\",\"message\":\"Session Expired\"}".getBytes(StandardCharsets.UTF_8);
    private static final Set<String> BLOCKED_FORWARD_HEADERS = Set.of(
            "authorization",
            "cookie",
            "host",
            "content-length",
            "transfer-encoding",
            "connection",
            "keep-alive",
            "proxy-authenticate",
            "proxy-authorization",
            "te",
            "trailer",
            "upgrade",
            "accept-encoding",
            "x-ibm-client-id",
            "x-ibm-client-secret",
            "x-user-id"
    );
    private static final Set<String> BLOCKED_RESPONSE_HEADERS = Set.of(
            "content-length",
            "transfer-encoding",
            "connection",
            "keep-alive",
            "proxy-authenticate",
            "proxy-authorization",
            "te",
            "trailer",
            "upgrade"
    );

    private final BcmProxyProperties properties;
    private final SessionService sessionService;
    private final WebClient bcmWebClient;
    private final WebClient bcmFallbackWebClient;
    private final WebClient bcoWebClient;
    private final WebClient bcoFallbackWebClient;
    private final ProxyEndpoint bcmEndpoint;
    private final ProxyEndpoint bcoEndpoint;
    private final ObjectMapper objectMapper;
    private final MeterRegistry meterRegistry;
    private final ConcurrentMap<String, RouteGuard> routeGuards = new ConcurrentHashMap<>();

    public WebClientBcmProxyService(
            BcmProxyProperties properties,
            BcoProxyProperties bcoProperties,
            WebClient.Builder webClientBuilder,
            ObjectMapper objectMapper,
            SessionService sessionService,
            ObjectProvider<MeterRegistry> meterRegistryProvider
    ) {
        this.properties = properties;
        this.sessionService = sessionService;
        this.bcmEndpoint = new ProxyEndpoint(UpstreamSystem.BCM.name(), properties.getBaseUrl(), properties.getFallbackIp());
        this.bcoEndpoint = new ProxyEndpoint(UpstreamSystem.BCO.name(), bcoProperties.getBaseUrl(), bcoProperties.getFallbackIp());
        this.bcmWebClient = ProxyWebClientFactory.bcmWebClient(webClientBuilder, properties);
        this.bcmFallbackWebClient = ProxyWebClientFactory.bcmWebClient(webClientBuilder, properties, bcmEndpoint);
        this.bcoWebClient = ProxyWebClientFactory.standardWebClient(webClientBuilder, bcoProperties.getTls());
        this.bcoFallbackWebClient = ProxyWebClientFactory.standardWebClient(webClientBuilder, bcoEndpoint, bcoProperties.getTls());
        this.objectMapper = objectMapper;
        this.meterRegistry = meterRegistryProvider.getIfAvailable();
    }

    @Override
    public Mono<ProxyResult> proxy(String routeId, JsonNode requestBody, ProxyRequestContext context) {
        Route route = properties.resolveRoute(routeId);
        RouteGuard guard = routeGuards.computeIfAbsent(routeId, ignored -> new RouteGuard(route));
        long startedAtNanos = System.nanoTime();
        return Mono.defer(() -> guardedProxy(routeId, route, guard, requestBody, context))
                .doOnSuccess(result -> recordSuccess(routeId, route, context, result, startedAtNanos))
                .doOnError(error -> recordFailure(routeId, route, context, error, startedAtNanos));
    }

    @Override
    public Mono<RawProxyResult> proxyRaw(String routeId, byte[] requestBody, ProxyRequestContext context) {
        Route route = properties.resolveRoute(routeId);
        RouteGuard guard = routeGuards.computeIfAbsent(routeId, ignored -> new RouteGuard(route));
        long startedAtNanos = System.nanoTime();
        return Mono.defer(() -> guardedRawProxy(routeId, route, guard, requestBody, context))
                .doOnSuccess(result -> recordRawSuccess(routeId, route, context, result, startedAtNanos))
                .doOnError(error -> recordFailure(routeId, route, context, error, startedAtNanos));
    }

    private Mono<ProxyResult> guardedProxy(
            String routeId,
            Route route,
            RouteGuard guard,
            JsonNode requestBody,
            ProxyRequestContext context
    ) {
        if (!guard.tryAcquire()) {
            return Mono.error(new ObservedBffException(
                    ErrorCode.TOO_MANY_REQUESTS,
                    "BCM proxy route is busy",
                    STATUS_NONE,
                    FAILURE_BULKHEAD_REJECTED));
        }

        if (!guard.allowRequest(route)) {
            guard.release();
            return Mono.error(new ObservedBffException(
                    ErrorCode.BAD_GATEWAY,
                    "BCM proxy circuit is open",
                    STATUS_NONE,
                    FAILURE_CIRCUIT_OPEN));
        }

        return executeUpstream(routeId, route, requestBody, context)
                .transformDeferred(upstream -> applyRetry(routeId, route, context, upstream))
                .doOnSuccess(result -> guard.onSuccess(route))
                .doOnError(error -> guard.onFailure(route, error))
                .doFinally(signalType -> guard.release());
    }

    private Mono<RawProxyResult> guardedRawProxy(
            String routeId,
            Route route,
            RouteGuard guard,
            byte[] requestBody,
            ProxyRequestContext context
    ) {
        if (!guard.tryAcquire()) {
            return Mono.error(new ObservedBffException(
                    ErrorCode.TOO_MANY_REQUESTS,
                    "BCM proxy route is busy",
                    STATUS_NONE,
                    FAILURE_BULKHEAD_REJECTED));
        }

        if (!guard.allowRequest(route)) {
            guard.release();
            return Mono.error(new ObservedBffException(
                    ErrorCode.BAD_GATEWAY,
                    "BCM proxy circuit is open",
                    STATUS_NONE,
                    FAILURE_CIRCUIT_OPEN));
        }

        return executeRawUpstream(routeId, route, requestBody, context)
                .transformDeferred(upstream -> applyRetry(routeId, route, context, upstream))
                .doOnSuccess(result -> guard.onSuccess(route))
                .doOnError(error -> guard.onFailure(route, error))
                .doFinally(signalType -> guard.release());
    }

    private Mono<ProxyResult> executeUpstream(String routeId, Route route, JsonNode requestBody, ProxyRequestContext context) {
        String pathAndQuery = upstreamUri(route, context);
        ProxyEndpoint endpoint = endpoint(route);
        return executeUpstream(routeId, route, requestBody, context, endpoint, pathAndQuery, false)
                .onErrorResume(error -> shouldTryFallback(error, endpoint)
                        ? executeFallback(routeId, route, requestBody, context, endpoint, pathAndQuery, error)
                        : Mono.error(error))
                .onErrorMap(TimeoutException.class, error -> new ObservedBffException(
                        ErrorCode.UPSTREAM_TIMEOUT,
                        ErrorCode.UPSTREAM_TIMEOUT.defaultMessage(),
                        STATUS_NONE,
                        FAILURE_TIMEOUT))
                .onErrorMap(WebClientRequestException.class, error -> new ObservedBffException(
                        ErrorCode.BAD_GATEWAY,
                        "Upstream request failed",
                        STATUS_NONE,
                        FAILURE_UPSTREAM_REQUEST_ERROR))
                .onErrorMap(WebClientResponseException.class, error -> new ObservedBffException(
                        ErrorCode.BAD_GATEWAY,
                        "Upstream service error",
                        Integer.toString(error.getStatusCode().value()),
                        FAILURE_UPSTREAM_STATUS_ERROR));
    }

    private Mono<RawProxyResult> executeRawUpstream(
            String routeId,
            Route route,
            byte[] requestBody,
            ProxyRequestContext context
    ) {
        String pathAndQuery = upstreamUri(route, context);
        ProxyEndpoint endpoint = endpoint(route);
        return executeRawUpstream(routeId, route, requestBody, context, endpoint, pathAndQuery, false)
                .onErrorResume(error -> shouldTryFallback(error, endpoint)
                        ? executeRawFallback(routeId, route, requestBody, context, endpoint, pathAndQuery, error)
                        : Mono.error(error))
                .onErrorMap(TimeoutException.class, error -> new ObservedBffException(
                        ErrorCode.UPSTREAM_TIMEOUT,
                        ErrorCode.UPSTREAM_TIMEOUT.defaultMessage(),
                        STATUS_NONE,
                        FAILURE_TIMEOUT))
                .onErrorMap(WebClientRequestException.class, error -> new ObservedBffException(
                        ErrorCode.BAD_GATEWAY,
                        "Upstream request failed",
                        STATUS_NONE,
                        FAILURE_UPSTREAM_REQUEST_ERROR))
                .onErrorMap(WebClientResponseException.class, error -> new ObservedBffException(
                        ErrorCode.BAD_GATEWAY,
                        "Upstream service error",
                        Integer.toString(error.getStatusCode().value()),
                        FAILURE_UPSTREAM_STATUS_ERROR));
    }

    private Mono<ProxyResult> executeFallback(
            String routeId,
            Route route,
            JsonNode requestBody,
            ProxyRequestContext context,
            ProxyEndpoint endpoint,
            String pathAndQuery,
            Throwable primaryError
    ) {
        log.warn("BFF_PROXY_FALLBACK system={} routeId={} traceId={} primaryBaseUrl={} fallbackBaseUrl={} reason={}",
                endpoint.systemName(),
                routeId,
                context.traceId(),
                endpoint.primaryBaseUrlForLog(),
                endpoint.fallbackBaseUrlForLog(),
                primaryError.getClass().getSimpleName());
        return executeUpstream(routeId, route, requestBody, context, endpoint, pathAndQuery, true);
    }

    private Mono<RawProxyResult> executeRawFallback(
            String routeId,
            Route route,
            byte[] requestBody,
            ProxyRequestContext context,
            ProxyEndpoint endpoint,
            String pathAndQuery,
            Throwable primaryError
    ) {
        log.warn("BFF_PROXY_FALLBACK system={} routeId={} traceId={} primaryBaseUrl={} fallbackBaseUrl={} reason={}",
                endpoint.systemName(),
                routeId,
                context.traceId(),
                endpoint.primaryBaseUrlForLog(),
                endpoint.fallbackBaseUrlForLog(),
                primaryError.getClass().getSimpleName());
        return executeRawUpstream(routeId, route, requestBody, context, endpoint, pathAndQuery, true);
    }

    private Mono<ProxyResult> executeUpstream(
            String routeId,
            Route route,
            JsonNode requestBody,
            ProxyRequestContext context,
            ProxyEndpoint endpoint,
            String pathAndQuery,
            boolean fallback
    ) {
        URI upstreamUri = fallback ? endpoint.fallbackUri(pathAndQuery) : endpoint.primaryUri(pathAndQuery);
        String method = upstreamMethod(route, context);
        boolean requestCanHaveBody = requestCanHaveBody(method);
        HttpHeaders outboundHeaders = new HttpHeaders();
        if (!route.isLegacyPassthrough()) {
            outboundHeaders.setAccept(List.of(MediaType.APPLICATION_JSON));
        }
        applyForwardHeaders(outboundHeaders, context, route, endpoint, fallback);
        if (requestCanHaveBody) {
            outboundHeaders.setContentType(MediaType.APPLICATION_JSON);
        } else {
            outboundHeaders.remove(HttpHeaders.CONTENT_LENGTH);
        }
        JsonNode outboundBody = requestCanHaveBody ? requestBody : null;
        logProxyRequest(routeId, route, context, upstreamUri, method, outboundHeaders, outboundBody, fallback);

        WebClient.RequestBodySpec requestSpec = webClient(route, fallback).method(HttpMethod.valueOf(method))
                .uri(upstreamUri)
                .headers(headers -> headers.addAll(outboundHeaders));
        WebClient.RequestHeadersSpec<?> responseSpec = requestCanHaveBody
                ? requestSpec.bodyValue(requestBody)
                : requestSpec;
        return responseSpec.exchangeToMono(response -> response.bodyToMono(String.class)
                .defaultIfEmpty("")
                .flatMap(body -> toProxyResult(
                        routeId,
                        route,
                        context,
                        response.statusCode(),
                        response.headers().contentType().orElse(null),
                        body)))
                .timeout(Duration.ofMillis(route.getResponseTimeoutMillis()));
    }

    private Mono<RawProxyResult> executeRawUpstream(
            String routeId,
            Route route,
            byte[] requestBody,
            ProxyRequestContext context,
            ProxyEndpoint endpoint,
            String pathAndQuery,
            boolean fallback
    ) {
        URI upstreamUri = fallback ? endpoint.fallbackUri(pathAndQuery) : endpoint.primaryUri(pathAndQuery);
        String method = upstreamMethod(route, context);
        boolean requestCanHaveBody = requestCanHaveBody(method);
        HttpHeaders outboundHeaders = new HttpHeaders();
        applyForwardHeaders(outboundHeaders, context, route, endpoint, fallback);
        if (!requestCanHaveBody) {
            outboundHeaders.remove(HttpHeaders.CONTENT_LENGTH);
        }
        byte[] outboundBody = requestCanHaveBody ? requestBody : null;
        logProxyRequest(routeId, route, context, upstreamUri, method, outboundHeaders, outboundBody, fallback);

        WebClient.RequestBodySpec requestSpec = webClient(route, fallback).method(HttpMethod.valueOf(method))
                .uri(upstreamUri)
                .headers(headers -> headers.addAll(outboundHeaders));
        WebClient.RequestHeadersSpec<?> responseSpec = requestCanHaveBody && hasRequestBody(requestBody)
                ? requestSpec.bodyValue(requestBody)
                : requestSpec;
        return responseSpec.exchangeToMono(response -> {
                    int upstreamStatus = response.statusCode().value();
                    HttpHeaders upstreamHeaders = response.headers().asHttpHeaders();
                    return response.bodyToMono(byte[].class)
                            .defaultIfEmpty(new byte[0])
                            .flatMap(body -> toRawProxyResult(
                                    route,
                                    context,
                                    upstreamStatus,
                                    upstreamHeaders,
                                    body,
                                    fallback));
                })
                .timeout(Duration.ofMillis(route.getResponseTimeoutMillis()));
    }

    private <T> Mono<T> applyRetry(
            String routeId,
            Route route,
            ProxyRequestContext context,
            Mono<T> upstream
    ) {
        if (route.getRetryMaxAttempts() <= 1) {
            return upstream;
        }

        return upstream.retryWhen(Retry.backoff(
                        route.getRetryMaxAttempts() - 1L,
                        Duration.ofMillis(route.getRetryBackoffMillis()))
                .filter(WebClientBcmProxyService::isRetryable)
                .doBeforeRetry(signal -> log.warn(
                        "BCM_PROXY_RETRY routeId={} traceId={} method={} retryAttempt={} errorCode={} upstreamStatus={} failureReason={}",
                        routeId,
                        context.traceId(),
                        upstreamMethod(route, context),
                        signal.totalRetries() + 1,
                        errorCode(signal.failure()),
                        upstreamStatus(signal.failure()),
                        failureReason(signal.failure())))
                .onRetryExhaustedThrow((retryBackoffSpec, retrySignal) -> retrySignal.failure()));
    }

    private void applyForwardHeaders(
            HttpHeaders headers,
            ProxyRequestContext context,
            Route route,
            ProxyEndpoint endpoint,
            boolean fallback
    ) {
        copyForwardableRequestHeaders(context.requestHeaders(), headers);
        headers.set(HeaderConstants.X_REQUEST_ID, context.traceId());
        headers.set(HeaderConstants.X_CORRELATION_ID, context.traceId());
        if (route.getUpstreamSystem() == UpstreamSystem.BCM) {
            headers.set(X_USER_ID, context.session().userId());
            setIfPresent(headers, IBM_CLIENT_ID, properties.getIbmClientId());
            setIfPresent(headers, IBM_CLIENT_SECRET, properties.getIbmClientSecret());
            setBcmSessionAuthorization(headers, context.session().bcmSessionId());
        }
        setIfPresent(headers, HeaderConstants.X_DEVICE_ID, context.deviceId());
        setIfPresent(headers, HeaderConstants.X_DEVICE_OS, context.deviceOs());
        setIfPresent(headers, HeaderConstants.LOCALE, context.locale());
        if (fallback) {
            endpoint.applyFallbackHostHeader(headers);
        }
    }

    private Mono<ProxyResult> toProxyResult(
            String routeId,
            Route route,
            ProxyRequestContext context,
            HttpStatusCode status,
            MediaType contentType,
            String body
    ) {
        if (!status.is2xxSuccessful()) {
            log.warn(
                    "BCM_PROXY_UPSTREAM_ERROR_RESPONSE routeId={} traceId={} method={} path={} upstreamStatus={} contentType={} body={}",
                    routeId,
                    context.traceId(),
                    upstreamMethod(route, context),
                    context.path(),
                    status.value(),
                    contentTypeValue(contentType),
                    DebugLogSanitizer.body(body));
            return Mono.error(new ObservedBffException(
                    ErrorCode.BAD_GATEWAY,
                    "Upstream service error",
                    Integer.toString(status.value()),
                    FAILURE_UPSTREAM_STATUS_ERROR));
        }

        if (body == null || body.isBlank()) {
            return Mono.just(new ProxyResult(status.value(), contentTypeValue(contentType), objectMapper.createObjectNode()));
        }

        return Mono.fromCallable(() -> new ProxyResult(status.value(), contentTypeValue(contentType), objectMapper.readTree(body)))
                .onErrorMap(error -> mapInvalidUpstreamBody(route, status, contentType));
    }

    private Mono<RawProxyResult> toRawProxyResult(
            Route route,
            ProxyRequestContext context,
            int upstreamStatus,
            HttpHeaders upstreamHeaders,
            byte[] body,
            boolean fallback
    ) {
        logProxyResponse(route, context, upstreamStatus, upstreamHeaders, body, fallback);
        if (isLegacySessionExpiredHtml(route, upstreamStatus, upstreamHeaders, body)) {
            return expireSession(context)
                    .thenReturn(legacySessionExpiredResult());
        }
        return Mono.just(new RawProxyResult(
                upstreamStatus,
                responseHeaders(upstreamHeaders),
                body));
    }

    private BffException mapInvalidUpstreamBody(Route route, HttpStatusCode status, MediaType contentType) {
        if (route.isHtmlResponseMeansSessionExpired()
                && contentType != null
                && contentType.toString().toLowerCase(Locale.ROOT).contains("html")) {
            return new ObservedBffException(
                    ErrorCode.SESSION_EXPIRED,
                    Integer.toString(status.value()),
                    FAILURE_HTML_SESSION_EXPIRED);
        }
        return new ObservedBffException(
                ErrorCode.BAD_GATEWAY,
                "Upstream response is not valid JSON",
                Integer.toString(status.value()),
                FAILURE_INVALID_JSON);
    }

    private Mono<Void> expireSession(ProxyRequestContext context) {
        if (context.session() == null || !hasText(context.session().sid())) {
            return Mono.empty();
        }
        return sessionService.expire(context.session().sid())
                .onErrorResume(error -> {
                    log.warn("BCM_PROXY_SESSION_EXPIRE_FAILED traceId={} sessionPresent=true errorType={}",
                            context.traceId(),
                            error.getClass().getSimpleName());
                    return Mono.empty();
                });
    }

    private static RawProxyResult legacySessionExpiredResult() {
        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_JSON);
        return new RawProxyResult(200, headers, LEGACY_SESSION_EXPIRED_BODY);
    }

    private static boolean isLegacySessionExpiredHtml(
            Route route,
            int upstreamStatus,
            HttpHeaders headers,
            byte[] body
    ) {
        return route.isLegacyPassthrough()
                && route.isHtmlResponseMeansSessionExpired()
                && upstreamStatus == 200
                && responseLooksHtml(headers, body);
    }

    private static boolean responseLooksHtml(HttpHeaders headers, byte[] body) {
        MediaType contentType = headers == null ? null : headers.getContentType();
        if (contentType != null && contentType.toString().toLowerCase(Locale.ROOT).contains("html")) {
            return true;
        }
        if (body == null || body.length == 0) {
            return false;
        }
        String sample = new String(body, 0, Math.min(body.length, 512), StandardCharsets.UTF_8)
                .toLowerCase(Locale.ROOT);
        return sample.contains("<html") || sample.contains("temporary suspension of service");
    }

    private static void setIfPresent(HttpHeaders headers, String name, String value) {
        if (value != null && !value.isBlank()) {
            headers.set(name, value);
        }
    }

    private static String contentTypeValue(MediaType contentType) {
        return contentType == null ? "" : contentType.toString();
    }

    private static HttpHeaders responseHeaders(HttpHeaders upstreamHeaders) {
        HttpHeaders target = new HttpHeaders();
        if (upstreamHeaders == null || upstreamHeaders.isEmpty()) {
            return target;
        }
        upstreamHeaders.forEach((name, values) -> {
            if (isBlockedResponseHeader(name) || values == null || values.isEmpty()) {
                return;
            }
            target.put(name, values);
        });
        return target;
    }

    private static String upstreamMethod(Route route, ProxyRequestContext context) {
        if (route.isLegacyPassthrough() && hasText(context.method())) {
            return context.method().trim().toUpperCase(Locale.ROOT);
        }
        return route.getMethod();
    }

    private static String upstreamUri(Route route, ProxyRequestContext context) {
        String upstreamPath = route.isLegacyPassthrough()
                ? legacyPassthroughPath(route, context.path())
                : route.getUpstreamPath();
        if (context.query() == null || context.query().isBlank()) {
            return upstreamPath;
        }
        String separator = upstreamPath.contains("?") ? "&" : "?";
        return upstreamPath + separator + context.query();
    }

    private static String legacyPassthroughPath(Route route, String requestPath) {
        String path = hasText(requestPath) ? requestPath : "/";
        String publicPrefix = wildcardPrefix(route.getPublicPath());
        String upstreamPrefix = route.getUpstreamPath();
        if (!hasText(publicPrefix) || !hasText(upstreamPrefix)) {
            return path;
        }

        String normalizedPublicPrefix = trimTrailingSlash(publicPrefix);
        if (path.equals(normalizedPublicPrefix)) {
            return trimTrailingSlash(upstreamPrefix);
        }

        String publicPrefixWithSlash = normalizedPublicPrefix + "/";
        if (!path.startsWith(publicPrefixWithSlash)) {
            return path;
        }

        return joinPathPrefix(upstreamPrefix, path.substring(publicPrefixWithSlash.length()));
    }

    private static String wildcardPrefix(String publicPath) {
        if (!hasText(publicPath)) {
            return "";
        }
        int wildcardIndex = publicPath.indexOf("**");
        String prefix = wildcardIndex >= 0 ? publicPath.substring(0, wildcardIndex) : publicPath;
        return trimTrailingSlash(prefix);
    }

    private static String joinPathPrefix(String upstreamPrefix, String suffix) {
        if (!hasText(suffix)) {
            return upstreamPrefix;
        }
        if (upstreamPrefix.endsWith("/")) {
            return upstreamPrefix + suffix;
        }
        return upstreamPrefix + "/" + suffix;
    }

    private static String trimTrailingSlash(String value) {
        if (!hasText(value)) {
            return "";
        }
        String trimmed = value.trim();
        if (trimmed.length() > 1 && trimmed.endsWith("/")) {
            return trimmed.substring(0, trimmed.length() - 1);
        }
        return trimmed;
    }

    private void recordSuccess(
            String routeId,
            Route route,
            ProxyRequestContext context,
            ProxyResult result,
            long startedAtNanos
    ) {
        Duration duration = elapsed(startedAtNanos);
        recordMetric(routeId, route, context, "success", Integer.toString(result.upstreamStatus()), "none", FAILURE_NONE, duration);
        log.info("BCM_PROXY_ACCESS routeId={} traceId={} method={} upstreamStatus={} outcome=success errorCode=none failureReason=none durationMs={} queryPresent={}",
                routeId,
                context.traceId(),
                upstreamMethod(route, context),
                result.upstreamStatus(),
                duration.toMillis(),
                context.query() != null && !context.query().isBlank());
    }

    private void recordRawSuccess(
            String routeId,
            Route route,
            ProxyRequestContext context,
            RawProxyResult result,
            long startedAtNanos
    ) {
        Duration duration = elapsed(startedAtNanos);
        recordMetric(routeId, route, context, "success", Integer.toString(result.statusCode()), "none", FAILURE_NONE, duration);
        log.info("BCM_PROXY_ACCESS routeId={} traceId={} method={} upstreamStatus={} outcome=success errorCode=none failureReason=none durationMs={} queryPresent={}",
                routeId,
                context.traceId(),
                upstreamMethod(route, context),
                result.statusCode(),
                duration.toMillis(),
                context.query() != null && !context.query().isBlank());
    }

    private void recordFailure(
            String routeId,
            Route route,
            ProxyRequestContext context,
            Throwable error,
            long startedAtNanos
    ) {
        Duration duration = elapsed(startedAtNanos);
        String errorCode = errorCode(error);
        String upstreamStatus = upstreamStatus(error);
        String failureReason = failureReason(error);
        recordMetric(routeId, route, context, "error", upstreamStatus, errorCode, failureReason, duration);
        log.warn("BCM_PROXY_ACCESS routeId={} traceId={} method={} upstreamStatus={} outcome=error errorCode={} failureReason={} errorType={} durationMs={} queryPresent={}",
                routeId,
                context.traceId(),
                upstreamMethod(route, context),
                upstreamStatus,
                errorCode,
                failureReason,
                error.getClass().getSimpleName(),
                duration.toMillis(),
                context.query() != null && !context.query().isBlank());
    }

    private void recordMetric(
            String routeId,
            Route route,
            ProxyRequestContext context,
            String outcome,
            String upstreamStatus,
            String errorCode,
            String failureReason,
            Duration duration
    ) {
        if (meterRegistry == null) {
            return;
        }

        Timer.builder(METRIC_PROXY_DURATION)
                .description("BCM BFF proxy upstream request duration")
                .tag("routeId", routeId)
                .tag("method", upstreamMethod(route, context))
                .tag("outcome", outcome)
                .tag("upstreamStatus", upstreamStatus)
                .tag("errorCode", errorCode)
                .tag("failureReason", failureReason)
                .register(meterRegistry)
                .record(duration);
    }

    private static Duration elapsed(long startedAtNanos) {
        return Duration.ofNanos(System.nanoTime() - startedAtNanos);
    }

    private static String errorCode(Throwable error) {
        if (error instanceof BffException bffException) {
            return bffException.errorCode().code();
        }
        return error.getClass().getSimpleName();
    }

    private static String upstreamStatus(Throwable error) {
        if (error instanceof ObservedBffException observedBffException) {
            return observedBffException.upstreamStatus();
        }
        return STATUS_NONE;
    }

    private static String failureReason(Throwable error) {
        if (error instanceof ObservedBffException observedBffException) {
            return observedBffException.failureReason();
        }
        return FAILURE_UNKNOWN;
    }

    private static boolean isRetryable(Throwable error) {
        if (error instanceof BffException bffException) {
            ErrorCode errorCode = bffException.errorCode();
            return errorCode == ErrorCode.BAD_GATEWAY || errorCode == ErrorCode.UPSTREAM_TIMEOUT;
        }
        return error instanceof TimeoutException;
    }

    private static boolean isCircuitFailure(Throwable error) {
        if (error instanceof BffException bffException) {
            ErrorCode errorCode = bffException.errorCode();
            return errorCode == ErrorCode.BAD_GATEWAY || errorCode == ErrorCode.UPSTREAM_TIMEOUT;
        }
        return false;
    }

    private WebClient webClient(Route route, boolean fallback) {
        if (route.getUpstreamSystem() == UpstreamSystem.BCO) {
            return fallback ? bcoFallbackWebClient : bcoWebClient;
        }
        return fallback ? bcmFallbackWebClient : bcmWebClient;
    }

    private ProxyEndpoint endpoint(Route route) {
        return route.getUpstreamSystem() == UpstreamSystem.BCO ? bcoEndpoint : bcmEndpoint;
    }

    private static boolean shouldTryFallback(Throwable error, ProxyEndpoint endpoint) {
        return endpoint.hasFallback()
                && (error instanceof WebClientRequestException || error instanceof TimeoutException);
    }

    private static void logProxyRequest(
            String routeId,
            Route route,
            ProxyRequestContext context,
            URI upstreamUri,
            String method,
            HttpHeaders headers,
            JsonNode requestBody,
            boolean fallback
    ) {
        if (!log.isDebugEnabled()) {
            return;
        }

        log.debug(
                "BCM_PROXY_REQUEST routeId={} traceId={} method={} upstreamSystem={} upstreamUri={} fallback={} headers={} body={}",
                routeId,
                context.traceId(),
                method,
                route.getUpstreamSystem(),
                upstreamUri,
                fallback,
                DebugLogSanitizer.headers(headers),
                DebugLogSanitizer.body(requestBody)
        );
    }

    private static void logProxyRequest(
            String routeId,
            Route route,
            ProxyRequestContext context,
            URI upstreamUri,
            String method,
            HttpHeaders headers,
            byte[] requestBody,
            boolean fallback
    ) {
        if (!log.isDebugEnabled()) {
            return;
        }

        log.debug(
                "BCM_PROXY_REQUEST routeId={} traceId={} method={} upstreamSystem={} upstreamUri={} fallback={} headers={} body={}",
                routeId,
                context.traceId(),
                method,
                route.getUpstreamSystem(),
                upstreamUri,
                fallback,
                DebugLogSanitizer.headers(headers),
                DebugLogSanitizer.body(requestBody)
        );
    }

    private static void logProxyResponse(
            Route route,
            ProxyRequestContext context,
            int upstreamStatus,
            HttpHeaders headers,
            byte[] responseBody,
            boolean fallback
    ) {
        if (!log.isDebugEnabled()) {
            return;
        }

        log.debug(
                "BCM_PROXY_RESPONSE traceId={} method={} path={} upstreamSystem={} upstreamStatus={} fallback={} headers={} body={}",
                context.traceId(),
                upstreamMethod(route, context),
                context.path(),
                route.getUpstreamSystem(),
                upstreamStatus,
                fallback,
                DebugLogSanitizer.headers(headers),
                DebugLogSanitizer.body(responseBody)
        );
    }

    private static void copyForwardableRequestHeaders(HttpHeaders source, HttpHeaders target) {
        if (source == null || source.isEmpty()) {
            return;
        }

        source.forEach((name, values) -> {
            if (!isForwardableHeader(name)) {
                return;
            }
            List<String> safeValues = values == null
                    ? List.of()
                    : values.stream()
                    .filter(WebClientBcmProxyService::hasText)
                    .toList();
            if (!safeValues.isEmpty()) {
                target.put(name, safeValues);
            }
        });
    }

    private static boolean isForwardableHeader(String name) {
        return hasText(name) && !BLOCKED_FORWARD_HEADERS.contains(name.trim().toLowerCase(Locale.ROOT));
    }

    private static boolean requestCanHaveBody(String method) {
        String normalized = method == null ? "" : method.trim().toUpperCase(Locale.ROOT);
        return !HttpMethod.GET.name().equals(normalized) && !HttpMethod.HEAD.name().equals(normalized);
    }

    private static boolean hasRequestBody(byte[] body) {
        return body != null && body.length > 0;
    }

    private static boolean isBlockedResponseHeader(String name) {
        return !hasText(name) || BLOCKED_RESPONSE_HEADERS.contains(name.trim().toLowerCase(Locale.ROOT));
    }

    private static void setBcmSessionAuthorization(HttpHeaders headers, String bcmSessionId) {
        if (hasText(bcmSessionId)) {
            headers.set(HeaderConstants.AUTHORIZATION, "Bearer " + bearerSessionId(bcmSessionId));
        }
    }

    private static String bearerSessionId(String bcmSessionId) {
        String trimmed = bcmSessionId.trim();
        for (String part : trimmed.split(";")) {
            int separator = part.indexOf('=');
            if (separator <= 0) {
                continue;
            }
            String name = part.substring(0, separator).trim();
            if ("jsessionid".equals(name.toLowerCase(Locale.ROOT))) {
                String value = part.substring(separator + 1).trim();
                if (hasText(value)) {
                    return value;
                }
            }
        }
        return trimmed;
    }

    private static boolean hasText(String value) {
        return value != null && !value.isBlank();
    }

    private static class ObservedBffException extends BffException {
        private final String upstreamStatus;
        private final String failureReason;

        ObservedBffException(ErrorCode errorCode, String upstreamStatus, String failureReason) {
            super(errorCode);
            this.upstreamStatus = upstreamStatus;
            this.failureReason = failureReason;
        }

        ObservedBffException(ErrorCode errorCode, String message, String upstreamStatus, String failureReason) {
            super(errorCode, message);
            this.upstreamStatus = upstreamStatus;
            this.failureReason = failureReason;
        }

        String upstreamStatus() {
            return upstreamStatus;
        }

        String failureReason() {
            return failureReason;
        }
    }

    private static class RouteGuard {
        private final Semaphore bulkhead;
        private final AtomicInteger consecutiveFailures = new AtomicInteger();
        private final AtomicLong openUntilEpochMillis = new AtomicLong();

        RouteGuard(Route route) {
            this.bulkhead = new Semaphore(route.getBulkheadMaxConcurrentRequests());
        }

        boolean tryAcquire() {
            return bulkhead.tryAcquire();
        }

        void release() {
            bulkhead.release();
        }

        boolean allowRequest(Route route) {
            if (!route.isCircuitBreakerEnabled()) {
                return true;
            }
            long openUntil = openUntilEpochMillis.get();
            return openUntil <= 0 || System.currentTimeMillis() >= openUntil;
        }

        void onSuccess(Route route) {
            if (!route.isCircuitBreakerEnabled()) {
                return;
            }
            consecutiveFailures.set(0);
            openUntilEpochMillis.set(0);
        }

        void onFailure(Route route, Throwable error) {
            if (!route.isCircuitBreakerEnabled() || !isCircuitFailure(error)) {
                return;
            }

            int failures = consecutiveFailures.incrementAndGet();
            if (failures >= route.getCircuitBreakerFailureThreshold()) {
                openUntilEpochMillis.set(System.currentTimeMillis() + route.getCircuitBreakerOpenMillis());
            }
        }
    }
}

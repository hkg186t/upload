package com.hkbea.bcm.bff.proxy.service;

import com.hkbea.bcm.bff.proxy.model.RawProxyRequestContext;
import com.hkbea.bcm.bff.proxy.model.RawProxyResult;
import reactor.core.publisher.Mono;

public interface BcmRawProxyService {
    Mono<RawProxyResult> proxy(byte[] requestBody, RawProxyRequestContext context);
}

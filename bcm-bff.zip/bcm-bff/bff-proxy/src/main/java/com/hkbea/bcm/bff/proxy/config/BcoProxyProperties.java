package com.hkbea.bcm.bff.proxy.config;

import org.springframework.boot.context.properties.ConfigurationProperties;

import java.util.ArrayList;
import java.util.List;

@ConfigurationProperties(prefix = "bff.proxy.bco")
public class BcoProxyProperties {
    private static final long DEFAULT_RESPONSE_TIMEOUT_MILLIS = 30000;
    private static final int DEFAULT_PUBLIC_KEY_RETRY_MAX_ATTEMPTS = 2;
    private static final long DEFAULT_PUBLIC_KEY_RETRY_BACKOFF_MILLIS = 100;
    public static final String SESSION_NONCE_PATH = "/digx/v1/session/nonce";
    public static final String PUBLIC_KEY_PATH = "/digx/cz/v1/publicKey";
    public static final String BCM_APPROVE_PATH = "/bcmApprove";

    private boolean enabled = true;
    private String baseUrl = "https://cdcuat-cmapp1.intranet.hkbea.com:9443";
    private String fallbackIp = "192.168.20.45";
    private boolean preferFallbackIp = true;
    private String legacyPassthroughPathPrefix = "/digx/";
    private long responseTimeoutMillis = DEFAULT_RESPONSE_TIMEOUT_MILLIS;
    private int publicKeyRetryMaxAttempts = DEFAULT_PUBLIC_KEY_RETRY_MAX_ATTEMPTS;
    private long publicKeyRetryBackoffMillis = DEFAULT_PUBLIC_KEY_RETRY_BACKOFF_MILLIS;
    private List<String> publicPaths = new ArrayList<>(List.of(
            SESSION_NONCE_PATH,
            PUBLIC_KEY_PATH,
            BCM_APPROVE_PATH
    ));
    private ProxyTlsProperties tls = new ProxyTlsProperties();
    private ProxyHealthCheckProperties healthCheck = new ProxyHealthCheckProperties();

    public boolean isEnabled() {
        return enabled;
    }

    public void setEnabled(boolean enabled) {
        this.enabled = enabled;
    }

    public String getBaseUrl() {
        return baseUrl;
    }

    public void setBaseUrl(String baseUrl) {
        this.baseUrl = baseUrl;
    }

    public String getFallbackIp() {
        return fallbackIp;
    }

    public void setFallbackIp(String fallbackIp) {
        this.fallbackIp = fallbackIp;
    }

    public boolean isPreferFallbackIp() {
        return preferFallbackIp;
    }

    public void setPreferFallbackIp(boolean preferFallbackIp) {
        this.preferFallbackIp = preferFallbackIp;
    }

    public String getLegacyPassthroughPathPrefix() {
        return legacyPassthroughPathPrefix;
    }

    public void setLegacyPassthroughPathPrefix(String legacyPassthroughPathPrefix) {
        this.legacyPassthroughPathPrefix = legacyPassthroughPathPrefix;
    }

    public long getResponseTimeoutMillis() {
        return responseTimeoutMillis;
    }

    public void setResponseTimeoutMillis(long responseTimeoutMillis) {
        this.responseTimeoutMillis = responseTimeoutMillis;
    }

    public List<String> getPublicPaths() {
        return publicPaths;
    }

    public void setPublicPaths(List<String> publicPaths) {
        this.publicPaths = publicPaths == null ? new ArrayList<>() : publicPaths;
    }

    public ProxyTlsProperties getTls() {
        return tls;
    }

    public void setTls(ProxyTlsProperties tls) {
        this.tls = tls == null ? new ProxyTlsProperties() : tls;
    }

    public ProxyHealthCheckProperties getHealthCheck() {
        return healthCheck;
    }

    public void setHealthCheck(ProxyHealthCheckProperties healthCheck) {
        this.healthCheck = healthCheck == null ? new ProxyHealthCheckProperties() : healthCheck;
    }

    public boolean isPublicPath(String path) {
        String normalizedPath = normalizePath(path);
        if (SESSION_NONCE_PATH.equals(normalizedPath)) {
            return false;
        }
        return publicPaths.stream()
                .map(BcoProxyProperties::normalizePath)
                .anyMatch(normalizedPath::equals);
    }

    public long defaultTimeoutMillis() {
        return responseTimeoutMillis > 0 ? responseTimeoutMillis : DEFAULT_RESPONSE_TIMEOUT_MILLIS;
    }

    public int getPublicKeyRetryMaxAttempts() {
        return publicKeyRetryMaxAttempts;
    }

    public void setPublicKeyRetryMaxAttempts(int publicKeyRetryMaxAttempts) {
        this.publicKeyRetryMaxAttempts = publicKeyRetryMaxAttempts;
    }

    public long getPublicKeyRetryBackoffMillis() {
        return publicKeyRetryBackoffMillis;
    }

    public void setPublicKeyRetryBackoffMillis(long publicKeyRetryBackoffMillis) {
        this.publicKeyRetryBackoffMillis = publicKeyRetryBackoffMillis;
    }

    public int publicKeyRetryMaxAttempts() {
        return publicKeyRetryMaxAttempts > 0
                ? publicKeyRetryMaxAttempts
                : DEFAULT_PUBLIC_KEY_RETRY_MAX_ATTEMPTS;
    }

    public long publicKeyRetryBackoffMillis() {
        return publicKeyRetryBackoffMillis > 0
                ? publicKeyRetryBackoffMillis
                : DEFAULT_PUBLIC_KEY_RETRY_BACKOFF_MILLIS;
    }

    private static String normalizePath(String path) {
        if (path == null || path.isBlank()) {
            return "";
        }
        String normalized = path.trim();
        if (normalized.length() > 1 && normalized.endsWith("/")) {
            return normalized.substring(0, normalized.length() - 1);
        }
        return normalized;
    }
}

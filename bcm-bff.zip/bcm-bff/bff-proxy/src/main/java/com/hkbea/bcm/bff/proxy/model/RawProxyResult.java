package com.hkbea.bcm.bff.proxy.model;

import org.springframework.http.HttpHeaders;

public record RawProxyResult(
        int statusCode,
        HttpHeaders headers,
        byte[] body
) {
}

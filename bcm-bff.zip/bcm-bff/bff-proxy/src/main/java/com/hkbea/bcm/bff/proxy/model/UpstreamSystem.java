package com.hkbea.bcm.bff.proxy.model;

public enum UpstreamSystem {
    BCM,
    BCO
}

package com.hkbea.bcm.bff.proxy.service;

import org.springframework.http.HttpHeaders;

import java.net.URI;

final class ProxyEndpoint {
    private final String systemName;
    private final URI primaryBaseUri;
    private final String fallbackIp;
    private final String originalHostHeader;

    ProxyEndpoint(String systemName, String baseUrl, String fallbackIp) {
        this.systemName = systemName;
        this.primaryBaseUri = ProxyEndpointSupport.parseBaseUri(systemName, baseUrl);
        this.fallbackIp = fallbackIp == null || fallbackIp.isBlank() ? "" : fallbackIp.trim();
        this.originalHostHeader = ProxyEndpointSupport.hostHeader(primaryBaseUri);
    }

    String systemName() {
        return systemName;
    }

    boolean hasFallback() {
        return !fallbackIp.isBlank();
    }

    URI primaryUri(String pathAndQuery) {
        return ProxyEndpointSupport.resolveAgainstBase(primaryBaseUri, pathAndQuery);
    }

    URI fallbackUri(String pathAndQuery) {
        if (!hasFallback()) {
            throw new IllegalStateException(systemName + " fallback IP is not configured");
        }
        return primaryUri(pathAndQuery);
    }

    String primaryHost() {
        return primaryBaseUri.getHost();
    }

    String fallbackIp() {
        return fallbackIp;
    }

    String primaryBaseUrlForLog() {
        return ProxyEndpointSupport.safeUriForLog(primaryBaseUri);
    }

    String fallbackBaseUrlForLog() {
        if (!hasFallback()) {
            return "";
        }
        return ProxyEndpointSupport.safeUriForLog(primaryBaseUri) + " via " + fallbackIp;
    }

    void applyFallbackHostHeader(HttpHeaders headers) {
        headers.set(HttpHeaders.HOST, originalHostHeader);
    }
}

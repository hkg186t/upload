package com.hkbea.bcm.bff.proxy.model;

import com.hkbea.bcm.bff.access.model.SessionRecord;
import org.springframework.http.HttpHeaders;

public record RawProxyRequestContext(
        String traceId,
        String method,
        String path,
        String query,
        HttpHeaders requestHeaders,
        SessionRecord session
) {
}

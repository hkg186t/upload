package com.hkbea.bcm.bff.proxy.service;

import com.hkbea.bcm.bff.proxy.config.BcoProxyProperties;
import com.hkbea.bcm.bff.proxy.model.RawProxyRequestContext;
import com.hkbea.bcm.bff.proxy.model.RawProxyResult;
import com.hkbea.bcm.bff.proxy.model.UpstreamSystem;
import com.hkbea.bcm.bff.shared.http.HeaderConstants;
import com.hkbea.bcm.bff.shared.logging.DebugLogSanitizer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.stereotype.Service;
import org.springframework.web.reactive.function.client.WebClient;
import org.springframework.web.reactive.function.client.WebClientRequestException;
import reactor.core.publisher.Mono;
import reactor.core.publisher.SignalType;
import reactor.util.retry.Retry;

import java.net.URI;
import java.net.URLDecoder;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.time.Duration;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.Set;
import java.util.concurrent.TimeoutException;

@Service
public class WebClientBcoProxyService implements BcoProxyService {
    private static final Logger log = LoggerFactory.getLogger(WebClientBcoProxyService.class);
    private static final String DEFAULT_USER_AGENT = "Mozilla/5.0 Chrome/144.0.0.0";
    private static final String DEFAULT_LOCALE = "en";
    private static final String RSA_KEY_INDICATOR = "RSAKeyIndicator";
    private static final String LOGIN_TYPE = "loginType";
    private static final String LOGIN_AUTH_TYPE = "Login-Auth-Type";
    private static final String LOGIN_AUTH_DATA = "Login-Auth-Data";
    private static final String TOKEN = "token";
    private static final String X_NONCE_COUNT = "x-noncecount";
    private static final String X_NONCE = "x-nonce";
    private static final String LOGIN_CHANNEL = "Login-Channel";
    private static final String X_CHALLENGE = "X-Challenge";
    private static final String X_CHALLENGE_RESPONSE = "X-Challenge_Response";
    private static final String MAC_KEY = "MacKey";
    private static final String MAC_MODULUS = "MacModulus";
    private static final String MAC_ENCRYPTED_DATA = "MacEncryptedData";
    private static final String MAC_RSA_INDICATOR = "MacRSAIndicator";
    private static final String PUBLIC_EXPONENT = "PublicExponent";
    private static final String X_TARGET_UNIT = "X-Target-Unit";
    private static final String PUBLIC_KEY = "PublicKey";
    private static final String ITOKEN_AUTH_TYPE = "Itoken-Auth-Type";
    private static final String USER_ROLE = "User-Role";
    private static final String BIO_TYPE = "Bio-Type";
    private static final String REG_METHOD = "Reg-Method";
    private static final String AUTH_METHOD = "Auth-Method";
    private static final String APP_VERSION = "App-Version";
    private static final String X_DEVICE_ID = "X-Device-Id";
    private static final String X_DEVICE_MODEL = "X-Device-Model";
    private static final String X_DEVICE_BRAND = "X-Device-Brand";
    private static final String X_DEVICE_OS = "X-Device-Os";
    private static final String X_DEVICE_OS_VERSION = "X-Device-Os-Version";
    private static final String PLATFORM = "Platform";
    private static final String APPROVE_PATH_SUFFIX = "/approve";
    private static final String TEXT_PLAIN = "text/plain";
    private static final String OVERRIDE_CONTENT_TYPE = "Override-Content-Type";
    private static final Set<String> BLOCKED_RESPONSE_HEADERS = Set.of(
            "content-length",
            "transfer-encoding",
            "connection",
            "keep-alive",
            "proxy-authenticate",
            "proxy-authorization",
            "te",
            "trailer",
            "upgrade"
    );

    private final BcoProxyProperties properties;
    private final ProxyEndpoint endpoint;
    private final WebClient webClient;
    private final WebClient fallbackWebClient;

    public WebClientBcoProxyService(BcoProxyProperties properties, WebClient.Builder webClientBuilder) {
        this.properties = properties;
        this.endpoint = new ProxyEndpoint(UpstreamSystem.BCO.name(), properties.getBaseUrl(), properties.getFallbackIp());
        this.webClient = ProxyWebClientFactory.bcoLegacyWebClient(webClientBuilder, properties.getTls());
        this.fallbackWebClient = ProxyWebClientFactory.bcoLegacyWebClient(webClientBuilder, endpoint, properties.getTls());
    }

    @Override
    public Mono<RawProxyResult> proxy(byte[] requestBody, RawProxyRequestContext context) {
        String pathAndQuery = pathAndQuery(context);
        long startedAtNanos = System.nanoTime();
        boolean preferFallback = properties.isPreferFallbackIp() && endpoint.hasFallback();
        if (preferFallback) {
            log.debug("BFF_PROXY_PREFER_FALLBACK system=BCO traceId={} primaryBaseUrl={} fallbackBaseUrl={}",
                    context.traceId(),
                    endpoint.primaryBaseUrlForLog(),
                    endpoint.fallbackBaseUrlForLog());
        }

        return executeWithPublicKeyRetry(requestBody, context, pathAndQuery, preferFallback)
                .onErrorResume(error -> !preferFallback && shouldTryFallback(error)
                        ? executeFallback(requestBody, context, pathAndQuery, error)
                        : Mono.error(error))
                .doOnSuccess(result -> log.info(
                        "BCO_PROXY_ACCESS traceId={} method={} path={} upstreamStatus={} outcome=success durationMs={} queryPresent={}",
                        context.traceId(),
                        context.method(),
                        context.path(),
                        result.statusCode(),
                        elapsedMillis(startedAtNanos),
                        context.query() != null && !context.query().isBlank()))
                .doOnError(error -> log.warn(
                        "BCO_PROXY_ACCESS traceId={} method={} path={} upstreamStatus=none outcome=error errorType={} durationMs={} queryPresent={}",
                        context.traceId(),
                        context.method(),
                        context.path(),
                        error.getClass().getSimpleName(),
                        elapsedMillis(startedAtNanos),
                        context.query() != null && !context.query().isBlank()))
                .doFinally(signalType -> {
                    if (signalType == SignalType.CANCEL) {
                        log.warn(
                                "BCO_PROXY_ACCESS traceId={} method={} path={} upstreamStatus=none outcome=cancelled errorType=cancelled durationMs={} queryPresent={}",
                                context.traceId(),
                                context.method(),
                                context.path(),
                                elapsedMillis(startedAtNanos),
                                context.query() != null && !context.query().isBlank());
                    }
                });
    }

    private Mono<RawProxyResult> executeFallback(
            byte[] requestBody,
            RawProxyRequestContext context,
            String pathAndQuery,
            Throwable primaryError
    ) {
        log.warn("BFF_PROXY_FALLBACK system=BCO traceId={} primaryBaseUrl={} fallbackBaseUrl={} reason={}",
                context.traceId(),
                endpoint.primaryBaseUrlForLog(),
                endpoint.fallbackBaseUrlForLog(),
                primaryError.getClass().getSimpleName());
        return executeWithPublicKeyRetry(requestBody, context, pathAndQuery, true);
    }

    private Mono<RawProxyResult> executeWithPublicKeyRetry(
            byte[] requestBody,
            RawProxyRequestContext context,
            String pathAndQuery,
            boolean fallback
    ) {
        Mono<RawProxyResult> upstream = Mono.defer(() -> execute(requestBody, context, pathAndQuery, fallback));
        if (!shouldRetryPublicKey(context)) {
            return upstream;
        }

        return upstream.retryWhen(Retry.backoff(
                        properties.publicKeyRetryMaxAttempts() - 1L,
                        Duration.ofMillis(properties.publicKeyRetryBackoffMillis()))
                .filter(WebClientBcoProxyService::isRetryablePublicKeyError)
                .doBeforeRetry(signal -> log.warn(
                        "BCO_PROXY_RETRY traceId={} method={} path={} retryAttempt={} fallback={} errorType={} reason={}",
                        context.traceId(),
                        context.method(),
                        context.path(),
                        signal.totalRetries() + 1,
                        fallback,
                        signal.failure().getClass().getSimpleName(),
                        sanitize(signal.failure().getMessage())))
                .onRetryExhaustedThrow((retryBackoffSpec, retrySignal) -> retrySignal.failure()));
    }

    private Mono<RawProxyResult> execute(
            byte[] requestBody,
            RawProxyRequestContext context,
            String pathAndQuery,
            boolean fallback
    ) {
        URI upstreamUri = fallback ? endpoint.fallbackUri(pathAndQuery) : endpoint.primaryUri(pathAndQuery);
        HttpHeaders outboundHeaders = new HttpHeaders();
        applyForwardHeaders(outboundHeaders, context, fallback);
        byte[] outboundRequestBody = normalizeApproveRequestBody(requestBody, context, outboundHeaders);
        logProxyRequest(context, upstreamUri, outboundHeaders, outboundRequestBody, fallback);

        WebClient.RequestBodySpec requestSpec = webClient(fallback)
                .method(HttpMethod.valueOf(context.method()))
                .uri(upstreamUri)
                .headers(headers -> headers.addAll(outboundHeaders));

        WebClient.RequestHeadersSpec<?> headersSpec = hasRequestBody(outboundRequestBody)
            ? requestSpec.bodyValue(outboundRequestBody)
                : requestSpec;

        return headersSpec.exchangeToMono(response -> {
                    int upstreamStatus = response.statusCode().value();
                    HttpHeaders upstreamHeaders = response.headers().asHttpHeaders();
                    return response.bodyToMono(byte[].class)
                            .defaultIfEmpty(new byte[0])
                            .map(body -> {
                                logProxyResponse(context, upstreamStatus, upstreamHeaders, body, fallback);
                                return new RawProxyResult(
                                        upstreamStatus,
                                        responseHeaders(upstreamHeaders),
                                        body);
                            });
                })
                .timeout(Duration.ofMillis(properties.defaultTimeoutMillis()));
    }

    private static byte[] normalizeApproveRequestBody(
            byte[] requestBody,
            RawProxyRequestContext context,
            HttpHeaders outboundHeaders
    ) {
        if (!hasRequestBody(requestBody)
                || !hasText(context.path())
                || !context.path().endsWith(APPROVE_PATH_SUFFIX)
                || !isTextPlain(outboundHeaders)) {
            return requestBody;
        }

        if (requestBody.length >= 2
                && requestBody[0] == '"'
                && requestBody[requestBody.length - 1] == '"') {
            log.debug("BCO_PROXY_APPROVE_BODY_NORMALIZED traceId={} path={} action=trim-wrapping-quotes",
                    context.traceId(),
                    context.path());
            byte[] trimmed = new byte[requestBody.length - 2];
            System.arraycopy(requestBody, 1, trimmed, 0, trimmed.length);
            return trimmed;
        }
        return requestBody;
    }

    private static boolean isTextPlain(HttpHeaders headers) {
        String contentType = headers == null ? null : headers.getFirst(HttpHeaders.CONTENT_TYPE);
        return hasText(contentType) && contentType.toLowerCase(Locale.ROOT).contains(TEXT_PLAIN);
    }

    private WebClient webClient(boolean fallback) {
        return fallback ? fallbackWebClient : webClient;
    }

    private void applyForwardHeaders(HttpHeaders headers, RawProxyRequestContext context, boolean fallback) {
        boolean publicPath = properties.isPublicPath(context.path());
        setLegacyGoUserAgent(context.requestHeaders(), headers);
        copyLegacyGoRequestHeaders(context.requestHeaders(), headers, publicPath);
        applyOverrideContentType(context.requestHeaders(), headers);
        setLegacyGoLocale(context.requestHeaders(), headers);
        if (!publicPath) {
            setSessionCookie(headers, context);
        }
        if (fallback) {
            endpoint.applyFallbackHostHeader(headers);
        }
    }

    private static void applyOverrideContentType(HttpHeaders source, HttpHeaders target) {
        String overrideContentType = source == null ? null : source.getFirst(OVERRIDE_CONTENT_TYPE);
        if (hasText(overrideContentType)) {
            target.set(HttpHeaders.CONTENT_TYPE, overrideContentType.trim());
        }
    }

    private static HttpHeaders responseHeaders(HttpHeaders upstreamHeaders) {
        HttpHeaders target = new HttpHeaders();
        upstreamHeaders.forEach((name, values) -> {
            if (isBlockedResponseHeader(name) || values == null || values.isEmpty()) {
                return;
            }
            target.put(name, values);
        });
        return target;
    }

    private static void setLegacyGoUserAgent(HttpHeaders source, HttpHeaders target) {
        String userAgent = source == null ? null : source.getFirst(HttpHeaders.USER_AGENT);
        target.set(HttpHeaders.USER_AGENT, hasText(userAgent) ? userAgent : DEFAULT_USER_AGENT);
    }

    private static void setLegacyGoLocale(HttpHeaders source, HttpHeaders target) {
        target.set(HeaderConstants.LOCALE, legacyGoLocale(source));
    }

    private static void copyLegacyGoRequestHeaders(HttpHeaders source, HttpHeaders target, boolean publicEndpoint) {
        if (source == null || source.isEmpty()) {
            return;
        }
        source.forEach((name, values) -> {
            String normalizedName = normalizeHeaderName(name);
            switch (normalizedName) {
                case "rsakeyindicator" -> putHeader(target, RSA_KEY_INDICATOR, values);
                case "logintype" -> putHeader(target, LOGIN_TYPE, values);
                case "login-auth-type" -> putHeader(target, LOGIN_AUTH_TYPE, values);
                case "login-auth-data" -> putHeader(target, LOGIN_AUTH_DATA, values);
                case "login-channel" -> putHeader(target, LOGIN_CHANNEL, values);
                case "locale" -> putHeader(target, HeaderConstants.LOCALE, values);
                case "token" -> putHeader(target, TOKEN, values);
                case "cookie" -> {
                    if (!publicEndpoint) {
                        putHeader(target, HttpHeaders.COOKIE, values);
                    }
                }
                case "x-noncecount" -> putHeader(target, X_NONCE_COUNT, values);
                case "x-nonce" -> putHeader(target, X_NONCE, values);
                case "content-type" -> putHeader(target, HttpHeaders.CONTENT_TYPE, values);
                case "accept" -> {
                    if (!publicEndpoint) {
                        putHeader(target, HttpHeaders.ACCEPT, values);
                    }
                }
                case "accept-encoding" -> {
                    if (!publicEndpoint) {
                        putHeader(target, HttpHeaders.ACCEPT_ENCODING, values);
                    }
                }
                case "connection" -> {
                    if (!publicEndpoint) {
                        putHeader(target, "Connection", values);
                    }
                }
                case "x-challenge" -> putHeader(target, X_CHALLENGE, values);
                case "x-challenge_response" -> putHeader(target, X_CHALLENGE_RESPONSE, values);
                case "mackey" -> putHeader(target, MAC_KEY, values);
                case "macmodulus" -> putHeader(target, MAC_MODULUS, values);
                case "macencrypteddata" -> putHeader(target, MAC_ENCRYPTED_DATA, values);
                case "macrsaindicator" -> putHeader(target, MAC_RSA_INDICATOR, values);
                case "publicexponent" -> putHeader(target, PUBLIC_EXPONENT, values);
                case "x-target-unit" -> putHeader(target, X_TARGET_UNIT, values);
                case "publickey" -> putHeader(target, PUBLIC_KEY, values);
                case "itoken-auth-type" -> putHeader(target, ITOKEN_AUTH_TYPE, values);
                case "user-role" -> putHeader(target, USER_ROLE, values);
                case "bio-type" -> putHeader(target, BIO_TYPE, values);
                case "reg-method" -> putHeader(target, REG_METHOD, values);
                case "auth-method" -> putHeader(target, AUTH_METHOD, values);
                case "app-version" -> putHeader(target, APP_VERSION, values);
                case "x-device-id" -> putHeader(target, X_DEVICE_ID, values);
                case "x-device-model" -> putHeader(target, X_DEVICE_MODEL, values);
                case "x-device-brand" -> putHeader(target, X_DEVICE_BRAND, values);
                case "x-device-os" -> putHeader(target, X_DEVICE_OS, values);
                case "x-device-os-version" -> putHeader(target, X_DEVICE_OS_VERSION, values);
                case "platform" -> putHeader(target, PLATFORM, values);
                default -> {
                    // Match the legacy Go proxy allow-list. Public mPaaS headers such as
                    // sign/appid/workspaceid are intentionally not forwarded.
                }
            }
        });
    }

    private static void setSessionCookie(HttpHeaders headers, RawProxyRequestContext context) {
        if (context.session() == null || !hasText(context.session().bcmSessionId())) {
            return;
        }
        headers.set(HttpHeaders.COOKIE, context.session().bcmSessionId().trim());
    }

    private static void putHeader(HttpHeaders target, String name, List<String> values) {
        if (values == null || values.isEmpty()) {
            return;
        }
        List<String> safeValues = values.stream()
                .filter(WebClientBcoProxyService::hasText)
                .toList();
        if (!safeValues.isEmpty()) {
            target.put(name, safeValues);
        }
    }

    private static String pathAndQuery(RawProxyRequestContext context) {
        return context.path() + "?" + queryWithLocale(context.query(), legacyGoLocale(context.requestHeaders()));
    }

    private static String queryWithLocale(String rawQuery, String locale) {
        List<String> pairs = new ArrayList<>();
        if (hasText(rawQuery)) {
            for (String pair : rawQuery.split("&")) {
                if (pair.isBlank() || "locale".equals(queryName(pair))) {
                    continue;
                }
                pairs.add(pair);
            }
        }
        pairs.add("locale=" + encode(locale));
        return String.join("&", pairs);
    }

    private static String queryName(String pair) {
        int separator = pair.indexOf('=');
        String encodedName = separator >= 0 ? pair.substring(0, separator) : pair;
        try {
            return URLDecoder.decode(encodedName, StandardCharsets.UTF_8);
        } catch (IllegalArgumentException error) {
            return encodedName;
        }
    }

    private static String legacyGoLocale(HttpHeaders source) {
        String locale = source == null ? null : source.getFirst(HeaderConstants.LOCALE);
        return hasText(locale) ? locale.trim() : DEFAULT_LOCALE;
    }

    private static String encode(String value) {
        return URLEncoder.encode(value == null ? "" : value, StandardCharsets.UTF_8);
    }

    private boolean shouldTryFallback(Throwable error) {
        return endpoint.hasFallback()
                && (error instanceof WebClientRequestException || error instanceof TimeoutException);
    }

    private boolean shouldRetryPublicKey(RawProxyRequestContext context) {
        return properties.publicKeyRetryMaxAttempts() > 1
                && HttpMethod.GET.matches(context.method())
                && BcoProxyProperties.PUBLIC_KEY_PATH.equals(normalizePath(context.path()));
    }

    private static boolean isRetryablePublicKeyError(Throwable error) {
        return error instanceof WebClientRequestException || error instanceof TimeoutException;
    }

    private static boolean hasRequestBody(byte[] body) {
        return body != null && body.length > 0;
    }

    private static boolean isBlockedResponseHeader(String name) {
        return !hasText(name) || BLOCKED_RESPONSE_HEADERS.contains(normalizeHeaderName(name));
    }

    private static String normalizeHeaderName(String name) {
        return hasText(name) ? name.trim().toLowerCase(Locale.ROOT) : "";
    }

    private static String normalizePath(String path) {
        String normalized = hasText(path) ? path.trim() : "";
        if (normalized.length() > 1 && normalized.endsWith("/")) {
            return normalized.substring(0, normalized.length() - 1);
        }
        return normalized;
    }

    private static void logProxyRequest(
            RawProxyRequestContext context,
            URI upstreamUri,
            HttpHeaders headers,
            byte[] requestBody,
            boolean fallback
    ) {
        if (!log.isDebugEnabled()) {
            return;
        }

        log.debug(
                "BCO_PROXY_REQUEST traceId={} method={} upstreamUri={} fallback={} headers={} body={}",
                context.traceId(),
                context.method(),
                upstreamUri,
                fallback,
                DebugLogSanitizer.headers(headers),
                DebugLogSanitizer.body(requestBody)
        );
    }

    private static void logProxyResponse(
            RawProxyRequestContext context,
            int upstreamStatus,
            HttpHeaders headers,
            byte[] responseBody,
            boolean fallback
    ) {
        if (!log.isDebugEnabled()) {
            return;
        }

        log.debug(
                "BCO_PROXY_RESPONSE traceId={} method={} path={} upstreamStatus={} fallback={} headers={} body={}",
                context.traceId(),
                context.method(),
                context.path(),
                upstreamStatus,
                fallback,
                DebugLogSanitizer.headers(headers),
                DebugLogSanitizer.body(responseBody)
        );
    }

    private static long elapsedMillis(long startedAtNanos) {
        return Duration.ofNanos(System.nanoTime() - startedAtNanos).toMillis();
    }

    private static boolean hasText(String value) {
        return value != null && !value.isBlank();
    }

    private static String sanitize(String message) {
        if (message == null || message.isBlank()) {
            return "";
        }
        return message.replace('\n', ' ').replace('\r', ' ');
    }
}

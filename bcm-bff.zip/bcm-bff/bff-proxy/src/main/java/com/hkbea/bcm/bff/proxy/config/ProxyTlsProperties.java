package com.hkbea.bcm.bff.proxy.config;

public class ProxyTlsProperties {
    private String trustCertFile = "";
    private boolean insecureSkipVerify;

    public String getTrustCertFile() {
        return trustCertFile;
    }

    public void setTrustCertFile(String trustCertFile) {
        this.trustCertFile = trustCertFile;
    }

    public boolean isInsecureSkipVerify() {
        return insecureSkipVerify;
    }

    public void setInsecureSkipVerify(boolean insecureSkipVerify) {
        this.insecureSkipVerify = insecureSkipVerify;
    }
}

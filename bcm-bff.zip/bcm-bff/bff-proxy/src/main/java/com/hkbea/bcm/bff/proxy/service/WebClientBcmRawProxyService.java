package com.hkbea.bcm.bff.proxy.service;

import com.hkbea.bcm.bff.proxy.config.BcmProxyProperties;
import com.hkbea.bcm.bff.proxy.config.BcmProxyProperties.Route;
import com.hkbea.bcm.bff.proxy.model.RawProxyRequestContext;
import com.hkbea.bcm.bff.proxy.model.RawProxyResult;
import com.hkbea.bcm.bff.proxy.model.UpstreamSystem;
import com.hkbea.bcm.bff.shared.http.HeaderConstants;
import com.hkbea.bcm.bff.shared.logging.DebugLogSanitizer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Service;
import org.springframework.web.reactive.function.client.WebClient;
import org.springframework.web.reactive.function.client.WebClientRequestException;
import reactor.core.publisher.Mono;

import java.net.URI;
import java.time.Duration;
import java.util.List;
import java.util.Locale;
import java.util.Set;
import java.util.concurrent.TimeoutException;

@Service
public class WebClientBcmRawProxyService implements BcmRawProxyService {
    private static final Logger log = LoggerFactory.getLogger(WebClientBcmRawProxyService.class);
    private static final String IBM_CLIENT_ID = "x-ibm-client-id";
    private static final String IBM_CLIENT_SECRET = "x-ibm-client-secret";
    private static final Set<String> BLOCKED_FORWARD_HEADERS = Set.of(
            "cookie",
            "host",
            "content-length",
            "transfer-encoding",
            "connection",
            "keep-alive",
            "proxy-authenticate",
            "proxy-authorization",
            "te",
            "trailer",
            "upgrade",
            "accept-encoding",
            "x-ibm-client-id",
            "x-ibm-client-secret"
    );
    private static final Set<String> BLOCKED_RESPONSE_HEADERS = Set.of(
            "content-length",
            "transfer-encoding",
            "connection",
            "keep-alive",
            "proxy-authenticate",
            "proxy-authorization",
            "te",
            "trailer",
            "upgrade"
    );

    private final BcmProxyProperties properties;
    private final ProxyEndpoint endpoint;
    private final WebClient webClient;
    private final WebClient fallbackWebClient;

    public WebClientBcmRawProxyService(BcmProxyProperties properties, WebClient.Builder webClientBuilder) {
        this.properties = properties;
        this.endpoint = new ProxyEndpoint(UpstreamSystem.BCM.name(), properties.getBaseUrl(), properties.getFallbackIp());
        this.webClient = ProxyWebClientFactory.bcmWebClient(webClientBuilder, properties);
        this.fallbackWebClient = ProxyWebClientFactory.bcmWebClient(webClientBuilder, properties, endpoint);
    }

    @Override
    public Mono<RawProxyResult> proxy(byte[] requestBody, RawProxyRequestContext context) {
        String pathAndQuery = pathAndQuery(context);
        long startedAtNanos = System.nanoTime();
        return execute(requestBody, context, pathAndQuery, false)
                .onErrorResume(error -> shouldTryFallback(error)
                        ? executeFallback(requestBody, context, pathAndQuery, error)
                        : Mono.error(error))
                .doOnSuccess(result -> log.info(
                        "BCM_RAW_PROXY_ACCESS traceId={} method={} path={} upstreamStatus={} outcome=success durationMs={} queryPresent={}",
                        context.traceId(),
                        context.method(),
                        context.path(),
                        result.statusCode(),
                        elapsedMillis(startedAtNanos),
                        context.query() != null && !context.query().isBlank()))
                .doOnError(error -> log.warn(
                        "BCM_RAW_PROXY_ACCESS traceId={} method={} path={} upstreamStatus=none outcome=error errorType={} durationMs={} queryPresent={}",
                        context.traceId(),
                        context.method(),
                        context.path(),
                        error.getClass().getSimpleName(),
                        elapsedMillis(startedAtNanos),
                        context.query() != null && !context.query().isBlank()));
    }

    private Mono<RawProxyResult> executeFallback(
            byte[] requestBody,
            RawProxyRequestContext context,
            String pathAndQuery,
            Throwable primaryError
    ) {
        log.warn("BFF_PROXY_FALLBACK system=BCM traceId={} primaryBaseUrl={} fallbackBaseUrl={} reason={}",
                context.traceId(),
                endpoint.primaryBaseUrlForLog(),
                endpoint.fallbackBaseUrlForLog(),
                primaryError.getClass().getSimpleName());
        return execute(requestBody, context, pathAndQuery, true);
    }

    private Mono<RawProxyResult> execute(
            byte[] requestBody,
            RawProxyRequestContext context,
            String pathAndQuery,
            boolean fallback
    ) {
        URI upstreamUri = fallback ? endpoint.fallbackUri(pathAndQuery) : endpoint.primaryUri(pathAndQuery);
        HttpHeaders outboundHeaders = new HttpHeaders();
        applyForwardHeaders(outboundHeaders, context, fallback);
        logProxyRequest(context, upstreamUri, outboundHeaders, requestBody, fallback);

        WebClient.RequestBodySpec requestSpec = webClient(fallback)
                .method(HttpMethod.valueOf(context.method()))
                .uri(upstreamUri)
                .headers(headers -> headers.addAll(outboundHeaders));

        WebClient.RequestHeadersSpec<?> headersSpec = hasRequestBody(requestBody)
                ? requestSpec.bodyValue(requestBody)
                : requestSpec;

        return headersSpec.exchangeToMono(response -> {
                    int upstreamStatus = response.statusCode().value();
                    HttpHeaders upstreamHeaders = response.headers().asHttpHeaders();
                    return response.bodyToMono(byte[].class)
                            .defaultIfEmpty(new byte[0])
                            .map(body -> {
                                logProxyResponse(context, upstreamStatus, upstreamHeaders, body, fallback);
                                return new RawProxyResult(
                                        upstreamStatus,
                                        responseHeaders(upstreamHeaders),
                                        body);
                            });
                })
                .timeout(Duration.ofMillis(properties.getResponseTimeoutMillis()));
    }

    private WebClient webClient(boolean fallback) {
        return fallback ? fallbackWebClient : webClient;
    }

    private void applyForwardHeaders(HttpHeaders headers, RawProxyRequestContext context, boolean fallback) {
        copyForwardableRequestHeaders(context.requestHeaders(), headers);
        headers.set(HeaderConstants.X_REQUEST_ID, context.traceId());
        headers.set(HeaderConstants.X_CORRELATION_ID, context.traceId());
        setIfPresent(headers, IBM_CLIENT_ID, properties.getIbmClientId());
        setIfPresent(headers, IBM_CLIENT_SECRET, properties.getIbmClientSecret());
        if (!headers.containsKey(HttpHeaders.ACCEPT)) {
            headers.setAccept(List.of(MediaType.ALL));
        }
        if (fallback) {
            endpoint.applyFallbackHostHeader(headers);
        }
    }

    private static HttpHeaders responseHeaders(HttpHeaders upstreamHeaders) {
        HttpHeaders target = new HttpHeaders();
        upstreamHeaders.forEach((name, values) -> {
            if (isBlockedResponseHeader(name) || values == null || values.isEmpty()) {
                return;
            }
            target.put(name, values);
        });
        return target;
    }

    private static void copyForwardableRequestHeaders(HttpHeaders source, HttpHeaders target) {
        if (source == null || source.isEmpty()) {
            return;
        }
        source.forEach((name, values) -> {
            if (!isForwardableHeader(name)) {
                return;
            }
            List<String> safeValues = values == null
                    ? List.of()
                    : values.stream()
                    .filter(WebClientBcmRawProxyService::hasText)
                    .map(String::trim)
                    .toList();
            if (!safeValues.isEmpty()) {
                target.put(name, safeValues);
            }
        });
    }

    private String pathAndQuery(RawProxyRequestContext context) {
        Route route = properties.resolveRoute(Route.DSP_LEGACY_PASSTHROUGH_ROUTE_ID);
        String path = rewritePath(route.getPublicPath(), route.getUpstreamPath(), context.path());
        if (context.query() == null || context.query().isBlank()) {
            return path;
        }
        return path + "?" + context.query();
    }

    private boolean shouldTryFallback(Throwable error) {
        return endpoint.hasFallback()
                && (error instanceof WebClientRequestException || error instanceof TimeoutException);
    }

    private static String rewritePath(String publicPath, String upstreamPath, String requestPath) {
        String path = hasText(requestPath) ? requestPath : "/";
        String publicPrefix = wildcardPrefix(publicPath);
        if (!hasText(publicPrefix) || !hasText(upstreamPath)) {
            return path;
        }

        String normalizedPublicPrefix = trimTrailingSlash(publicPrefix);
        if (path.equals(normalizedPublicPrefix)) {
            return trimTrailingSlash(upstreamPath);
        }

        String publicPrefixWithSlash = normalizedPublicPrefix + "/";
        if (!path.startsWith(publicPrefixWithSlash)) {
            return path;
        }

        return joinPathPrefix(upstreamPath, path.substring(publicPrefixWithSlash.length()));
    }

    private static String wildcardPrefix(String publicPath) {
        if (!hasText(publicPath)) {
            return "";
        }
        int wildcardIndex = publicPath.indexOf("**");
        String prefix = wildcardIndex >= 0 ? publicPath.substring(0, wildcardIndex) : publicPath;
        return trimTrailingSlash(prefix);
    }

    private static String joinPathPrefix(String upstreamPrefix, String suffix) {
        if (!hasText(suffix)) {
            return upstreamPrefix;
        }
        if (upstreamPrefix.endsWith("/")) {
            return upstreamPrefix + suffix;
        }
        return upstreamPrefix + "/" + suffix;
    }

    private static String trimTrailingSlash(String value) {
        if (!hasText(value)) {
            return "";
        }
        String trimmed = value.trim();
        if (trimmed.length() > 1 && trimmed.endsWith("/")) {
            return trimmed.substring(0, trimmed.length() - 1);
        }
        return trimmed;
    }

    private static boolean hasRequestBody(byte[] body) {
        return body != null && body.length > 0;
    }

    private static boolean isForwardableHeader(String name) {
        return hasText(name) && !BLOCKED_FORWARD_HEADERS.contains(name.trim().toLowerCase(Locale.ROOT));
    }

    private static boolean isBlockedResponseHeader(String name) {
        return !hasText(name) || BLOCKED_RESPONSE_HEADERS.contains(name.trim().toLowerCase(Locale.ROOT));
    }

    private static void setIfPresent(HttpHeaders headers, String name, String value) {
        if (hasText(value)) {
            headers.set(name, value.trim());
        }
    }

    private static void logProxyRequest(
            RawProxyRequestContext context,
            URI upstreamUri,
            HttpHeaders headers,
            byte[] requestBody,
            boolean fallback
    ) {
        if (!log.isDebugEnabled()) {
            return;
        }

        log.debug(
                "BCM_RAW_PROXY_REQUEST traceId={} method={} upstreamUri={} fallback={} headers={} body={}",
                context.traceId(),
                context.method(),
                upstreamUri,
                fallback,
                DebugLogSanitizer.headers(headers),
                DebugLogSanitizer.body(requestBody)
        );
    }

    private static void logProxyResponse(
            RawProxyRequestContext context,
            int upstreamStatus,
            HttpHeaders headers,
            byte[] responseBody,
            boolean fallback
    ) {
        if (!log.isDebugEnabled()) {
            return;
        }

        log.debug(
                "BCM_RAW_PROXY_RESPONSE traceId={} method={} path={} upstreamStatus={} fallback={} headers={} body={}",
                context.traceId(),
                context.method(),
                context.path(),
                upstreamStatus,
                fallback,
                DebugLogSanitizer.headers(headers),
                DebugLogSanitizer.body(responseBody)
        );
    }

    private static long elapsedMillis(long startedAtNanos) {
        return Duration.ofNanos(System.nanoTime() - startedAtNanos).toMillis();
    }

    private static boolean hasText(String value) {
        return value != null && !value.isBlank();
    }
}

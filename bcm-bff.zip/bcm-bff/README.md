# BCM BFF

BCM BFF is the Java runtime service for the BEA BCM API entry point. The API contract source lives in `../bcm-contracts`; this project implements access control, proxying, and aggregation behind those contracts.

## Modules

- `bff-bootstrap`: Spring Boot entry point, health checks, security wiring, observability.
- `bff-contract-adapter`: Generated OpenAPI adapter integration point. It compiles Spring WebFlux interfaces and models from the synced OpenAPI snapshot under `bff-contract-adapter/src/main/openapi`.
- `bff-access-control`: JWT, refresh token, and session state. It defaults to an in-memory store and can switch to Redis with configuration.
- `bff-proxy`: BCM/BCO proxy runtime.
- `bff-aggregation`: BFF aggregation orchestration.
- `bff-shared`: Shared response, error, trace, and session models.

## Local Build

```bash
./gradlew :bff-bootstrap:bootJar
```

## Docker Build

```bash
./gradlew docker -PdockerImageTag=bcm-bff:local
```

The Gradle build resolves dependencies only from the BEA internal JFrog repository and uses the checked-in wrapper distribution from the same internal Artifactory. The image is built through the Gradle docker task with `src/main/docker/Dockerfile`, runs the BFF as a non-root user on the BEA Temurin JRE 21 Alpine base image, and supports JVM tuning through `JVM_OPTIONS` or the legacy `JAVA_OPTS` override. ACS deployment notes live in `docs/acs-deployment-v0.1.md`.

Deployment starter artifacts:

- `deploy/acs.env.example`: ACS runtime env template.
- `deploy/acs.k8s.example.yaml`: K8s-compatible ACS Secret, ConfigMap, Deployment, and Service starter manifest.
- `docs/devops-handoff-v0.1.md`: pipeline handoff for CI, image push, ACS deploy, and rollback.
- `docs/commit-readiness-v0.1.md`: commit/PR checklist for the coordinated `bcm-contracts` and `bcm-services` changes.
- `scripts/validate-acs-manifest-env.sh`: checks the ACS K8s starter manifest covers every key from the env template.
- `scripts/release-image.sh`: release gate for env validation, CI checks, Docker smoke, and optional image push.
- `scripts/post-deploy-check.sh`: post-deployment checks for health probes, metrics access policy, and protected endpoint auth behavior.

## Production Profile

ACS should run the service with `SPRING_PROFILES_ACTIVE=prod`. The prod profile removes local-safe defaults for critical runtime dependencies and fails startup when unsafe settings are detected.

Runtime configuration starts from:

```bash
deploy/acs.env.example
```

The production startup guard rejects:

- blank `BFF_AUTH_ISSUER` or `BFF_AUTH_AUDIENCE`
- local/default `BFF_JWT_SECRET`
- missing/local-default `BFF_JWT_KEY_ID`
- malformed or weak `BFF_JWT_PREVIOUS_KEYS`
- `BFF_AUTH_LOCAL_LOGIN_ENABLED=true`
- `BFF_AUTH_LOGIN_PROVIDER=local`
- `BFF_SESSION_STORE` values other than `redis`
- `BFF_PROXY_BCM_BASE_URL` values pointing to localhost or loopback
- `BFF_ENTITLEMENT_IAM_MOCK_ENABLED=true`
- configured `BFF_MANAGEMENT_ACCESS_METRICS_TOKEN` values shorter than 32 characters

## Tests

```bash
./gradlew test
```

For the full BFF CI-style check, including route config drift against `../bcm-contracts`, OpenAPI lint when contracts are available, Gradle tests, and whitespace checks:

```bash
./scripts/ci-check.sh
```

The BEA intranet DevOps pipeline should use the standard `Jenkinsfile` in this directory. The pipeline resolves build dependencies from internal JFrog and publishes the image through the standard Gradle docker task.

To include the Docker image build in the same check:

```bash
RUN_DOCKER_BUILD=true DOCKER_IMAGE_TAG=bcm-bff:ci ./scripts/ci-check.sh
```

To include a real container startup smoke test:

```bash
RUN_DOCKER_SMOKE=true DOCKER_IMAGE_TAG=bcm-bff:ci ./scripts/ci-check.sh
```

For a pipeline-friendly release gate:

```bash
./scripts/release-image.sh \
  --image-tag <registry>/bcm-bff:<tag> \
  --env-file /path/to/bcm-bff-prod.env \
  --manifest-file /path/to/acs.k8s.yaml \
  --contracts ../../bcm-contracts \
  --push
```

After deploying to ACS:

```bash
./scripts/post-deploy-check.sh --base-url https://<bcm-bff-host>
```

For ACS startup-probe checks before the public route is open, run the same script from Jenkins or an ACS debug shell that has bash and curl available, using `--acs-local` and repeated `--upstream-response`; those upstream checks skip certificate verification and only confirm BCM/BCO return HTTP responses.

The BFF bootstrap tests include proxy resilience coverage with an in-process BCM mock upstream:

- Legacy `/corporate/**` BCM proxy paths are supported during migration from `proxy/bcm-proxy`.
- DSP legacy `/dsp/corporate/**` paths are public raw passthrough paths and are forwarded upstream as `/corporate/**`.
- The self-managed JWT session remains the frontend auth boundary; the session can optionally carry the upstream BCM `JSESSIONID`.
- BCM upstream calls inject `x-ibm-client-id`, `x-ibm-client-secret`, `X-User-Id`, and `Authorization: Bearer <JSESSIONID>` when the upstream session id is present.
- HTML upstream response maps to `419 Session Expired`.
- Upstream `500` maps to `502`.
- Auth audit logs avoid raw password, token, user ID, customer ID, session ID, and device ID values.
- Retry can recover a retryable upstream failure.
- Bulkhead overflow returns `429`.
- Oversized request bodies return `413`.
- Ingress rate limiting returns `429` with `Retry-After` and `X-RateLimit-*` headers.
- Consecutive upstream failures open the circuit breaker.
- Route authorization policy allows valid sessions and rejects missing roles, missing scopes, or disallowed device OS values.
- Contract-driven aggregation composes proxy routes, propagates required-step failures, and returns partial results for optional-step failures.

## Local Run

```bash
./gradlew :bff-bootstrap:bootRun
```

Then check:

```bash
curl http://localhost:8080/health
```

## Auth API Skeleton

The first access-control endpoints are available:

- `POST /auth/login`
- `POST /auth/refresh`
- `POST /auth/logout`

The service returns frontend-compatible error bodies. Missing or invalid bearer tokens return HTTP `401` with body `status: "401"`. Expired, replaced, logged-out, or otherwise invalid sessions return HTTP `419` with body `status: "419"` and `message: "Session Expired"`.

All non-public paths are protected by the BFF auth filter. Public paths are health probes, `/auth/login`, and `/auth/refresh`; `/auth/logout`, proxy APIs, aggregation APIs, and actuator non-health endpoints require a valid Bearer token.

`/auth/login` is currently a local-development token issuer, not a production credential verifier. It accepts test roles/scopes so proxy and aggregation flows can be exercised before real IAM integration exists. Keep it enabled only outside production:

```bash
BFF_AUTH_LOGIN_PROVIDER=local
BFF_AUTH_LOCAL_LOGIN_ENABLED=true
```

The `prod` profile defaults `BFF_AUTH_LOGIN_PROVIDER=disabled` and `BFF_AUTH_LOCAL_LOGIN_ENABLED=false`; startup validation rejects any production deployment that switches back to the local provider. Production login should be replaced by an approved IAM/core-banking authentication integration before external traffic is enabled.

Login issuance is isolated behind `LoginAuthenticator`:

- `local`: development-only username/password token issuer.
- `disabled`: production-safe placeholder that rejects `/auth/login`.
- `iam`: production integration seam; it requires a real `IamLoginClient` bean and fails startup if the client is missing.

For local runs, token settings can be overridden with:

```bash
BFF_JWT_SECRET=local-dev-test-secret-at-least-32-bytes \
BFF_JWT_KEY_ID=local-dev \
BFF_AUTH_LOCAL_BCM_SESSION_ID=optional-local-upstream-jsession \
BFF_ACCESS_TOKEN_TTL_SECONDS=900 \
BFF_REFRESH_TOKEN_TTL_SECONDS=604800 \
./gradlew :bff-bootstrap:bootRun
```

To use Redis-backed sessions:

```bash
BFF_SESSION_STORE=redis \
SPRING_DATA_REDIS_HOST=127.0.0.1 \
SPRING_DATA_REDIS_PORT=6379 \
./gradlew :bff-bootstrap:bootRun
```

## BCM Proxy Demo

The first protected proxy endpoint is:

- `POST /bcm/demo/user-profile`

It forwards JSON to the BCM upstream route generated from `../bcm-contracts`, injects BFF trace headers plus `X-User-Id`, and returns the upstream JSON in the standard BFF response envelope. HTML or invalid JSON from an otherwise successful upstream response is treated as a session-expired upstream condition and returns `419`.

For migration compatibility with the existing Go `bcm-proxy`, the BFF also accepts protected `/corporate/**` requests and forwards them to the same path on the BCM upstream. These paths still require a valid BFF Bearer token, apply the `bcm:proxy` authorization policy, preserve forwardable BCM business headers, block client `Cookie`/`Authorization`, and inject the configured IBM client credentials plus the upstream BCM session id from the BFF session.

DSP-prefixed `/dsp/corporate/**` requests are raw public passthrough requests for MGS migration traffic. They do not require a BFF Bearer token and strip the leading `/dsp`, so `/dsp/corporate/v1/example` is forwarded upstream as `/corporate/v1/example`. The BFF preserves the incoming business headers including `Authorization` and `X-User-Id`, blocks client `Cookie`, and injects the configured `x-ibm-client-id` and `x-ibm-client-secret`.

Proxy routes are sourced from OpenAPI operation metadata:

```yaml
x-bcm-bff-route:
  routeId: user-profile
  upstreamSystem: bcm
  upstreamMethod: POST
  upstreamPath: /corporate/v1/approval/center/user/userProfile
  responseTimeoutMillis: 30000
  htmlResponseMeansSessionExpired: true
  retryMaxAttempts: 1
  retryBackoffMillis: 100
  bulkheadMaxConcurrentRequests: 200
  circuitBreakerEnabled: true
  circuitBreakerFailureThreshold: 5
  circuitBreakerOpenMillis: 30000
  requiredRoles: [BCM_USER]
  requiredScopes: [bcm:proxy]
  allowedDeviceOs: [Android, iOS]
```

After changing route metadata in `../bcm-contracts`, sync the BFF runtime config:

```bash
./scripts/sync-proxy-routes.mjs
```

CI should also guard against contracts/runtime drift:

```bash
./scripts/sync-proxy-routes.mjs --check
```

The script writes `bff-bootstrap/src/main/resources/bcm-proxy-routes.yaml`, which is imported by `application.yaml` at startup.

The contract adapter also keeps an in-repo OpenAPI snapshot so Docker builds do not need access to the sibling `bcm-contracts` checkout:

```bash
./scripts/sync-openapi-contracts.sh
```

Gradle generates Spring reactive API interfaces and models from `bff-contract-adapter/src/main/openapi/root.yaml` during `bff-contract-adapter` compilation. CI checks this snapshot for drift:

```bash
./scripts/sync-openapi-contracts.sh --check
```

The public BFF method/path are inferred from the OpenAPI operation that owns `x-bcm-bff-route`; `publicMethod` and `publicPath` can be set explicitly only if an operation needs an override. The generic proxy controller handles configured `/bcm/**` routes by resolving the incoming public method/path to a `routeId`, then forwarding to the configured upstream method/path.

Proxy routes without a `publicPath` are treated as internal routes. They can be used by aggregation steps without being exposed directly as `/bcm/**` endpoints.

## BFF Aggregation Demo

The first protected aggregation endpoint is:

- `POST /bff/demo/home-summary`

It is configured from `x-bcm-bff-aggregation` metadata in `../bcm-contracts` and composes one or more proxy routes. Required step failures fail the whole aggregation and preserve the upstream-facing BFF error code, including `419` for session-expired upstream responses. Optional step failures return HTTP `200` with `data.partial=true` and a per-step entry in `data.errors`.

Aggregation routes are sourced from OpenAPI operation metadata:

```yaml
x-bcm-bff-aggregation:
  aggregationId: home-summary
  responseTimeoutMillis: 30000
  partialResponseEnabled: true
  maxConcurrentSteps: 4
  steps: [userProfile:user-profile:required]
  requiredRoles: [BCM_USER]
  requiredScopes: [bcm:aggregate]
  allowedDeviceOs: [Android, iOS]
```

Step syntax is `responseName:proxyRouteId:required` or `responseName:proxyRouteId:optional`. The runtime executes steps with bounded parallelism (`maxConcurrentSteps`) and returns:

```json
{
  "code": "0000",
  "message": "success",
  "data": {
    "items": {
      "userProfile": {}
    },
    "partial": false,
    "errors": {}
  },
  "traceId": "..."
}
```

At startup, the BFF validates route configuration before accepting traffic:

- Public proxy routes must live under `/bcm/`.
- Public aggregation routes must live under `/bff/`.
- Duplicate public method/path combinations fail startup.
- Aggregation steps must reference an existing proxy route.

Route authorization policy is generated from the same metadata into `bff.authorization.rules`. The auth filter first validates the Bearer token/session, then enforces the route policy before the controller runs. Current policy dimensions are:

- `requiredRoles`: all listed roles must exist on the session.
- `requiredScopes`: all listed scopes must exist on the session.
- `allowedDeviceOs`: if non-empty, the session device OS must match one of the values.

The local login API accepts optional `roles` and `scopes` for development and tests. If omitted, it assigns `BCM_USER` and `bcm:proxy` as local defaults; production IAM integration should replace this with authoritative user entitlement data.

Authorization reads roles, scopes, and device attributes through `EntitlementProvider`. The default provider resolves them from the BFF session, keeping the local runtime simple while leaving a clean seam for future Keycloak claims, internal IAM entitlement lookup, or Casbin-backed policy decisions.

The provider mode is explicit and fail-fast:

```bash
BFF_ENTITLEMENT_PROVIDER=session
```

Supported runtime mode today is `session`. The `iam` mode has a production-facing interface plus a local mock client, but no real IAM network integration yet:

```bash
BFF_ENTITLEMENT_PROVIDER=iam
BFF_ENTITLEMENT_IAM_MOCK_ENABLED=true
BFF_ENTITLEMENT_IAM_REQUEST_TIMEOUT_MILLIS=500
BFF_ENTITLEMENT_IAM_CIRCUIT_BREAKER_FAILURE_THRESHOLD=5
BFF_ENTITLEMENT_IAM_CIRCUIT_BREAKER_OPEN_MILLIS=30000
```

`iam` without an `IamEntitlementClient` fails at startup. Reserved modes `jwt` and `casbin` are recognized by configuration but intentionally fail at startup until their production integrations are implemented.

## Error Responses

The BFF returns one stable JSON shape for edge errors from authentication, authorization, request-size guardrails, rate limits, proxy resilience, and unexpected failures:

```json
{
  "status": "419",
  "code": "419",
  "message": "Session Expired",
  "traceId": "..."
}
```

The same normalized trace ID is also returned in `X-Request-Id` and `X-Correlation-Id`. Frontend logic can keep using `status` or `code` for `401` invalid token, `419` session expired or another device login, `429` rate limited, `413` payload too large, and `5xx` BFF/upstream failures.

## Auth Audit Logging

Access-control events write structured audit logs with the `BCM_AUTH_ACCESS` marker:

```text
BCM_AUTH_ACCESS event=login outcome=success provider=LOCAL userHash=... customerHash=... sessionHash=... deviceHash=... deviceOs=Android rolesCount=1 scopesCount=1 durationMs=12 errorCode=none
BCM_AUTH_ACCESS event=access_token outcome=error tokenHash=... tokenPresent=true durationMs=5 errorCode=401 failureReason=invalid_signature
```

Audited events are:

- Login success and failure.
- Refresh success and failure.
- Logout success and failure.
- Access token/session validation failure.

Token validation failures include a low-cardinality `failureReason` such as `missing_bearer_token`, `malformed_token`, `invalid_signature`, `unexpected_audience`, or `expired`.

Micrometer also exports JWT validation failures as `bcm_bff_auth_jwt_validation_failures_total` with low-cardinality tags `event`, `errorCode`, and `failureReason`.

The audit log intentionally hashes user ID, customer/account ID, session ID, device ID, and token values. It does not log passwords, raw JWTs, cookies, bearer headers, request bodies, or response bodies. Normal protected API token validation success is not audit-logged per request to avoid duplicating `BCM_HTTP_ACCESS` at high volume.

Resilience settings are per route:

- `responseTimeoutMillis`: end-to-end upstream call timeout.
- `retryMaxAttempts`: total attempts including the first call. Keep `1` for non-idempotent banking POSTs unless product/BE confirms retry safety.
- `retryBackoffMillis`: backoff before retrying retryable upstream failures.
- `bulkheadMaxConcurrentRequests`: max in-flight upstream requests for this route; overflow returns `429`.
- `circuitBreakerEnabled`: enables consecutive-failure circuit breaker.
- `circuitBreakerFailureThreshold`: consecutive `502/504` failures before the circuit opens.
- `circuitBreakerOpenMillis`: how long an open circuit fast-fails before allowing traffic again.

## Request Size Limits

The BFF rejects oversized request bodies before authentication and proxy execution. This protects the entry point from accidental uploads and intentionally large payloads. The guard checks `Content-Length` first and also counts bytes while reading chunked bodies.

Default limits are:

- `/auth/**`: `65536` bytes.
- `/bcm/**`: `1048576` bytes.
- `/bff/**`: `1048576` bytes.

Rejected requests return `413` with a frontend-compatible error body and log `BCM_REQUEST_SIZE_ACCESS`. The log contains only rule ID, path, source, configured limit, and observed byte count.

## Ingress Rate Limiting

The BFF has an ingress rate limit filter before authentication. It protects configured path prefixes and does not apply to health probes or other unmatched paths. The default key is:

- Bearer token hash when an `Authorization: Bearer ...` header is present.
- Client IP hash from the remote address when no Bearer token exists.
- Client IP hash from `X-Forwarded-For` only when `BFF_RATE_LIMIT_TRUST_X_FORWARDED_FOR=true`.

Default limits are:

- `/auth/**`: `30` requests per `60` seconds.
- `/bcm/**`: `600` requests per `60` seconds.
- `/bff/**`: `300` requests per `60` seconds.

Rejected requests return `429` with a frontend-compatible error body, `Retry-After`, `X-RateLimit-Limit`, `X-RateLimit-Remaining`, and `X-RateLimit-Reset`. Rejections log `BCM_RATE_LIMIT_ACCESS` with hashed keys only.

ACS can tune these with `BFF_RATE_LIMIT_*` environment variables. `BFF_RATE_LIMIT_STORE=memory` keeps a lightweight per-pod guard for local development. `BFF_RATE_LIMIT_STORE=redis` uses atomic Redis counters and is the production default so limits are shared across ACS replicas. Set `BFF_RATE_LIMIT_TRUST_X_FORWARDED_FOR=true` only when the ACS ingress strips or overwrites client-supplied `X-Forwarded-For`; the `prod` profile requires it when BFF-managed rate limiting is enabled. If strict limits are enforced only at gateway/WAF level, set `BFF_RATE_LIMIT_ENABLED=false`.

## Browser CORS

CORS is disabled by default. This keeps the BFF as a non-browser API entry point unless H5 or Portal browser access is explicitly needed. Enable it only with a concrete HTTPS allowlist:

```bash
BFF_CORS_ENABLED=true
BFF_CORS_ALLOWED_ORIGINS=https://bcm.example.com,https://portal.example.com
BFF_CORS_MAX_AGE_SECONDS=3600
```

The `prod` startup guard rejects blank origins, wildcard origins, and non-HTTPS origins when CORS is enabled.

## Proxy Observability

Every inbound request writes one structured access log line with the `BCM_HTTP_ACCESS` marker after the response is known:

```text
BCM_HTTP_ACCESS traceId=... method=POST path=/bcm/demo/user-profile status=200 outcome=success errorCode=none durationMs=42
```

The access log intentionally excludes request body, response body, query string, bearer token, cookies, and client IP. Use it as the first lookup key in ACS logs, then follow the same `traceId` into proxy, aggregation, entitlement, or rate-limit markers.

For short-lived troubleshooting, enable `LOGGING_LEVEL_COM_HKBEA_BCM_BFF=DEBUG`. DEBUG mode emits `BCM_HTTP_REQUEST`, `BCM_HTTP_REQUEST_BODY`, `BCM_PROXY_REQUEST`, and `BCO_PROXY_REQUEST` entries with request headers and bodies. Sensitive headers and body fields such as authorization, cookies, tokens, passwords, secrets, and sessions are redacted, and body output is capped.

Incoming `X-Request-Id` or `X-Correlation-Id` values are normalized at the BFF edge before they are logged, returned, or forwarded upstream. Only short ASCII trace IDs using letters, digits, `.`, `_`, `:`, or `-` are accepted; unsafe, blank, `null`, or oversized values are replaced with a server-generated UUID.

All BFF responses include conservative API security headers: `Cache-Control: no-store, no-cache, max-age=0, must-revalidate`, `Pragma: no-cache`, `Expires: 0`, `X-Content-Type-Options: nosniff`, `X-Frame-Options: DENY`, and `Referrer-Policy: no-referrer`. `Strict-Transport-Security` is configurable with `BFF_SECURITY_HEADERS_HSTS_*`; it is off by default for local HTTP development and on by default in the `prod` profile.

Every upstream proxy call writes a structured log line with the `BCM_PROXY_ACCESS` marker:

```text
BCM_PROXY_ACCESS routeId=user-profile traceId=... method=POST upstreamStatus=200 outcome=success errorCode=none failureReason=none durationMs=36 queryPresent=true
```

Proxy latency is also exported through Micrometer/Prometheus as `bcm_bff_proxy_duration_seconds` with low-cardinality tags:

- `routeId`
- `method`
- `outcome`
- `upstreamStatus`
- `errorCode`
- `failureReason`

`failureReason` separates upstream failures from BFF guardrails, for example `upstream_status_error`, `html_session_expired`, `invalid_json`, `timeout`, `upstream_request_error`, `bulkhead_rejected`, or `circuit_open`.

`/actuator/prometheus` is protected by the BFF auth filter by default. For ACS/Prometheus scraping, configure a dedicated management token instead of reusing a user JWT:

```bash
MANAGEMENT_PROMETHEUS_METRICS_EXPORT_ENABLED=true
BFF_MANAGEMENT_ACCESS_METRICS_TOKEN=<inject-from-acs-secret-min-32-chars>
BFF_MANAGEMENT_ACCESS_METRICS_TOKEN_HEADER=X-BFF-Monitoring-Token
```

Then scrape with `X-BFF-Monitoring-Token`. If the token is blank, `/actuator/prometheus` keeps requiring the normal Bearer token path. ACS env validation requires Prometheus export to stay enabled so post-deploy checks and platform monitoring do not silently lose metrics.

## Aggregation Observability

Every aggregation request writes a structured log line with the `BCM_AGGREGATION_ACCESS` marker:

```text
BCM_AGGREGATION_ACCESS aggregationId=home-summary traceId=... outcome=success durationMs=42 stepCount=1 partial=false errorCount=0
```

Aggregation latency is exported as `bcm_bff_aggregation_duration_seconds` with low-cardinality tags:

- `aggregationId`
- `outcome`
- `errorCode`

## Entitlement Observability

IAM entitlement lookup writes a structured log line with the `BCM_ENTITLEMENT_ACCESS` marker. The log intentionally avoids user ID, customer ID, and session ID:

```text
BCM_ENTITLEMENT_ACCESS provider=iam outcome=success errorCode=none durationMs=12 rolesCount=1 scopesCount=1 deviceOsPresent=true
```

Entitlement latency is exported as `bcm_bff_entitlement_duration_seconds` with low-cardinality tags:

- `provider`
- `outcome`
- `errorCode`

#!/usr/bin/env bash
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
REPO_DIR="$(cd "${SCRIPT_DIR}/.." && pwd)"
OPENAPI_SNAPSHOT_DIR="${REPO_DIR}/bff-contract-adapter/src/main/openapi"

cd "${REPO_DIR}"

section() {
  printf '\n==> %s\n' "$1"
}

resolve_contracts_dir() {
  if [[ -n "${BCM_CONTRACTS_PATH:-}" ]]; then
    if [[ -d "${REPO_DIR}/${BCM_CONTRACTS_PATH}/contracts/apis" ]]; then
      (cd "${REPO_DIR}" && cd "${BCM_CONTRACTS_PATH}" && pwd)
      return
    fi

    if [[ -d "${BCM_CONTRACTS_PATH}/contracts/apis" ]]; then
      (cd "${BCM_CONTRACTS_PATH}" && pwd)
      return
    fi

    return 1
  fi

  local candidates=(
    "${REPO_DIR}/../../bcm-contracts"
    "${REPO_DIR}/../bcm-contracts"
  )

  for candidate in "${candidates[@]}"; do
    if [[ -d "${candidate}/contracts/apis" ]]; then
      (cd "${candidate}" && pwd)
      return
    fi
  done

  return 1
}

resolve_route_source_dir() {
  if [[ -n "${contracts_dir:-}" ]]; then
    echo "${contracts_dir}"
    return
  fi

  if [[ -d "${OPENAPI_SNAPSHOT_DIR}/apis" ]]; then
    echo "${OPENAPI_SNAPSHOT_DIR}"
    return
  fi

  return 1
}

section "Checking helper script syntax"
node --check scripts/sync-proxy-routes.mjs
node --check scripts/sync-proxy-routes.test.mjs
bash -n scripts/ci-check.sh
bash -n scripts/docker-smoke.sh
bash -n scripts/post-deploy-check.sh
bash -n scripts/release-image.sh
bash -n scripts/sync-openapi-contracts.sh
bash -n scripts/validate-acs-deploy.test.sh
bash -n scripts/validate-acs-manifest-env.sh
bash -n scripts/validate-acs-env.sh

section "Running helper script tests"
node --test scripts/sync-proxy-routes.test.mjs
./scripts/validate-acs-deploy.test.sh

contracts_dir=""
if contracts_dir="$(resolve_contracts_dir)"; then
  echo "Using source contracts: ${contracts_dir}"
else
  echo "bcm-contracts was not found; falling back to in-repo OpenAPI snapshot for route checks"
fi

section "Checking generated route config drift"
route_source_dir="$(resolve_route_source_dir)"
./scripts/sync-proxy-routes.mjs --check --contracts "${route_source_dir}"

if [[ -n "${contracts_dir}" ]]; then
  section "Checking OpenAPI contract adapter snapshot drift"
  ./scripts/sync-openapi-contracts.sh --check --contracts "${contracts_dir}"
else
  echo "bcm-contracts was not found; skipping OpenAPI contract adapter snapshot drift check"
fi

if [[ "${RUN_CONTRACT_LINT:-auto}" != "false" ]]; then
  if [[ -n "${contracts_dir:-}" && -f "${contracts_dir}/package.json" ]]; then
    section "Linting bcm-contracts OpenAPI"
    (cd "${contracts_dir}" && NPM_CONFIG_YES="${NPM_CONFIG_YES:-true}" npm run lint:all)
  elif [[ "${RUN_CONTRACT_LINT:-auto}" == "true" ]]; then
    echo "RUN_CONTRACT_LINT=true but bcm-contracts was not found" >&2
    exit 1
  fi
fi

section "Running BFF tests"
./gradlew test

section "Checking ACS env template"
./scripts/validate-acs-env.sh --allow-placeholders deploy/acs.env.example
./scripts/validate-acs-manifest-env.sh deploy/acs.env.example deploy/acs.k8s.example.yaml

section "Checking whitespace"
git diff --check -- .

if [[ "${RUN_DOCKER_SMOKE:-false}" == "true" ]]; then
  section "Running Docker smoke test"
  ./scripts/docker-smoke.sh
elif [[ "${RUN_DOCKER_BUILD:-false}" == "true" ]]; then
  section "Building Docker image"
  ./gradlew docker -PdockerImageTag="${DOCKER_IMAGE_TAG:-bcm-bff:ci}"
fi

section "BFF CI checks passed"

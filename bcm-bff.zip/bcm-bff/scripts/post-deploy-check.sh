#!/usr/bin/env bash
set -euo pipefail

BASE_URL=""
STARTUP_PROBE_BASE_URL=""
ACS_LOCAL=false
LOCAL_PORT="${SERVER_PORT:-8080}"
METRICS_MODE="protected"
METRICS_TOKEN=""
METRICS_TOKEN_HEADER="X-BFF-Monitoring-Token"
PROTECTED_METHOD="POST"
PROTECTED_PATH="/auth/logout"
EXPECTED_PROTECTED_STATUS="401"
BEARER_TOKEN=""
TIMEOUT_SECONDS="10"
CERT_REPORT_DIR=""
CERT_CHECKS=()
UPSTREAM_RESPONSE_CHECKS=()

usage() {
  cat <<'USAGE'
Usage:
  scripts/post-deploy-check.sh --base-url <https://bff.example.com> [options]
  scripts/post-deploy-check.sh --acs-local [options]

Runs post-deployment checks against a deployed BCM BFF endpoint.

Required:
  --base-url <url>              Base URL of the deployed BFF.
  --acs-local                   Run from the ACS/container terminal using
                                 http://127.0.0.1:<port>. No external route is required.
  --local-port <port>           Port used by --acs-local. Default: SERVER_PORT or 8080.

Health checks:
  --timeout-seconds <seconds>   Curl timeout per request. Default: 10.
  --startup-probe-base-url <url>
                                 Optional direct Pod/ACS startup probe base URL,
                                 for example http://10.23.32.226:8080.

Metrics checks:
  --metrics-mode <mode>         protected | token | public | skip. Default: protected.
  --metrics-token <token>       Token value for metrics-mode=token.
  --metrics-token-header <name> Header name for the metrics token. Default: X-BFF-Monitoring-Token.

Protected API checks:
  --protected-method <method>   Method for the protected probe. Default: POST.
  --protected-path <path>       Protected path to probe. Default: /auth/logout.
  --expect-protected-status <n> Expected unauthenticated status. Default: 401.
  --bearer-token <token>        Optional Bearer token. If set, the protected check uses it.
  --skip-protected              Skip the protected endpoint check.

Upstream response checks:
  --upstream-response <spec>    Check upstream HTTP response without certificate verification.
                                 Format: name,method,url,connect-ip
                                 Repeat for BCM and BCO.

Upstream certificate evidence:
  --upstream-cert <spec>        Capture upstream TLS certificate evidence.
                                 Format: name,host,port,connect-ip[,trust-cert-file]
                                 Repeat for BCM and BCO.
  --cert-report-dir <dir>       Directory for certificate evidence files.
                                 Default: ./post-deploy-cert-report-<timestamp>

Examples:
  scripts/post-deploy-check.sh --base-url https://bff.example.com

  scripts/post-deploy-check.sh --acs-local --metrics-mode skip --skip-protected

  scripts/post-deploy-check.sh \
    --base-url https://bff.example.com \
    --metrics-mode token \
    --metrics-token "$BFF_MANAGEMENT_ACCESS_METRICS_TOKEN"

  scripts/post-deploy-check.sh \
    --acs-local \
    --metrics-mode skip \
    --skip-protected \
    --upstream-response BCO,GET,https://cdcuat-cmapp1.intranet.hkbea.com:9443/digx/v1/bankConfiguration,192.168.20.45 \
    --upstream-response BCM,POST,https://eam-intgw-test.intranet.hkbea.com/hkbea/uat-int/corporate/v1/approval/center/demandDeposit/searchCompanies,192.168.20.157
USAGE
}

fail() {
  echo "post-deploy-check: $1" >&2
  exit 1
}

section() {
  printf '\n==> %s\n' "$1"
}

trim_trailing_slash() {
  local value="$1"
  while [[ "${value}" == */ ]]; do
    value="${value%/}"
  done
  printf '%s' "${value}"
}

response_status() {
  local method="$1"
  local url="$2"
  local output_file="$3"
  shift 3

  curl \
    --silent \
    --show-error \
    --location \
    --max-time "${TIMEOUT_SECONDS}" \
    --request "${method}" \
    --output "${output_file}" \
    --write-out "%{http_code}" \
    "$@" \
    "${url}"
}

assert_url_status() {
  local label="$1"
  local method="$2"
  local url="$3"
  local expected="$4"
  shift 4

  local body_file
  body_file="$(mktemp)"
  local status
  if ! status="$(response_status "${method}" "${url}" "${body_file}" "$@")"; then
    rm -f "${body_file}"
    fail "${label} request failed: ${method} ${url}"
  fi

  if [[ "${status}" != "${expected}" ]]; then
    echo "Unexpected response body for ${label}:" >&2
    sed -n '1,80p' "${body_file}" >&2
    rm -f "${body_file}"
    fail "${label} expected HTTP ${expected}, got ${status}"
  fi

  rm -f "${body_file}"
  printf '%s %s -> HTTP %s\n' "${method}" "${url}" "${status}"
}

assert_status() {
  local label="$1"
  local method="$2"
  local path="$3"
  local expected="$4"
  shift 4

  assert_url_status "${label}" "${method}" "${BASE_URL}${path}" "${expected}" "$@"
}

assert_body_contains() {
  local label="$1"
  local method="$2"
  local path="$3"
  local expected_status="$4"
  local pattern="$5"
  shift 5

  local body_file
  body_file="$(mktemp)"
  local status
  if ! status="$(response_status "${method}" "${BASE_URL}${path}" "${body_file}" "$@")"; then
    rm -f "${body_file}"
    fail "${label} request failed: ${method} ${path}"
  fi

  if [[ "${status}" != "${expected_status}" ]]; then
    echo "Unexpected response body for ${label}:" >&2
    sed -n '1,80p' "${body_file}" >&2
    rm -f "${body_file}"
    fail "${label} expected HTTP ${expected_status}, got ${status}"
  fi

  if ! grep -Eq "${pattern}" "${body_file}"; then
    echo "Unexpected response body for ${label}:" >&2
    sed -n '1,80p' "${body_file}" >&2
    rm -f "${body_file}"
    fail "${label} body did not match pattern: ${pattern}"
  fi

  rm -f "${body_file}"
  printf '%s %s -> HTTP %s, body matched %s\n' "${method}" "${path}" "${status}" "${pattern}"
}

assert_url_body_contains() {
  local label="$1"
  local method="$2"
  local url="$3"
  local expected_status="$4"
  local pattern="$5"
  shift 5

  local body_file
  body_file="$(mktemp)"
  local status
  if ! status="$(response_status "${method}" "${url}" "${body_file}" "$@")"; then
    rm -f "${body_file}"
    fail "${label} request failed: ${method} ${url}"
  fi

  if [[ "${status}" != "${expected_status}" ]]; then
    echo "Unexpected response body for ${label}:" >&2
    sed -n '1,80p' "${body_file}" >&2
    rm -f "${body_file}"
    fail "${label} expected HTTP ${expected_status}, got ${status}"
  fi

  if ! grep -Eq "${pattern}" "${body_file}"; then
    echo "Unexpected response body for ${label}:" >&2
    sed -n '1,80p' "${body_file}" >&2
    rm -f "${body_file}"
    fail "${label} body did not match pattern: ${pattern}"
  fi

  rm -f "${body_file}"
  printf '%s %s -> HTTP %s, body matched %s\n' "${method}" "${url}" "${status}" "${pattern}"
}

parse_url_host_port() {
  local url="$1"
  local host_var="$2"
  local port_var="$3"
  local parsed_scheme
  local parsed_host
  local parsed_port

  if [[ "${url}" =~ ^(https?)://([^/:]+)(:([0-9]+))?(/.*)?$ ]]; then
    parsed_scheme="${BASH_REMATCH[1]}"
    parsed_host="${BASH_REMATCH[2]}"
    parsed_port="${BASH_REMATCH[4]}"
    if [[ -z "${parsed_port}" ]]; then
      if [[ "${parsed_scheme}" == "https" ]]; then
        parsed_port="443"
      else
        parsed_port="80"
      fi
    fi
  else
    fail "upstream URL must start with http:// or https://: ${url}"
  fi

  printf -v "${host_var}" '%s' "${parsed_host}"
  printf -v "${port_var}" '%s' "${parsed_port}"
}

check_upstream_response() {
  local spec="$1"

  IFS=',' read -r name method url connect_ip extra <<< "${spec}"
  [[ -n "${name:-}" && -n "${method:-}" && -n "${url:-}" && -n "${connect_ip:-}" && -z "${extra:-}" ]] \
    || fail "--upstream-response must use format name,method,url,connect-ip"

  local host
  local port
  parse_url_host_port "${url}" host port

  local body_file
  body_file="$(mktemp)"
  local status
  if ! status="$(curl \
      --silent \
      --show-error \
      --location \
      --insecure \
      --max-time "${TIMEOUT_SECONDS}" \
      --request "${method}" \
      --resolve "${host}:${port}:${connect_ip}" \
      --output "${body_file}" \
      --write-out "%{http_code}" \
      "${url}")"; then
    sed -n '1,80p' "${body_file}" >&2 || true
    rm -f "${body_file}"
    fail "${name} upstream response check failed: ${method} ${url} via ${connect_ip}"
  fi

  if [[ ! "${status}" =~ ^[0-9]{3}$ || "${status}" == "000" ]]; then
    sed -n '1,80p' "${body_file}" >&2 || true
    rm -f "${body_file}"
    fail "${name} upstream did not return an HTTP response: ${method} ${url} via ${connect_ip}"
  fi

  rm -f "${body_file}"
  printf '%s %s via %s -> HTTP %s\n' "${method}" "${url}" "${connect_ip}" "${status}"
}

sanitize_filename() {
  printf '%s' "$1" | tr -c '[:alnum:]._-' '_'
}

extract_cert_chain() {
  local raw_file="$1"
  local cert_dir="$2"

  rm -rf "${cert_dir}"
  mkdir -p "${cert_dir}"

  awk -v cert_dir="${cert_dir}" '
    /-----BEGIN CERTIFICATE-----/ {
      cert_index += 1
      file = sprintf("%s/%02d.pem", cert_dir, cert_index)
    }
    file != "" {
      print > file
    }
    /-----END CERTIFICATE-----/ {
      file = ""
    }
  ' "${raw_file}"
}

append_cert_details() {
  local cert_file="$1"
  local label="$2"

  {
    printf '\n[%s]\n' "${label}"
    openssl x509 -in "${cert_file}" -noout -subject -issuer -dates -serial -fingerprint -sha256
    openssl x509 -in "${cert_file}" -noout -ext subjectAltName 2>/dev/null || true
  }
}

verify_cert_chain() {
  local leaf_cert="$1"
  local cert_dir="$2"
  local trust_cert="$3"
  local output_file="$4"

  if [[ -z "${trust_cert}" ]]; then
    printf 'No trust cert file provided. Evidence captured only; verification skipped.\n' > "${output_file}"
    return 0
  fi

  if [[ ! -f "${trust_cert}" ]]; then
    printf 'Trust cert file not found: %s. Evidence captured only; verification skipped.\n' "${trust_cert}" > "${output_file}"
    return 0
  fi

  local intermediate_file="${cert_dir}/intermediates.pem"
  : > "${intermediate_file}"
  find "${cert_dir}" -maxdepth 1 -type f -name '*.pem' ! -name '01.pem' ! -name 'intermediates.pem' | sort | while read -r cert; do
    cat "${cert}" >> "${intermediate_file}"
  done

  if [[ -s "${intermediate_file}" ]]; then
    openssl verify -partial_chain -trusted "${trust_cert}" -untrusted "${intermediate_file}" "${leaf_cert}" > "${output_file}" 2>&1
  else
    openssl verify -partial_chain -trusted "${trust_cert}" "${leaf_cert}" > "${output_file}" 2>&1
  fi
}

capture_upstream_cert() {
  local spec="$1"

  IFS=',' read -r name host port connect_ip trust_cert extra <<< "${spec}"
  [[ -n "${name:-}" && -n "${host:-}" && -n "${port:-}" && -n "${connect_ip:-}" && -z "${extra:-}" ]] \
    || fail "--upstream-cert must use format name,host,port,connect-ip[,trust-cert-file]"
  [[ "${port}" =~ ^[0-9]+$ ]] || fail "--upstream-cert port must be numeric: ${spec}"

  local safe_name
  safe_name="$(sanitize_filename "${name}")"
  local raw_file="${CERT_REPORT_DIR}/${safe_name}-s_client.txt"
  local cert_dir="${CERT_REPORT_DIR}/${safe_name}-chain"
  local summary_file="${CERT_REPORT_DIR}/${safe_name}-summary.txt"
  local verify_file="${CERT_REPORT_DIR}/${safe_name}-verify.txt"

  printf 'Capturing %s certificate chain from %s:%s via %s\n' "${name}" "${host}" "${port}" "${connect_ip}"

  if ! openssl s_client \
      -connect "${connect_ip}:${port}" \
      -servername "${host}" \
      -showcerts \
      </dev/null > "${raw_file}" 2>&1; then
    sed -n '1,120p' "${raw_file}" >&2 || true
    fail "${name} certificate capture failed. See ${raw_file}"
  fi

  extract_cert_chain "${raw_file}" "${cert_dir}"
  local leaf_cert="${cert_dir}/01.pem"
  [[ -f "${leaf_cert}" ]] || fail "${name} did not return a certificate chain. See ${raw_file}"

  {
    printf 'Upstream certificate evidence: %s\n' "${name}"
    printf 'Host/SNI: %s\n' "${host}"
    printf 'Connect: %s:%s\n' "${connect_ip}" "${port}"
    printf 'Generated at: %s\n' "$(date -u '+%Y-%m-%dT%H:%M:%SZ')"
    printf 'Raw openssl output: %s\n' "${raw_file}"
    printf 'Extracted chain dir: %s\n' "${cert_dir}"
    append_cert_details "${leaf_cert}" "leaf certificate"

    local index=0
    find "${cert_dir}" -maxdepth 1 -type f -name '*.pem' | sort | while read -r cert; do
      index=$((index + 1))
      append_cert_details "${cert}" "chain certificate ${index}"
    done
  } > "${summary_file}"

  if verify_cert_chain "${leaf_cert}" "${cert_dir}" "${trust_cert:-}" "${verify_file}"; then
    printf 'Certificate evidence written: %s\n' "${summary_file}"
    printf 'Certificate verification: %s\n' "$(tr '\n' ' ' < "${verify_file}")"
  else
    sed -n '1,120p' "${verify_file}" >&2 || true
    fail "${name} certificate verification failed. Summary: ${summary_file}, verify: ${verify_file}"
  fi
}

SKIP_PROTECTED=false

while [[ $# -gt 0 ]]; do
  case "$1" in
    --base-url)
      [[ $# -ge 2 ]] || fail "--base-url requires a value"
      BASE_URL="$2"
      shift 2
      ;;
    --acs-local)
      ACS_LOCAL=true
      shift
      ;;
    --local-port)
      [[ $# -ge 2 ]] || fail "--local-port requires a value"
      LOCAL_PORT="$2"
      shift 2
      ;;
    --startup-probe-base-url)
      [[ $# -ge 2 ]] || fail "--startup-probe-base-url requires a value"
      STARTUP_PROBE_BASE_URL="$2"
      shift 2
      ;;
    --timeout-seconds)
      [[ $# -ge 2 ]] || fail "--timeout-seconds requires a value"
      TIMEOUT_SECONDS="$2"
      shift 2
      ;;
    --metrics-mode)
      [[ $# -ge 2 ]] || fail "--metrics-mode requires a value"
      METRICS_MODE="$2"
      shift 2
      ;;
    --metrics-token)
      [[ $# -ge 2 ]] || fail "--metrics-token requires a value"
      METRICS_TOKEN="$2"
      shift 2
      ;;
    --metrics-token-header)
      [[ $# -ge 2 ]] || fail "--metrics-token-header requires a value"
      METRICS_TOKEN_HEADER="$2"
      shift 2
      ;;
    --protected-method)
      [[ $# -ge 2 ]] || fail "--protected-method requires a value"
      PROTECTED_METHOD="$2"
      shift 2
      ;;
    --protected-path)
      [[ $# -ge 2 ]] || fail "--protected-path requires a value"
      PROTECTED_PATH="$2"
      shift 2
      ;;
    --expect-protected-status)
      [[ $# -ge 2 ]] || fail "--expect-protected-status requires a value"
      EXPECTED_PROTECTED_STATUS="$2"
      shift 2
      ;;
    --bearer-token)
      [[ $# -ge 2 ]] || fail "--bearer-token requires a value"
      BEARER_TOKEN="$2"
      shift 2
      ;;
    --skip-protected)
      SKIP_PROTECTED=true
      shift
      ;;
    --upstream-response)
      [[ $# -ge 2 ]] || fail "--upstream-response requires a value"
      UPSTREAM_RESPONSE_CHECKS+=("$2")
      shift 2
      ;;
    --upstream-cert)
      [[ $# -ge 2 ]] || fail "--upstream-cert requires a value"
      CERT_CHECKS+=("$2")
      shift 2
      ;;
    --cert-report-dir)
      [[ $# -ge 2 ]] || fail "--cert-report-dir requires a value"
      CERT_REPORT_DIR="$2"
      shift 2
      ;;
    -h|--help)
      usage
      exit 0
      ;;
    *)
      fail "unknown argument: $1"
      ;;
  esac
done

[[ "${LOCAL_PORT}" =~ ^[0-9]+$ ]] || fail "--local-port must be numeric"
if [[ "${ACS_LOCAL}" == "true" ]]; then
  if [[ -z "${BASE_URL}" ]]; then
    BASE_URL="http://127.0.0.1:${LOCAL_PORT}"
  fi
  if [[ -z "${STARTUP_PROBE_BASE_URL}" ]]; then
    STARTUP_PROBE_BASE_URL="http://127.0.0.1:${LOCAL_PORT}"
  fi
fi

[[ -n "${BASE_URL}" ]] || fail "--base-url is required unless --acs-local is used"
[[ "${BASE_URL}" =~ ^https?:// ]] || fail "--base-url must start with http:// or https://"
if [[ -n "${STARTUP_PROBE_BASE_URL}" && ! "${STARTUP_PROBE_BASE_URL}" =~ ^https?:// ]]; then
  fail "--startup-probe-base-url must start with http:// or https://"
fi
[[ "${TIMEOUT_SECONDS}" =~ ^[0-9]+$ ]] || fail "--timeout-seconds must be a positive integer"
[[ "${EXPECTED_PROTECTED_STATUS}" =~ ^[0-9]{3}$ ]] || fail "--expect-protected-status must be a three-digit HTTP status"

case "${METRICS_MODE}" in
  protected|token|public|skip)
    ;;
  *)
    fail "--metrics-mode must be protected, token, public, or skip"
    ;;
esac

if [[ "${METRICS_MODE}" == "token" && -z "${METRICS_TOKEN}" ]]; then
  fail "--metrics-token is required when --metrics-mode token"
fi

BASE_URL="$(trim_trailing_slash "${BASE_URL}")"
if [[ -n "${STARTUP_PROBE_BASE_URL}" ]]; then
  STARTUP_PROBE_BASE_URL="$(trim_trailing_slash "${STARTUP_PROBE_BASE_URL}")"
fi

section "Checking health probes"
assert_body_contains "startup health" GET /health 200 '"status"[[:space:]]*:[[:space:]]*"UP"'
assert_body_contains "readiness" GET /actuator/health/readiness 200 '"status"[[:space:]]*:[[:space:]]*"UP"'
assert_body_contains "liveness" GET /actuator/health/liveness 200 '"status"[[:space:]]*:[[:space:]]*"UP"'

if [[ -n "${STARTUP_PROBE_BASE_URL}" ]]; then
  section "Checking direct ACS startup probe target"
  assert_url_body_contains "direct startup probe" GET "${STARTUP_PROBE_BASE_URL}/health" 200 '"status"[[:space:]]*:[[:space:]]*"UP"'
fi

if [[ ${#UPSTREAM_RESPONSE_CHECKS[@]} -gt 0 ]]; then
  section "Checking upstream HTTP responses"
  for upstream_check in "${UPSTREAM_RESPONSE_CHECKS[@]}"; do
    check_upstream_response "${upstream_check}"
  done
fi

if [[ ${#CERT_CHECKS[@]} -gt 0 ]]; then
  command -v openssl >/dev/null 2>&1 || fail "openssl is required for --upstream-cert checks"
  if [[ -z "${CERT_REPORT_DIR}" ]]; then
    CERT_REPORT_DIR="./post-deploy-cert-report-$(date '+%Y%m%d%H%M%S')"
  fi
  mkdir -p "${CERT_REPORT_DIR}"

  section "Capturing upstream certificate evidence"
  for cert_check in "${CERT_CHECKS[@]}"; do
    capture_upstream_cert "${cert_check}"
  done
  printf 'Certificate report directory: %s\n' "${CERT_REPORT_DIR}"
fi

if [[ "${METRICS_MODE}" != "skip" ]]; then
  section "Checking metrics endpoint"
  case "${METRICS_MODE}" in
    protected)
      assert_status "metrics protected" GET /actuator/prometheus 401
      ;;
    token)
      assert_body_contains \
        "metrics token access" \
        GET \
        /actuator/prometheus \
        200 \
        "^(# HELP|# TYPE|jvm_|process_|http_)" \
        --header "${METRICS_TOKEN_HEADER}: ${METRICS_TOKEN}"
      ;;
    public)
      assert_body_contains \
        "metrics public access" \
        GET \
        /actuator/prometheus \
        200 \
        "^(# HELP|# TYPE|jvm_|process_|http_)"
      ;;
  esac
fi

if [[ "${SKIP_PROTECTED}" != "true" ]]; then
  section "Checking protected endpoint behavior"
  if [[ -n "${BEARER_TOKEN}" ]]; then
    assert_status \
      "protected endpoint" \
      "${PROTECTED_METHOD}" \
      "${PROTECTED_PATH}" \
      "${EXPECTED_PROTECTED_STATUS}" \
      --header "Authorization: Bearer ${BEARER_TOKEN}"
  else
    assert_status \
      "protected endpoint" \
      "${PROTECTED_METHOD}" \
      "${PROTECTED_PATH}" \
      "${EXPECTED_PROTECTED_STATUS}"
  fi
fi

section "Post-deploy checks passed"

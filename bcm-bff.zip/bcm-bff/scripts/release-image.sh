#!/usr/bin/env bash
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
REPO_DIR="$(cd "${SCRIPT_DIR}/.." && pwd)"

IMAGE_TAG=""
ENV_FILE=""
MANIFEST_FILE=""
CONTRACTS_DIR=""
PUSH_IMAGE=false
SKIP_ENV_VALIDATION=false
ALLOW_PLACEHOLDER_ENV=false
resolved_env_file=""

usage() {
  cat <<'USAGE'
Usage:
  scripts/release-image.sh --image-tag <registry>/bcm-bff:<tag> --env-file <prod.env> [options]

Runs the BFF release gate: ACS env validation, contract drift checks, Java tests,
Docker image build, and container health/readiness smoke. Optionally pushes the
validated image tag.

Required:
  --image-tag <tag>       Docker image tag to build and smoke test.

Environment validation:
  --env-file <file>       ACS env file to validate before release.
  --manifest-file <file>  Optional ACS/K8s manifest to validate against the env file.
  --allow-placeholder-env Allow <...> placeholders in env validation. For template checks only.
  --skip-env-validation  Skip ACS env validation. Not allowed with --push.

Contract location:
  --contracts <dir>       Path to bcm-contracts checkout. Defaults to ci-check auto-detection.

Release action:
  --push                  Push the image after all checks pass.

Examples:
  scripts/release-image.sh \
    --image-tag registry.example.com/bcm-bff:abc123 \
    --env-file /secure/bcm-bff-prod.env \
    --contracts ../../bcm-contracts \
    --push

  scripts/release-image.sh \
    --image-tag bcm-bff:release-smoke \
    --env-file deploy/acs.env.example \
    --manifest-file deploy/acs.k8s.example.yaml \
    --allow-placeholder-env
USAGE
}

section() {
  printf '\n==> %s\n' "$1"
}

fail() {
  echo "release-image: $1" >&2
  exit 1
}

resolve_path() {
  local path="$1"
  if [[ "${path}" = /* ]]; then
    printf '%s' "${path}"
  else
    printf '%s/%s' "${REPO_DIR}" "${path}"
  fi
}

while [[ $# -gt 0 ]]; do
  case "$1" in
    --image-tag)
      [[ $# -ge 2 ]] || fail "--image-tag requires a value"
      IMAGE_TAG="$2"
      shift 2
      ;;
    --env-file)
      [[ $# -ge 2 ]] || fail "--env-file requires a value"
      ENV_FILE="$2"
      shift 2
      ;;
    --manifest-file)
      [[ $# -ge 2 ]] || fail "--manifest-file requires a value"
      MANIFEST_FILE="$2"
      shift 2
      ;;
    --contracts)
      [[ $# -ge 2 ]] || fail "--contracts requires a value"
      CONTRACTS_DIR="$2"
      shift 2
      ;;
    --push)
      PUSH_IMAGE=true
      shift
      ;;
    --skip-env-validation)
      SKIP_ENV_VALIDATION=true
      shift
      ;;
    --allow-placeholder-env)
      ALLOW_PLACEHOLDER_ENV=true
      shift
      ;;
    -h|--help)
      usage
      exit 0
      ;;
    *)
      fail "unknown argument: $1"
      ;;
  esac
done

[[ -n "${IMAGE_TAG}" ]] || fail "--image-tag is required"

if [[ "${SKIP_ENV_VALIDATION}" == "true" && -n "${ENV_FILE}" ]]; then
  fail "--skip-env-validation cannot be combined with --env-file"
fi

if [[ "${SKIP_ENV_VALIDATION}" != "true" && -z "${ENV_FILE}" ]]; then
  fail "--env-file is required unless --skip-env-validation is set"
fi

if [[ "${PUSH_IMAGE}" == "true" && "${SKIP_ENV_VALIDATION}" == "true" ]]; then
  fail "--push requires ACS env validation"
fi

if [[ "${SKIP_ENV_VALIDATION}" == "true" && -n "${MANIFEST_FILE}" ]]; then
  fail "--manifest-file requires ACS env validation"
fi

if [[ "${PUSH_IMAGE}" == "true" && "${ALLOW_PLACEHOLDER_ENV}" == "true" ]]; then
  fail "--push does not allow placeholder env validation"
fi

cd "${REPO_DIR}"

if [[ "${SKIP_ENV_VALIDATION}" != "true" ]]; then
  resolved_env_file="$(resolve_path "${ENV_FILE}")"
  [[ -f "${resolved_env_file}" ]] || fail "env file not found: ${resolved_env_file}"

  section "Validating ACS env"
  if [[ "${ALLOW_PLACEHOLDER_ENV}" == "true" ]]; then
    ./scripts/validate-acs-env.sh --allow-placeholders "${resolved_env_file}"
  else
    ./scripts/validate-acs-env.sh "${resolved_env_file}"
  fi

  if [[ -n "${MANIFEST_FILE}" ]]; then
    resolved_manifest_file="$(resolve_path "${MANIFEST_FILE}")"
    [[ -f "${resolved_manifest_file}" ]] || fail "manifest file not found: ${resolved_manifest_file}"

    section "Validating ACS manifest env coverage"
    ./scripts/validate-acs-manifest-env.sh "${resolved_env_file}" "${resolved_manifest_file}"
  fi
fi

if [[ -n "${CONTRACTS_DIR}" ]]; then
  resolved_contracts_dir="$(resolve_path "${CONTRACTS_DIR}")"
  [[ -d "${resolved_contracts_dir}/contracts/apis" ]] || fail "bcm-contracts checkout not found: ${resolved_contracts_dir}"
  export BCM_CONTRACTS_PATH="${resolved_contracts_dir}"
fi

section "Running release gate"
RUN_DOCKER_SMOKE=true DOCKER_IMAGE_TAG="${IMAGE_TAG}" ./scripts/ci-check.sh

if [[ "${PUSH_IMAGE}" == "true" ]]; then
  section "Pushing Docker image"
  docker push "${IMAGE_TAG}"
else
  section "Skipping Docker push"
  echo "Image was built and smoke-tested locally as ${IMAGE_TAG}."
fi

section "Release image gate passed"

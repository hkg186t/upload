#!/usr/bin/env bash
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
REPO_DIR="$(cd "${SCRIPT_DIR}/.." && pwd)"

workspace="$(mktemp -d)"
trap 'rm -rf "${workspace}"' EXIT

assert_success() {
  local label="$1"
  shift

  if ! output="$("$@" 2>&1)"; then
    echo "Expected success for ${label}, got failure:" >&2
    echo "${output}" >&2
    exit 1
  fi
}

assert_failure_contains() {
  local label="$1"
  local expected="$2"
  shift 2

  set +e
  output="$("$@" 2>&1)"
  status=$?
  set -e

  if [[ ${status} -eq 0 ]]; then
    echo "Expected failure for ${label}, got success:" >&2
    echo "${output}" >&2
    exit 1
  fi

  if ! grep -Fq -- "${expected}" <<< "${output}"; then
    echo "Expected failure for ${label} to contain: ${expected}" >&2
    echo "Actual output:" >&2
    echo "${output}" >&2
    exit 1
  fi
}

env_file="${workspace}/acs.env"
manifest_file="${workspace}/acs.k8s.yaml"
cp "${REPO_DIR}/deploy/acs.env.example" "${env_file}"
cp "${REPO_DIR}/deploy/acs.k8s.example.yaml" "${manifest_file}"

assert_success \
  "ACS env template validation" \
  "${REPO_DIR}/scripts/validate-acs-env.sh" \
  --allow-placeholders \
  "${env_file}"

assert_success \
  "ACS manifest env coverage" \
  "${REPO_DIR}/scripts/validate-acs-manifest-env.sh" \
  "${env_file}" \
  "${manifest_file}"

prometheus_disabled_env="${workspace}/acs-prometheus-disabled.env"
awk '{
  if ($0 ~ /^MANAGEMENT_PROMETHEUS_METRICS_EXPORT_ENABLED=/) {
    print "MANAGEMENT_PROMETHEUS_METRICS_EXPORT_ENABLED=false"
  } else {
    print
  }
}' "${env_file}" > "${prometheus_disabled_env}"

assert_failure_contains \
  "disabled Prometheus export" \
  "MANAGEMENT_PROMETHEUS_METRICS_EXPORT_ENABLED must be true for ACS" \
  "${REPO_DIR}/scripts/validate-acs-env.sh" \
  --allow-placeholders \
  "${prometheus_disabled_env}"

manifest_missing_key="${workspace}/acs-missing-key.yaml"
awk '$1 != "BFF_RATE_LIMIT_TRUST_X_FORWARDED_FOR:" { print }' "${manifest_file}" > "${manifest_missing_key}"

assert_failure_contains \
  "manifest missing env key" \
  "BFF_RATE_LIMIT_TRUST_X_FORWARDED_FOR" \
  "${REPO_DIR}/scripts/validate-acs-manifest-env.sh" \
  "${env_file}" \
  "${manifest_missing_key}"

assert_failure_contains \
  "release manifest without env validation" \
  "--manifest-file requires ACS env validation" \
  "${REPO_DIR}/scripts/release-image.sh" \
  --image-tag bcm-bff:test \
  --skip-env-validation \
  --manifest-file "${manifest_file}"

assert_failure_contains \
  "release missing manifest" \
  "manifest file not found" \
  "${REPO_DIR}/scripts/release-image.sh" \
  --image-tag bcm-bff:test \
  --env-file "${env_file}" \
  --allow-placeholder-env \
  --manifest-file "${workspace}/missing.yaml"

assert_failure_contains \
  "release manifest coverage before contracts" \
  "bcm-contracts checkout not found" \
  "${REPO_DIR}/scripts/release-image.sh" \
  --image-tag bcm-bff:test \
  --env-file "${env_file}" \
  --allow-placeholder-env \
  --manifest-file "${manifest_file}" \
  --contracts "${workspace}/missing-contracts"

echo "ACS deployment validation script tests passed"

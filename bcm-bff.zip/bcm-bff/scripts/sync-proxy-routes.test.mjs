#!/usr/bin/env node

import assert from 'node:assert/strict';
import { execFileSync } from 'node:child_process';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import test from 'node:test';

const repoRoot = path.resolve(new URL('..', import.meta.url).pathname);
const syncScript = path.join(repoRoot, 'scripts', 'sync-proxy-routes.mjs');

test('sync-proxy-routes supports scalar YAML block lists in BFF extensions', () => {
  const workspace = fs.mkdtempSync(path.join(os.tmpdir(), 'bcm-bff-routes-'));
  const contractsDir = path.join(workspace, 'bcm-contracts');
  const apisDir = path.join(contractsDir, 'contracts', 'apis');
  const outputPath = path.join(workspace, 'generated-routes.yaml');

  fs.mkdirSync(apisDir, { recursive: true });
  fs.writeFileSync(path.join(apisDir, 'bff.yaml'), contractWithBlockLists());

  execFileSync(process.execPath, [
    syncScript,
    '--contracts',
    contractsDir,
    '--out',
    outputPath,
  ], {
    cwd: repoRoot,
    stdio: 'pipe',
  });

  const generated = fs.readFileSync(outputPath, 'utf8');

  assert.match(generated, /account-read:\n\s+method: GET\n\s+path: \/accounts\/\{accountId\}/);
  assert.match(generated, /required-roles: \[BCM_USER, ACCOUNT_VIEWER\]/);
  assert.match(generated, /required-scopes: \[account:read\]/);
  assert.match(generated, /allowed-device-os: \[Android, iOS\]/);
  assert.match(generated, /user-profile:\n\s+public-method: POST\n\s+public-path: \/bcm\/demo\/user-profile/);
  assert.match(generated, /retry-max-attempts: 2/);
  assert.match(generated, /home-summary:\n\s+public-method: POST\n\s+public-path: \/bff\/demo\/home-summary/);
  assert.match(generated, /- name: userProfile\n\s+proxy-route-id: user-profile\n\s+required: true/);
  assert.match(generated, /- name: limits\n\s+proxy-route-id: account-limits\n\s+required: false/);

  execFileSync(process.execPath, [
    syncScript,
    '--check',
    '--contracts',
    contractsDir,
    '--out',
    outputPath,
  ], {
    cwd: repoRoot,
    stdio: 'pipe',
  });
});

function contractWithBlockLists() {
  return `openapi: 3.0.3
info:
  title: Test
  version: 1.0.0
paths:
  /accounts/{accountId}:
    get:
      operationId: getAccount
      x-bcm-bff-access:
        ruleId: account-read
        requiredRoles:
          - BCM_USER
          - ACCOUNT_VIEWER
        requiredScopes:
          - account:read
        allowedDeviceOs:
          - Android
          - iOS
      responses:
        '200':
          description: OK
  /bcm/demo/user-profile:
    post:
      operationId: proxyUserProfileDemo
      x-bcm-bff-route:
        routeId: user-profile
        upstreamMethod: POST
        upstreamPath: /corporate/v1/approval/center/user/userProfile
        responseTimeoutMillis: 30000
        htmlResponseMeansSessionExpired: true
        retryMaxAttempts: 2
        requiredRoles:
          - BCM_USER
        requiredScopes:
          - bcm:proxy
        allowedDeviceOs:
          - Android
          - iOS
      responses:
        '200':
          description: OK
  /bff/demo/home-summary:
    post:
      operationId: aggregateHomeSummaryDemo
      x-bcm-bff-aggregation:
        aggregationId: home-summary
        responseTimeoutMillis: 30000
        partialResponseEnabled: true
        maxConcurrentSteps: 4
        steps:
          - userProfile:user-profile:required
          - limits:account-limits:optional
        requiredRoles:
          - BCM_USER
        requiredScopes:
          - bcm:aggregate
        allowedDeviceOs:
          - Android
          - iOS
      responses:
        '200':
          description: OK
`;
}

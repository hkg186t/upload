#!/usr/bin/env bash
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
REPO_DIR="$(cd "${SCRIPT_DIR}/.." && pwd)"
DEST_DIR="${REPO_DIR}/bff-contract-adapter/src/main/openapi"
CHECK_MODE=false
CONTRACTS_DIR="${BCM_CONTRACTS_PATH:-}"

usage() {
  echo "Usage: $0 [--check] [--contracts <path>]" >&2
}

while [[ $# -gt 0 ]]; do
  case "$1" in
    --check)
      CHECK_MODE=true
      shift
      ;;
    --contracts)
      CONTRACTS_DIR="${2:-}"
      if [[ -z "${CONTRACTS_DIR}" ]]; then
        usage
        exit 2
      fi
      shift 2
      ;;
    -h|--help)
      usage
      exit 0
      ;;
    *)
      usage
      exit 2
      ;;
  esac
done

resolve_contracts_dir() {
  if [[ -n "${CONTRACTS_DIR}" ]]; then
    (cd "${REPO_DIR}" && cd "${CONTRACTS_DIR}" && pwd)
    return
  fi

  local candidates=(
    "${REPO_DIR}/../../bcm-contracts"
    "${REPO_DIR}/../bcm-contracts"
  )

  for candidate in "${candidates[@]}"; do
    if [[ -f "${candidate}/contracts/root.yaml" && -d "${candidate}/contracts/apis" ]]; then
      (cd "${candidate}" && pwd)
      return
    fi
  done

  return 1
}

copy_contracts() {
  local contracts_dir="$1"
  local destination="$2"

  rm -rf "${destination}"
  mkdir -p "${destination}/apis"

  cp "${contracts_dir}/contracts/root.yaml" "${destination}/root.yaml"
  cp "${contracts_dir}/contracts/common.yaml" "${destination}/common.yaml"

  while IFS= read -r -d '' api_file; do
    cp "${api_file}" "${destination}/apis/$(basename "${api_file}")"
  done < <(find "${contracts_dir}/contracts/apis" -maxdepth 1 -type f -name '*.yaml' -print0 | sort -z)
}

contracts_dir="$(resolve_contracts_dir)"

if [[ "${CHECK_MODE}" == "true" ]]; then
  tmp_dir="$(mktemp -d)"
  trap 'rm -rf "${tmp_dir}"' EXIT
  copy_contracts "${contracts_dir}" "${tmp_dir}/openapi"

  if diff -ru "${DEST_DIR}" "${tmp_dir}/openapi" >/dev/null; then
    echo "OpenAPI contract adapter snapshot is up to date: bff-contract-adapter/src/main/openapi"
    exit 0
  fi

  echo "OpenAPI contract adapter snapshot is out of date. Run scripts/sync-openapi-contracts.sh." >&2
  diff -ru "${DEST_DIR}" "${tmp_dir}/openapi" >&2 || true
  exit 1
fi

copy_contracts "${contracts_dir}" "${DEST_DIR}"
echo "OpenAPI contract adapter snapshot written to bff-contract-adapter/src/main/openapi"

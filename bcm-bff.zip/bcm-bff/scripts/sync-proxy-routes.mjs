#!/usr/bin/env node

import fs from 'node:fs';
import path from 'node:path';

const args = parseArgs(process.argv.slice(2));
const repoRoot = path.resolve(new URL('..', import.meta.url).pathname);
const contractSource = resolveContractSource(args.contracts);
const apisDir = contractSource.apisDir;
const outputPath = path.resolve(repoRoot, args.out ?? 'bff-bootstrap/src/main/resources/bcm-proxy-routes.yaml');

const accessRules = discoverAccessRules(apisDir);
const proxyRoutes = discoverProxyRoutes(apisDir);
const aggregationRoutes = discoverAggregationRoutes(apisDir);
const routeConfig = renderRoutes(accessRules, proxyRoutes, aggregationRoutes);

if (args.check) {
  checkRoutes(outputPath, routeConfig);
  console.log(`Route config is up to date: ${path.relative(repoRoot, outputPath)}`);
} else {
  writeRoutes(outputPath, routeConfig);
  console.log(`Synced ${proxyRoutes.length} BCM proxy route(s) and ${aggregationRoutes.length} aggregation route(s) to ${path.relative(repoRoot, outputPath)}`);
}

function parseArgs(argv) {
  const parsed = {};
  for (let index = 0; index < argv.length; index += 1) {
    const arg = argv[index];
    if (!arg.startsWith('--')) {
      continue;
    }
    const key = arg.slice(2);
    const next = argv[index + 1];
    if (next && !next.startsWith('--')) {
      parsed[key] = next;
      index += 1;
    } else {
      parsed[key] = true;
    }
  }
  return parsed;
}

function resolveContractSource(input) {
  if (input) {
    return contractSourceFromRoot(path.resolve(process.cwd(), input));
  }

  const candidates = [
    path.resolve(repoRoot, '../../bcm-contracts'),
    path.resolve(repoRoot, '../bcm-contracts'),
    path.resolve(process.cwd(), '../bcm-contracts'),
    path.resolve(repoRoot, 'bff-contract-adapter/src/main/openapi'),
  ];

  const found = candidates
    .map(candidate => {
      try {
        return contractSourceFromRoot(candidate);
      } catch {
        return undefined;
      }
    })
    .find(Boolean);
  if (!found) {
    throw new Error(`Unable to find bcm-contracts. Tried: ${candidates.join(', ')}`);
  }
  return found;
}

function contractSourceFromRoot(root) {
  const contractsApisDir = path.join(root, 'contracts', 'apis');
  if (fs.existsSync(contractsApisDir)) {
    return { root, apisDir: contractsApisDir };
  }

  const snapshotApisDir = path.join(root, 'apis');
  if (fs.existsSync(snapshotApisDir)) {
    return { root, apisDir: snapshotApisDir };
  }

  throw new Error(`Contract source does not contain contracts/apis or apis: ${root}`);
}

function discoverProxyRoutes(directory) {
  const apiFiles = fs.readdirSync(directory)
    .filter(file => file.endsWith('.yaml') || file.endsWith('.yml'))
    .sort()
    .map(file => path.join(directory, file));

  const byRouteId = new Map();
  for (const file of apiFiles) {
    for (const route of extractRoutes(file)) {
      if (byRouteId.has(route.routeId)) {
        throw new Error(`Duplicate x-bcm-bff-route routeId "${route.routeId}" in ${file}`);
      }
      byRouteId.set(route.routeId, route);
    }
  }

  return [...byRouteId.values()].sort((left, right) => left.routeId.localeCompare(right.routeId));
}

function discoverAccessRules(directory) {
  const apiFiles = fs.readdirSync(directory)
    .filter(file => file.endsWith('.yaml') || file.endsWith('.yml'))
    .sort()
    .map(file => path.join(directory, file));

  const byRuleId = new Map();
  for (const file of apiFiles) {
    for (const rule of extractAccessRules(file)) {
      if (byRuleId.has(rule.ruleId)) {
        throw new Error(`Duplicate x-bcm-bff-access ruleId "${rule.ruleId}" in ${file}`);
      }
      byRuleId.set(rule.ruleId, rule);
    }
  }

  return [...byRuleId.values()].sort((left, right) => left.ruleId.localeCompare(right.ruleId));
}

function discoverAggregationRoutes(directory) {
  const apiFiles = fs.readdirSync(directory)
    .filter(file => file.endsWith('.yaml') || file.endsWith('.yml'))
    .sort()
    .map(file => path.join(directory, file));

  const byAggregationId = new Map();
  for (const file of apiFiles) {
    for (const route of extractAggregationRoutes(file)) {
      if (byAggregationId.has(route.aggregationId)) {
        throw new Error(`Duplicate x-bcm-bff-aggregation aggregationId "${route.aggregationId}" in ${file}`);
      }
      byAggregationId.set(route.aggregationId, route);
    }
  }

  return [...byAggregationId.values()]
    .sort((left, right) => left.aggregationId.localeCompare(right.aggregationId));
}

function extractAccessRules(file) {
  const lines = fs.readFileSync(file, 'utf8').split(/\r?\n/);
  const rules = [];

  for (let index = 0; index < lines.length; index += 1) {
    const match = lines[index].match(/^(\s*)x-bcm-bff-access:\s*$/);
    if (!match) {
      continue;
    }

    const extensionIndent = match[1].length;
    const values = collectExtensionValues(lines, index, extensionIndent, file, 'x-bcm-bff-access');

    rules.push(normalizeAccessRule(values, findOperationContext(lines, index, extensionIndent), file, index + 1));
  }

  return rules;
}

function extractRoutes(file) {
  const lines = fs.readFileSync(file, 'utf8').split(/\r?\n/);
  const routes = [];

  for (let index = 0; index < lines.length; index += 1) {
    const match = lines[index].match(/^(\s*)x-bcm-bff-route:\s*$/);
    if (!match) {
      continue;
    }

    const extensionIndent = match[1].length;
    const values = collectExtensionValues(lines, index, extensionIndent, file, 'x-bcm-bff-route');

    routes.push(normalizeRoute(values, findOperationContext(lines, index, extensionIndent), file, index + 1));
  }

  return routes;
}

function extractAggregationRoutes(file) {
  const lines = fs.readFileSync(file, 'utf8').split(/\r?\n/);
  const routes = [];

  for (let index = 0; index < lines.length; index += 1) {
    const match = lines[index].match(/^(\s*)x-bcm-bff-aggregation:\s*$/);
    if (!match) {
      continue;
    }

    const extensionIndent = match[1].length;
    const values = collectExtensionValues(lines, index, extensionIndent, file, 'x-bcm-bff-aggregation');

    routes.push(normalizeAggregationRoute(values, findOperationContext(lines, index, extensionIndent), file, index + 1));
  }

  return routes;
}

function collectExtensionValues(lines, extensionIndex, extensionIndent, file, extensionName) {
  const values = {};

  for (let cursor = extensionIndex + 1; cursor < lines.length; cursor += 1) {
    const line = lines[cursor];
    if (isIgnorableYamlLine(line)) {
      continue;
    }

    const indent = indentationOf(line);
    if (indent <= extensionIndent) {
      break;
    }

    const field = line.trim().match(/^([A-Za-z0-9_-]+):\s*(.*)$/);
    if (!field) {
      throw new Error(`Unsupported ${extensionName} line in ${file}:${cursor + 1}`);
    }

    if (field[2].trim() === '') {
      const blockList = collectScalarBlockList(lines, cursor, indent, file, extensionName);
      if (blockList.values.length > 0) {
        values[field[1]] = blockList.values;
        cursor = blockList.nextIndex - 1;
      } else {
        values[field[1]] = '';
      }
      continue;
    }

    values[field[1]] = parseScalar(field[2]);
  }

  return values;
}

function collectScalarBlockList(lines, fieldIndex, fieldIndent, file, extensionName) {
  const values = [];
  let nextIndex = fieldIndex + 1;

  for (; nextIndex < lines.length; nextIndex += 1) {
    const line = lines[nextIndex];
    if (isIgnorableYamlLine(line)) {
      continue;
    }

    const indent = indentationOf(line);
    if (indent <= fieldIndent) {
      break;
    }

    const item = line.trim().match(/^-\s*(.*)$/);
    if (!item || item[1].trim() === '') {
      throw new Error(
        `Unsupported nested ${extensionName} value in ${file}:${nextIndex + 1}. Only scalar block lists are supported.`,
      );
    }
    values.push(parseScalar(item[1]));
  }

  return { values, nextIndex };
}

function isIgnorableYamlLine(line) {
  return !line.trim() || line.trimStart().startsWith('#');
}

function indentationOf(line) {
  return line.match(/^(\s*)/)?.[1].length ?? 0;
}

function findOperationContext(lines, extensionIndex, extensionIndent) {
  let method;
  let methodIndent;
  let publicPath;

  for (let index = extensionIndex - 1; index >= 0; index -= 1) {
    const line = lines[index];
    const indent = line.match(/^(\s*)/)?.[1].length ?? 0;
    const trimmed = line.trim();

    if (method === undefined && indent < extensionIndent) {
      const methodMatch = trimmed.match(/^(get|post|put|patch|delete):\s*$/i);
      if (methodMatch) {
        method = methodMatch[1].toUpperCase();
        methodIndent = indent;
        continue;
      }
    }

    if (method !== undefined && indent < methodIndent) {
      const pathMatch = trimmed.match(/^['"]?(\/[^:'"]*)['"]?:\s*$/);
      if (pathMatch) {
        publicPath = pathMatch[1];
        break;
      }
    }
  }

  if (!method || !publicPath) {
    throw new Error(`Unable to infer OpenAPI path/method for x-bcm-bff-route near line ${extensionIndex + 1}`);
  }

  return { method, publicPath };
}

function normalizeAccessRule(values, operationContext, file, lineNumber) {
  const ruleId = requiredText(values.ruleId, 'ruleId', file, lineNumber);
  const method = text(values.method, operationContext.method).toUpperCase();
  const path = text(values.path, operationContext.publicPath);
  const requiredRoles = stringList(values.requiredRoles);
  const requiredScopes = stringList(values.requiredScopes);
  const allowedDeviceOs = stringList(values.allowedDeviceOs);

  return {
    ruleId,
    method,
    path,
    requiredRoles,
    requiredScopes,
    allowedDeviceOs,
  };
}

function normalizeRoute(values, operationContext, file, lineNumber) {
  const routeId = requiredText(values.routeId, 'routeId', file, lineNumber);
  const upstreamPath = requiredText(values.upstreamPath, 'upstreamPath', file, lineNumber);
  const method = text(values.upstreamMethod ?? values.method, 'POST').toUpperCase();
  const publicMethod = text(values.publicMethod, operationContext.method).toUpperCase();
  const publicPath = text(values.publicPath, operationContext.publicPath);
  const responseTimeoutMillis = number(values.responseTimeoutMillis, 30000);
  const htmlResponseMeansSessionExpired = boolean(values.htmlResponseMeansSessionExpired, true);
  const retryMaxAttempts = integer(values.retryMaxAttempts, 1);
  const retryBackoffMillis = number(values.retryBackoffMillis, 100);
  const bulkheadMaxConcurrentRequests = integer(values.bulkheadMaxConcurrentRequests, 200);
  const circuitBreakerEnabled = boolean(values.circuitBreakerEnabled, true);
  const circuitBreakerFailureThreshold = integer(values.circuitBreakerFailureThreshold, 5);
  const circuitBreakerOpenMillis = number(values.circuitBreakerOpenMillis, 30000);
  const requiredRoles = stringList(values.requiredRoles);
  const requiredScopes = stringList(values.requiredScopes);
  const allowedDeviceOs = stringList(values.allowedDeviceOs);

  return {
    routeId,
    publicMethod,
    publicPath,
    method,
    upstreamPath,
    responseTimeoutMillis,
    htmlResponseMeansSessionExpired,
    retryMaxAttempts,
    retryBackoffMillis,
    bulkheadMaxConcurrentRequests,
    circuitBreakerEnabled,
    circuitBreakerFailureThreshold,
    circuitBreakerOpenMillis,
    requiredRoles,
    requiredScopes,
    allowedDeviceOs,
  };
}

function normalizeAggregationRoute(values, operationContext, file, lineNumber) {
  const aggregationId = requiredText(values.aggregationId ?? values.routeId, 'aggregationId', file, lineNumber);
  const publicMethod = text(values.publicMethod, operationContext.method).toUpperCase();
  const publicPath = text(values.publicPath, operationContext.publicPath);
  const responseTimeoutMillis = number(values.responseTimeoutMillis, 30000);
  const partialResponseEnabled = boolean(values.partialResponseEnabled, true);
  const maxConcurrentSteps = integer(values.maxConcurrentSteps, 4);
  const requiredRoles = stringList(values.requiredRoles);
  const requiredScopes = stringList(values.requiredScopes);
  const allowedDeviceOs = stringList(values.allowedDeviceOs);
  const steps = parseAggregationSteps(values.steps, file, lineNumber);

  return {
    aggregationId,
    publicMethod,
    publicPath,
    responseTimeoutMillis,
    partialResponseEnabled,
    maxConcurrentSteps,
    requiredRoles,
    requiredScopes,
    allowedDeviceOs,
    steps,
  };
}

function requiredText(value, field, file, lineNumber) {
  const normalized = text(value, '');
  if (!normalized) {
    throw new Error(`Missing ${field} in x-bcm-bff-route at ${file}:${lineNumber}`);
  }
  return normalized;
}

function text(value, defaultValue) {
  if (value === undefined || value === null) {
    return defaultValue;
  }
  return String(value).trim();
}

function number(value, defaultValue) {
  if (value === undefined || value === null || value === '') {
    return defaultValue;
  }
  const parsed = Number(value);
  if (!Number.isFinite(parsed) || parsed <= 0) {
    throw new Error(`Expected positive number, got "${value}"`);
  }
  return parsed;
}

function integer(value, defaultValue) {
  const parsed = number(value, defaultValue);
  if (!Number.isInteger(parsed)) {
    throw new Error(`Expected integer, got "${value}"`);
  }
  return parsed;
}

function boolean(value, defaultValue) {
  if (value === undefined || value === null || value === '') {
    return defaultValue;
  }
  if (value === true || value === 'true') {
    return true;
  }
  if (value === false || value === 'false') {
    return false;
  }
  throw new Error(`Expected boolean, got "${value}"`);
}

function stringList(value) {
  if (value === undefined || value === null || value === '') {
    return [];
  }
  const values = Array.isArray(value) ? value : String(value).split(',');
  return values
    .map(item => String(item).trim())
    .filter(Boolean);
}

function parseAggregationSteps(value, file, lineNumber) {
  const values = stringList(value);
  if (values.length === 0) {
    throw new Error(`Missing steps in x-bcm-bff-aggregation at ${file}:${lineNumber}`);
  }

  return values.map(rawStep => {
    const parts = rawStep.split(':').map(part => part.trim()).filter(Boolean);
    if (parts.length < 2 || parts.length > 3) {
      throw new Error(`Invalid aggregation step "${rawStep}" at ${file}:${lineNumber}. Expected name:proxyRouteId[:required|optional]`);
    }
    return {
      name: parts[0],
      proxyRouteId: parts[1],
      required: parts[2] === undefined ? true : parseStepRequired(parts[2], file, lineNumber),
    };
  });
}

function parseStepRequired(value, file, lineNumber) {
  const normalized = String(value).trim().toLowerCase();
  if (normalized === 'required' || normalized === 'true') {
    return true;
  }
  if (normalized === 'optional' || normalized === 'false') {
    return false;
  }
  throw new Error(`Invalid aggregation step required flag "${value}" at ${file}:${lineNumber}`);
}

function parseScalar(rawValue) {
  const withoutComment = rawValue.replace(/\s+#.*$/, '').trim();
  if (!withoutComment) {
    return '';
  }
  if ((withoutComment.startsWith('"') && withoutComment.endsWith('"'))
      || (withoutComment.startsWith("'") && withoutComment.endsWith("'"))) {
    return withoutComment.slice(1, -1);
  }
  if (withoutComment === 'true') {
    return true;
  }
  if (withoutComment === 'false') {
    return false;
  }
  if (withoutComment.startsWith('[') && withoutComment.endsWith(']')) {
    const body = withoutComment.slice(1, -1).trim();
    if (!body) {
      return [];
    }
    return body.split(',').map(item => item.trim().replace(/^['"]|['"]$/g, ''));
  }
  if (/^-?\d+(\.\d+)?$/.test(withoutComment)) {
    return Number(withoutComment);
  }
  return withoutComment;
}

function checkRoutes(file, expectedContent) {
  if (!fs.existsSync(file)) {
    console.error(`Generated route config is missing: ${path.relative(repoRoot, file)}`);
    console.error('Run ./scripts/sync-proxy-routes.mjs to create it.');
    process.exit(1);
  }

  const currentContent = fs.readFileSync(file, 'utf8');
  if (currentContent !== expectedContent) {
    console.error(`Generated route config is stale: ${path.relative(repoRoot, file)}`);
    console.error('Run ./scripts/sync-proxy-routes.mjs and commit the updated file.');
    process.exit(1);
  }
}

function writeRoutes(file, content) {
  fs.mkdirSync(path.dirname(file), { recursive: true });
  fs.writeFileSync(file, content);
}

function renderRoutes(accessRuleDefinitions, proxyRouteDefinitions, aggregationRouteDefinitions) {
  const lines = [
    '# Generated by scripts/sync-proxy-routes.mjs.',
    '# Source: BCM OpenAPI x-bcm-bff-access, x-bcm-bff-route, and x-bcm-bff-aggregation extensions.',
    '# Do not edit manually; update bcm-contracts and rerun the sync script.',
    'bff:',
    '  authorization:',
    '    rules:',
  ];

  for (const rule of accessRuleDefinitions) {
    lines.push(
      `      ${rule.ruleId}:`,
      `        method: ${rule.method}`,
      `        path: ${rule.path}`,
      `        required-roles: ${formatInlineList(rule.requiredRoles)}`,
      `        required-scopes: ${formatInlineList(rule.requiredScopes)}`,
      `        allowed-device-os: ${formatInlineList(rule.allowedDeviceOs)}`,
    );
  }

  for (const route of proxyRouteDefinitions) {
    lines.push(
      `      ${route.routeId}:`,
      `        method: ${route.publicMethod}`,
      `        path: ${route.publicPath}`,
      `        required-roles: ${formatInlineList(route.requiredRoles)}`,
      `        required-scopes: ${formatInlineList(route.requiredScopes)}`,
      `        allowed-device-os: ${formatInlineList(route.allowedDeviceOs)}`,
    );
  }

  for (const route of aggregationRouteDefinitions) {
    lines.push(
      `      aggregation-${route.aggregationId}:`,
      `        method: ${route.publicMethod}`,
      `        path: ${route.publicPath}`,
      `        required-roles: ${formatInlineList(route.requiredRoles)}`,
      `        required-scopes: ${formatInlineList(route.requiredScopes)}`,
      `        allowed-device-os: ${formatInlineList(route.allowedDeviceOs)}`,
    );
  }

  lines.push(
    '  proxy:',
    '    bcm:',
    '      routes:',
  );

  for (const route of proxyRouteDefinitions) {
    lines.push(
      `        ${route.routeId}:`,
      `          public-method: ${route.publicMethod}`,
      `          public-path: ${route.publicPath}`,
      `          method: ${route.method}`,
      `          upstream-path: ${route.upstreamPath}`,
      `          response-timeout-millis: ${route.responseTimeoutMillis}`,
      `          html-response-means-session-expired: ${route.htmlResponseMeansSessionExpired}`,
      `          retry-max-attempts: ${route.retryMaxAttempts}`,
      `          retry-backoff-millis: ${route.retryBackoffMillis}`,
      `          bulkhead-max-concurrent-requests: ${route.bulkheadMaxConcurrentRequests}`,
      `          circuit-breaker-enabled: ${route.circuitBreakerEnabled}`,
      `          circuit-breaker-failure-threshold: ${route.circuitBreakerFailureThreshold}`,
      `          circuit-breaker-open-millis: ${route.circuitBreakerOpenMillis}`,
    );
  }

  lines.push(
    '  aggregation:',
    '    routes:',
  );

  for (const route of aggregationRouteDefinitions) {
    lines.push(
      `      ${route.aggregationId}:`,
      `        public-method: ${route.publicMethod}`,
      `        public-path: ${route.publicPath}`,
      `        response-timeout-millis: ${route.responseTimeoutMillis}`,
      `        partial-response-enabled: ${route.partialResponseEnabled}`,
      `        max-concurrent-steps: ${route.maxConcurrentSteps}`,
      '        steps:',
    );
    for (const step of route.steps) {
      lines.push(
        `          - name: ${step.name}`,
        `            proxy-route-id: ${step.proxyRouteId}`,
        `            required: ${step.required}`,
      );
    }
  }

  return `${lines.join('\n')}\n`;
}

function formatInlineList(values) {
  if (!values || values.length === 0) {
    return '[]';
  }
  return `[${values.join(', ')}]`;
}

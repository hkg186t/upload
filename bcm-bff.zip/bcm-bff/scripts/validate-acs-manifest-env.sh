#!/usr/bin/env bash
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
REPO_DIR="$(cd "${SCRIPT_DIR}/.." && pwd)"
ENV_FILE="${1:-deploy/acs.env.example}"
MANIFEST_FILE="${2:-deploy/acs.k8s.example.yaml}"

if [[ "${ENV_FILE}" != /* ]]; then
  ENV_FILE="${REPO_DIR}/${ENV_FILE}"
fi

if [[ "${MANIFEST_FILE}" != /* ]]; then
  MANIFEST_FILE="${REPO_DIR}/${MANIFEST_FILE}"
fi

if [[ ! -f "${ENV_FILE}" ]]; then
  echo "ACS env file not found: ${ENV_FILE}" >&2
  exit 1
fi

if [[ ! -f "${MANIFEST_FILE}" ]]; then
  echo "ACS manifest file not found: ${MANIFEST_FILE}" >&2
  exit 1
fi

env_keys_file="$(mktemp)"
manifest_keys_file="$(mktemp)"
missing_keys_file="$(mktemp)"
trap 'rm -f "${env_keys_file}" "${manifest_keys_file}" "${missing_keys_file}"' EXIT

awk -F= '/^[A-Z0-9_]+=/{print $1}' "${ENV_FILE}" | sort -u > "${env_keys_file}"
awk '/^[[:space:]]{2}[A-Z0-9_]+:/{key=$1; sub(/:$/, "", key); print key}' "${MANIFEST_FILE}" \
  | sort -u > "${manifest_keys_file}"

comm -23 "${env_keys_file}" "${manifest_keys_file}" > "${missing_keys_file}"

if [[ -s "${missing_keys_file}" ]]; then
  echo "ACS manifest is missing env keys from ${ENV_FILE}:" >&2
  sed 's/^/  - /' "${missing_keys_file}" >&2
  exit 1
fi

echo "ACS manifest env coverage passed: ${MANIFEST_FILE}"

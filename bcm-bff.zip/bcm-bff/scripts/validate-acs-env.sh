#!/usr/bin/env bash
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
REPO_DIR="$(cd "${SCRIPT_DIR}/.." && pwd)"

ALLOW_PLACEHOLDERS=false
ENV_FILE="${REPO_DIR}/deploy/acs.env.example"

usage() {
  cat <<'USAGE'
Usage:
  scripts/validate-acs-env.sh [--allow-placeholders] [env-file]

Validates the ACS runtime environment file before deployment.

Options:
  --allow-placeholders  Validate the checked-in template without failing on <...> values.
USAGE
}

while [[ $# -gt 0 ]]; do
  case "$1" in
    --allow-placeholders)
      ALLOW_PLACEHOLDERS=true
      shift
      ;;
    -h|--help)
      usage
      exit 0
      ;;
    -*)
      echo "Unknown option: $1" >&2
      usage >&2
      exit 2
      ;;
    *)
      ENV_FILE="$1"
      shift
      ;;
  esac
done

if [[ ! -f "${ENV_FILE}" ]]; then
  echo "ACS env file not found: ${ENV_FILE}" >&2
  exit 1
fi

ENV_KEYS=()
ENV_VALUES=()
ENV_COUNT=0

PLACEHOLDER_ALLOWED_KEYS=(
  BFF_JWT_SECRET
  SPRING_DATA_REDIS_HOST
  SPRING_DATA_REDIS_PASSWORD
  BFF_PROXY_BCM_BASE_URL
  BFF_PROXY_BCM_IBM_CLIENT_ID
  BFF_PROXY_BCM_IBM_CLIENT_SECRET
  BFF_PROXY_BCO_BASE_URL
)

failures=()

fail() {
  failures+=("$1")
}

trim() {
  local value="$1"
  value="${value#"${value%%[![:space:]]*}"}"
  value="${value%"${value##*[![:space:]]}"}"
  printf '%s' "${value}"
}

unquote() {
  local value="$1"
  if [[ "${value}" == \"*\" && "${value}" == *\" ]]; then
    value="${value:1:${#value}-2}"
  elif [[ "${value}" == \'*\' && "${value}" == *\' ]]; then
    value="${value:1:${#value}-2}"
  fi
  printf '%s' "${value}"
}

while IFS= read -r raw_line || [[ -n "${raw_line}" ]]; do
  line="$(trim "${raw_line}")"
  [[ -z "${line}" || "${line}" == \#* ]] && continue
  [[ "${line}" == export\ * ]] && line="$(trim "${line#export }")"

  if [[ "${line}" != *=* ]]; then
    fail "Invalid env line without '=': ${raw_line}"
    continue
  fi

  key="$(trim "${line%%=*}")"
  value="$(trim "${line#*=}")"
  value="$(unquote "${value}")"

  if [[ ! "${key}" =~ ^[A-Z_][A-Z0-9_]*$ ]]; then
    fail "Invalid env key: ${key}"
    continue
  fi

  duplicate=false
  for ((index = 0; index < ENV_COUNT; index++)); do
    existing_key="${ENV_KEYS[${index}]}"
    if [[ "${existing_key}" == "${key}" ]]; then
      duplicate=true
      break
    fi
  done

  if [[ "${duplicate}" == "true" ]]; then
    fail "Duplicate env key: ${key}"
    continue
  fi

  ENV_KEYS[${ENV_COUNT}]="${key}"
  ENV_VALUES[${ENV_COUNT}]="${value}"
  ENV_COUNT=$((ENV_COUNT + 1))
done < "${ENV_FILE}"

key_index() {
  local target="$1"
  local index
  for ((index = 0; index < ENV_COUNT; index++)); do
    if [[ "${ENV_KEYS[${index}]}" == "${target}" ]]; then
      printf '%s' "${index}"
      return 0
    fi
  done
  return 1
}

value_of() {
  local key="$1"
  local index
  if index="$(key_index "${key}")"; then
    printf '%s' "${ENV_VALUES[${index}]}"
  fi
}

has_key() {
  local key="$1"
  key_index "${key}" >/dev/null
}

is_placeholder() {
  local value="$1"
  [[ "${value}" == *"<"*">"* ]]
}

is_placeholder_allowed_for_key() {
  local key="$1"
  local allowed_key
  [[ "${ALLOW_PLACEHOLDERS}" == "true" ]] || return 1
  for allowed_key in "${PLACEHOLDER_ALLOWED_KEYS[@]}"; do
    [[ "${allowed_key}" == "${key}" ]] && return 0
  done
  return 1
}

require_key() {
  local key="$1"
  if ! has_key "${key}"; then
    fail "Missing required env key: ${key}"
  fi
}

require_non_empty() {
  local key="$1"
  require_key "${key}"
  if ! has_key "${key}"; then
    return
  fi
  local value
  value="$(value_of "${key}")"
  if [[ -z "${value}" ]]; then
    fail "${key} must not be blank"
  fi
}

require_bool() {
  local key="$1"
  require_non_empty "${key}"
  if ! has_key "${key}"; then
    return
  fi
  local value
  value="$(value_of "${key}")"
  if [[ "${value}" != "true" && "${value}" != "false" ]]; then
    fail "${key} must be true or false"
  fi
}

require_number() {
  local key="$1"
  require_non_empty "${key}"
  if ! has_key "${key}"; then
    return
  fi
  local value
  value="$(value_of "${key}")"
  if [[ ! "${value}" =~ ^[0-9]+$ ]]; then
    fail "${key} must be a positive integer"
  fi
}

require_min_length_unless_placeholder() {
  local key="$1"
  local min_length="$2"
  require_non_empty "${key}"
  if ! has_key "${key}"; then
    return
  fi
  local value
  value="$(value_of "${key}")"
  if is_placeholder "${value}" && is_placeholder_allowed_for_key "${key}"; then
    return
  fi
  if ((${#value} < min_length)); then
    fail "${key} must be at least ${min_length} characters"
  fi
}

fail_if_placeholder() {
  local key="$1"
  if ! has_key "${key}"; then
    return
  fi
  local value
  value="$(value_of "${key}")"
  if is_placeholder "${value}" && ! is_placeholder_allowed_for_key "${key}"; then
    fail "${key} still contains a placeholder value: ${value}"
  fi
}

is_local_host() {
  local host="$1"
  local normalized
  normalized="$(printf '%s' "${host}" | tr '[:upper:]' '[:lower:]')"
  [[ "${normalized}" == "localhost" \
    || "${normalized}" == "127.0.0.1" \
    || "${normalized}" == "0.0.0.0" \
    || "${normalized}" == "::1" ]]
}

host_from_url() {
  local url="$1"
  local without_scheme="${url#*://}"
  local authority="${without_scheme%%/*}"
  authority="${authority#*@}"
  authority="${authority%%:*}"
  authority="${authority#[}"
  authority="${authority%]}"
  printf '%s' "${authority}"
}

required_keys=(
  SPRING_PROFILES_ACTIVE
  SERVER_PORT
  JAVA_OPTS
  MANAGEMENT_PROMETHEUS_METRICS_EXPORT_ENABLED
  BFF_CORS_ENABLED
  BFF_CORS_MAX_AGE_SECONDS
  BFF_SECURITY_HEADERS_HSTS_ENABLED
  BFF_SECURITY_HEADERS_HSTS_MAX_AGE_SECONDS
  BFF_SECURITY_HEADERS_HSTS_INCLUDE_SUBDOMAINS
  BFF_SECURITY_HEADERS_HSTS_PRELOAD
  BFF_AUTH_ISSUER
  BFF_AUTH_AUDIENCE
  BFF_JWT_SECRET
  BFF_JWT_KEY_ID
  BFF_ACCESS_TOKEN_TTL_SECONDS
  BFF_REFRESH_TOKEN_TTL_SECONDS
  BFF_AUTH_LOCAL_LOGIN_ENABLED
  BFF_AUTH_LOGIN_PROVIDER
  BFF_SESSION_STORE
  BFF_SESSION_TTL_SECONDS
  BFF_SESSION_REDIS_KEY_PREFIX
  BFF_REQUEST_SIZE_LIMIT_ENABLED
  BFF_REQUEST_SIZE_LIMIT_AUTH_MAX_BYTES
  BFF_REQUEST_SIZE_LIMIT_BCM_MAX_BYTES
  BFF_REQUEST_SIZE_LIMIT_BCO_MAX_BYTES
  BFF_REQUEST_SIZE_LIMIT_BFF_MAX_BYTES
  BFF_RATE_LIMIT_ENABLED
  BFF_RATE_LIMIT_STORE
  BFF_RATE_LIMIT_MAX_BUCKETS
  BFF_RATE_LIMIT_REDIS_KEY_PREFIX
  BFF_RATE_LIMIT_TRUST_X_FORWARDED_FOR
  BFF_RATE_LIMIT_AUTH_MAX_REQUESTS
  BFF_RATE_LIMIT_AUTH_WINDOW_SECONDS
  BFF_RATE_LIMIT_BCM_MAX_REQUESTS
  BFF_RATE_LIMIT_BCM_WINDOW_SECONDS
  BFF_RATE_LIMIT_BCO_MAX_REQUESTS
  BFF_RATE_LIMIT_BCO_WINDOW_SECONDS
  BFF_RATE_LIMIT_BFF_MAX_REQUESTS
  BFF_RATE_LIMIT_BFF_WINDOW_SECONDS
  SPRING_DATA_REDIS_HOST
  SPRING_DATA_REDIS_USERNAME
  SPRING_DATA_REDIS_PORT
  SPRING_DATA_REDIS_PASSWORD
  SPRING_DATA_REDIS_SSL_ENABLED
  BFF_PROXY_HEALTH_CHECK_STARTUP_ENABLED
  BFF_PROXY_HEALTH_CHECK_SCHEDULED_ENABLED
  BFF_PROXY_BCM_BASE_URL
  BFF_PROXY_BCM_IBM_CLIENT_ID
  BFF_PROXY_BCM_IBM_CLIENT_SECRET
  BFF_PROXY_BCM_LEGACY_PASSTHROUGH_ENABLED
  BFF_PROXY_BCM_LEGACY_PASSTHROUGH_PATH_PREFIX
  BFF_PROXY_BCM_DSP_LEGACY_PASSTHROUGH_PATH_PREFIX
  BFF_PROXY_BCM_DSP_LEGACY_PASSTHROUGH_UPSTREAM_PATH_PREFIX
  BFF_PROXY_BCM_TLS_INSECURE_SKIP_VERIFY
  BFF_PROXY_BCM_MTLS_ENABLED
  BFF_PROXY_BCM_MTLS_CERT_FILE
  BFF_PROXY_BCM_MTLS_KEY_FILE
  BFF_PROXY_BCM_MTLS_INSECURE_SKIP_VERIFY
  BFF_PROXY_BCM_RESPONSE_TIMEOUT_MILLIS
  BFF_PROXY_BCM_HEALTH_CHECK_ENABLED
  BFF_PROXY_BCM_HEALTH_CHECK_PATH
  BFF_PROXY_BCM_HEALTH_CHECK_METHOD
  BFF_PROXY_BCM_HEALTH_CHECK_TIMEOUT_MILLIS
  BFF_PROXY_BCO_ENABLED
  BFF_PROXY_BCO_BASE_URL
  BFF_PROXY_BCO_LEGACY_PASSTHROUGH_PATH_PREFIX
  BFF_PROXY_BCO_RESPONSE_TIMEOUT_MILLIS
  BFF_PROXY_BCO_PUBLIC_PATHS
  BFF_PROXY_BCO_TLS_INSECURE_SKIP_VERIFY
  BFF_PROXY_BCO_HEALTH_CHECK_ENABLED
  BFF_PROXY_BCO_HEALTH_CHECK_PATH
  BFF_PROXY_BCO_HEALTH_CHECK_METHOD
  BFF_PROXY_BCO_HEALTH_CHECK_TIMEOUT_MILLIS
  SPRING_CODEC_MAX_IN_MEMORY_SIZE
  BFF_ENTITLEMENT_PROVIDER
  BFF_ENTITLEMENT_IAM_MOCK_ENABLED
  BFF_ENTITLEMENT_IAM_REQUEST_TIMEOUT_MILLIS
  BFF_ENTITLEMENT_IAM_CIRCUIT_BREAKER_ENABLED
  BFF_ENTITLEMENT_IAM_CIRCUIT_BREAKER_FAILURE_THRESHOLD
  BFF_ENTITLEMENT_IAM_CIRCUIT_BREAKER_OPEN_MILLIS
)

for key in "${required_keys[@]}"; do
  require_non_empty "${key}"
  fail_if_placeholder "${key}"
done

optional_placeholder_keys=(
  BFF_MANAGEMENT_ACCESS_METRICS_TOKEN
  BFF_CORS_ALLOWED_ORIGINS
  BFF_JWT_PREVIOUS_KEYS
  BFF_PROXY_BCM_FALLBACK_IP
  BFF_PROXY_BCM_TLS_TRUST_CERT_FILE
  BFF_PROXY_BCO_FALLBACK_IP
  BFF_PROXY_BCO_TLS_TRUST_CERT_FILE
)

for key in "${optional_placeholder_keys[@]}"; do
  fail_if_placeholder "${key}"
done

if has_key SPRING_PROFILES_ACTIVE; then
  profiles=", $(value_of SPRING_PROFILES_ACTIVE),"
  profiles="${profiles// /}"
  if [[ "${profiles}" != *,prod,* ]]; then
    fail "SPRING_PROFILES_ACTIVE must include prod"
  fi
fi

if has_key MANAGEMENT_PROMETHEUS_METRICS_EXPORT_ENABLED \
  && [[ "$(value_of MANAGEMENT_PROMETHEUS_METRICS_EXPORT_ENABLED)" != "true" ]]; then
  fail "MANAGEMENT_PROMETHEUS_METRICS_EXPORT_ENABLED must be true for ACS"
fi

if has_key BFF_AUTH_LOCAL_LOGIN_ENABLED && [[ "$(value_of BFF_AUTH_LOCAL_LOGIN_ENABLED)" != "false" ]]; then
  fail "BFF_AUTH_LOCAL_LOGIN_ENABLED must be false for ACS"
fi

if has_key BFF_AUTH_LOGIN_PROVIDER && [[ "$(value_of BFF_AUTH_LOGIN_PROVIDER)" == "local" ]]; then
  fail "BFF_AUTH_LOGIN_PROVIDER must not be local for ACS"
fi

if has_key BFF_SESSION_STORE && [[ "$(value_of BFF_SESSION_STORE)" != "redis" ]]; then
  fail "BFF_SESSION_STORE must be redis for ACS"
fi

if has_key BFF_RATE_LIMIT_STORE; then
  rate_limit_store="$(value_of BFF_RATE_LIMIT_STORE)"
  if [[ "${rate_limit_store}" != "memory" && "${rate_limit_store}" != "redis" ]]; then
    fail "BFF_RATE_LIMIT_STORE must be memory or redis"
  fi
  if has_key BFF_RATE_LIMIT_ENABLED \
    && [[ "$(value_of BFF_RATE_LIMIT_ENABLED)" == "true" ]] \
    && [[ "${rate_limit_store}" != "redis" ]]; then
    fail "BFF_RATE_LIMIT_STORE must be redis for ACS when BFF_RATE_LIMIT_ENABLED=true"
  fi
fi

if has_key BFF_RATE_LIMIT_ENABLED \
  && [[ "$(value_of BFF_RATE_LIMIT_ENABLED)" == "true" ]] \
  && has_key BFF_RATE_LIMIT_TRUST_X_FORWARDED_FOR \
  && [[ "$(value_of BFF_RATE_LIMIT_TRUST_X_FORWARDED_FOR)" != "true" ]]; then
  fail "BFF_RATE_LIMIT_TRUST_X_FORWARDED_FOR must be true for ACS when BFF_RATE_LIMIT_ENABLED=true"
fi

if has_key BFF_ENTITLEMENT_IAM_MOCK_ENABLED && [[ "$(value_of BFF_ENTITLEMENT_IAM_MOCK_ENABLED)" != "false" ]]; then
  fail "BFF_ENTITLEMENT_IAM_MOCK_ENABLED must be false for ACS"
fi

if has_key BFF_SECURITY_HEADERS_HSTS_ENABLED && [[ "$(value_of BFF_SECURITY_HEADERS_HSTS_ENABLED)" != "true" ]]; then
  fail "BFF_SECURITY_HEADERS_HSTS_ENABLED must be true for ACS"
fi

if has_key BFF_CORS_ENABLED && [[ "$(value_of BFF_CORS_ENABLED)" == "true" ]]; then
  if ! has_key BFF_CORS_ALLOWED_ORIGINS || [[ -z "$(value_of BFF_CORS_ALLOWED_ORIGINS)" ]]; then
    fail "BFF_CORS_ALLOWED_ORIGINS must not be blank when BFF_CORS_ENABLED=true"
  else
    cors_allowed_origins="$(value_of BFF_CORS_ALLOWED_ORIGINS)"
    IFS=',' read -r -a cors_origin_entries <<< "${cors_allowed_origins}"
    for raw_origin in "${cors_origin_entries[@]}"; do
      origin="$(trim "${raw_origin}")"
      if [[ -z "${origin}" ]]; then
        continue
      fi
      if [[ "${origin}" == "*" ]]; then
        fail "BFF_CORS_ALLOWED_ORIGINS must not contain wildcard origins"
        continue
      fi
      if [[ ! "${origin}" =~ ^https:// ]]; then
        fail "BFF_CORS_ALLOWED_ORIGINS must contain only https:// origins"
        continue
      fi
      cors_host="$(host_from_url "${origin}")"
      if [[ -z "${cors_host}" ]]; then
        fail "BFF_CORS_ALLOWED_ORIGINS entries must include a host"
      elif is_local_host "${cors_host}"; then
        fail "BFF_CORS_ALLOWED_ORIGINS must not point to localhost for ACS"
      fi
    done
  fi
fi

bool_keys=(
  MANAGEMENT_PROMETHEUS_METRICS_EXPORT_ENABLED
  BFF_CORS_ENABLED
  BFF_SECURITY_HEADERS_HSTS_ENABLED
  BFF_SECURITY_HEADERS_HSTS_INCLUDE_SUBDOMAINS
  BFF_SECURITY_HEADERS_HSTS_PRELOAD
  BFF_AUTH_LOCAL_LOGIN_ENABLED
  BFF_REQUEST_SIZE_LIMIT_ENABLED
  BFF_RATE_LIMIT_ENABLED
  BFF_RATE_LIMIT_TRUST_X_FORWARDED_FOR
  SPRING_DATA_REDIS_SSL_ENABLED
  BFF_PROXY_HEALTH_CHECK_STARTUP_ENABLED
  BFF_PROXY_HEALTH_CHECK_SCHEDULED_ENABLED
  BFF_PROXY_BCM_LEGACY_PASSTHROUGH_ENABLED
  BFF_PROXY_BCM_TLS_INSECURE_SKIP_VERIFY
  BFF_PROXY_BCM_MTLS_ENABLED
  BFF_PROXY_BCM_MTLS_INSECURE_SKIP_VERIFY
  BFF_PROXY_BCM_HEALTH_CHECK_ENABLED
  BFF_PROXY_BCO_ENABLED
  BFF_PROXY_BCO_TLS_INSECURE_SKIP_VERIFY
  BFF_PROXY_BCO_HEALTH_CHECK_ENABLED
  BFF_ENTITLEMENT_IAM_MOCK_ENABLED
  BFF_ENTITLEMENT_IAM_CIRCUIT_BREAKER_ENABLED
)

for key in "${bool_keys[@]}"; do
  require_bool "${key}"
done

number_keys=(
  SERVER_PORT
  BFF_CORS_MAX_AGE_SECONDS
  BFF_SECURITY_HEADERS_HSTS_MAX_AGE_SECONDS
  BFF_ACCESS_TOKEN_TTL_SECONDS
  BFF_REFRESH_TOKEN_TTL_SECONDS
  BFF_SESSION_TTL_SECONDS
  BFF_REQUEST_SIZE_LIMIT_AUTH_MAX_BYTES
  BFF_REQUEST_SIZE_LIMIT_BCM_MAX_BYTES
  BFF_REQUEST_SIZE_LIMIT_BCO_MAX_BYTES
  BFF_REQUEST_SIZE_LIMIT_BFF_MAX_BYTES
  BFF_RATE_LIMIT_MAX_BUCKETS
  BFF_RATE_LIMIT_AUTH_MAX_REQUESTS
  BFF_RATE_LIMIT_AUTH_WINDOW_SECONDS
  BFF_RATE_LIMIT_BCM_MAX_REQUESTS
  BFF_RATE_LIMIT_BCM_WINDOW_SECONDS
  BFF_RATE_LIMIT_BCO_MAX_REQUESTS
  BFF_RATE_LIMIT_BCO_WINDOW_SECONDS
  BFF_RATE_LIMIT_BFF_MAX_REQUESTS
  BFF_RATE_LIMIT_BFF_WINDOW_SECONDS
  SPRING_DATA_REDIS_PORT
  BFF_PROXY_HEALTH_CHECK_INITIAL_DELAY_MILLIS
  BFF_PROXY_HEALTH_CHECK_INTERVAL_MILLIS
  BFF_PROXY_BCM_RESPONSE_TIMEOUT_MILLIS
  BFF_PROXY_BCM_HEALTH_CHECK_TIMEOUT_MILLIS
  BFF_PROXY_BCO_RESPONSE_TIMEOUT_MILLIS
  BFF_PROXY_BCO_HEALTH_CHECK_TIMEOUT_MILLIS
  BFF_ENTITLEMENT_IAM_REQUEST_TIMEOUT_MILLIS
  BFF_ENTITLEMENT_IAM_CIRCUIT_BREAKER_FAILURE_THRESHOLD
  BFF_ENTITLEMENT_IAM_CIRCUIT_BREAKER_OPEN_MILLIS
)

for key in "${number_keys[@]}"; do
  require_number "${key}"
done

if has_key BFF_SECURITY_HEADERS_HSTS_MAX_AGE_SECONDS && [[ "$(value_of BFF_SECURITY_HEADERS_HSTS_MAX_AGE_SECONDS)" == "0" ]]; then
  fail "BFF_SECURITY_HEADERS_HSTS_MAX_AGE_SECONDS must be greater than zero for ACS"
fi

if has_key BFF_CORS_MAX_AGE_SECONDS && [[ "$(value_of BFF_CORS_MAX_AGE_SECONDS)" == "0" ]]; then
  fail "BFF_CORS_MAX_AGE_SECONDS must be greater than zero for ACS"
fi

require_min_length_unless_placeholder BFF_JWT_SECRET 32

if has_key BFF_JWT_SECRET; then
  jwt_secret="$(value_of BFF_JWT_SECRET)"
  if [[ "${jwt_secret}" == "local-dev-change-me-at-least-32-bytes" || "${jwt_secret}" == local-dev-* ]]; then
    fail "BFF_JWT_SECRET must not use a local development value"
  fi
fi

if has_key BFF_JWT_KEY_ID; then
  jwt_key_id="$(value_of BFF_JWT_KEY_ID)"
  if [[ "${jwt_key_id}" == "local" ]]; then
    fail "BFF_JWT_KEY_ID must not use the local development value"
  fi
fi

if has_key BFF_JWT_PREVIOUS_KEYS; then
  previous_keys="$(value_of BFF_JWT_PREVIOUS_KEYS)"
  if [[ -n "${previous_keys}" ]]; then
    IFS=',' read -r -a previous_key_entries <<< "${previous_keys}"
    for raw_entry in "${previous_key_entries[@]}"; do
      entry="$(trim "${raw_entry}")"
      [[ -z "${entry}" ]] && continue

      if [[ "${entry}" != *=* ]]; then
        fail "BFF_JWT_PREVIOUS_KEYS must use comma-separated kid=secret entries"
        continue
      fi

      previous_key_id="$(trim "${entry%%=*}")"
      previous_secret="$(trim "${entry#*=}")"
      if [[ -z "${previous_key_id}" || -z "${previous_secret}" ]]; then
        fail "BFF_JWT_PREVIOUS_KEYS entries must not contain blank kid or secret"
        continue
      fi

      if has_key BFF_JWT_KEY_ID && [[ "${previous_key_id}" == "$(value_of BFF_JWT_KEY_ID)" ]]; then
        fail "BFF_JWT_PREVIOUS_KEYS must not repeat BFF_JWT_KEY_ID"
      fi
      if ((${#previous_secret} < 32)); then
        fail "BFF_JWT_PREVIOUS_KEYS secrets must be at least 32 characters"
      fi
      if [[ "${previous_secret}" == "local-dev-change-me-at-least-32-bytes" || "${previous_secret}" == local-dev-* ]]; then
        fail "BFF_JWT_PREVIOUS_KEYS must not use a local development value"
      fi
    done
  fi
fi

if has_key BFF_MANAGEMENT_ACCESS_METRICS_TOKEN; then
  metrics_token="$(value_of BFF_MANAGEMENT_ACCESS_METRICS_TOKEN)"
  if [[ -n "${metrics_token}" ]]; then
    if ((${#metrics_token} < 32)); then
      fail "BFF_MANAGEMENT_ACCESS_METRICS_TOKEN must be at least 32 characters when configured"
    fi
    require_non_empty BFF_MANAGEMENT_ACCESS_METRICS_TOKEN_HEADER
  fi
fi

if has_key SPRING_DATA_REDIS_HOST; then
  redis_host="$(value_of SPRING_DATA_REDIS_HOST)"
  if ! { is_placeholder "${redis_host}" && is_placeholder_allowed_for_key SPRING_DATA_REDIS_HOST; }; then
    if is_local_host "${redis_host}"; then
      fail "SPRING_DATA_REDIS_HOST must not point to localhost for ACS"
    fi
  fi
fi

if has_key BFF_PROXY_BCM_BASE_URL; then
  bcm_base_url="$(value_of BFF_PROXY_BCM_BASE_URL)"
  if ! { is_placeholder "${bcm_base_url}" && is_placeholder_allowed_for_key BFF_PROXY_BCM_BASE_URL; }; then
    if [[ ! "${bcm_base_url}" =~ ^https?:// ]]; then
      fail "BFF_PROXY_BCM_BASE_URL must start with http:// or https://"
    else
      bcm_host="$(host_from_url "${bcm_base_url}")"
      if [[ -z "${bcm_host}" ]]; then
        fail "BFF_PROXY_BCM_BASE_URL must include a host"
      elif is_local_host "${bcm_host}"; then
        fail "BFF_PROXY_BCM_BASE_URL must not point to localhost for ACS"
      fi
    fi
  fi
fi

if has_key BFF_PROXY_BCO_BASE_URL; then
  bco_base_url="$(value_of BFF_PROXY_BCO_BASE_URL)"
  if ! { is_placeholder "${bco_base_url}" && is_placeholder_allowed_for_key BFF_PROXY_BCO_BASE_URL; }; then
    if [[ ! "${bco_base_url}" =~ ^https?:// ]]; then
      fail "BFF_PROXY_BCO_BASE_URL must start with http:// or https://"
    else
      bco_host="$(host_from_url "${bco_base_url}")"
      if [[ -z "${bco_host}" ]]; then
        fail "BFF_PROXY_BCO_BASE_URL must include a host"
      elif is_local_host "${bco_host}"; then
        fail "BFF_PROXY_BCO_BASE_URL must not point to localhost for ACS"
      fi
    fi
  fi
fi

if has_key BFF_PROXY_BCM_MTLS_ENABLED && [[ "$(value_of BFF_PROXY_BCM_MTLS_ENABLED)" == "true" ]]; then
  require_non_empty BFF_PROXY_BCM_MTLS_CERT_FILE
  require_non_empty BFF_PROXY_BCM_MTLS_KEY_FILE
fi

if [[ ${#failures[@]} -gt 0 ]]; then
  echo "ACS env validation failed for ${ENV_FILE}:" >&2
  for failure in "${failures[@]}"; do
    echo "  - ${failure}" >&2
  done
  exit 1
fi

echo "ACS env validation passed: ${ENV_FILE}"

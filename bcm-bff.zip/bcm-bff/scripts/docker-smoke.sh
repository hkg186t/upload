#!/usr/bin/env bash
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
REPO_DIR="$(cd "${SCRIPT_DIR}/.." && pwd)"

IMAGE_TAG="${DOCKER_IMAGE_TAG:-bcm-bff:smoke}"
DOCKER_BUILD_PLATFORM="${DOCKER_BUILD_PLATFORM:-}"
DOCKER_RUN_PLATFORM="${DOCKER_RUN_PLATFORM:-}"
SKIP_DOCKER_BUILD="${SKIP_DOCKER_BUILD:-false}"
SMOKE_TIMEOUT_SECONDS="${SMOKE_TIMEOUT_SECONDS:-60}"
SMOKE_METRICS_MODE="${SMOKE_METRICS_MODE:-protected}"
DOCKER_SMOKE_HOST="${DOCKER_SMOKE_HOST:-127.0.0.1}"
CONTAINER_ID=""

cleanup() {
  if [[ -n "${CONTAINER_ID}" ]]; then
    docker rm -f "${CONTAINER_ID}" >/dev/null 2>&1 || true
  fi
}
trap cleanup EXIT

if [[ "${SKIP_DOCKER_BUILD}" != "true" ]]; then
  echo "Building Docker image with Gradle docker task: ${IMAGE_TAG}"
  if [[ -n "${DOCKER_BUILD_PLATFORM}" ]]; then
    echo "DOCKER_BUILD_PLATFORM is ignored by the Gradle docker task; configure the Docker daemon or BEA pipeline node architecture instead."
  fi
  (cd "${REPO_DIR}" && ./gradlew docker -PdockerImageTag="${IMAGE_TAG}")
fi

echo "Starting Docker smoke container"
run_platform_args=()
if [[ -n "${DOCKER_RUN_PLATFORM}" ]]; then
  run_platform_args=(--platform "${DOCKER_RUN_PLATFORM}")
fi
CONTAINER_ID="$(
  docker run -d --rm \
    "${run_platform_args[@]}" \
    -p 127.0.0.1::8080 \
    -e BFF_JWT_SECRET=local-dev-test-secret-at-least-32-bytes \
    -e BFF_PROXY_BCM_BASE_URL=http://127.0.0.1:19090 \
    "${IMAGE_TAG}"
)"

HOST_PORT="$(docker port "${CONTAINER_ID}" 8080/tcp | tail -n 1 | sed -E 's/.*:([0-9]+)$/\1/')"
if [[ -z "${HOST_PORT}" ]]; then
  echo "Unable to resolve mapped container port" >&2
  docker logs "${CONTAINER_ID}" >&2 || true
  exit 1
fi

HEALTH_URL="http://${DOCKER_SMOKE_HOST}:${HOST_PORT}/health"
READINESS_URL="http://${DOCKER_SMOKE_HOST}:${HOST_PORT}/actuator/health/readiness"
DEADLINE=$(( $(date +%s) + SMOKE_TIMEOUT_SECONDS ))

until curl -fsS "${HEALTH_URL}" >/dev/null 2>&1 && curl -fsS "${READINESS_URL}" >/dev/null 2>&1; do
  if (( $(date +%s) >= DEADLINE )); then
    echo "Docker smoke check timed out after ${SMOKE_TIMEOUT_SECONDS}s" >&2
    echo "Health URL: ${HEALTH_URL}" >&2
    docker logs "${CONTAINER_ID}" >&2 || true
    exit 1
  fi
  sleep 2
done

echo "Docker smoke checks passed: ${HEALTH_URL}, ${READINESS_URL}"

echo "Running post-deploy behavior checks against smoke container"
"${REPO_DIR}/scripts/post-deploy-check.sh" \
  --base-url "http://${DOCKER_SMOKE_HOST}:${HOST_PORT}" \
  --timeout-seconds "${SMOKE_TIMEOUT_SECONDS}" \
  --metrics-mode "${SMOKE_METRICS_MODE}"

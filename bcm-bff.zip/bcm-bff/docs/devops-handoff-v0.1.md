# BCM BFF DevOps Handoff v0.1

This handoff is for building a deployment pipeline for the BEA BCM BFF service.

## Repositories

- Runtime service: `bcm-services/bcm-bff`
- API contracts: `bcm-contracts`

The BFF build is self-contained after contract sync because `bff-contract-adapter/src/main/openapi` keeps an in-repo OpenAPI snapshot. Docker builds should not require the sibling `bcm-contracts` checkout.

The BEA intranet pipeline should use the standard `Jenkinsfile` in this directory. The build uses Gradle, resolves dependencies only from BEA internal JFrog, and builds the image through the standard Gradle docker task with `src/main/docker/Dockerfile`.

## Pipeline Inputs

- Git commit SHA for `bcm-services`.
- Git commit SHA for `bcm-contracts`, used by the route and OpenAPI sync checks.
- Image tag, recommended format: `<registry>/bcm-bff:<git-sha>`.
- ACS runtime env file based on `deploy/acs.env.example`.
- ACS/K8s deployment manifest based on `deploy/acs.k8s.example.yaml`.

## Required Pipeline Stages

Standard BEA DevOps entrypoint:

```groovy
@Library("hkbea-shared-library") _
microservicePipeline {
	credentialsIdUsernamePasswordBuildBot = 'jenkins_buildbot'
	credentialsIdStringSonarToken = 'sonar_buildbot'
	withClient = false
	namespace = 'bcm'
	dockerPublishRepo = 'xdoartdev.intranet.hkbea.com/hkbea-docker-beta-local'
	sonarUrl = 'https://lapxdo01p.intranet.hkbea.com:9000'
	deployEnv = 'n'
	jvmVersion = 17
}
```

Recommended single-entry release gate:

```bash
cd bcm-services/bcm-bff
./scripts/release-image.sh \
  --image-tag <registry>/bcm-bff:<git-sha> \
  --env-file /path/to/bcm-bff-prod.env \
  --manifest-file /path/to/acs.k8s.yaml \
  --contracts ../../bcm-contracts \
  --push
```

The script validates the ACS env file, optionally verifies the ACS manifest covers every env key, runs contract drift checks, lints the OpenAPI contracts, runs Java tests, builds and smoke-tests the Docker image, and pushes the image only after all checks pass.

## Gradle And JFrog

- Wrapper distribution: `gradle/wrapper/gradle-wrapper.properties` points to BEA internal Artifactory.
- Plugin and dependency repository: `https://xdoartdev.intranet.hkbea.com/artifactory/mvn`.
- Dependency credentials: `mavenUser` and `mavenPassword` from Jenkins/`~/.gradle/gradle.properties`.
- Publish target: `artifactoryPublishUrl=https://xdoartdev.intranet.hkbea.com/artifactory`, `artifactoryPublishRepo=hkbea-mvn-beta-local`.
- Docker repository base: `xdoartdev.intranet.hkbea.com/hkbea-docker-beta-local/bcm`.
- Image base: `xdoartdev.intranet.hkbea.com/cdc-docker-local/eclipse-temurin:21.0.11_10-jre-alpine-3.23`.

Expanded pipeline stages:

1. Checkout `bcm-services` and `bcm-contracts` side by side.
2. Enter `bcm-services/bcm-bff`.
3. Validate contract/runtime drift:

```bash
./scripts/sync-proxy-routes.mjs --check --contracts ../../bcm-contracts
./scripts/sync-openapi-contracts.sh --check --contracts ../../bcm-contracts
```

4. Validate OpenAPI contracts:

```bash
cd ../../bcm-contracts
npm ci
npm run lint:all
cd ../bcm-services/bcm-bff
```

5. Validate the ACS env file and deployment manifest coverage:

```bash
./scripts/validate-acs-env.sh /path/to/bcm-bff-prod.env
./scripts/validate-acs-manifest-env.sh /path/to/bcm-bff-prod.env /path/to/acs.k8s.yaml
```

6. Run CI and local container smoke through Gradle:

```bash
RUN_DOCKER_SMOKE=true \
DOCKER_IMAGE_TAG=<registry>/bcm-bff:<git-sha> \
./scripts/ci-check.sh
```

7. Push the image only after the CI and smoke checks pass:

```bash
docker push <registry>/bcm-bff:<git-sha>
```

8. Deploy to ACS with the same image tag and validated env values.
9. Run post-deployment checks:

```bash
./scripts/post-deploy-check.sh --base-url https://<bcm-bff-host>
```

From Jenkins or an ACS debug shell that has bash and curl available, run the smoke script to capture the direct startup probe and confirm BCM/BCO return HTTP responses. These upstream checks intentionally skip certificate verification and only prove network/application reachability:

```bash
./scripts/post-deploy-check.sh \
  --acs-local \
  --metrics-mode skip \
  --skip-protected \
  --upstream-response BCO,GET,https://cdcuat-cmapp1.intranet.hkbea.com:9443/digx/v1/bankConfiguration,192.168.20.45 \
  --upstream-response BCM,POST,https://eam-intgw-test.intranet.hkbea.com/hkbea/uat-int/corporate/v1/approval/center/demandDeposit/searchCompanies,192.168.20.157
```

If metrics scraping uses the dedicated management token:

```bash
./scripts/post-deploy-check.sh \
  --base-url https://<bcm-bff-host> \
  --metrics-mode token \
  --metrics-token "$BFF_MANAGEMENT_ACCESS_METRICS_TOKEN"
```

For non-pushing local template checks, use:

```bash
./scripts/release-image.sh \
  --image-tag bcm-bff:release-smoke \
  --env-file deploy/acs.env.example \
  --manifest-file deploy/acs.k8s.example.yaml \
  --allow-placeholder-env
```

## Runtime Artifacts

- `Jenkinsfile`: BEA standard `microservicePipeline` entrypoint.
- `build.gradle`, `settings.gradle`, `gradle.properties`, `gradlew`, and `gradle/wrapper/*`: Gradle build and internal JFrog dependency resolution.
- `src/main/docker/Dockerfile`: Gradle docker-task image recipe.
- `deploy/acs.env.example`: flat env template for ACS configuration.
- `deploy/acs.k8s.example.yaml`: K8s-compatible starter manifest for Secret, ConfigMap, Deployment, and Service.
- `docs/commit-readiness-v0.1.md`: commit/PR checklist for the coordinated contract and BFF runtime changes.
- `scripts/validate-acs-env.sh`: deployment gate for env files.
- `scripts/validate-acs-manifest-env.sh`: verifies the starter manifest carries all keys from the ACS env template.
- `scripts/docker-smoke.sh`: image build plus container health, readiness, metrics-access, and protected-endpoint smoke test.
- `scripts/ci-check.sh`: route drift, OpenAPI snapshot drift, contract lint, Java tests, env template check, whitespace check, and optional Docker smoke.
- `scripts/release-image.sh`: release gate that wraps env validation, optional manifest coverage, CI, Docker smoke, and optional image push.
- `scripts/post-deploy-check.sh`: post-deployment check for health probes, metrics access policy, and protected endpoint auth behavior.

## Secrets

Inject these from ACS Secret or an approved secret manager. Do not commit real values.

- `BFF_JWT_SECRET`: required, at least 32 characters.
- `SPRING_DATA_REDIS_PASSWORD`: required only when Redis requires password authentication.
- `BFF_MANAGEMENT_ACCESS_METRICS_TOKEN`: optional, at least 32 characters when configured.
- `MANAGEMENT_PROMETHEUS_METRICS_EXPORT_ENABLED`: keep `true` in ACS so post-deploy checks and platform scraping can verify `/actuator/prometheus`.
- `BFF_RATE_LIMIT_STORE`: use `redis` for BFF-managed distributed limits across ACS replicas, or disable BFF rate limiting if gateway/WAF fully owns this control.
- `BFF_PROXY_BCM_IBM_CLIENT_ID` and `BFF_PROXY_BCM_IBM_CLIENT_SECRET`: BCM gateway credentials injected by the BFF proxy.
- BCM currently targets the internal APIC at `BFF_PROXY_BCM_BASE_URL=https://eam-intgw-test.intranet.hkbea.com/hkbea/uat-int/` with `BFF_PROXY_BCM_FALLBACK_IP=192.168.20.157` and `BFF_PROXY_BCM_MTLS_ENABLED=false`. Keep the mTLS mount variables available only for a future gateway that requires client certificates.
- BCO currently targets `BFF_PROXY_BCO_BASE_URL=https://cdcuat-cmapp1.intranet.hkbea.com:9443` with `BFF_PROXY_BCO_FALLBACK_IP=192.168.20.45` and `BFF_PROXY_BCO_TLS_TRUST_CERT_FILE=/opt/bcm/tls/cdcuat-cmapp1.intranet.hkbea.com.pem`. The fallback is implemented as a DNS override so HTTPS Host/SNI stays on the original domain.
- `BFF_PROXY_HEALTH_CHECK_STARTUP_ENABLED=true` emits startup `BFF_PROXY_HEALTHCHECK` logs for ACS network verification. Keep `BFF_PROXY_HEALTH_CHECK_SCHEDULED_ENABLED=false` by default; enable it only temporarily if one-minute upstream reachability checks are needed.

## External Dependencies

- Container registry reachable by ACS.
- Redis reachable from ACS pods or serverless containers: `r-3ns55b26c559d944.redis.cnhk.rds.aliyuncs.com:6379`, with `SPRING_DATA_REDIS_USERNAME=r-3ns55b26c559d944`.
- BCM internal APIC and BCO upstream reachable from ACS network. Check ACS logs for `BFF_PROXY_HEALTHCHECK system=BCM|BCO outcome=reachable` after deployment.
- Observability path for application logs and `/actuator/prometheus`.
- ACS ingress or gateway rule that routes public BFF traffic to the `bcm-bff` service.

## Health And Probes

- Startup: `GET /health`
- Readiness: `GET /actuator/health/readiness`
- Liveness: `GET /actuator/health/liveness`
- Metrics: `GET /actuator/prometheus`

If ACS reports `Startup probe failed ... host unreachable`, compare `curl http://127.0.0.1:8080/health`, `curl http://<pod-ip>:8080/health`, and the service URL from an ACS debug shell. If localhost passes but Pod IP fails, the BFF process is healthy and the issue is ACS Pod networking, security policy, or HTTP probe routing. The Helm chart uses Kubernetes HTTP probes so the slim Temurin Alpine runtime does not need curl. When no public ACS route exists yet, use `./scripts/post-deploy-check.sh --acs-local --metrics-mode skip --skip-protected` from a shell that has bash and curl.

`/actuator/prometheus` requires either a normal authorized Bearer token or the optional `BFF_MANAGEMENT_ACCESS_METRICS_TOKEN` header. The ACS validator requires Prometheus metrics export to stay enabled.

## Release Policy

- Use immutable image tags; do not deploy `latest`.
- Deploy with `SPRING_PROFILES_ACTIVE=prod`.
- Keep `BFF_AUTH_LOGIN_PROVIDER=disabled` until the real IAM login client is implemented.
- Keep `BFF_ENTITLEMENT_PROVIDER=session` until a production entitlement provider is implemented.
- Keep `BFF_ENTITLEMENT_IAM_MOCK_ENABLED=false` in all ACS environments.
- Keep `BFF_PROXY_BCM_LEGACY_PASSTHROUGH_ENABLED=true` only during the `proxy/bcm-proxy` migration window; later move each `/corporate/**` API into `bcm-contracts` and generated route config.
- Keep `BFF_PROXY_BCO_ENABLED=true` while `/digx/**` BCO endpoints are still served through this BFF pass-through path.
- Start with two replicas for rolling update safety. Tune replica count and resource limits after load testing.

## Rollback

Rollback should switch the Deployment image back to the previous immutable tag. No database migration is introduced by this BFF baseline. Session data is stored in Redis and should remain compatible across this v0.1 rollout.

Before rollback, capture:

- failing image tag
- previous stable image tag
- `BCM_PROD_CONFIG_VALIDATION` startup log line
- readiness/liveness failures
- `BCM_HTTP_ACCESS`, `BCM_PROXY_ACCESS`, and `BCM_AGGREGATION_ACCESS` error rates
- `scripts/post-deploy-check.sh` output, including `/health`, readiness/liveness, and BCM/BCO upstream HTTP response statuses

# BFF + bcm-contracts API-First Integration v0.1

## Decision

`../bcm-contracts` is the source of truth for externally visible APIs. `bcm-bff` is the runtime implementation that consumes generated interfaces/models and implements access control, proxying, and aggregation.

## Responsibilities

`bcm-contracts` owns:

- OpenAPI definitions.
- Common headers, schemas, responses, and security schemes.
- Spectral lint rules.
- Mock and example responses.
- Portal/API documentation.
- SDK and server adapter generation.
- Contract tests.

`bcm-bff` owns:

- JWT and Redis-backed session runtime.
- Access-control filters and 401/419 behavior.
- BCM/BCO proxy implementation.
- Upstream session injection and mTLS.
- Aggregation orchestration.
- ACS-ready Docker image.

## Generated Code Rule

Generated code is treated as disposable adapter code. It should not contain business logic and should not be manually edited. The BFF implementation lives in service classes under `bff-access-control`, `bff-proxy`, and `bff-aggregation`.

`bff-contract-adapter` now compiles the API-first server adapter during Gradle builds. The source of that generation is the synced OpenAPI snapshot under:

```text
bff-contract-adapter/src/main/openapi/root.yaml
```

The snapshot is copied from `../bcm-contracts/contracts` with:

```bash
./scripts/sync-openapi-contracts.sh
```

CI runs `./scripts/sync-openapi-contracts.sh --check` when `../bcm-contracts` is available. This keeps Docker builds self-contained while still failing fast when the BFF snapshot drifts from the API-first contract source. The generated Java output remains under `bff-contract-adapter/build/generated/openapi` and is not committed.

## First API Set

The first contract batch defines:

- `POST /auth/login`
- `POST /auth/refresh`
- `POST /auth/logout`
- Standard `401`, `419`, `429`, `502`, and `504` error responses

The proxy contract batch defines `POST /bcm/demo/user-profile` as the first protected BCM proxy demo API. The aggregation contract batch defines `POST /bff/demo/home-summary` as the first protected BFF aggregation demo API. The next contract batch should define the generated server adapter package layout.

## Proxy Route Metadata

BCM proxy route configuration starts in `bcm-contracts` as OpenAPI vendor extensions. Each proxy operation can declare:

```yaml
x-bcm-bff-route:
  routeId: user-profile
  upstreamSystem: bcm
  upstreamMethod: POST
  upstreamPath: /corporate/v1/approval/center/user/userProfile
  responseTimeoutMillis: 30000
  htmlResponseMeansSessionExpired: true
  retryMaxAttempts: 1
  retryBackoffMillis: 100
  bulkheadMaxConcurrentRequests: 200
  circuitBreakerEnabled: true
  circuitBreakerFailureThreshold: 5
  circuitBreakerOpenMillis: 30000
  requiredRoles: [BCM_USER]
  requiredScopes: [bcm:proxy]
  allowedDeviceOs: [Android, iOS]
```

`bcm-bff/scripts/sync-proxy-routes.mjs` extracts these extensions and writes `bff-bootstrap/src/main/resources/bcm-proxy-routes.yaml`. The generated YAML is loaded by Spring Boot through `spring.config.import`, so the route registry used by the runtime stays aligned with the API contract. CI should run `./scripts/sync-proxy-routes.mjs --check` to fail fast when contracts changed but the generated runtime config was not committed.

The sync script infers the public BFF method/path from the OpenAPI path item and operation. For example, `POST /bcm/demo/user-profile` becomes `public-method: POST` and `public-path: /bcm/demo/user-profile` in the generated runtime YAML. The BFF runtime uses a generic `/bcm/**` controller that resolves public method/path to a `routeId` and delegates all upstream forwarding to `bff-proxy`.

The generated route registry also carries the first resilience controls. Timeout, retry, bulkhead, and circuit-breaker values are intentionally route-scoped because BCM endpoints have different idempotency and latency profiles. The default retry policy is conservative: `retryMaxAttempts: 1`, meaning no retry. Retrying POST routes must be explicitly approved and configured.

The same metadata can carry route-level authorization policy. `requiredRoles`, `requiredScopes`, and `allowedDeviceOs` are generated into `bff.authorization.rules`, so contract review covers both the public API shape and the BFF entry-access policy for that route. The runtime checks these rules after token/session validation and before the proxy controller forwards to BCM.

The current policy semantics are intentionally simple and fast:

- `requiredRoles`: all listed roles must exist on the session.
- `requiredScopes`: all listed scopes must exist on the session.
- `allowedDeviceOs`: if non-empty, the session device OS must match one of the listed values case-insensitively.
- Missing route policy means allow after normal token/session validation.

The policy service does not read these attributes from `SessionRecord` directly. It resolves an `EntitlementContext` through `EntitlementProvider`, whose default implementation reads from the BFF session. This keeps the first runtime lightweight while giving production integrations a stable seam for Keycloak claims, internal IAM entitlement lookup, or Casbin-backed decisions.

`BFF_ENTITLEMENT_PROVIDER` controls the provider mode. Implemented runtime modes are `session` and `iam` with an explicitly enabled mock client. The IAM provider already has timeout and circuit-breaker settings so the real client can be wired without changing the route policy service:

```bash
BFF_ENTITLEMENT_PROVIDER=iam
BFF_ENTITLEMENT_IAM_MOCK_ENABLED=true
BFF_ENTITLEMENT_IAM_REQUEST_TIMEOUT_MILLIS=500
BFF_ENTITLEMENT_IAM_CIRCUIT_BREAKER_FAILURE_THRESHOLD=5
BFF_ENTITLEMENT_IAM_CIRCUIT_BREAKER_OPEN_MILLIS=30000
```

`iam` without an `IamEntitlementClient` fails fast at startup. Reserved modes `jwt` and `casbin` are accepted as known configuration values but fail fast until their production integrations are implemented.

## Aggregation Metadata

BFF aggregation configuration also starts in `bcm-contracts` as OpenAPI vendor extensions. Each aggregation operation can declare:

```yaml
x-bcm-bff-aggregation:
  aggregationId: home-summary
  responseTimeoutMillis: 30000
  partialResponseEnabled: true
  maxConcurrentSteps: 4
  steps: [userProfile:user-profile:required]
  requiredRoles: [BCM_USER]
  requiredScopes: [bcm:aggregate]
  allowedDeviceOs: [Android, iOS]
```

`steps` is intentionally compact for the first version: `responseName:proxyRouteId:required` or `responseName:proxyRouteId:optional`. The runtime resolves each `proxyRouteId` through the same proxy registry generated from `x-bcm-bff-route`, executes steps with bounded parallelism, and returns results under `data.items`.

Required step failures fail the whole aggregation. Optional step failures return `data.partial=true` with a per-step `data.errors` entry. Authentication/session failures such as `401` and `419` are always fatal, even for optional steps, so the frontend can consistently return the user to pre-login when the BCM session is invalid or replaced.

The same aggregation metadata generates route-level authorization policy into `bff.authorization.rules`. Aggregation route policy is evaluated at the public BFF route boundary; internal step execution does not separately re-run HTTP route authorization.

Startup validation fails fast if generated route configuration is inconsistent. Public proxy routes must stay under `/bcm/`, public aggregation routes must stay under `/bff/`, public method/path pairs must be unique, and every aggregation step must reference a known proxy route. Proxy routes without a public path are allowed as internal aggregation-only routes.

## Proxy Observability

The proxy runtime emits one `BCM_PROXY_ACCESS` log per upstream exchange. The log includes `routeId`, normalized `traceId`, upstream method/status, outcome, error code, duration, and whether a query string was present. Request and response bodies are intentionally excluded from this access log to avoid leaking sensitive banking data.

The edge `TraceIdWebFilter` accepts short ASCII `X-Request-Id` or `X-Correlation-Id` values using letters, digits, `.`, `_`, `:`, or `-`. Unsafe, blank, `null`, or oversized values are replaced with a server-generated UUID before the trace ID is logged, returned, or forwarded to BCM.

Micrometer exports the same high-level signal as `bcm_bff_proxy_duration_seconds`. Metric tags are intentionally low cardinality: `routeId`, `method`, `outcome`, `upstreamStatus`, `errorCode`, and `failureReason`. `traceId` stays in logs only.

IAM entitlement lookup emits `BCM_ENTITLEMENT_ACCESS` with provider, outcome, error code, duration, role count, scope count, and whether device OS is present. It intentionally excludes user ID, customer ID, and session ID. Micrometer exports the same latency signal as `bcm_bff_entitlement_duration_seconds` with tags `provider`, `outcome`, and `errorCode`.

JWT validation failures emit `BCM_AUTH_ACCESS` with a safe `failureReason` and increment `bcm_bff_auth_jwt_validation_failures_total` with tags `event`, `errorCode`, and `failureReason`.

Aggregation emits `BCM_AGGREGATION_ACCESS` with aggregation ID, trace ID, outcome, duration, step count, partial flag, and error count. Micrometer exports `bcm_bff_aggregation_duration_seconds` with tags `aggregationId`, `outcome`, and `errorCode`.

## Access-Control Direction

The first implementation uses Spring Security, JWT, and Redis session state. Keycloak can be integrated later if BCM adopts centralized IAM/OIDC. Casbin is reserved for dynamic RBAC/ABAC policy if route-level authorization becomes complex.

The runtime now has a BFF auth filter: health probes plus `/auth/login` and `/auth/refresh` are public, while all other paths require a valid Bearer token. Session state defaults to an in-memory store for local development and can switch to Redis with `BFF_SESSION_STORE=redis`.

Local login accepts optional `roles` and `scopes` to support integration testing. If omitted, the BFF assigns `BCM_USER` and `bcm:proxy` as local defaults. Production integration should replace these local defaults with authoritative entitlement data from the selected IAM/session source.

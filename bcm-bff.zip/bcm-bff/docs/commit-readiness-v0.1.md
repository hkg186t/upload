# BCM BFF Commit Readiness v0.1

This checklist keeps the BFF and API-first contract changes clean before commit or PR creation.

## Recommended Commit Split

Use two coordinated commits or PRs if the repositories are reviewed separately:

- `bcm-contracts`: API-first contract baseline for BFF auth, BCM proxy demo, account demo, shared response models, route metadata, and generator script updates.
- `bcm-services`: `bcm-bff` Java service, Gradle build, generated OpenAPI snapshot, route sync, access control, proxy, aggregation, ACS deployment artifacts, and release/post-deploy scripts.

If the team prefers one delivery unit, link both commits in the same change request because `bcm-bff` expects the matching `bcm-contracts` contract shape.

## bcm-contracts Files To Include

- `README.md`
- `contracts/root.yaml`
- `contracts/common.yaml`
- `contracts/apis/account.yaml`
- `contracts/apis/auth.yaml`
- `contracts/apis/bcm-proxy.yaml`
- `package.json`
- `scripts/generate-docs.sh`
- `scripts/generate-sdk.sh`
- `scripts/generate-server.sh`

These changes define the API-first source of truth and the BFF-specific metadata consumed by `bcm-services/bcm-bff`.

## bcm-services Files To Include

Include the full `bcm-bff/` directory, excluding ignored build outputs.

Important included areas:

- `settings.gradle`, `build.gradle`, `gradle.properties`, Gradle wrapper files, and `Jenkinsfile`.
- `bff-shared`, `bff-access-control`, `bff-proxy`, `bff-aggregation`, `bff-contract-adapter`, and `bff-bootstrap` source and tests.
- `bff-contract-adapter/src/main/openapi`, which is the synced OpenAPI snapshot used by Docker builds.
- `bff-bootstrap/src/main/resources/bcm-proxy-routes.yaml`, which is generated from contract metadata.
- `deploy/`, `docs/`, and `scripts/` operational artifacts.

## Do Not Commit

- Gradle build outputs: `.gradle/` and `build/` directories.
- Legacy Maven build outputs: `target/`.
- Real ACS env files: `.env`, `.env.*`, or any copied production secret file.
- Docker image archives or registry credentials.
- Logs, PID files, local IDE metadata, and temporary smoke-test files.
- Real `BFF_JWT_SECRET`, Redis password, metrics token, upstream credentials, mTLS keys, or customer data.

The `bcm-bff/.gitignore` should keep these local files out of staging.

## Required Checks Before Commit

From `bcm-services/bcm-bff`:

```bash
./scripts/ci-check.sh
```

For the container/release path:

```bash
RUN_DOCKER_SMOKE=true DOCKER_IMAGE_TAG=bcm-bff:ci-smoke ./scripts/ci-check.sh
```

For the pipeline entrypoint without pushing:

```bash
./scripts/release-image.sh \
  --image-tag bcm-bff:release-smoke \
  --env-file deploy/acs.env.example \
  --allow-placeholder-env
```

For a real ACS env file:

```bash
./scripts/validate-acs-env.sh /path/to/bcm-bff-prod.env
```

## Safe Staging Preview

Before staging, preview what Git would add:

```bash
git -C /Users/williai/DRepo/bcm-services add -n bcm-bff
git -C /Users/williai/DRepo/bcm-contracts add -n \
  README.md \
  contracts/root.yaml \
  contracts/common.yaml \
  contracts/apis/account.yaml \
  contracts/apis/auth.yaml \
  contracts/apis/bcm-proxy.yaml \
  package.json \
  scripts/generate-docs.sh \
  scripts/generate-sdk.sh \
  scripts/generate-server.sh
```

The preview must not show `target/`, real env files, logs, or secrets.

## Suggested Commit Messages

For `bcm-contracts`:

```text
feat: add BCM BFF API-first contracts
```

For `bcm-services`:

```text
feat: add Java BCM BFF service baseline
```

## Known Follow-Ups

- Replace `BFF_AUTH_LOGIN_PROVIDER=disabled` with a real IAM/core-banking login integration before production traffic.
- Replace session-derived entitlement mode with real IAM or policy-engine entitlements when available.
- Decide whether strict global rate limits are owned by BFF Redis mode or by ALB/API Gateway/WAF for each environment.
- Load-test ACS resource requests/limits before final production sizing.
- Clean up OpenAPI unused-component warnings in `bcm-contracts` when the shared components mature.

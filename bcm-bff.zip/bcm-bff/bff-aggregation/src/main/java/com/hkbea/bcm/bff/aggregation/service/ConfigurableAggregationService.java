package com.hkbea.bcm.bff.aggregation.service;

import com.fasterxml.jackson.databind.JsonNode;
import com.hkbea.bcm.bff.aggregation.config.AggregationProperties;
import com.hkbea.bcm.bff.aggregation.config.AggregationProperties.Route;
import com.hkbea.bcm.bff.aggregation.config.AggregationProperties.Step;
import com.hkbea.bcm.bff.aggregation.model.AggregationResult;
import com.hkbea.bcm.bff.aggregation.model.AggregationStepError;
import com.hkbea.bcm.bff.proxy.model.ProxyRequestContext;
import com.hkbea.bcm.bff.proxy.service.BcmProxyService;
import com.hkbea.bcm.bff.shared.api.BffException;
import com.hkbea.bcm.bff.shared.api.ErrorCode;
import io.micrometer.core.instrument.MeterRegistry;
import io.micrometer.core.instrument.Timer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.ObjectProvider;
import org.springframework.stereotype.Service;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

import java.time.Duration;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.concurrent.TimeoutException;

@Service
public class ConfigurableAggregationService implements AggregationService {
    private static final Logger log = LoggerFactory.getLogger(ConfigurableAggregationService.class);
    private static final String METRIC_AGGREGATION_DURATION = "bcm.bff.aggregation.duration";

    private final AggregationProperties properties;
    private final BcmProxyService proxyService;
    private final MeterRegistry meterRegistry;

    public ConfigurableAggregationService(
            AggregationProperties properties,
            BcmProxyService proxyService,
            ObjectProvider<MeterRegistry> meterRegistryProvider
    ) {
        this.properties = properties;
        this.proxyService = proxyService;
        this.meterRegistry = meterRegistryProvider.getIfAvailable();
    }

    @Override
    public Mono<AggregationResult> aggregate(String aggregationId, JsonNode requestBody, ProxyRequestContext context) {
        Route route = properties.resolveRoute(aggregationId);
        long startedAtNanos = System.nanoTime();
        return Mono.defer(() -> executeRoute(route, requestBody, context))
                .timeout(Duration.ofMillis(route.getResponseTimeoutMillis()))
                .onErrorMap(TimeoutException.class,
                        error -> new BffException(ErrorCode.UPSTREAM_TIMEOUT, "Aggregation timed out"))
                .doOnSuccess(result -> recordSuccess(aggregationId, route, context, result, startedAtNanos))
                .doOnError(error -> recordFailure(aggregationId, route, context, error, startedAtNanos));
    }

    private Mono<AggregationResult> executeRoute(Route route, JsonNode requestBody, ProxyRequestContext context) {
        return Flux.fromIterable(route.getSteps())
                .flatMapSequential(
                        step -> executeStep(route, step, requestBody, context),
                        route.getMaxConcurrentSteps())
                .collectList()
                .map(outcomes -> {
                    Map<String, JsonNode> items = new LinkedHashMap<>();
                    Map<String, AggregationStepError> errors = new LinkedHashMap<>();
                    for (StepOutcome outcome : outcomes) {
                        if (outcome.error() == null) {
                            items.put(outcome.name(), outcome.item());
                        } else {
                            errors.put(outcome.name(), outcome.error());
                        }
                    }
                    return new AggregationResult(items, !errors.isEmpty(), errors);
                });
    }

    private Mono<StepOutcome> executeStep(
            Route route,
            Step step,
            JsonNode requestBody,
            ProxyRequestContext context
    ) {
        return proxyService.proxy(step.getProxyRouteId(), requestBody, context)
                .map(result -> StepOutcome.success(step.getName(), result.body()))
                .onErrorResume(error -> {
                    if (step.isRequired() || !route.isPartialResponseEnabled() || isSessionFatal(error)) {
                        return Mono.error(error);
                    }
                    return Mono.just(StepOutcome.failure(step.getName(), toStepError(error)));
                });
    }

    private void recordSuccess(
            String aggregationId,
            Route route,
            ProxyRequestContext context,
            AggregationResult result,
            long startedAtNanos
    ) {
        Duration duration = elapsed(startedAtNanos);
        String outcome = result.partial() ? "partial" : "success";
        recordMetric(aggregationId, outcome, "none", duration);
        log.info("BCM_AGGREGATION_ACCESS aggregationId={} traceId={} outcome={} durationMs={} stepCount={} partial={} errorCount={}",
                aggregationId,
                context.traceId(),
                outcome,
                duration.toMillis(),
                route.getSteps().size(),
                result.partial(),
                result.errors().size());
    }

    private void recordFailure(
            String aggregationId,
            Route route,
            ProxyRequestContext context,
            Throwable error,
            long startedAtNanos
    ) {
        Duration duration = elapsed(startedAtNanos);
        String errorCode = errorCode(error);
        recordMetric(aggregationId, "error", errorCode, duration);
        log.warn("BCM_AGGREGATION_ACCESS aggregationId={} traceId={} outcome=error errorCode={} errorType={} durationMs={} stepCount={}",
                aggregationId,
                context.traceId(),
                errorCode,
                error.getClass().getSimpleName(),
                duration.toMillis(),
                route.getSteps().size());
    }

    private void recordMetric(String aggregationId, String outcome, String errorCode, Duration duration) {
        if (meterRegistry == null) {
            return;
        }

        Timer.builder(METRIC_AGGREGATION_DURATION)
                .description("BCM BFF aggregation request duration")
                .tag("aggregationId", aggregationId)
                .tag("outcome", outcome)
                .tag("errorCode", errorCode)
                .register(meterRegistry)
                .record(duration);
    }

    private static boolean isSessionFatal(Throwable error) {
        if (error instanceof BffException bffException) {
            return bffException.errorCode() == ErrorCode.UNAUTHORIZED
                    || bffException.errorCode() == ErrorCode.SESSION_EXPIRED;
        }
        return false;
    }

    private static AggregationStepError toStepError(Throwable error) {
        return new AggregationStepError(errorCode(error), safeMessage(error));
    }

    private static String errorCode(Throwable error) {
        if (error instanceof BffException bffException) {
            return bffException.errorCode().code();
        }
        return ErrorCode.INTERNAL_ERROR.code();
    }

    private static String safeMessage(Throwable error) {
        if (error instanceof BffException bffException) {
            return bffException.getMessage();
        }
        return ErrorCode.INTERNAL_ERROR.defaultMessage();
    }

    private static Duration elapsed(long startedAtNanos) {
        return Duration.ofNanos(System.nanoTime() - startedAtNanos);
    }

    private record StepOutcome(
            String name,
            JsonNode item,
            AggregationStepError error
    ) {
        static StepOutcome success(String name, JsonNode item) {
            return new StepOutcome(name, item, null);
        }

        static StepOutcome failure(String name, AggregationStepError error) {
            return new StepOutcome(name, null, error);
        }
    }
}

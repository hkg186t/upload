package com.hkbea.bcm.bff.aggregation.model;

import com.fasterxml.jackson.databind.JsonNode;

import java.util.Map;

public record AggregationResult(
        Map<String, JsonNode> items,
        boolean partial,
        Map<String, AggregationStepError> errors
) {
}

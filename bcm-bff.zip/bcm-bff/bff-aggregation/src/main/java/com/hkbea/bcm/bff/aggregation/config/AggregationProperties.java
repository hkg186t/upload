package com.hkbea.bcm.bff.aggregation.config;

import com.hkbea.bcm.bff.shared.api.BffException;
import com.hkbea.bcm.bff.shared.api.ErrorCode;
import org.springframework.boot.context.properties.ConfigurationProperties;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

@ConfigurationProperties(prefix = "bff.aggregation")
public class AggregationProperties {
    private static final long DEFAULT_RESPONSE_TIMEOUT_MILLIS = 30000;
    private static final int DEFAULT_MAX_CONCURRENT_STEPS = 4;

    private Map<String, Route> routes = new LinkedHashMap<>();

    public String resolveRouteId(String publicMethod, String publicPath) {
        String requestedMethod = validateHttpMethod("public-aggregation-request", defaultText(publicMethod, ""));
        String requestedPath = normalizePath(publicPath);

        for (Map.Entry<String, Route> entry : routes.entrySet()) {
            Route route = resolveRoute(entry.getKey());
            String routePublicMethod = validateHttpMethod(entry.getKey(), defaultText(route.getPublicMethod(), "POST"));
            String routePublicPath = normalizePath(route.getPublicPath());
            if (requestedMethod.equals(routePublicMethod) && requestedPath.equals(routePublicPath)) {
                return entry.getKey();
            }
        }

        throw new BffException(ErrorCode.BAD_REQUEST, "Unknown BFF aggregation public route: "
                + requestedMethod + " " + requestedPath);
    }

    public Route resolveRoute(String aggregationId) {
        Route route = routes.get(aggregationId);
        if (route == null) {
            throw new BffException(ErrorCode.BAD_REQUEST, "Unknown BFF aggregation route: " + aggregationId);
        }
        if (route.getPublicPath() == null || route.getPublicPath().isBlank()) {
            throw new BffException(ErrorCode.BAD_REQUEST, "BFF aggregation publicPath is required: " + aggregationId);
        }
        if (route.getSteps().isEmpty()) {
            throw new BffException(ErrorCode.BAD_REQUEST, "BFF aggregation steps are required: " + aggregationId);
        }

        Route resolved = new Route();
        resolved.setPublicMethod(validateHttpMethod(aggregationId, defaultText(route.getPublicMethod(), "POST")));
        resolved.setPublicPath(route.getPublicPath());
        resolved.setResponseTimeoutMillis(route.getResponseTimeoutMillis() > 0
                ? route.getResponseTimeoutMillis()
                : DEFAULT_RESPONSE_TIMEOUT_MILLIS);
        resolved.setPartialResponseEnabled(route.isPartialResponseEnabled());
        resolved.setMaxConcurrentSteps(route.getMaxConcurrentSteps() > 0
                ? route.getMaxConcurrentSteps()
                : DEFAULT_MAX_CONCURRENT_STEPS);
        resolved.setSteps(resolveSteps(aggregationId, route.getSteps()));
        return resolved;
    }

    public Map<String, Route> getRoutes() {
        return routes;
    }

    public void setRoutes(Map<String, Route> routes) {
        this.routes = routes == null ? new LinkedHashMap<>() : routes;
    }

    private static List<Step> resolveSteps(String aggregationId, List<Step> steps) {
        List<Step> resolved = new ArrayList<>();
        for (Step step : steps) {
            if (step.getName() == null || step.getName().isBlank()) {
                throw new BffException(ErrorCode.BAD_REQUEST,
                        "BFF aggregation step name is required: " + aggregationId);
            }
            if (step.getProxyRouteId() == null || step.getProxyRouteId().isBlank()) {
                throw new BffException(ErrorCode.BAD_REQUEST,
                        "BFF aggregation step proxyRouteId is required: " + aggregationId + "." + step.getName());
            }
            Step resolvedStep = new Step();
            resolvedStep.setName(step.getName());
            resolvedStep.setProxyRouteId(step.getProxyRouteId());
            resolvedStep.setRequired(step.isRequired());
            resolved.add(resolvedStep);
        }
        return List.copyOf(resolved);
    }

    private static String defaultText(String value, String defaultValue) {
        if (value == null || value.isBlank()) {
            return defaultValue;
        }
        return value.trim();
    }

    private static String validateHttpMethod(String routeId, String method) {
        String normalized = method == null ? "" : method.trim().toUpperCase(Locale.ROOT);
        return switch (normalized) {
            case "GET", "POST", "PUT", "PATCH", "DELETE" -> normalized;
            default -> throw new BffException(ErrorCode.BAD_REQUEST,
                    "Unsupported BFF aggregation route method: " + routeId + " " + method);
        };
    }

    private static String normalizePath(String path) {
        String normalized = defaultText(path, "");
        if (normalized.length() > 1 && normalized.endsWith("/")) {
            return normalized.substring(0, normalized.length() - 1);
        }
        return normalized;
    }

    public static class Route {
        private String publicMethod = "POST";
        private String publicPath;
        private long responseTimeoutMillis;
        private boolean partialResponseEnabled = true;
        private int maxConcurrentSteps = DEFAULT_MAX_CONCURRENT_STEPS;
        private List<Step> steps = List.of();

        public String getPublicMethod() {
            return publicMethod;
        }

        public void setPublicMethod(String publicMethod) {
            this.publicMethod = publicMethod == null ? null : publicMethod.toUpperCase(Locale.ROOT);
        }

        public String getPublicPath() {
            return publicPath;
        }

        public void setPublicPath(String publicPath) {
            this.publicPath = publicPath;
        }

        public long getResponseTimeoutMillis() {
            return responseTimeoutMillis;
        }

        public void setResponseTimeoutMillis(long responseTimeoutMillis) {
            this.responseTimeoutMillis = responseTimeoutMillis;
        }

        public boolean isPartialResponseEnabled() {
            return partialResponseEnabled;
        }

        public void setPartialResponseEnabled(boolean partialResponseEnabled) {
            this.partialResponseEnabled = partialResponseEnabled;
        }

        public int getMaxConcurrentSteps() {
            return maxConcurrentSteps;
        }

        public void setMaxConcurrentSteps(int maxConcurrentSteps) {
            this.maxConcurrentSteps = maxConcurrentSteps;
        }

        public List<Step> getSteps() {
            return steps;
        }

        public void setSteps(List<Step> steps) {
            this.steps = steps == null ? List.of() : steps;
        }
    }

    public static class Step {
        private String name;
        private String proxyRouteId;
        private boolean required = true;

        public String getName() {
            return name;
        }

        public void setName(String name) {
            this.name = name;
        }

        public String getProxyRouteId() {
            return proxyRouteId;
        }

        public void setProxyRouteId(String proxyRouteId) {
            this.proxyRouteId = proxyRouteId;
        }

        public boolean isRequired() {
            return required;
        }

        public void setRequired(boolean required) {
            this.required = required;
        }
    }
}

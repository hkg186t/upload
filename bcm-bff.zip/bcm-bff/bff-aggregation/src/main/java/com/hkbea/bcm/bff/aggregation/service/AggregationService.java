package com.hkbea.bcm.bff.aggregation.service;

import com.fasterxml.jackson.databind.JsonNode;
import com.hkbea.bcm.bff.aggregation.model.AggregationResult;
import com.hkbea.bcm.bff.proxy.model.ProxyRequestContext;
import reactor.core.publisher.Mono;

public interface AggregationService {
    Mono<AggregationResult> aggregate(String aggregationId, JsonNode requestBody, ProxyRequestContext context);
}

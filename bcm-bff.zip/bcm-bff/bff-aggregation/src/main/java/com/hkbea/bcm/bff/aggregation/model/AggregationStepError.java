package com.hkbea.bcm.bff.aggregation.model;

public record AggregationStepError(
        String code,
        String message
) {
}

package com.hkbea.bcm.bff.access.config;

import org.junit.jupiter.api.Test;

import java.util.LinkedHashMap;
import java.util.Map;

import static org.assertj.core.api.Assertions.assertThat;

class AuthorizationPolicyPropertiesTest {
    @Test
    void resolvesExactPathRules() {
        AuthorizationPolicyProperties properties = propertiesWithRule("GET", "/health");

        assertThat(properties.resolve("get", "/health")).isPresent();
    }

    @Test
    void resolvesPathTemplateRules() {
        AuthorizationPolicyProperties properties = propertiesWithRule("GET", "/accounts/{accountId}");

        assertThat(properties.resolve("GET", "/accounts/1234567890")).isPresent();
    }

    @Test
    void resolvesWildcardPrefixRules() {
        AuthorizationPolicyProperties properties = propertiesWithRule("POST", "/corporate/**");

        assertThat(properties.resolve("POST", "/corporate/v1/approval/center/user/userProfile")).isPresent();
    }

    @Test
    void doesNotMatchPathTemplateAcrossSegmentBoundaries() {
        AuthorizationPolicyProperties properties = propertiesWithRule("GET", "/accounts/{accountId}");

        assertThat(properties.resolve("GET", "/accounts/1234567890/transactions")).isEmpty();
    }

    private static AuthorizationPolicyProperties propertiesWithRule(String method, String path) {
        AuthorizationPolicyProperties.Rule rule = new AuthorizationPolicyProperties.Rule();
        rule.setMethod(method);
        rule.setPath(path);

        AuthorizationPolicyProperties properties = new AuthorizationPolicyProperties();
        properties.setRules(new LinkedHashMap<>(Map.of("test", rule)));
        return properties;
    }
}

package com.hkbea.bcm.bff.access.token;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.hkbea.bcm.bff.access.config.AuthProperties;
import com.hkbea.bcm.bff.access.model.SessionRecord;
import com.hkbea.bcm.bff.shared.api.ErrorCode;
import com.hkbea.bcm.bff.shared.session.SessionState;
import org.junit.jupiter.api.Test;

import javax.crypto.Mac;
import javax.crypto.spec.SecretKeySpec;
import java.nio.charset.StandardCharsets;
import java.time.Instant;
import java.util.Base64;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;

class JwtTokenServiceTest {
    private static final String TEST_SECRET = "test-secret-test-secret-test-secret-32";
    private static final String PREVIOUS_SECRET = "previous-secret-previous-secret-32";
    private static final TypeReference<Map<String, Object>> MAP_TYPE = new TypeReference<>() {
    };

    @Test
    void validatesIssuedTokenClaims() {
        JwtTokenService tokenService = tokenService("bcm-bff", "bcm-bff");

        TokenClaims claims = tokenService.validate(
                tokenService.issue(session(), TokenUse.ACCESS, 900, "access-token-id"),
                TokenUse.ACCESS);

        assertThat(claims.subject()).isEqualTo("KYLEWENG@015521104095930");
        assertThat(claims.sid()).isEqualTo("sid-1");
        assertThat(claims.tokenId()).isEqualTo("access-token-id");
        assertThat(claims.tokenUse()).isEqualTo(TokenUse.ACCESS);
        assertThat(claims.deviceId()).isEqualTo("device-1");
    }

    @Test
    void issuesTokenWithActiveKeyId() throws Exception {
        JwtTokenService tokenService = tokenService(
                "bcm-bff",
                "bcm-bff",
                "active-2026-05",
                "");

        Map<String, Object> header = decodeHeader(tokenService.issue(session(), TokenUse.ACCESS, 900));

        assertThat(header).containsEntry("kid", "active-2026-05");
    }

    @Test
    void validatesLegacyTokenWithoutKeyIdUsingActiveSecret() throws Exception {
        String token = signedTokenWithHeader(Map.of("alg", "HS256", "typ", "JWT"));
        JwtTokenService validatingService = tokenService(
                "bcm-bff",
                "bcm-bff",
                "active-2026-05",
                "");

        TokenClaims claims = validatingService.validate(token, TokenUse.ACCESS);

        assertThat(claims.subject()).isEqualTo("KYLEWENG@015521104095930");
    }

    @Test
    void validatesTokenSignedWithPreviousKeyId() throws Exception {
        String token = signedTokenWithHeader(
                Map.of("alg", "HS256", "typ", "JWT", "kid", "previous-2026-04"),
                PREVIOUS_SECRET);
        JwtTokenService validatingService = tokenService(
                "bcm-bff",
                "bcm-bff",
                "active-2026-05",
                "previous-2026-04=" + PREVIOUS_SECRET);

        TokenClaims claims = validatingService.validate(token, TokenUse.ACCESS);

        assertThat(claims.tokenId()).isEqualTo("access-token-id");
    }

    @Test
    void rejectsTokenWithUnknownKeyIdEvenWhenSignatureUsesActiveSecret() throws Exception {
        String token = signedTokenWithHeader(Map.of("alg", "HS256", "typ", "JWT", "kid", "unknown"));
        JwtTokenService validatingService = tokenService(
                "bcm-bff",
                "bcm-bff",
                "active-2026-05",
                "");

        assertThatThrownBy(() -> validatingService.validate(token, TokenUse.ACCESS))
                .isInstanceOfSatisfying(JwtValidationException.class, error -> {
                    assertThat(error.errorCode()).isEqualTo(ErrorCode.UNAUTHORIZED);
                    assertThat(error.failure()).isEqualTo(JwtValidationFailure.UNKNOWN_KEY_ID);
                });
    }

    @Test
    void rejectsTokenWithBlankKeyId() throws Exception {
        String token = signedTokenWithHeader(Map.of("alg", "HS256", "typ", "JWT", "kid", " "));
        JwtTokenService validatingService = tokenService("bcm-bff", "bcm-bff");

        assertThatThrownBy(() -> validatingService.validate(token, TokenUse.ACCESS))
                .isInstanceOfSatisfying(JwtValidationException.class, error -> {
                    assertThat(error.errorCode()).isEqualTo(ErrorCode.UNAUTHORIZED);
                    assertThat(error.failure()).isEqualTo(JwtValidationFailure.UNKNOWN_KEY_ID);
                });
    }

    @Test
    void reportsMalformedTokenFailureReason() {
        JwtTokenService validatingService = tokenService("bcm-bff", "bcm-bff");

        assertThatThrownBy(() -> validatingService.validate("not-a-jwt", TokenUse.ACCESS))
                .isInstanceOfSatisfying(JwtValidationException.class, error -> {
                    assertThat(error.errorCode()).isEqualTo(ErrorCode.UNAUTHORIZED);
                    assertThat(error.failure()).isEqualTo(JwtValidationFailure.MALFORMED_TOKEN);
                });
    }

    @Test
    void reportsInvalidSignatureFailureReason() {
        JwtTokenService tokenService = tokenService("bcm-bff", "bcm-bff");
        String token = tokenService.issue(session(), TokenUse.ACCESS, 900);
        int signatureStart = token.lastIndexOf('.') + 1;
        String tamperedToken = token.substring(0, signatureStart)
                + (token.charAt(signatureStart) == 'A' ? "B" : "A")
                + token.substring(signatureStart + 1);

        assertThatThrownBy(() -> tokenService.validate(tamperedToken, TokenUse.ACCESS))
                .isInstanceOfSatisfying(JwtValidationException.class, error -> {
                    assertThat(error.errorCode()).isEqualTo(ErrorCode.UNAUTHORIZED);
                    assertThat(error.failure()).isEqualTo(JwtValidationFailure.INVALID_SIGNATURE);
                });
    }

    @Test
    void reportsExpiredTokenFailureReason() {
        JwtTokenService tokenService = tokenService("bcm-bff", "bcm-bff");
        String token = tokenService.issue(session(), TokenUse.ACCESS, -1);

        assertThatThrownBy(() -> tokenService.validate(token, TokenUse.ACCESS))
                .isInstanceOfSatisfying(JwtValidationException.class, error -> {
                    assertThat(error.errorCode()).isEqualTo(ErrorCode.SESSION_EXPIRED);
                    assertThat(error.failure()).isEqualTo(JwtValidationFailure.EXPIRED);
                });
    }

    @Test
    void rejectsTokenFromUnexpectedIssuerEvenWhenSignatureIsValid() {
        JwtTokenService issuingService = tokenService("other-bff", "bcm-bff");
        JwtTokenService validatingService = tokenService("bcm-bff", "bcm-bff");
        String token = issuingService.issue(session(), TokenUse.ACCESS, 900);

        assertThatThrownBy(() -> validatingService.validate(token, TokenUse.ACCESS))
                .isInstanceOfSatisfying(JwtValidationException.class, error -> {
                    assertThat(error.errorCode()).isEqualTo(ErrorCode.UNAUTHORIZED);
                    assertThat(error.failure()).isEqualTo(JwtValidationFailure.UNEXPECTED_ISSUER);
                });
    }

    @Test
    void rejectsTokenFromUnexpectedAudienceEvenWhenIssuerAndSignatureAreValid() {
        JwtTokenService issuingService = tokenService("bcm-bff", "other-service");
        JwtTokenService validatingService = tokenService("bcm-bff", "bcm-bff");
        String token = issuingService.issue(session(), TokenUse.ACCESS, 900);

        assertThatThrownBy(() -> validatingService.validate(token, TokenUse.ACCESS))
                .isInstanceOfSatisfying(JwtValidationException.class, error -> {
                    assertThat(error.errorCode()).isEqualTo(ErrorCode.UNAUTHORIZED);
                    assertThat(error.failure()).isEqualTo(JwtValidationFailure.UNEXPECTED_AUDIENCE);
                });
    }

    @Test
    void rejectsSignedTokenWithUnsupportedHeaderAlgorithm() throws Exception {
        String token = signedTokenWithHeader(Map.of("alg", "none", "typ", "JWT"));
        JwtTokenService validatingService = tokenService("bcm-bff", "bcm-bff");

        assertThatThrownBy(() -> validatingService.validate(token, TokenUse.ACCESS))
                .isInstanceOfSatisfying(JwtValidationException.class, error -> {
                    assertThat(error.errorCode()).isEqualTo(ErrorCode.UNAUTHORIZED);
                    assertThat(error.failure()).isEqualTo(JwtValidationFailure.UNSUPPORTED_HEADER);
                });
    }

    @Test
    void rejectsSignedTokenWithUnsupportedHeaderType() throws Exception {
        String token = signedTokenWithHeader(Map.of("alg", "HS256", "typ", "JOSE"));
        JwtTokenService validatingService = tokenService("bcm-bff", "bcm-bff");

        assertThatThrownBy(() -> validatingService.validate(token, TokenUse.ACCESS))
                .isInstanceOfSatisfying(JwtValidationException.class, error -> {
                    assertThat(error.errorCode()).isEqualTo(ErrorCode.UNAUTHORIZED);
                    assertThat(error.failure()).isEqualTo(JwtValidationFailure.UNSUPPORTED_HEADER);
                });
    }

    private static JwtTokenService tokenService(String issuer, String audience) {
        return tokenService(issuer, audience, "local", "");
    }

    private static JwtTokenService tokenService(String issuer, String audience, String keyId, String previousKeys) {
        AuthProperties properties = new AuthProperties();
        properties.setIssuer(issuer);
        properties.setAudience(audience);
        properties.setJwtSecret(TEST_SECRET);
        properties.setJwtKeyId(keyId);
        properties.setJwtPreviousKeys(previousKeys);
        return new JwtTokenService(properties, new ObjectMapper());
    }

    private static String signedTokenWithHeader(Map<String, Object> header) throws Exception {
        return signedTokenWithHeader(header, TEST_SECRET);
    }

    private static String signedTokenWithHeader(Map<String, Object> header, String secret) throws Exception {
        ObjectMapper objectMapper = new ObjectMapper();
        Map<String, Object> payload = new LinkedHashMap<>();
        payload.put("iss", "bcm-bff");
        payload.put("aud", "bcm-bff");
        payload.put("sub", "KYLEWENG@015521104095930");
        payload.put("sid", "sid-1");
        payload.put("use", TokenUse.ACCESS.claimValue());
        payload.put("ver", 1);
        payload.put("device_id", "device-1");
        payload.put("iat", Instant.now().getEpochSecond());
        payload.put("exp", Instant.now().plusSeconds(900).getEpochSecond());
        payload.put("jti", "access-token-id");

        String unsignedToken = base64Url(objectMapper.writeValueAsBytes(header))
                + "."
                + base64Url(objectMapper.writeValueAsBytes(payload));
        return unsignedToken + "." + base64Url(sign(unsignedToken, secret));
    }

    private static byte[] sign(String value, String secret) throws Exception {
        Mac mac = Mac.getInstance("HmacSHA256");
        mac.init(new SecretKeySpec(secret.getBytes(StandardCharsets.UTF_8), "HmacSHA256"));
        return mac.doFinal(value.getBytes(StandardCharsets.UTF_8));
    }

    private static Map<String, Object> decodeHeader(String token) throws Exception {
        String encodedHeader = token.split("\\.")[0];
        return new ObjectMapper().readValue(Base64.getUrlDecoder().decode(encodedHeader), MAP_TYPE);
    }

    private static String base64Url(byte[] value) {
        return Base64.getUrlEncoder().withoutPadding().encodeToString(value);
    }

    private static SessionRecord session() {
        Instant now = Instant.parse("2026-05-17T00:00:00Z");
        return new SessionRecord(
                "sid-1",
                "KYLEWENG@015521104095930",
                "015521104095930",
                "device-1",
                "Android",
                List.of("BCM_USER"),
                List.of("bcm:proxy"),
                null,
                SessionState.ACTIVE,
                1,
                "refresh-token-id",
                now,
                now);
    }
}

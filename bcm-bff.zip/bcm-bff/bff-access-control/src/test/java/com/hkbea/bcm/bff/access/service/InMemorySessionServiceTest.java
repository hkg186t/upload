package com.hkbea.bcm.bff.access.service;

import com.hkbea.bcm.bff.access.model.SessionRecord;
import com.hkbea.bcm.bff.shared.session.SessionState;
import org.junit.jupiter.api.Test;

import java.time.Instant;
import java.util.List;

import static org.assertj.core.api.Assertions.assertThat;

class InMemorySessionServiceTest {
    @Test
    void rotatesRefreshTokenOnlyOnceForExpectedToken() {
        InMemorySessionService sessionService = new InMemorySessionService();
        SessionRecord session = session("refresh-1", SessionState.ACTIVE, 1);
        sessionService.save(session).block();

        SessionRecord rotated = sessionService
                .rotateRefreshToken(session, "refresh-1", "refresh-2")
                .block();

        assertThat(rotated).isNotNull();
        assertThat(rotated.refreshTokenId()).isEqualTo("refresh-2");
        assertThat(sessionService.rotateRefreshToken(session, "refresh-1", "refresh-3").blockOptional()).isEmpty();
        assertThat(sessionService.findBySid(session.sid()).block().refreshTokenId()).isEqualTo("refresh-2");
    }

    @Test
    void initializesLegacyBlankRefreshTokenThenRequiresRotationMatch() {
        InMemorySessionService sessionService = new InMemorySessionService();
        SessionRecord session = session(null, SessionState.ACTIVE, 1);
        sessionService.save(session).block();

        SessionRecord rotated = sessionService
                .rotateRefreshToken(session, "legacy-token-id", "refresh-2")
                .block();

        assertThat(rotated).isNotNull();
        assertThat(rotated.refreshTokenId()).isEqualTo("refresh-2");
        assertThat(sessionService.rotateRefreshToken(session, "legacy-token-id", "refresh-3").blockOptional()).isEmpty();
    }

    @Test
    void refusesRotateWhenCurrentSessionIsNoLongerActive() {
        InMemorySessionService sessionService = new InMemorySessionService();
        SessionRecord session = session("refresh-1", SessionState.ACTIVE, 1);
        sessionService.save(session).block();
        sessionService.expire(session.sid()).block();

        assertThat(sessionService.rotateRefreshToken(session, "refresh-1", "refresh-2").blockOptional()).isEmpty();
    }

    @Test
    void refusesRotateWhenSessionVersionChanged() {
        InMemorySessionService sessionService = new InMemorySessionService();
        SessionRecord staleSession = session("refresh-1", SessionState.ACTIVE, 1);
        SessionRecord currentSession = session("refresh-1", SessionState.ACTIVE, 2);
        sessionService.save(currentSession).block();

        assertThat(sessionService.rotateRefreshToken(staleSession, "refresh-1", "refresh-2").blockOptional()).isEmpty();
    }

    private static SessionRecord session(String refreshTokenId, SessionState state, int sessionVersion) {
        Instant now = Instant.parse("2026-05-17T00:00:00Z");
        return new SessionRecord(
                "sid-1",
                "KYLEWENG@015521104095930",
                "015521104095930",
                "device-1",
                "Android",
                List.of("BCM_USER"),
                List.of("bcm:proxy"),
                null,
                state,
                sessionVersion,
                refreshTokenId,
                now,
                now);
    }
}

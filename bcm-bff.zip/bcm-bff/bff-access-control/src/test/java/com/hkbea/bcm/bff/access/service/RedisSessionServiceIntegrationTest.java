package com.hkbea.bcm.bff.access.service;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.hkbea.bcm.bff.access.config.SessionStoreProperties;
import com.hkbea.bcm.bff.access.model.SessionRecord;
import com.hkbea.bcm.bff.shared.session.SessionState;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.data.redis.connection.RedisStandaloneConfiguration;
import org.springframework.data.redis.connection.lettuce.LettuceConnectionFactory;
import org.springframework.data.redis.core.ReactiveStringRedisTemplate;
import org.testcontainers.containers.GenericContainer;
import org.testcontainers.junit.jupiter.Container;
import org.testcontainers.junit.jupiter.Testcontainers;
import org.testcontainers.utility.DockerImageName;
import reactor.core.publisher.Mono;

import java.time.Duration;
import java.time.Instant;
import java.util.List;
import java.util.UUID;

import static org.assertj.core.api.Assertions.assertThat;

@Testcontainers(disabledWithoutDocker = true)
class RedisSessionServiceIntegrationTest {
    private static final DockerImageName REDIS_IMAGE = DockerImageName.parse("redis:7-alpine");

    @Container
    static final GenericContainer<?> redis = new GenericContainer<>(REDIS_IMAGE)
            .withExposedPorts(6379);

    private LettuceConnectionFactory connectionFactory;
    private ReactiveStringRedisTemplate redisTemplate;
    private RedisSessionService sessionService;
    private SessionStoreProperties properties;

    @BeforeEach
    void setUp() {
        RedisStandaloneConfiguration redisConfig = new RedisStandaloneConfiguration(
                redis.getHost(),
                redis.getMappedPort(6379));
        connectionFactory = new LettuceConnectionFactory(redisConfig);
        connectionFactory.afterPropertiesSet();
        redisTemplate = new ReactiveStringRedisTemplate(connectionFactory);

        properties = new SessionStoreProperties();
        properties.setRedisKeyPrefix("bcm-bff-it:" + UUID.randomUUID());
        properties.setTtlSeconds(60);
        sessionService = new RedisSessionService(
                redisTemplate,
                new ObjectMapper().findAndRegisterModules(),
                properties);
    }

    @AfterEach
    void tearDown() {
        if (connectionFactory != null) {
            connectionFactory.destroy();
        }
    }

    @Test
    void rotatesRefreshTokenOnlyOnceForExpectedToken() {
        SessionRecord session = session("refresh-1", SessionState.ACTIVE, 1);
        sessionService.save(session).block();

        List<SessionRecord> results = Mono.zip(
                        sessionService.rotateRefreshToken(session, "refresh-1", "refresh-2").singleOptional(),
                        sessionService.rotateRefreshToken(session, "refresh-1", "refresh-3").singleOptional())
                .map(tuple -> List.of(tuple.getT1(), tuple.getT2()).stream()
                        .flatMap(optional -> optional.stream())
                        .toList())
                .block();

        assertThat(results).hasSize(1);
        assertThat(results.get(0).refreshTokenId()).isIn("refresh-2", "refresh-3");
        assertThat(sessionService.rotateRefreshToken(session, "refresh-1", "refresh-4").blockOptional()).isEmpty();
        assertThat(sessionService.findBySid(session.sid()).block().refreshTokenId())
                .isEqualTo(results.get(0).refreshTokenId());
    }

    @Test
    void initializesLegacyBlankRefreshTokenThenRequiresRotationMatch() {
        SessionRecord session = session(null, SessionState.ACTIVE, 1);
        sessionService.save(session).block();

        SessionRecord rotated = sessionService
                .rotateRefreshToken(session, "legacy-token-id", "refresh-2")
                .block();

        assertThat(rotated).isNotNull();
        assertThat(rotated.refreshTokenId()).isEqualTo("refresh-2");
        assertThat(sessionService.rotateRefreshToken(session, "legacy-token-id", "refresh-3").blockOptional()).isEmpty();
    }

    @Test
    void refreshRotationKeepsSessionKeyExpiring() {
        SessionRecord session = session("refresh-1", SessionState.ACTIVE, 1);
        sessionService.save(session).block();

        SessionRecord rotated = sessionService
                .rotateRefreshToken(session, "refresh-1", "refresh-2")
                .block();

        assertThat(rotated).isNotNull();
        Duration ttl = redisTemplate.getExpire(sessionKey(session.sid())).block();
        assertThat(ttl).isNotNull();
        assertThat(ttl.toMillis()).isGreaterThan(0);
        assertThat(ttl).isLessThanOrEqualTo(Duration.ofSeconds(properties.getTtlSeconds()));
    }

    private String sessionKey(String sid) {
        return properties.getRedisKeyPrefix() + ":session:" + sid;
    }

    private static SessionRecord session(String refreshTokenId, SessionState state, int sessionVersion) {
        Instant now = Instant.parse("2026-05-17T00:00:00Z");
        return new SessionRecord(
                "sid-1",
                "KYLEWENG@015521104095930",
                "015521104095930",
                "device-1",
                "Android",
                List.of("BCM_USER"),
                List.of("bcm:proxy"),
                null,
                state,
                sessionVersion,
                refreshTokenId,
                now,
                now);
    }
}

package com.hkbea.bcm.bff.access.login;

import com.hkbea.bcm.bff.access.config.AuthProperties;
import org.springframework.beans.factory.ObjectProvider;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class LoginAuthenticatorConfiguration {
    @Bean
    LoginAuthenticator loginAuthenticator(
            AuthProperties properties,
            ObjectProvider<IamLoginClient> iamLoginClient
    ) {
        return switch (properties.getLoginProvider()) {
            case LOCAL -> new LocalLoginAuthenticator(properties);
            case DISABLED -> new DisabledLoginAuthenticator();
            case IAM -> {
                IamLoginClient client = iamLoginClient.getIfAvailable();
                if (client == null) {
                    throw new IllegalStateException("BFF auth login provider 'IAM' requires an IamLoginClient");
                }
                yield new IamLoginAuthenticator(client);
            }
        };
    }
}

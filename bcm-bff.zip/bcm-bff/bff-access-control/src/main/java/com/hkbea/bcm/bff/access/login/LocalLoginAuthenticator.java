package com.hkbea.bcm.bff.access.login;

import com.hkbea.bcm.bff.access.config.AuthProperties;
import com.hkbea.bcm.bff.access.model.LoginCommand;
import com.hkbea.bcm.bff.shared.api.BffException;
import com.hkbea.bcm.bff.shared.api.ErrorCode;
import reactor.core.publisher.Mono;

import java.util.List;
import java.util.Locale;

public class LocalLoginAuthenticator implements LoginAuthenticator {
    private static final List<String> DEFAULT_ROLES = List.of("BCM_USER");
    private static final List<String> DEFAULT_SCOPES = List.of("bcm:proxy");

    private final AuthProperties properties;

    public LocalLoginAuthenticator(AuthProperties properties) {
        this.properties = properties;
    }

    @Override
    public Mono<AuthenticatedUser> authenticate(LoginCommand command) {
        return Mono.defer(() -> {
            if (!properties.isLocalLoginEnabled()) {
                return Mono.error(new BffException(ErrorCode.FORBIDDEN,
                        "Local login is disabled for this environment"));
            }

            requireNonBlank(command.username(), "username is required");
            requireNonBlank(command.password(), "password is required");

            String customerId = blankToNull(command.parentAccountId());
            String userId = normalizeUserId(command.username(), customerId);
            return Mono.just(new AuthenticatedUser(
                    userId,
                    displayName(command.username()),
                    customerId,
                    normalizeList(command.roles(), DEFAULT_ROLES),
                    normalizeList(command.scopes(), DEFAULT_SCOPES),
                    blankToNull(properties.getLocalBcmSessionId())
            ));
        });
    }

    private static String normalizeUserId(String username, String parentAccountId) {
        String normalized = username.trim();
        if (normalized.contains("@") || parentAccountId == null || parentAccountId.isBlank()) {
            return normalized.toUpperCase(Locale.ROOT);
        }
        return (normalized + "@" + parentAccountId).toUpperCase(Locale.ROOT);
    }

    private static String displayName(String username) {
        String trimmed = username.trim();
        int separator = trimmed.indexOf('@');
        if (separator > 0) {
            return trimmed.substring(0, separator);
        }
        return trimmed;
    }

    private static void requireNonBlank(String value, String message) {
        if (value == null || value.isBlank()) {
            throw new BffException(ErrorCode.BAD_REQUEST, message);
        }
    }

    private static String blankToNull(String value) {
        if (value == null || value.isBlank()) {
            return null;
        }
        return value.trim();
    }

    private static List<String> normalizeList(List<String> values, List<String> defaults) {
        if (values == null || values.isEmpty()) {
            return defaults;
        }

        List<String> normalized = values.stream()
                .filter(value -> value != null && !value.isBlank())
                .map(String::trim)
                .distinct()
                .toList();
        return normalized.isEmpty() ? defaults : normalized;
    }
}

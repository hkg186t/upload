package com.hkbea.bcm.bff.access.token;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.hkbea.bcm.bff.access.config.AuthProperties;
import com.hkbea.bcm.bff.access.model.SessionRecord;
import com.hkbea.bcm.bff.shared.api.BffException;
import com.hkbea.bcm.bff.shared.api.ErrorCode;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import javax.crypto.Mac;
import javax.crypto.spec.SecretKeySpec;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.time.Clock;
import java.time.Instant;
import java.util.Base64;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.UUID;

import static com.hkbea.bcm.bff.access.token.JwtValidationFailure.EXPIRED;
import static com.hkbea.bcm.bff.access.token.JwtValidationFailure.INVALID_CLAIMS;
import static com.hkbea.bcm.bff.access.token.JwtValidationFailure.INVALID_HEADER;
import static com.hkbea.bcm.bff.access.token.JwtValidationFailure.INVALID_SIGNATURE;
import static com.hkbea.bcm.bff.access.token.JwtValidationFailure.KEY_CONFIGURATION_ERROR;
import static com.hkbea.bcm.bff.access.token.JwtValidationFailure.MALFORMED_TOKEN;
import static com.hkbea.bcm.bff.access.token.JwtValidationFailure.UNKNOWN_KEY_ID;
import static com.hkbea.bcm.bff.access.token.JwtValidationFailure.UNEXPECTED_AUDIENCE;
import static com.hkbea.bcm.bff.access.token.JwtValidationFailure.UNEXPECTED_ISSUER;
import static com.hkbea.bcm.bff.access.token.JwtValidationFailure.UNEXPECTED_USE;
import static com.hkbea.bcm.bff.access.token.JwtValidationFailure.UNSUPPORTED_HEADER;

@Service
public class JwtTokenService {
    private static final String HMAC_SHA256 = "HmacSHA256";
    private static final String JWT_ALGORITHM = "HS256";
    private static final String JWT_TYPE = "JWT";
    private static final TypeReference<Map<String, Object>> MAP_TYPE = new TypeReference<>() {
    };

    private final AuthProperties properties;
    private final ObjectMapper objectMapper;
    private final Clock clock;

    @Autowired
    public JwtTokenService(AuthProperties properties, ObjectMapper objectMapper) {
        this(properties, objectMapper, Clock.systemUTC());
    }

    JwtTokenService(AuthProperties properties, ObjectMapper objectMapper, Clock clock) {
        this.properties = properties;
        this.objectMapper = objectMapper;
        this.clock = clock;
    }

    public String issue(SessionRecord session, TokenUse tokenUse, long ttlSeconds) {
        return issue(session, tokenUse, ttlSeconds, UUID.randomUUID().toString());
    }

    public String issue(SessionRecord session, TokenUse tokenUse, long ttlSeconds, String tokenId) {
        if (tokenId == null || tokenId.isBlank()) {
            throw new IllegalArgumentException("tokenId is required");
        }

        Instant now = clock.instant();
        Instant expiresAt = now.plusSeconds(ttlSeconds);

        Map<String, Object> header = new LinkedHashMap<>();
        header.put("alg", JWT_ALGORITHM);
        header.put("typ", JWT_TYPE);
        if (hasText(properties.getJwtKeyId())) {
            header.put("kid", properties.getJwtKeyId());
        }

        Map<String, Object> payload = new LinkedHashMap<>();
        payload.put("iss", properties.getIssuer());
        payload.put("aud", properties.getAudience());
        payload.put("sub", session.userId());
        payload.put("sid", session.sid());
        payload.put("use", tokenUse.claimValue());
        payload.put("ver", session.sessionVersion());
        payload.put("device_id", session.deviceId());
        payload.put("iat", now.getEpochSecond());
        payload.put("exp", expiresAt.getEpochSecond());
        payload.put("jti", tokenId);

        String unsignedToken = encodeJson(header) + "." + encodeJson(payload);
        return unsignedToken + "." + base64Url(sign(unsignedToken, properties.getJwtSecret()));
    }

    public TokenClaims validate(String token, TokenUse expectedUse) {
        try {
            if (!hasText(token)) {
                throw unauthorized(MALFORMED_TOKEN);
            }

            String[] parts = token.split("\\.", -1);
            if (parts.length != 3 || !hasText(parts[0]) || !hasText(parts[1]) || !hasText(parts[2])) {
                throw unauthorized(MALFORMED_TOKEN);
            }

            Map<String, Object> header = decodeJsonPart(parts[0], INVALID_HEADER);
            if (!JWT_ALGORITHM.equals(requiredString(header, "alg", INVALID_HEADER))
                    || !JWT_TYPE.equals(requiredString(header, "typ", INVALID_HEADER))) {
                throw unauthorized(UNSUPPORTED_HEADER);
            }

            String unsignedToken = parts[0] + "." + parts[1];
            byte[] expectedSignature = sign(unsignedToken, verificationSecret(header));
            byte[] actualSignature = decodeBase64Part(parts[2], INVALID_SIGNATURE);
            if (!MessageDigest.isEqual(expectedSignature, actualSignature)) {
                throw unauthorized(INVALID_SIGNATURE);
            }

            Map<String, Object> claims = decodeJsonPart(parts[1], INVALID_CLAIMS);
            if (!properties.getIssuer().equals(requiredString(claims, "iss", INVALID_CLAIMS))) {
                throw unauthorized(UNEXPECTED_ISSUER);
            }
            if (!properties.getAudience().equals(requiredString(claims, "aud", INVALID_CLAIMS))) {
                throw unauthorized(UNEXPECTED_AUDIENCE);
            }

            TokenUse actualUse = TokenUse.fromClaimValue(requiredString(claims, "use", INVALID_CLAIMS));
            if (actualUse != expectedUse) {
                throw unauthorized(UNEXPECTED_USE);
            }

            Instant expiresAt = Instant.ofEpochSecond(requiredLong(claims, "exp", INVALID_CLAIMS));
            if (!expiresAt.isAfter(clock.instant())) {
                throw new JwtValidationException(ErrorCode.SESSION_EXPIRED, EXPIRED);
            }

            return new TokenClaims(
                    requiredString(claims, "sub", INVALID_CLAIMS),
                    requiredString(claims, "sid", INVALID_CLAIMS),
                    requiredString(claims, "jti", INVALID_CLAIMS),
                    actualUse,
                    (int) requiredLong(claims, "ver", INVALID_CLAIMS),
                    requiredString(claims, "device_id", INVALID_CLAIMS),
                    Instant.ofEpochSecond(requiredLong(claims, "iat", INVALID_CLAIMS)),
                    expiresAt
            );
        } catch (BffException error) {
            throw error;
        } catch (Exception error) {
            throw unauthorized(INVALID_CLAIMS);
        }
    }

    private String encodeJson(Map<String, Object> value) {
        try {
            return base64Url(objectMapper.writeValueAsBytes(value));
        } catch (Exception error) {
            throw new IllegalStateException("Failed to encode JWT JSON", error);
        }
    }

    private String verificationSecret(Map<String, Object> header) {
        boolean hasKeyId = header.containsKey("kid");
        String keyId = optionalString(header, "kid");
        if (!hasKeyId) {
            return properties.getJwtSecret();
        }
        if (!hasText(keyId)) {
            throw unauthorized(UNKNOWN_KEY_ID);
        }
        if (keyId.equals(properties.getJwtKeyId())) {
            return properties.getJwtSecret();
        }

        try {
            String previousSecret = properties.jwtPreviousKeyMap().get(keyId);
            if (previousSecret != null) {
                return previousSecret;
            }
        } catch (IllegalArgumentException error) {
            throw unauthorized(KEY_CONFIGURATION_ERROR);
        }

        throw unauthorized(UNKNOWN_KEY_ID);
    }

    private byte[] sign(String value, String secret) {
        try {
            Mac mac = Mac.getInstance(HMAC_SHA256);
            mac.init(new SecretKeySpec(secret.getBytes(StandardCharsets.UTF_8), HMAC_SHA256));
            return mac.doFinal(value.getBytes(StandardCharsets.UTF_8));
        } catch (Exception error) {
            throw new IllegalStateException("Failed to sign JWT", error);
        }
    }

    private static String base64Url(byte[] value) {
        return Base64.getUrlEncoder().withoutPadding().encodeToString(value);
    }

    private Map<String, Object> decodeJsonPart(String value, JwtValidationFailure failure) {
        try {
            return objectMapper.readValue(decodeBase64Part(value, failure), MAP_TYPE);
        } catch (JwtValidationException error) {
            throw error;
        } catch (Exception error) {
            throw unauthorized(failure);
        }
    }

    private static byte[] decodeBase64Part(String value, JwtValidationFailure failure) {
        try {
            return Base64.getUrlDecoder().decode(value);
        } catch (IllegalArgumentException error) {
            throw unauthorized(failure);
        }
    }

    private static String requiredString(Map<String, Object> claims, String key, JwtValidationFailure failure) {
        Object value = claims.get(key);
        if (value instanceof String text && !text.isBlank()) {
            return text;
        }
        throw unauthorized(failure);
    }

    private static String optionalString(Map<String, Object> claims, String key) {
        Object value = claims.get(key);
        if (value instanceof String text && !text.isBlank()) {
            return text;
        }
        return "";
    }

    private static long requiredLong(Map<String, Object> claims, String key, JwtValidationFailure failure) {
        Object value = claims.get(key);
        if (value instanceof Number number) {
            return number.longValue();
        }
        throw unauthorized(failure);
    }

    private static JwtValidationException unauthorized(JwtValidationFailure failure) {
        return new JwtValidationException(ErrorCode.UNAUTHORIZED, failure);
    }

    private static boolean hasText(String value) {
        return value != null && !value.isBlank();
    }
}

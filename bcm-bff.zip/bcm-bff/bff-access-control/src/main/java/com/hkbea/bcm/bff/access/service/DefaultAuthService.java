package com.hkbea.bcm.bff.access.service;

import com.hkbea.bcm.bff.access.audit.AuthAuditLogger;
import com.hkbea.bcm.bff.access.config.AuthProperties;
import com.hkbea.bcm.bff.access.login.AuthenticatedUser;
import com.hkbea.bcm.bff.access.login.LoginAuthenticator;
import com.hkbea.bcm.bff.access.model.AuthResult;
import com.hkbea.bcm.bff.access.model.LoginCommand;
import com.hkbea.bcm.bff.access.model.RefreshCommand;
import com.hkbea.bcm.bff.access.model.SessionRecord;
import com.hkbea.bcm.bff.access.model.TokenPair;
import com.hkbea.bcm.bff.access.model.UserSummary;
import com.hkbea.bcm.bff.access.token.JwtTokenService;
import com.hkbea.bcm.bff.access.token.JwtValidationException;
import com.hkbea.bcm.bff.access.token.JwtValidationFailure;
import com.hkbea.bcm.bff.access.token.TokenClaims;
import com.hkbea.bcm.bff.access.token.TokenUse;
import com.hkbea.bcm.bff.shared.api.BffException;
import com.hkbea.bcm.bff.shared.api.ErrorCode;
import com.hkbea.bcm.bff.shared.session.SessionState;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import reactor.core.publisher.Mono;

import java.time.Instant;
import java.util.UUID;

@Service
public class DefaultAuthService implements AuthService {
    private static final String BEARER_PREFIX = "Bearer ";

    private final SessionService sessionService;
    private final JwtTokenService jwtTokenService;
    private final AuthProperties properties;
    private final LoginAuthenticator loginAuthenticator;
    private final AuthAuditLogger auditLogger;

    public DefaultAuthService(
            SessionService sessionService,
            JwtTokenService jwtTokenService,
            AuthProperties properties,
            LoginAuthenticator loginAuthenticator
    ) {
        this(sessionService, jwtTokenService, properties, loginAuthenticator, new AuthAuditLogger());
    }

    @Autowired
    public DefaultAuthService(
            SessionService sessionService,
            JwtTokenService jwtTokenService,
            AuthProperties properties,
            LoginAuthenticator loginAuthenticator,
            AuthAuditLogger auditLogger
    ) {
        this.sessionService = sessionService;
        this.jwtTokenService = jwtTokenService;
        this.properties = properties;
        this.loginAuthenticator = loginAuthenticator;
        this.auditLogger = auditLogger;
    }

    @Override
    public Mono<AuthResult> login(LoginCommand command) {
        long startedAtNanos = System.nanoTime();
        return Mono.defer(() -> {
            requireNonBlank(command.deviceId(), "deviceId is required");
            requireNonBlank(command.deviceOs(), "deviceOs is required");

            return loginAuthenticator.authenticate(command)
                    .flatMap(principal -> createAuthenticatedSession(command, principal));
        })
                .doOnSuccess(result -> auditLogger.loginSuccess(
                        properties.getLoginProvider(),
                        command,
                        sessionFromAuthResult(command, result),
                        elapsedMillis(startedAtNanos)))
                .doOnError(error -> auditLogger.loginFailure(
                        properties.getLoginProvider(),
                        command,
                        error,
                        elapsedMillis(startedAtNanos)));
    }

    @Override
    public Mono<TokenPair> refresh(RefreshCommand command) {
        long startedAtNanos = System.nanoTime();
        return Mono.defer(() -> {
            requireNonBlank(command.refreshToken(), "refreshToken is required");
            requireNonBlank(command.deviceId(), "deviceId is required");

            TokenClaims claims = validateRefreshToken(command.refreshToken());
            return findActiveSession(claims, false)
                    .flatMap(session -> {
                        if (!command.deviceId().equals(session.deviceId())) {
                            return Mono.error(new BffException(ErrorCode.SESSION_EXPIRED));
                        }
                        return sessionService.rotateRefreshToken(session, claims.tokenId(), newTokenId())
                                .switchIfEmpty(Mono.error(new BffException(ErrorCode.SESSION_EXPIRED)))
                                .doOnSuccess(savedSession -> auditLogger.refreshSuccess(
                                        claims,
                                        savedSession,
                                        elapsedMillis(startedAtNanos)))
                                .map(this::issueTokenPair);
                    });
        })
                .doOnError(error -> auditLogger.refreshFailure(
                        command.refreshToken(),
                        command.deviceId(),
                        error,
                        elapsedMillis(startedAtNanos)));
    }

    @Override
    public Mono<SessionRecord> validateAccessToken(String authorizationHeader) {
        long startedAtNanos = System.nanoTime();
        return Mono.defer(() -> {
            TokenClaims claims = jwtTokenService.validate(extractBearerToken(authorizationHeader), TokenUse.ACCESS);
            return findActiveSession(claims);
        }).doOnError(error -> auditLogger.accessTokenFailure(
                authorizationHeader,
                error,
                elapsedMillis(startedAtNanos)));
    }

    @Override
    public Mono<Void> logout(String authorizationHeader) {
        long startedAtNanos = System.nanoTime();
        return validateAccessToken(authorizationHeader)
                .flatMap(this::logout)
                .doOnError(error -> auditLogger.logoutFailure(
                        authorizationHeader,
                        error,
                        elapsedMillis(startedAtNanos)));
    }

    @Override
    public Mono<Void> logout(SessionRecord session) {
        long startedAtNanos = System.nanoTime();
        return sessionService.expire(session.sid())
                .doOnSuccess(ignored -> auditLogger.logoutSuccess(session, elapsedMillis(startedAtNanos)));
    }

    private TokenPair issueTokenPair(SessionRecord session) {
        long accessTtl = properties.getAccessTokenTtlSeconds();
        long refreshTtl = properties.getRefreshTokenTtlSeconds();
        return TokenPair.bearer(
                jwtTokenService.issue(session, TokenUse.ACCESS, accessTtl),
                jwtTokenService.issue(session, TokenUse.REFRESH, refreshTtl, session.refreshTokenId()),
                accessTtl,
                refreshTtl
        );
    }

    private TokenClaims validateRefreshToken(String refreshToken) {
        try {
            return jwtTokenService.validate(refreshToken, TokenUse.REFRESH);
        } catch (BffException error) {
            if (error.errorCode() == ErrorCode.BAD_REQUEST) {
                throw error;
            }
            if (error instanceof JwtValidationException jwtValidationException) {
                throw new JwtValidationException(ErrorCode.SESSION_EXPIRED, jwtValidationException.failure());
            }
            throw new BffException(ErrorCode.SESSION_EXPIRED);
        }
    }

    private Mono<SessionRecord> findActiveSession(TokenClaims claims) {
        return findActiveSession(claims, true);
    }

    private Mono<SessionRecord> findActiveSession(TokenClaims claims, boolean touchSession) {
        return sessionService.findBySid(claims.sid())
                .switchIfEmpty(Mono.error(new BffException(ErrorCode.SESSION_EXPIRED)))
                .flatMap(session -> {
                    if (!session.userId().equals(claims.subject())
                            || !session.deviceId().equals(claims.deviceId())
                            || session.sessionVersion() != claims.sessionVersion()
                            || session.state() != SessionState.ACTIVE) {
                        return Mono.error(new BffException(ErrorCode.SESSION_EXPIRED));
                    }

                    if (!touchSession) {
                        return Mono.just(session);
                    }
                    return sessionService.save(touch(session));
                });
    }

    private SessionRecord touch(SessionRecord session) {
        return new SessionRecord(
                session.sid(),
                session.userId(),
                session.customerId(),
                session.deviceId(),
                session.deviceOs(),
                session.roles(),
                session.scopes(),
                session.bcmSessionId(),
                session.state(),
                session.sessionVersion(),
                session.refreshTokenId(),
                session.loginTime(),
                Instant.now()
        );
    }

    private static String extractBearerToken(String authorizationHeader) {
        if (authorizationHeader == null || !authorizationHeader.regionMatches(true, 0, BEARER_PREFIX, 0, BEARER_PREFIX.length())) {
            throw new JwtValidationException(ErrorCode.UNAUTHORIZED, JwtValidationFailure.MISSING_BEARER_TOKEN);
        }
        String token = authorizationHeader.substring(BEARER_PREFIX.length()).trim();
        if (token.isBlank()) {
            throw new JwtValidationException(ErrorCode.UNAUTHORIZED, JwtValidationFailure.MISSING_BEARER_TOKEN);
        }
        return token;
    }

    private static void requireNonBlank(String value, String message) {
        if (value == null || value.isBlank()) {
            throw new BffException(ErrorCode.BAD_REQUEST, message);
        }
    }

    private Mono<AuthResult> createAuthenticatedSession(LoginCommand command, AuthenticatedUser principal) {
        Instant now = Instant.now();
        SessionRecord session = new SessionRecord(
                UUID.randomUUID().toString(),
                principal.userId(),
                principal.customerId(),
                command.deviceId(),
                command.deviceOs(),
                principal.roles(),
                principal.scopes(),
                principal.bcmSessionId(),
                SessionState.ACTIVE,
                1,
                newTokenId(),
                now,
                now
        );

        return sessionService.replaceActiveSessionsForUser(principal.userId())
                .then(sessionService.save(session))
                .map(savedSession -> new AuthResult(
                        issueTokenPair(savedSession),
                        savedSession.sid(),
                        new UserSummary(
                                principal.userId(),
                                principal.displayName(),
                                principal.customerId(),
                                principal.roles(),
                                principal.scopes())
                ));
    }

    private static SessionRecord sessionFromAuthResult(LoginCommand command, AuthResult result) {
        UserSummary user = result.user();
        Instant now = Instant.now();
        return new SessionRecord(
                result.sessionId(),
                user.username(),
                user.parentAccountId(),
                command.deviceId(),
                command.deviceOs(),
                user.roles(),
                user.scopes(),
                null,
                SessionState.ACTIVE,
                1,
                newTokenId(),
                now,
                now
        );
    }

    private static String newTokenId() {
        return UUID.randomUUID().toString();
    }

    private static long elapsedMillis(long startedAtNanos) {
        return (System.nanoTime() - startedAtNanos) / 1_000_000;
    }
}

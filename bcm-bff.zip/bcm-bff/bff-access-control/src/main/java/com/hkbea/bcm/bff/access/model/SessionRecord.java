package com.hkbea.bcm.bff.access.model;

import com.hkbea.bcm.bff.shared.session.SessionState;

import java.time.Instant;
import java.util.List;

public record SessionRecord(
        String sid,
        String userId,
        String customerId,
        String deviceId,
        String deviceOs,
        List<String> roles,
        List<String> scopes,
        String bcmSessionId,
        SessionState state,
        int sessionVersion,
        String refreshTokenId,
        Instant loginTime,
        Instant lastAccessTime
) {
}

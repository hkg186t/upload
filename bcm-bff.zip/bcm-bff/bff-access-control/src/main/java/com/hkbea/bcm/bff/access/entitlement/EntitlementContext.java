package com.hkbea.bcm.bff.access.entitlement;

import com.hkbea.bcm.bff.access.model.SessionRecord;

import java.util.List;

public record EntitlementContext(
        String userId,
        String customerId,
        String deviceId,
        String deviceOs,
        List<String> roles,
        List<String> scopes
) {
    public static EntitlementContext fromSession(SessionRecord session) {
        return new EntitlementContext(
                session.userId(),
                session.customerId(),
                session.deviceId(),
                session.deviceOs(),
                session.roles(),
                session.scopes()
        );
    }
}

package com.hkbea.bcm.bff.access.service;

import com.hkbea.bcm.bff.access.config.AuthorizationPolicyProperties;
import com.hkbea.bcm.bff.access.config.AuthorizationPolicyProperties.Rule;
import com.hkbea.bcm.bff.access.entitlement.EntitlementContext;
import com.hkbea.bcm.bff.access.entitlement.EntitlementProvider;
import com.hkbea.bcm.bff.access.model.SessionRecord;
import com.hkbea.bcm.bff.shared.api.BffException;
import com.hkbea.bcm.bff.shared.api.ErrorCode;
import org.springframework.stereotype.Service;
import reactor.core.publisher.Mono;

import java.util.List;
import java.util.Locale;
import java.util.Set;
import java.util.stream.Collectors;

@Service
public class AuthorizationPolicyService {
    private final AuthorizationPolicyProperties properties;
    private final EntitlementProvider entitlementProvider;

    public AuthorizationPolicyService(AuthorizationPolicyProperties properties, EntitlementProvider entitlementProvider) {
        this.properties = properties;
        this.entitlementProvider = entitlementProvider;
    }

    public Mono<Void> authorize(String method, String path, SessionRecord session) {
        if (!properties.isEnabled()) {
            return Mono.empty();
        }

        return properties.resolve(method, path)
                .map(rule -> entitlementProvider.resolve(session)
                        .doOnNext(entitlement -> enforce(rule, entitlement))
                        .then())
                .orElseGet(Mono::empty);
    }

    private static void enforce(Rule rule, EntitlementContext entitlement) {
        if (!containsAll(entitlement.roles(), rule.getRequiredRoles())) {
            throw forbidden("Missing required role");
        }
        if (!containsAll(entitlement.scopes(), rule.getRequiredScopes())) {
            throw forbidden("Missing required scope");
        }
        if (!allowsDeviceOs(entitlement.deviceOs(), rule.getAllowedDeviceOs())) {
            throw forbidden("Device OS is not allowed");
        }
    }

    private static boolean containsAll(List<String> actualValues, List<String> requiredValues) {
        if (requiredValues == null || requiredValues.isEmpty()) {
            return true;
        }
        Set<String> actual = normalizeSet(actualValues);
        return normalizeSet(requiredValues).stream().allMatch(actual::contains);
    }

    private static boolean allowsDeviceOs(String actualDeviceOs, List<String> allowedDeviceOs) {
        if (allowedDeviceOs == null || allowedDeviceOs.isEmpty()) {
            return true;
        }
        String actual = normalize(actualDeviceOs);
        return normalizeSet(allowedDeviceOs).contains(actual);
    }

    private static Set<String> normalizeSet(List<String> values) {
        if (values == null) {
            return Set.of();
        }
        return values.stream()
                .filter(value -> value != null && !value.isBlank())
                .map(AuthorizationPolicyService::normalize)
                .collect(Collectors.toSet());
    }

    private static String normalize(String value) {
        return value == null ? "" : value.trim().toUpperCase(Locale.ROOT);
    }

    private static BffException forbidden(String reason) {
        return new BffException(ErrorCode.FORBIDDEN, reason);
    }
}

package com.hkbea.bcm.bff.access.model;

public record RefreshCommand(
        String refreshToken,
        String deviceId
) {
}

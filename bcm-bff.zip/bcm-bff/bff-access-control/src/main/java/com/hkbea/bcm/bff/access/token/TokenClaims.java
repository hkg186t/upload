package com.hkbea.bcm.bff.access.token;

import java.time.Instant;

public record TokenClaims(
        String subject,
        String sid,
        String tokenId,
        TokenUse tokenUse,
        int sessionVersion,
        String deviceId,
        Instant issuedAt,
        Instant expiresAt
) {
}

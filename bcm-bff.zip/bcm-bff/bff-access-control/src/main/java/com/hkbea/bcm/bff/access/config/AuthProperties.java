package com.hkbea.bcm.bff.access.config;

import org.springframework.boot.context.properties.ConfigurationProperties;

import java.util.LinkedHashMap;
import java.util.Map;

@ConfigurationProperties(prefix = "bff.auth")
public class AuthProperties {
    private String issuer = "bcm-bff";
    private String audience = "bcm-bff";
    private String jwtSecret = "local-dev-change-me-at-least-32-bytes";
    private String jwtKeyId = "local";
    private String jwtPreviousKeys = "";
    private long accessTokenTtlSeconds = 900;
    private long refreshTokenTtlSeconds = 604800;
    private boolean localLoginEnabled = true;
    private LoginProvider loginProvider = LoginProvider.LOCAL;
    private String localBcmSessionId = "";

    public String getIssuer() {
        return issuer;
    }

    public void setIssuer(String issuer) {
        this.issuer = issuer;
    }

    public String getAudience() {
        return audience;
    }

    public void setAudience(String audience) {
        this.audience = audience;
    }

    public String getJwtSecret() {
        return jwtSecret;
    }

    public void setJwtSecret(String jwtSecret) {
        this.jwtSecret = jwtSecret;
    }

    public String getJwtKeyId() {
        return jwtKeyId;
    }

    public void setJwtKeyId(String jwtKeyId) {
        this.jwtKeyId = jwtKeyId;
    }

    public String getJwtPreviousKeys() {
        return jwtPreviousKeys;
    }

    public void setJwtPreviousKeys(String jwtPreviousKeys) {
        this.jwtPreviousKeys = jwtPreviousKeys;
    }

    public Map<String, String> jwtPreviousKeyMap() {
        return parseJwtPreviousKeys(jwtPreviousKeys);
    }

    public long getAccessTokenTtlSeconds() {
        return accessTokenTtlSeconds;
    }

    public void setAccessTokenTtlSeconds(long accessTokenTtlSeconds) {
        this.accessTokenTtlSeconds = accessTokenTtlSeconds;
    }

    public long getRefreshTokenTtlSeconds() {
        return refreshTokenTtlSeconds;
    }

    public void setRefreshTokenTtlSeconds(long refreshTokenTtlSeconds) {
        this.refreshTokenTtlSeconds = refreshTokenTtlSeconds;
    }

    public boolean isLocalLoginEnabled() {
        return localLoginEnabled;
    }

    public void setLocalLoginEnabled(boolean localLoginEnabled) {
        this.localLoginEnabled = localLoginEnabled;
    }

    public LoginProvider getLoginProvider() {
        return loginProvider;
    }

    public void setLoginProvider(LoginProvider loginProvider) {
        this.loginProvider = loginProvider == null ? LoginProvider.LOCAL : loginProvider;
    }

    public String getLocalBcmSessionId() {
        return localBcmSessionId;
    }

    public void setLocalBcmSessionId(String localBcmSessionId) {
        this.localBcmSessionId = localBcmSessionId == null ? "" : localBcmSessionId.trim();
    }

    public enum LoginProvider {
        LOCAL,
        IAM,
        DISABLED
    }

    public static Map<String, String> parseJwtPreviousKeys(String value) {
        Map<String, String> keys = new LinkedHashMap<>();
        if (value == null || value.isBlank()) {
            return keys;
        }

        for (String rawEntry : value.split(",")) {
            String entry = rawEntry.trim();
            if (entry.isEmpty()) {
                continue;
            }

            int separator = entry.indexOf('=');
            if (separator <= 0 || separator == entry.length() - 1) {
                throw new IllegalArgumentException("JWT previous keys must use kid=secret entries");
            }

            String keyId = entry.substring(0, separator).trim();
            String secret = entry.substring(separator + 1).trim();
            if (keyId.isBlank() || secret.isBlank()) {
                throw new IllegalArgumentException("JWT previous keys must not contain blank kid or secret");
            }
            if (keys.putIfAbsent(keyId, secret) != null) {
                throw new IllegalArgumentException("JWT previous keys must not contain duplicate kid values");
            }
        }

        return keys;
    }
}

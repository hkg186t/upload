package com.hkbea.bcm.bff.access.token;

import com.hkbea.bcm.bff.shared.api.BffException;
import com.hkbea.bcm.bff.shared.api.ErrorCode;

public class JwtValidationException extends BffException {
    private final JwtValidationFailure failure;

    public JwtValidationException(ErrorCode errorCode, JwtValidationFailure failure) {
        super(errorCode);
        this.failure = failure;
    }

    public JwtValidationFailure failure() {
        return failure;
    }
}

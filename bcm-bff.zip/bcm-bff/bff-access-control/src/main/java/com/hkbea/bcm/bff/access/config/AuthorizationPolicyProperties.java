package com.hkbea.bcm.bff.access.config;

import org.springframework.boot.context.properties.ConfigurationProperties;

import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Optional;

@ConfigurationProperties(prefix = "bff.authorization")
public class AuthorizationPolicyProperties {
    private boolean enabled = true;
    private Map<String, Rule> rules = new LinkedHashMap<>();

    public Optional<Rule> resolve(String method, String path) {
        String normalizedMethod = normalizeMethod(method);
        String normalizedPath = normalizePath(path);
        return rules.values().stream()
                .filter(rule -> normalizedMethod.equals(normalizeMethod(rule.getMethod())))
                .filter(rule -> pathMatches(normalizePath(rule.getPath()), normalizedPath))
                .findFirst();
    }

    public boolean isEnabled() {
        return enabled;
    }

    public void setEnabled(boolean enabled) {
        this.enabled = enabled;
    }

    public Map<String, Rule> getRules() {
        return rules;
    }

    public void setRules(Map<String, Rule> rules) {
        this.rules = rules == null ? new LinkedHashMap<>() : rules;
    }

    private static String normalizeMethod(String method) {
        return method == null ? "" : method.trim().toUpperCase(Locale.ROOT);
    }

    private static String normalizePath(String path) {
        if (path == null || path.isBlank()) {
            return "";
        }
        String normalized = path.trim();
        if (normalized.length() > 1 && normalized.endsWith("/")) {
            return normalized.substring(0, normalized.length() - 1);
        }
        return normalized;
    }

    private static boolean pathMatches(String configuredPath, String requestPath) {
        if (configuredPath.equals(requestPath)) {
            return true;
        }
        if (configuredPath.endsWith("/**")) {
            String prefix = configuredPath.substring(0, configuredPath.length() - 2);
            return requestPath.startsWith(prefix);
        }
        if (!configuredPath.contains("{")) {
            return false;
        }

        String[] configuredSegments = configuredPath.split("/");
        String[] requestSegments = requestPath.split("/");
        if (configuredSegments.length != requestSegments.length) {
            return false;
        }

        for (int index = 0; index < configuredSegments.length; index++) {
            String configuredSegment = configuredSegments[index];
            String requestSegment = requestSegments[index];
            if (isPathVariable(configuredSegment)) {
                if (requestSegment.isBlank()) {
                    return false;
                }
                continue;
            }
            if (!configuredSegment.equals(requestSegment)) {
                return false;
            }
        }

        return true;
    }

    private static boolean isPathVariable(String segment) {
        return segment.length() > 2 && segment.startsWith("{") && segment.endsWith("}");
    }

    public static class Rule {
        private String method;
        private String path;
        private List<String> requiredRoles = List.of();
        private List<String> requiredScopes = List.of();
        private List<String> allowedDeviceOs = List.of();

        public String getMethod() {
            return method;
        }

        public void setMethod(String method) {
            this.method = method;
        }

        public String getPath() {
            return path;
        }

        public void setPath(String path) {
            this.path = path;
        }

        public List<String> getRequiredRoles() {
            return requiredRoles;
        }

        public void setRequiredRoles(List<String> requiredRoles) {
            this.requiredRoles = requiredRoles == null ? List.of() : requiredRoles;
        }

        public List<String> getRequiredScopes() {
            return requiredScopes;
        }

        public void setRequiredScopes(List<String> requiredScopes) {
            this.requiredScopes = requiredScopes == null ? List.of() : requiredScopes;
        }

        public List<String> getAllowedDeviceOs() {
            return allowedDeviceOs;
        }

        public void setAllowedDeviceOs(List<String> allowedDeviceOs) {
            this.allowedDeviceOs = allowedDeviceOs == null ? List.of() : allowedDeviceOs;
        }
    }
}

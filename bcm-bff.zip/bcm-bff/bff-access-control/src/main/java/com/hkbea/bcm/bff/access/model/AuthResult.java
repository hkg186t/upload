package com.hkbea.bcm.bff.access.model;

public record AuthResult(
        TokenPair tokenPair,
        String sessionId,
        UserSummary user
) {
}

package com.hkbea.bcm.bff.access.entitlement;

import com.hkbea.bcm.bff.access.model.SessionRecord;
import reactor.core.publisher.Mono;

public interface IamEntitlementClient {
    Mono<EntitlementContext> resolve(SessionRecord session);
}

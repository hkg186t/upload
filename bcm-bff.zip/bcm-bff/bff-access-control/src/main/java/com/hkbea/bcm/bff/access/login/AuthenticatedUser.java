package com.hkbea.bcm.bff.access.login;

import java.util.List;

public record AuthenticatedUser(
        String userId,
        String displayName,
        String customerId,
        List<String> roles,
        List<String> scopes,
        String bcmSessionId
) {
}

package com.hkbea.bcm.bff.access.service;

import com.hkbea.bcm.bff.access.model.SessionRecord;
import com.hkbea.bcm.bff.shared.session.SessionState;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.stereotype.Service;
import reactor.core.publisher.Mono;

import java.time.Instant;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentMap;
import java.util.concurrent.atomic.AtomicReference;

@Service
@ConditionalOnProperty(prefix = "bff.session", name = "store", havingValue = "memory", matchIfMissing = true)
public class InMemorySessionService implements SessionService {
    private final ConcurrentMap<String, SessionRecord> sessions = new ConcurrentHashMap<>();

    @Override
    public Mono<SessionRecord> findBySid(String sid) {
        return Mono.justOrEmpty(sessions.get(sid));
    }

    @Override
    public Mono<SessionRecord> save(SessionRecord session) {
        sessions.put(session.sid(), session);
        return Mono.just(session);
    }

    @Override
    public Mono<SessionRecord> rotateRefreshToken(
            SessionRecord session,
            String expectedRefreshTokenId,
            String nextRefreshTokenId
    ) {
        AtomicReference<SessionRecord> rotated = new AtomicReference<>();
        sessions.compute(session.sid(), (ignored, current) -> {
            if (!canRotate(current, session, expectedRefreshTokenId)) {
                return current;
            }

            SessionRecord updated = withRefreshToken(current, nextRefreshTokenId);
            rotated.set(updated);
            return updated;
        });
        return Mono.justOrEmpty(rotated.get());
    }

    @Override
    public Mono<Void> expire(String sid) {
        sessions.computeIfPresent(sid, (ignored, current) -> withState(current, SessionState.LOGGED_OUT));
        return Mono.empty();
    }

    @Override
    public Mono<Void> replaceActiveSessionsForUser(String userId) {
        sessions.replaceAll((ignored, current) -> {
            if (current.userId().equals(userId) && current.state() == SessionState.ACTIVE) {
                return withState(current, SessionState.REPLACED_BY_NEW_LOGIN);
            }
            return current;
        });
        return Mono.empty();
    }

    private static SessionRecord withState(SessionRecord current, SessionState state) {
        return new SessionRecord(
                current.sid(),
                current.userId(),
                current.customerId(),
                current.deviceId(),
                current.deviceOs(),
                current.roles(),
                current.scopes(),
                current.bcmSessionId(),
                state,
                current.sessionVersion(),
                current.refreshTokenId(),
                current.loginTime(),
                Instant.now()
        );
    }

    private static SessionRecord withRefreshToken(SessionRecord current, String refreshTokenId) {
        return new SessionRecord(
                current.sid(),
                current.userId(),
                current.customerId(),
                current.deviceId(),
                current.deviceOs(),
                current.roles(),
                current.scopes(),
                current.bcmSessionId(),
                current.state(),
                current.sessionVersion(),
                refreshTokenId,
                current.loginTime(),
                Instant.now()
        );
    }

    private static boolean canRotate(
            SessionRecord current,
            SessionRecord expected,
            String expectedRefreshTokenId
    ) {
        if (current == null
                || current.state() != SessionState.ACTIVE
                || !current.userId().equals(expected.userId())
                || !current.deviceId().equals(expected.deviceId())
                || current.sessionVersion() != expected.sessionVersion()) {
            return false;
        }

        String currentRefreshTokenId = current.refreshTokenId();
        return currentRefreshTokenId == null
                || currentRefreshTokenId.isBlank()
                || currentRefreshTokenId.equals(expectedRefreshTokenId);
    }
}

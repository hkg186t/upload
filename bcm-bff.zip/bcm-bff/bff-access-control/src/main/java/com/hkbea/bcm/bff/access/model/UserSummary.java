package com.hkbea.bcm.bff.access.model;

import java.util.List;

public record UserSummary(
        String username,
        String displayName,
        String parentAccountId,
        List<String> roles,
        List<String> scopes
) {
}

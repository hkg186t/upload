package com.hkbea.bcm.bff.access.entitlement;

import com.hkbea.bcm.bff.access.config.EntitlementProperties.Iam;
import com.hkbea.bcm.bff.access.model.SessionRecord;
import com.hkbea.bcm.bff.shared.api.BffException;
import com.hkbea.bcm.bff.shared.api.ErrorCode;
import io.micrometer.core.instrument.MeterRegistry;
import io.micrometer.core.instrument.Timer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import reactor.core.publisher.Mono;

import java.time.Duration;
import java.util.List;
import java.util.concurrent.TimeoutException;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.concurrent.atomic.AtomicLong;

public class IamEntitlementProvider implements EntitlementProvider {
    private static final Logger log = LoggerFactory.getLogger(IamEntitlementProvider.class);

    private static final String METRIC_ENTITLEMENT_DURATION = "bcm.bff.entitlement.duration";
    private static final long DEFAULT_TIMEOUT_MILLIS = 500;
    private static final String PROVIDER_IAM = "iam";
    private static final String OUTCOME_SUCCESS = "success";
    private static final String OUTCOME_ERROR = "error";
    private static final String ERROR_NONE = "none";

    private final IamEntitlementClient client;
    private final Iam properties;
    private final MeterRegistry meterRegistry;
    private final CircuitGuard circuitGuard = new CircuitGuard();

    public IamEntitlementProvider(IamEntitlementClient client, Iam properties) {
        this(client, properties, null);
    }

    public IamEntitlementProvider(IamEntitlementClient client, Iam properties, MeterRegistry meterRegistry) {
        this.client = client;
        this.properties = properties;
        this.meterRegistry = meterRegistry;
    }

    @Override
    public Mono<EntitlementContext> resolve(SessionRecord session) {
        long startedAtNanos = System.nanoTime();
        return Mono.defer(() -> resolveWithCircuit(session))
                .doOnSuccess(entitlement -> recordSuccess(entitlement, startedAtNanos))
                .doOnError(error -> recordFailure(session, error, startedAtNanos));
    }

    private Mono<EntitlementContext> resolveWithCircuit(SessionRecord session) {
        return Mono.defer(() -> {
            if (!circuitGuard.allowRequest(properties)) {
                return Mono.error(new BffException(ErrorCode.BAD_GATEWAY, "IAM entitlement circuit is open"));
            }

            return client.resolve(session)
                    .timeout(requestTimeout())
                    .doOnSuccess(ignored -> circuitGuard.onSuccess(properties))
                    .doOnError(error -> circuitGuard.onFailure(properties))
                    .onErrorMap(TimeoutException.class,
                            error -> new BffException(ErrorCode.UPSTREAM_TIMEOUT, "IAM entitlement lookup timed out"))
                    .onErrorMap(error -> !(error instanceof BffException),
                            error -> new BffException(ErrorCode.BAD_GATEWAY, "IAM entitlement lookup failed"));
        });
    }

    private Duration requestTimeout() {
        long timeoutMillis = properties.getRequestTimeoutMillis() > 0
                ? properties.getRequestTimeoutMillis()
                : DEFAULT_TIMEOUT_MILLIS;
        return Duration.ofMillis(timeoutMillis);
    }

    private void recordSuccess(EntitlementContext entitlement, long startedAtNanos) {
        Duration duration = elapsed(startedAtNanos);
        recordMetric(OUTCOME_SUCCESS, ERROR_NONE, duration);
        log.info("BCM_ENTITLEMENT_ACCESS provider={} outcome=success errorCode={} durationMs={} rolesCount={} scopesCount={} deviceOsPresent={}",
                PROVIDER_IAM,
                ERROR_NONE,
                duration.toMillis(),
                size(entitlement.roles()),
                size(entitlement.scopes()),
                hasText(entitlement.deviceOs()));
    }

    private void recordFailure(SessionRecord session, Throwable error, long startedAtNanos) {
        Duration duration = elapsed(startedAtNanos);
        String errorCode = errorCode(error);
        recordMetric(OUTCOME_ERROR, errorCode, duration);
        log.warn("BCM_ENTITLEMENT_ACCESS provider={} outcome=error errorCode={} errorType={} durationMs={} deviceOsPresent={}",
                PROVIDER_IAM,
                errorCode,
                error.getClass().getSimpleName(),
                duration.toMillis(),
                hasText(session.deviceOs()));
    }

    private void recordMetric(String outcome, String errorCode, Duration duration) {
        if (meterRegistry == null) {
            return;
        }

        Timer.builder(METRIC_ENTITLEMENT_DURATION)
                .description("BCM BFF entitlement lookup duration")
                .tag("provider", PROVIDER_IAM)
                .tag("outcome", outcome)
                .tag("errorCode", errorCode)
                .register(meterRegistry)
                .record(duration);
    }

    private static Duration elapsed(long startedAtNanos) {
        return Duration.ofNanos(System.nanoTime() - startedAtNanos);
    }

    private static String errorCode(Throwable error) {
        if (error instanceof BffException bffException) {
            return bffException.errorCode().code();
        }
        return ErrorCode.INTERNAL_ERROR.code();
    }

    private static boolean hasText(String value) {
        return value != null && !value.isBlank();
    }

    private static int size(List<String> values) {
        return values == null ? 0 : values.size();
    }

    private static class CircuitGuard {
        private final AtomicInteger consecutiveFailures = new AtomicInteger();
        private final AtomicLong openUntilEpochMillis = new AtomicLong();

        boolean allowRequest(Iam properties) {
            if (!properties.isCircuitBreakerEnabled()) {
                return true;
            }
            return System.currentTimeMillis() >= openUntilEpochMillis.get();
        }

        void onSuccess(Iam properties) {
            if (!properties.isCircuitBreakerEnabled()) {
                return;
            }
            consecutiveFailures.set(0);
            openUntilEpochMillis.set(0);
        }

        void onFailure(Iam properties) {
            if (!properties.isCircuitBreakerEnabled()) {
                return;
            }
            int threshold = Math.max(properties.getCircuitBreakerFailureThreshold(), 1);
            int failures = consecutiveFailures.incrementAndGet();
            if (failures >= threshold) {
                openUntilEpochMillis.set(System.currentTimeMillis() + Math.max(properties.getCircuitBreakerOpenMillis(), 1));
            }
        }
    }
}

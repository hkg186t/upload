package com.hkbea.bcm.bff.access.token;

public enum JwtValidationFailure {
    MISSING_BEARER_TOKEN("missing_bearer_token"),
    MALFORMED_TOKEN("malformed_token"),
    INVALID_HEADER("invalid_header"),
    UNSUPPORTED_HEADER("unsupported_header"),
    UNKNOWN_KEY_ID("unknown_key_id"),
    INVALID_SIGNATURE("invalid_signature"),
    INVALID_CLAIMS("invalid_claims"),
    UNEXPECTED_ISSUER("unexpected_issuer"),
    UNEXPECTED_AUDIENCE("unexpected_audience"),
    UNEXPECTED_USE("unexpected_use"),
    EXPIRED("expired"),
    KEY_CONFIGURATION_ERROR("key_configuration_error");

    private final String logValue;

    JwtValidationFailure(String logValue) {
        this.logValue = logValue;
    }

    public String logValue() {
        return logValue;
    }
}

package com.hkbea.bcm.bff.access.service;

import com.hkbea.bcm.bff.access.model.SessionRecord;
import reactor.core.publisher.Mono;

public interface SessionService {
    Mono<SessionRecord> findBySid(String sid);

    Mono<SessionRecord> save(SessionRecord session);

    Mono<SessionRecord> rotateRefreshToken(
            SessionRecord session,
            String expectedRefreshTokenId,
            String nextRefreshTokenId
    );

    Mono<Void> expire(String sid);

    Mono<Void> replaceActiveSessionsForUser(String userId);
}

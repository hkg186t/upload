package com.hkbea.bcm.bff.access.token;

public enum TokenUse {
    ACCESS("access"),
    REFRESH("refresh");

    private final String claimValue;

    TokenUse(String claimValue) {
        this.claimValue = claimValue;
    }

    public String claimValue() {
        return claimValue;
    }

    public static TokenUse fromClaimValue(String value) {
        for (TokenUse tokenUse : values()) {
            if (tokenUse.claimValue.equals(value)) {
                return tokenUse;
            }
        }
        return null;
    }
}

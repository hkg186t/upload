package com.hkbea.bcm.bff.access.model;

public record TokenPair(
        String accessToken,
        String refreshToken,
        long expiresIn,
        long refreshExpiresIn,
        String tokenType
) {
    public static TokenPair bearer(String accessToken, String refreshToken, long expiresIn, long refreshExpiresIn) {
        return new TokenPair(accessToken, refreshToken, expiresIn, refreshExpiresIn, "Bearer");
    }
}

package com.hkbea.bcm.bff.access.model;

import java.util.List;

public record LoginCommand(
        String username,
        String password,
        String parentAccountId,
        String deviceId,
        String deviceOs,
        String appVersion,
        String locale,
        List<String> roles,
        List<String> scopes
) {
}

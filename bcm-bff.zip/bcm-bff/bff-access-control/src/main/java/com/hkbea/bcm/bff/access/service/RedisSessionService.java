package com.hkbea.bcm.bff.access.service;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.hkbea.bcm.bff.access.config.SessionStoreProperties;
import com.hkbea.bcm.bff.access.model.SessionRecord;
import com.hkbea.bcm.bff.shared.session.SessionState;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.data.redis.core.ReactiveStringRedisTemplate;
import org.springframework.data.redis.core.script.RedisScript;
import org.springframework.stereotype.Service;
import reactor.core.publisher.Mono;

import java.time.Duration;
import java.time.Instant;
import java.util.List;

@Service
@ConditionalOnProperty(prefix = "bff.session", name = "store", havingValue = "redis")
public class RedisSessionService implements SessionService {
    private static final RedisScript<Long> ROTATE_REFRESH_TOKEN_SCRIPT = RedisScript.of("""
            local session_json = redis.call('GET', KEYS[1])
            if not session_json then
              return 0
            end

            local session = cjson.decode(session_json)
            if session.userId ~= ARGV[1]
              or session.deviceId ~= ARGV[2]
              or tostring(session.sessionVersion) ~= ARGV[3]
              or session.state ~= 'ACTIVE' then
              return 0
            end

            if session.refreshTokenId ~= nil
              and session.refreshTokenId ~= cjson.null
              and session.refreshTokenId ~= ''
              and session.refreshTokenId ~= ARGV[4] then
              return 0
            end

            redis.call('PSETEX', KEYS[1], ARGV[6], ARGV[5])
            return 1
            """, Long.class);

    private final ReactiveStringRedisTemplate redisTemplate;
    private final ObjectMapper objectMapper;
    private final SessionStoreProperties properties;

    public RedisSessionService(
            ReactiveStringRedisTemplate redisTemplate,
            ObjectMapper objectMapper,
            SessionStoreProperties properties
    ) {
        this.redisTemplate = redisTemplate;
        this.objectMapper = objectMapper;
        this.properties = properties;
    }

    @Override
    public Mono<SessionRecord> findBySid(String sid) {
        return redisTemplate.opsForValue()
                .get(sessionKey(sid))
                .flatMap(this::decode);
    }

    @Override
    public Mono<SessionRecord> save(SessionRecord session) {
        return encode(session)
                .flatMap(json -> redisTemplate.opsForValue()
                        .set(sessionKey(session.sid()), json, sessionTtl())
                        .then(redisTemplate.opsForSet().add(userSessionsKey(session.userId()), session.sid()))
                        .then(redisTemplate.expire(userSessionsKey(session.userId()), sessionTtl()))
                        .thenReturn(session));
    }

    @Override
    public Mono<SessionRecord> rotateRefreshToken(
            SessionRecord session,
            String expectedRefreshTokenId,
            String nextRefreshTokenId
    ) {
        SessionRecord updated = withRefreshToken(session, nextRefreshTokenId);
        long ttlMillis = sessionTtl().toMillis();
        return encode(updated)
                .flatMap(json -> redisTemplate.execute(
                                ROTATE_REFRESH_TOKEN_SCRIPT,
                                List.of(sessionKey(session.sid())),
                                List.of(
                                        session.userId(),
                                        session.deviceId(),
                                        Integer.toString(session.sessionVersion()),
                                        expectedRefreshTokenId,
                                        json,
                                        Long.toString(ttlMillis)))
                        .next())
                .filter(result -> Long.valueOf(1L).equals(result))
                .flatMap(ignored -> redisTemplate.expire(userSessionsKey(session.userId()), sessionTtl())
                        .thenReturn(updated));
    }

    @Override
    public Mono<Void> expire(String sid) {
        return findBySid(sid)
                .flatMap(session -> save(withState(session, SessionState.LOGGED_OUT)))
                .then();
    }

    @Override
    public Mono<Void> replaceActiveSessionsForUser(String userId) {
        return redisTemplate.opsForSet()
                .members(userSessionsKey(userId))
                .flatMap(this::findBySid)
                .filter(session -> session.state() == SessionState.ACTIVE)
                .flatMap(session -> save(withState(session, SessionState.REPLACED_BY_NEW_LOGIN)))
                .then();
    }

    private Mono<String> encode(SessionRecord session) {
        return Mono.fromCallable(() -> objectMapper.writeValueAsString(session));
    }

    private Mono<SessionRecord> decode(String json) {
        return Mono.fromCallable(() -> objectMapper.readValue(json, SessionRecord.class));
    }

    private Duration sessionTtl() {
        return Duration.ofSeconds(properties.getTtlSeconds());
    }

    private String sessionKey(String sid) {
        return properties.getRedisKeyPrefix() + ":session:" + sid;
    }

    private String userSessionsKey(String userId) {
        return properties.getRedisKeyPrefix() + ":user-sessions:" + userId;
    }

    private static SessionRecord withState(SessionRecord current, SessionState state) {
        return new SessionRecord(
                current.sid(),
                current.userId(),
                current.customerId(),
                current.deviceId(),
                current.deviceOs(),
                current.roles(),
                current.scopes(),
                current.bcmSessionId(),
                state,
                current.sessionVersion(),
                current.refreshTokenId(),
                current.loginTime(),
                Instant.now()
        );
    }

    private static SessionRecord withRefreshToken(SessionRecord current, String refreshTokenId) {
        return new SessionRecord(
                current.sid(),
                current.userId(),
                current.customerId(),
                current.deviceId(),
                current.deviceOs(),
                current.roles(),
                current.scopes(),
                current.bcmSessionId(),
                current.state(),
                current.sessionVersion(),
                refreshTokenId,
                current.loginTime(),
                Instant.now()
        );
    }
}

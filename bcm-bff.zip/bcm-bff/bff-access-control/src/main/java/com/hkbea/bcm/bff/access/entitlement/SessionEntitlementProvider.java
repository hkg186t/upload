package com.hkbea.bcm.bff.access.entitlement;

import com.hkbea.bcm.bff.access.model.SessionRecord;
import reactor.core.publisher.Mono;

public class SessionEntitlementProvider implements EntitlementProvider {
    @Override
    public Mono<EntitlementContext> resolve(SessionRecord session) {
        return Mono.just(EntitlementContext.fromSession(session));
    }
}

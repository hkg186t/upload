package com.hkbea.bcm.bff.access.config;

import org.springframework.boot.context.properties.ConfigurationProperties;

@ConfigurationProperties(prefix = "bff.entitlement")
public class EntitlementProperties {
    private Provider provider = Provider.SESSION;
    private Iam iam = new Iam();

    public Provider getProvider() {
        return provider;
    }

    public void setProvider(Provider provider) {
        this.provider = provider == null ? Provider.SESSION : provider;
    }

    public Iam getIam() {
        return iam;
    }

    public void setIam(Iam iam) {
        this.iam = iam == null ? new Iam() : iam;
    }

    public enum Provider {
        SESSION,
        JWT,
        IAM,
        CASBIN
    }

    public static class Iam {
        private boolean mockEnabled;
        private long requestTimeoutMillis = 500;
        private boolean circuitBreakerEnabled = true;
        private int circuitBreakerFailureThreshold = 5;
        private long circuitBreakerOpenMillis = 30000;

        public boolean isMockEnabled() {
            return mockEnabled;
        }

        public void setMockEnabled(boolean mockEnabled) {
            this.mockEnabled = mockEnabled;
        }

        public long getRequestTimeoutMillis() {
            return requestTimeoutMillis;
        }

        public void setRequestTimeoutMillis(long requestTimeoutMillis) {
            this.requestTimeoutMillis = requestTimeoutMillis;
        }

        public boolean isCircuitBreakerEnabled() {
            return circuitBreakerEnabled;
        }

        public void setCircuitBreakerEnabled(boolean circuitBreakerEnabled) {
            this.circuitBreakerEnabled = circuitBreakerEnabled;
        }

        public int getCircuitBreakerFailureThreshold() {
            return circuitBreakerFailureThreshold;
        }

        public void setCircuitBreakerFailureThreshold(int circuitBreakerFailureThreshold) {
            this.circuitBreakerFailureThreshold = circuitBreakerFailureThreshold;
        }

        public long getCircuitBreakerOpenMillis() {
            return circuitBreakerOpenMillis;
        }

        public void setCircuitBreakerOpenMillis(long circuitBreakerOpenMillis) {
            this.circuitBreakerOpenMillis = circuitBreakerOpenMillis;
        }
    }
}

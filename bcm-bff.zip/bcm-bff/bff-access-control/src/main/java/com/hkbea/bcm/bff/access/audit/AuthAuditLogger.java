package com.hkbea.bcm.bff.access.audit;

import com.hkbea.bcm.bff.access.config.AuthProperties;
import com.hkbea.bcm.bff.access.model.LoginCommand;
import com.hkbea.bcm.bff.access.model.SessionRecord;
import com.hkbea.bcm.bff.access.token.JwtValidationException;
import com.hkbea.bcm.bff.access.token.TokenClaims;
import com.hkbea.bcm.bff.shared.api.BffException;
import com.hkbea.bcm.bff.shared.api.ErrorCode;
import io.micrometer.core.instrument.Counter;
import io.micrometer.core.instrument.MeterRegistry;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.ObjectProvider;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.HexFormat;

@Component
public class AuthAuditLogger {
    private static final Logger log = LoggerFactory.getLogger(AuthAuditLogger.class);
    private static final String METRIC_JWT_VALIDATION_FAILURES = "bcm.bff.auth.jwt.validation.failures";
    private static final String BEARER_PREFIX = "Bearer ";
    private static final String EVENT_ACCESS_TOKEN = "access_token";
    private static final String EVENT_REFRESH = "refresh";

    private final MeterRegistry meterRegistry;

    public AuthAuditLogger() {
        this((MeterRegistry) null);
    }

    public AuthAuditLogger(MeterRegistry meterRegistry) {
        this.meterRegistry = meterRegistry;
    }

    @Autowired
    public AuthAuditLogger(ObjectProvider<MeterRegistry> meterRegistryProvider) {
        this(meterRegistryProvider.getIfAvailable());
    }

    public void loginSuccess(
            AuthProperties.LoginProvider provider,
            LoginCommand command,
            SessionRecord session,
            long durationMillis
    ) {
        log.info("BCM_AUTH_ACCESS event=login outcome=success provider={} userHash={} customerHash={} sessionHash={} deviceHash={} deviceOs={} rolesCount={} scopesCount={} durationMs={} errorCode=none",
                provider,
                safeHash(session.userId()),
                safeHash(session.customerId()),
                safeHash(session.sid()),
                safeHash(session.deviceId()),
                safeValue(command.deviceOs()),
                session.roles().size(),
                session.scopes().size(),
                durationMillis);
    }

    public void loginFailure(AuthProperties.LoginProvider provider, LoginCommand command, Throwable error, long durationMillis) {
        log.warn("BCM_AUTH_ACCESS event=login outcome=error provider={} usernameHash={} parentAccountHash={} deviceHash={} deviceOs={} durationMs={} errorCode={}",
                provider,
                safeHash(command.username()),
                safeHash(command.parentAccountId()),
                safeHash(command.deviceId()),
                safeValue(command.deviceOs()),
                durationMillis,
                errorCode(error));
    }

    public void refreshSuccess(TokenClaims claims, SessionRecord session, long durationMillis) {
        log.info("BCM_AUTH_ACCESS event=refresh outcome=success userHash={} sessionHash={} deviceHash={} durationMs={} errorCode=none",
                safeHash(session.userId()),
                safeHash(claims.sid()),
                safeHash(session.deviceId()),
                durationMillis);
    }

    public void refreshFailure(String refreshToken, String deviceId, Throwable error, long durationMillis) {
        recordJwtValidationFailure(EVENT_REFRESH, error);
        log.warn("BCM_AUTH_ACCESS event=refresh outcome=error tokenHash={} deviceHash={} durationMs={} errorCode={} failureReason={}",
                safeHash(refreshToken),
                safeHash(deviceId),
                durationMillis,
                errorCode(error),
                failureReason(error));
    }

    public void accessTokenFailure(String authorizationHeader, Throwable error, long durationMillis) {
        recordJwtValidationFailure(EVENT_ACCESS_TOKEN, error);
        log.warn("BCM_AUTH_ACCESS event=access_token outcome=error tokenHash={} tokenPresent={} durationMs={} errorCode={} failureReason={}",
                safeHash(extractBearerTokenOrNull(authorizationHeader)),
                authorizationHeader != null && !authorizationHeader.isBlank(),
                durationMillis,
                errorCode(error),
                failureReason(error));
    }

    public void logoutSuccess(SessionRecord session, long durationMillis) {
        log.info("BCM_AUTH_ACCESS event=logout outcome=success userHash={} sessionHash={} deviceHash={} durationMs={} errorCode=none",
                safeHash(session.userId()),
                safeHash(session.sid()),
                safeHash(session.deviceId()),
                durationMillis);
    }

    public void logoutFailure(String authorizationHeader, Throwable error, long durationMillis) {
        log.warn("BCM_AUTH_ACCESS event=logout outcome=error tokenHash={} tokenPresent={} durationMs={} errorCode={} failureReason={}",
                safeHash(extractBearerTokenOrNull(authorizationHeader)),
                authorizationHeader != null && !authorizationHeader.isBlank(),
                durationMillis,
                errorCode(error),
                failureReason(error));
    }

    private static String errorCode(Throwable error) {
        if (error instanceof BffException bffException) {
            return bffException.errorCode().code();
        }
        return ErrorCode.INTERNAL_ERROR.code();
    }

    private static String failureReason(Throwable error) {
        if (error instanceof JwtValidationException jwtValidationException) {
            return jwtValidationException.failure().logValue();
        }
        return "none";
    }

    private void recordJwtValidationFailure(String event, Throwable error) {
        if (meterRegistry == null || !(error instanceof JwtValidationException jwtValidationException)) {
            return;
        }

        Counter.builder(METRIC_JWT_VALIDATION_FAILURES)
                .description("BCM BFF JWT validation failures")
                .tag("event", event)
                .tag("errorCode", errorCode(error))
                .tag("failureReason", jwtValidationException.failure().logValue())
                .register(meterRegistry)
                .increment();
    }

    private static String extractBearerTokenOrNull(String authorizationHeader) {
        if (authorizationHeader == null
                || !authorizationHeader.regionMatches(true, 0, BEARER_PREFIX, 0, BEARER_PREFIX.length())) {
            return null;
        }
        String token = authorizationHeader.substring(BEARER_PREFIX.length()).trim();
        return token.isBlank() ? null : token;
    }

    private static String safeValue(String value) {
        return value == null || value.isBlank() ? "none" : value;
    }

    private static String safeHash(String value) {
        if (value == null || value.isBlank()) {
            return "none";
        }
        try {
            byte[] digest = MessageDigest.getInstance("SHA-256")
                    .digest(value.getBytes(StandardCharsets.UTF_8));
            return HexFormat.of().formatHex(digest, 0, 8);
        } catch (Exception error) {
            throw new IllegalStateException("Failed to hash auth audit value", error);
        }
    }
}

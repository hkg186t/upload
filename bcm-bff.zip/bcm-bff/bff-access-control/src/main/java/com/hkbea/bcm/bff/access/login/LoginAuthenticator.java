package com.hkbea.bcm.bff.access.login;

import com.hkbea.bcm.bff.access.model.LoginCommand;
import reactor.core.publisher.Mono;

public interface LoginAuthenticator {
    Mono<AuthenticatedUser> authenticate(LoginCommand command);
}

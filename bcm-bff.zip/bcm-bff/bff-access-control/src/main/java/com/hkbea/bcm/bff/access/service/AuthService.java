package com.hkbea.bcm.bff.access.service;

import com.hkbea.bcm.bff.access.model.AuthResult;
import com.hkbea.bcm.bff.access.model.LoginCommand;
import com.hkbea.bcm.bff.access.model.RefreshCommand;
import com.hkbea.bcm.bff.access.model.SessionRecord;
import com.hkbea.bcm.bff.access.model.TokenPair;
import reactor.core.publisher.Mono;

public interface AuthService {
    Mono<AuthResult> login(LoginCommand command);

    Mono<TokenPair> refresh(RefreshCommand command);

    Mono<SessionRecord> validateAccessToken(String authorizationHeader);

    Mono<Void> logout(String authorizationHeader);

    Mono<Void> logout(SessionRecord session);
}

package com.hkbea.bcm.bff.access.entitlement;

import com.hkbea.bcm.bff.access.config.EntitlementProperties;
import com.hkbea.bcm.bff.access.config.EntitlementProperties.Provider;
import io.micrometer.core.instrument.MeterRegistry;
import org.springframework.beans.factory.ObjectProvider;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration(proxyBeanMethods = false)
public class EntitlementProviderConfiguration {
    @Bean
    public EntitlementProvider entitlementProvider(
            EntitlementProperties properties,
            ObjectProvider<IamEntitlementClient> iamClientProvider,
            ObjectProvider<MeterRegistry> meterRegistryProvider
    ) {
        Provider provider = properties.getProvider();
        return switch (provider) {
            case SESSION -> new SessionEntitlementProvider();
            case IAM -> new IamEntitlementProvider(
                    requiredIamClient(iamClientProvider),
                    properties.getIam(),
                    meterRegistryProvider.getIfAvailable());
            case JWT, CASBIN -> throw new IllegalStateException(
                    "BFF entitlement provider '%s' is reserved but not implemented yet".formatted(provider.name()));
        };
    }

    @Bean
    @ConditionalOnProperty(prefix = "bff.entitlement.iam", name = "mock-enabled", havingValue = "true")
    public IamEntitlementClient mockIamEntitlementClient() {
        return new MockIamEntitlementClient();
    }

    private static IamEntitlementClient requiredIamClient(ObjectProvider<IamEntitlementClient> iamClientProvider) {
        IamEntitlementClient client = iamClientProvider.getIfAvailable();
        if (client == null) {
            throw new IllegalStateException(
                    "BFF entitlement provider 'IAM' requires an IamEntitlementClient. "
                            + "Use bff.entitlement.iam.mock-enabled=true for local testing only.");
        }
        return client;
    }
}

package com.hkbea.bcm.bff.access.login;

import com.hkbea.bcm.bff.access.model.LoginCommand;
import com.hkbea.bcm.bff.shared.api.BffException;
import com.hkbea.bcm.bff.shared.api.ErrorCode;
import reactor.core.publisher.Mono;

public class DisabledLoginAuthenticator implements LoginAuthenticator {
    @Override
    public Mono<AuthenticatedUser> authenticate(LoginCommand command) {
        return Mono.error(new BffException(ErrorCode.FORBIDDEN,
                "Login provider is disabled for this environment"));
    }
}

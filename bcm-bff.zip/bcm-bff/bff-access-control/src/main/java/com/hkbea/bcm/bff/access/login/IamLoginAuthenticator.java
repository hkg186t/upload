package com.hkbea.bcm.bff.access.login;

import com.hkbea.bcm.bff.access.model.LoginCommand;
import reactor.core.publisher.Mono;

public class IamLoginAuthenticator implements LoginAuthenticator {
    private final IamLoginClient client;

    public IamLoginAuthenticator(IamLoginClient client) {
        this.client = client;
    }

    @Override
    public Mono<AuthenticatedUser> authenticate(LoginCommand command) {
        return client.authenticate(command);
    }
}

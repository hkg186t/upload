var WPErrorID={
		    ERRID_InvalidPIN                : 11,
			ERRID_InvalidAccountNumber      : 12,
			ERRID_InvalidRSAPublicKey       : 13,

			ERRID_InvalidSignatureLen       : 21,
			ERRID_EncryptionFailure         : 22,

			ERRID_NullRSAPublicKey          : 30,
			ERRID_NullData                  : 31,
			ERRID_NullKey                   : 32,
			ERRID_NullCipher                : 33,

			ERRID_InvalidHashType           : 40,
			ERRID_InvalidEnvelopeType       : 41,
			ERRID_InvalidMode               : 42,
			ERRID_InvalidHashMode           : 43,

			ERRID_InvalidIVLength           : 50,
			ERRID_InvalidKeyLength          : 51,

			ERRID_InvalidMsgLength          : 61,
			ERRID_ExceedMaxMsgLength        : 62,
			ERRID_NullIV                    : 63,
			ERRID_InvalidIV                 : 64,
			ERRID_InvalidKey                : 65,
			
			ERRID_InvalidMessageVersion     : 70,
			ERRID_InvalidTokenDataLength    : 71,
			ERRID_Invalid_WP_Hashmode       : 72,
			ERRID_BufferTooSmall            : 73,
			ERRID_NullPtr                   : 74,
			ERRID_InvalidMajorVersion       : 75,
			ERRID_InvalidMinorVersion       : 76,
			ERRID_InvalidMAC       			: 77
	}
define([
    "baseService",
    "framework/js/libs/webPinEncrypt/WPRSA",
    "framework/js/libs/webPinEncrypt/aes",
    "framework/js/libs/webPinEncrypt/sha1",
    "framework/js/libs/webPinEncrypt/sha256",
    "framework/js/libs/webPinEncrypt/tripledes",
    "framework/js/libs/webPinEncrypt/mode-ecb",
    "framework/js/libs/webPinEncrypt/pad-zeropadding-min",
    "framework/js/libs/webPinEncrypt/pad-nopadding-min",
    "framework/js/libs/webPinEncrypt/WPCommon",
    "framework/js/libs/webPinEncrypt/WPConstant",
    "framework/js/libs/webPinEncrypt/WPErrorID",
    "framework/js/libs/webPinEncrypt/sjcl",
    "framework/js/libs/webPinEncrypt/E2EE",
    "framework/js/libs/webPinEncrypt/ErrorCheck"
], function (BaseService) {
    "use strict";

    const baseService = BaseService.getInstance();

    function generateToken() {
        const min = 10000000 , max = 99999999;

        return (Math.floor(Math.random() * (max - min + 1)) + min).toString();
    }

    function trimAccountNo(accountNo, username) {
        if(accountNo.length > 12 && username !== null) {
            return accountNo.slice(accountNo.length - 12);
        }

        return accountNo;
    }

    return function (passwordList, username, cdcId, apiType, tfaRefNo) {
        if (!Array.isArray(passwordList)) {
            passwordList = [passwordList];
        }

        const password = passwordList;

        return baseService.fetch({
            url: "publicKey",
            version: "cz/v1",
            throttle: false,
            apiType: apiType
        }).then(function (data) {
            //eslint-disable-next-line no-undef
            const majorversion = WPConstant.WP_Major_Version_4,
            //eslint-disable-next-line no-undef
            minorversion = WPConstant.WP_Minor_Version_0,
            //eslint-disable-next-line no-undef
            encryptMode = WPConstant.AES_MODE_CBC,
            modulus512 = data.publicKeyDTO.modulus,
            exponent = data.publicKeyDTO.publicExponent,
            token = generateToken(),
            szMacData = tfaRefNo ? tfaRefNo : cdcId,
            //eslint-disable-next-line no-undef
            hashmode = WPConstant.HASH_MODE_NONE_LONG32,
            anpin = password[0],
            accountno = trimAccountNo(cdcId, username),
            rsaKeyIndicator = "CDC" + data.publicKeyDTO.publicKey,
            //eslint-disable-next-line no-undef
            pin = E2EE.WP_encryptAlphaPINAndGenerateMAC(majorversion, minorversion, hashmode, encryptMode, modulus512, exponent, anpin, accountno, token, szMacData);

            Object.freeze(pin);

            return [pin, rsaKeyIndicator, token];
        });
    };
});